﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.Common.Helpers;
using BBSI.ATS.Domain.Entities;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Data.Repositories.Interfaces;
using BBSI.ATS.Infrastructure.Integrations.Concrete;
using BBSI.ATS.Infrastructure.Integrations.Interfaces;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System.Reflection;
using static BBSI.ATS.Common.Constants;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class ApplicantInterviewControllerTests : IDisposable
{
    private readonly ApplicantInterviewsController _applicantInterviewController;

    private readonly IApplicantInterviewService _applicantInterviewService;
    private readonly IApplicationFormService _applicationFormService;
    private readonly AtsDbContext _dbContext;
    private readonly JobApplicationService _jobApplicationService;
    private readonly CurrentUserContext _currentUserContext;
    private readonly IJobPostService _jobPostService;
    private readonly IAtsBaseRepository _atsBaseRepository;
    private readonly IJobApplicationNoteService _jobApplicationNoteService;
    private readonly IUserService _userService;
    private readonly IMapper _mapper;
    private readonly Dictionary<string, string> _templates;
    private bool disposed;

    public ApplicantInterviewControllerTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        var jobApplicationRepository = new JobApplicationRepository(_dbContext, _currentUserContext);
        var applicationFormRepository = new ApplicationFormRepository(_dbContext, _currentUserContext);
        _atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var JobPostRepository = new JobPostRepository(_dbContext, _currentUserContext);
        var companyRepository = new CompanyRepository(_dbContext, _currentUserContext);
        var userRepository = new UserRepository(_dbContext, _currentUserContext);
        var jobApplicationNoteRepository = new JobApplicationNoteRepository(_dbContext, _currentUserContext);
        var applicantQuizRepository = new ApplicantQuizRepository(_dbContext, _currentUserContext);
        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        _mapper = mappingConfig.CreateMapper();
        var mockCosmosDbService = new Mock<ICosmosDbService>();

        _userService = new UserService(_atsBaseRepository, null!, userRepository, _currentUserContext);
        _jobApplicationNoteService = new JobApplicationNoteService(_atsBaseRepository, _mapper, jobApplicationRepository,
                                    _currentUserContext, jobApplicationNoteRepository, _userService, mockCosmosDbService.Object);

        var mockLogger = new Mock<ILogger<JobApplicationService>>();

        var formFieldComparer = new ApplicationFormFieldComparer();
        var applicationFormComparer = new ApplicationFormComparer(formFieldComparer);
        _applicationFormService = new ApplicationFormService(applicationFormRepository, _mapper, _currentUserContext, mockCosmosDbService.Object, applicationFormComparer);

        var companyService = new CompanyService(companyRepository, _userService, null!, _mapper, null!);
        var appConfig = new AppConfig();
        _jobPostService = new JobPostService(JobPostRepository, _mapper, _applicationFormService, _currentUserContext,
                                                mockCosmosDbService.Object, applicantQuizRepository, companyService, appConfig);

        var metaDataRepository = new MetaDataRepository(_dbContext, _currentUserContext);
        var metadataService = new MetaDataService(metaDataRepository, _mapper);

        var mockConfig = new Mock<IOptions<EmailTemplateConfig>>();
        var mockLoggerEmailClient = new Mock<ILogger<EmailClient>>();
        var emailConfig = new SendGridEmailConfig();
        emailConfig.ApiKey = "testkey";
        emailConfig.SenderEmail = "ats-no-reply@mybbsi.com";
        var emailClient = new EmailClient(emailConfig, mockLoggerEmailClient.Object);
        var notificationTemplates = ResourceReader.ReadEmbeddedResource(Assembly.LoadFrom(Assembly.GetExecutingAssembly().Location.Replace(Assembly.GetExecutingAssembly().Location.Split("\\").Last(), string.Empty) + "BBSI.ATS.Common.dll"), $"BBSI.ATS.Common.NotificationTemplates");
        _templates = notificationTemplates.ToDictionary(template => Path.GetFileNameWithoutExtension(template.Key.Replace($"BBSI.ATS.Common.NotificationTemplates.", string.Empty)), template => template.Value);
        _jobApplicationService = new JobApplicationService(jobApplicationRepository, _mapper, _applicationFormService, null!, null!, _jobApplicationNoteService, metadataService, mockLogger.Object, emailClient, mockConfig.Object, null!, null!, _currentUserContext, _userService, mockCosmosDbService.Object, applicantQuizRepository);

        var applicantInterviewComparer = new ApplicantInterviewComparer();
        _applicantInterviewService = new ApplicantInterviewService(_atsBaseRepository, _mapper, jobApplicationRepository, null!,
                                        _jobApplicationService, _jobApplicationNoteService, emailClient, _templates,
                                        _currentUserContext, _userService, applicantInterviewComparer, metadataService, mockCosmosDbService.Object);
        _applicantInterviewController = new ApplicantInterviewsController(_applicantInterviewService);
    }

    [Fact]
    public async Task ShouldCancelApplicantInterview()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewId = await CreateApplicantInterview();
        Assert.True(applicantInterviewId > 0);

        var applicantInterview = await _applicantInterviewController.GetById(applicantInterviewId);
        var applicantInterviewResult = Assert.IsType<OkObjectResult>(applicantInterview.Result);
        Assert.NotNull(applicantInterviewResult.Value);
        ApplicantInterviewDto applicantInterviewResultValue = (ApplicantInterviewDto)applicantInterviewResult.Value;
        Assert.NotNull(applicantInterviewResultValue);

        var cancelDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, Note = "Test cancel note", SendEmail = false, JobApplicationId = jobApplicationId, Version = applicantInterviewResultValue.Version };
        var result = await _applicantInterviewController.CancelAsync(cancelDto);
        Assert.IsType<OkObjectResult>(result);

        var applicantInterviewDetails = await _applicantInterviewService.GetApplicantInterviewDetailsByIdAsync(applicantInterviewId);
        Assert.NotNull(applicantInterview);
        Assert.Equal((long)InterviewStatus.InterviewCancelled, applicantInterviewDetails.StatusId);
    }

    [Fact]
    public async Task ShouldCancelInterviewAndNotifyApplicant()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (int)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Now.AddDays(2).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.UtcNow.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.UtcNow.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId = _currentUserContext.UserId,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (int)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = true,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty,
        };

        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var applicantInterview = await _applicantInterviewController.GetById(applicantInterviewId);
        var applicantInterviewResult = Assert.IsType<OkObjectResult>(applicantInterview.Result);
        Assert.NotNull(applicantInterviewResult.Value);
        ApplicantInterviewDto applicantInterviewResultValue = (ApplicantInterviewDto)applicantInterviewResult.Value;
        Assert.NotNull(applicantInterviewResultValue);

        applicantInterviewDto.Id = applicantInterviewId;
        applicantInterviewDto.StatusId = (int)InterviewStatus.InterviewCancelled;
        applicantInterviewDto.Version= applicantInterviewResultValue.Version;

        var updateResult = await _applicantInterviewController.UpdateAsync(applicantInterviewDto);
        Assert.IsType<OkResult>(updateResult);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhileNoteAddingBeforeInterview()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewId = await CreateApplicantInterview();
        Assert.True(applicantInterviewId > 0);

        var cancelDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, Note = "Test complete note", SendEmail = false, JobApplicationId = jobApplicationId };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantInterviewController.CompleteAsync(cancelDto));
        Assert.Equal(JobApplicationNoteValidation.JobApplicationNoteUpdateInvalid, exception.Message);
    }

    [Fact]
    public async Task ShouldGetAllInterviewsByApplicant()
    {
        var jobApplicationId = await CreateJobApplication();
        var StartDateTime = DateTime.Now;
        var applicantInterviewDtos = new List<ApplicantInterviewDto>
            {
                new ApplicantInterviewDto
                {
                    JobApplicationId = jobApplicationId,
                    InterviewTypeId = (long)InterviewType.Phone,
                    InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(1).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
                    StartDateTime = StartDateTime.AddMinutes(30).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
                    EndDateTime = StartDateTime.AddMinutes(40).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
                    Interviewers =
                    [
                         new()
                         {
                             InterviewerId = 1,
                         }
                    ],
                TimeZone = "PST",
                StartTime=string.Empty,
                EndTime=string.Empty
                },
                new ApplicantInterviewDto
                {
                    Id = 0,
                    JobApplicationId = jobApplicationId,
                    InterviewTypeId = (long)InterviewType.Phone,
                    InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(3).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
                    StartDateTime = StartDateTime.AddMinutes(50).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
                    EndDateTime = StartDateTime.AddMinutes(55).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
                    Interviewers =
                    [
                         new()
                         {
                             InterviewerId = 1,
                         }

                    ],
                TimeZone = "PST",
                StartTime = string.Empty,
                EndTime = string.Empty
                }
            };

        for (int i = 0; i < applicantInterviewDtos.Count; i++)
        {
            var applicantInterviewDto = applicantInterviewDtos[i];
            var applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
            applicantInterviewDto.Id = applicantInterviewId;
            Assert.True(applicantInterviewId > 0);
        }

        var applicantInterviewListResult = await _applicantInterviewController.GetAllAsync(jobApplicationId);
        Assert.IsType<ActionResult<IEnumerable<ApplicantInterviewListDto>>>(applicantInterviewListResult);
        var okResult = Assert.IsType<OkObjectResult>(applicantInterviewListResult.Result);
        var applicantInterviews = Assert.IsAssignableFrom<IEnumerable<ApplicantInterviewListDto>>(okResult.Value);
        Assert.NotEmpty(applicantInterviews);

        for (int i = 0; i < applicantInterviewDtos.Count; i++)
        {
            var expected = applicantInterviewDtos[i];

            var actual = applicantInterviews.ToList().Find(item => item.Id == expected.Id);
            Assert.Equal(expected.InterviewDate, actual.InterviewDate);
            Assert.Equal(expected.StartDateTime, actual.StartTime);
            Assert.Equal(expected.EndDateTime, actual.EndTime);
        }
    }

    [Fact]
    public async Task ShouldUpdateApplicantInterview()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.AddDays(55).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            EndDateTime = DateTime.Now.AddDays(55).AddMinutes(10).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };
        long id = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(id > 0);

        var getInterviewAfterSave = await _applicantInterviewController.GetById(id);
        Assert.NotNull(getInterviewAfterSave.Result);
        var savedInterviewResult = Assert.IsType<OkObjectResult>(getInterviewAfterSave.Result);
        Assert.NotNull(savedInterviewResult.Value);
        ApplicantInterviewDto savedInterviewFromDB = (ApplicantInterviewDto)savedInterviewResult.Value;
        Assert.NotNull(savedInterviewFromDB);

        var UpdateApplicantInterviewDto = new ApplicantInterviewDto
        {
            Id = savedInterviewFromDB.Id,
            JobApplicationId = savedInterviewFromDB.JobApplicationId,
            InterviewTypeId = (long)InterviewType.Video,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(1).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.AddDays(60).AddMinutes(10).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            EndDateTime = DateTime.Now.AddDays(60).AddMinutes(40).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId =1,
                 }
            ],
            StatusId = (long)InterviewStatus.InterviewNoShow,
            MeetingLink = "test",
            WorksiteLocationId = null,
            LocationTypeId = (long)LocationType.CustomLocation,
            Location = "Custom location",
            Address1 = "Test address1",
            Address2 = "Test address1",
            City = "Test city",
            StateId = 1,
            ZipCode = "12345",
            IsEmailSent = true,
            Version= savedInterviewFromDB.Version
        };
        await _applicantInterviewController.UpdateAsync(UpdateApplicantInterviewDto);
        var afterUpdateGetInterview = await _applicantInterviewController.GetById(savedInterviewFromDB.Id);
        Assert.NotNull(afterUpdateGetInterview.Result);
        var afterUpdateGetInterviewResult = Assert.IsType<OkObjectResult>(afterUpdateGetInterview.Result);
        Assert.NotNull(afterUpdateGetInterviewResult.Value);
        ApplicantInterviewDto afterUpdateformFromDB = (ApplicantInterviewDto)afterUpdateGetInterviewResult.Value;
        Assert.NotNull(afterUpdateformFromDB);
        Assert.True(afterUpdateformFromDB?.Interviewers?.Count > 0);
        Assert.True(afterUpdateformFromDB.InterviewTypeId == UpdateApplicantInterviewDto.InterviewTypeId);
        Assert.True(afterUpdateformFromDB.InterviewDate == UpdateApplicantInterviewDto.InterviewDate);
        Assert.True(afterUpdateformFromDB.StatusId == UpdateApplicantInterviewDto.StatusId);
        Assert.True(afterUpdateformFromDB.StartDateTime == UpdateApplicantInterviewDto.StartDateTime);
        Assert.True(afterUpdateformFromDB.EndDateTime == UpdateApplicantInterviewDto.EndDateTime);
        Assert.True(afterUpdateformFromDB.Interviewers.First().InterviewerId == UpdateApplicantInterviewDto.Interviewers.First().InterviewerId);
        Assert.True(afterUpdateformFromDB.WorksiteLocationId == UpdateApplicantInterviewDto.WorksiteLocationId);
        Assert.True(afterUpdateformFromDB.LocationTypeId == UpdateApplicantInterviewDto.LocationTypeId);
        Assert.True(afterUpdateformFromDB.Location == UpdateApplicantInterviewDto.Location);
        Assert.True(afterUpdateformFromDB.Address1 == UpdateApplicantInterviewDto.Address1);
        Assert.True(afterUpdateformFromDB.Address2 == UpdateApplicantInterviewDto.Address2);
        Assert.True(afterUpdateformFromDB.City == UpdateApplicantInterviewDto.City);
        Assert.True(afterUpdateformFromDB.StateId == UpdateApplicantInterviewDto.StateId);
        Assert.True(afterUpdateformFromDB.ZipCode == UpdateApplicantInterviewDto.ZipCode);
    }

    [Fact]
    public async Task ShouldFailUpdateApplicantInterview()
    {
        var jobApplicationId = await CreateJobApplication();
        long applicantInterviewId = 0;
        var StartDateTime = DateTime.Now;
        var applicantInterviewDtos = new List<ApplicantInterviewDto>
        {
            new ApplicantInterviewDto
            {
                JobApplicationId = jobApplicationId,
                InterviewTypeId = (long)InterviewType.Phone,
                InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(2).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
                StartDateTime = StartDateTime.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
                EndDateTime = StartDateTime.AddMinutes(40).ToString(ApplicantInterviewFields.TimeFormat),
                Interviewers =
                [
                     new()
                     {
                         InterviewerId = 1,
                     }
                ],
                TimeZone = "PST",
                StartTime=string.Empty,
                EndTime=string.Empty
            },
            new ApplicantInterviewDto
            {
                JobApplicationId = jobApplicationId,
                InterviewTypeId = (long)InterviewType.Phone,
                InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(2).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
                StartDateTime = StartDateTime.AddMinutes(50).ToString(ApplicantInterviewFields.TimeFormat),
                EndDateTime = StartDateTime.AddMinutes(55).ToString(ApplicantInterviewFields.TimeFormat),
                Interviewers =
                [
                     new()
                     {
                         InterviewerId = 1,
                     }
                ],
                TimeZone = "PST",
                StartTime = string.Empty,
                EndTime = string.Empty
            }
        };

        for (int i = 0; i < applicantInterviewDtos.Count; i++)
        {
            var applicantInterviewDto = applicantInterviewDtos[i];
            applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
            Assert.True(applicantInterviewId > 0);
        }

        var applicantInterview = await _applicantInterviewController.GetById(applicantInterviewId);
        var applicantInterviewResult = Assert.IsType<OkObjectResult>(applicantInterview.Result);
        Assert.NotNull(applicantInterviewResult.Value);
        ApplicantInterviewDto applicantInterviewResultValue = (ApplicantInterviewDto)applicantInterviewResult.Value;
        Assert.NotNull(applicantInterviewResultValue);

        var UpdateApplicantInterviewDto = new ApplicantInterviewDto
        {
            Id = applicantInterviewId,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Video,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(2).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = StartDateTime.AddMinutes(31).ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = StartDateTime.AddMinutes(40).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId = 6,
             }
            ],
            StatusId = (long)InterviewStatus.InterviewNoShow,
            MeetingLink = "test",
            WorksiteLocationId = null,
            LocationTypeId = (long)LocationType.CustomLocation,
            Location = "Custom locaton",
            Address1 = "Test address1",
            Address2 = "Test address1",
            City = "Test city",
            StateId = 1,
            ZipCode = "12345",
            IsEmailSent = true,
            TimeZone = "PST",
            Version= applicantInterviewResultValue.Version
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _applicantInterviewController.UpdateAsync(UpdateApplicantInterviewDto));
        exception.Message.Contains(string.Format(ApplicantInterviewValidation.InterviewTimeValidationErrorMessage, "TestFirstName"));
    }

    [Fact]
    public async Task ShouldCreateApplicantInterview()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(5).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty,
        };
        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var jobApplicationStatusHistories = await _atsBaseRepository.GetListAsync<JobApplicationStatusHistory>
                                                                     (history => history.JobApplicationId == jobApplicationId);

        Assert.NotNull(jobApplicationStatusHistories);
        Assert.Contains(jobApplicationStatusHistories, result => result.ToStatusId == (long)JobApplicationStatuses.InterviewScheduled
                                                            && !result.IsManualUpdate);
    }

    [Fact]
    public async Task ShouldFailApplicantInterviewWhenEndDateTimeIsLessThanStartDateTime()
    {
        var jobApplicationId = await CreateJobApplication();

        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(-30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =3,
             }
            ],
            TimeZone = "PST"
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateApplicantInterviewDto(applicantInterviewDto));
        Assert.Equal(ApplicantInterviewValidation.InterviewTimeValidationErrorMessage, exception.Message);
    }

    [Fact]
    public async Task ShouldFailApplicantInterviewWhenInvalidStartDateTimeAndEndDateTime()
    {
        var jobApplicationId = await CreateJobApplication();

        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = "1:0 p",
            EndDateTime = "1:0 p",
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            TimeZone = "PST"
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateApplicantInterviewDto(applicantInterviewDto));
        Assert.Contains(string.Format(ApplicantInterviewValidation.InvalidInterviewTimeFormatErrorMessage, ApplicantInterviewFields.StartTime), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWithInvalidJobApplicationId()
    {
        await CreateJobApplication();

        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = long.MaxValue,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(-30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            TimeZone = "PST"
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateApplicantInterviewDto(applicantInterviewDto));
        Assert.Contains(ApplicantInterviewValidation.InvalidJobApplicationId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenWhenApplicantInterviewDateAndTimeIsConflict()
    {
        var jobApplicationId = await CreateJobApplication();

        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(7).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };

        long applicantInterviewId1 = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId1 > 0);

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateApplicantInterviewDto(applicantInterviewDto));
        Assert.Contains(string.Format(ApplicantInterviewValidation.InterviewDatAndTimeConflict, "John Doe", "johndoe@gmail.com"), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenApplicantInterviewDateAndTimeIsOverlapped()
    {
        var jobApplicationId = await CreateJobApplication();

        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(7).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.AddDays(51).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            EndDateTime = DateTime.Now.AddDays(51).AddMinutes(30).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };

        long applicantInterviewId1 = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId1 > 0);

        var applicantInterviewDto1 = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(7).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.AddMinutes(-60).ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(70).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            TimeZone = "PST"
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateApplicantInterviewDto(applicantInterviewDto1));
        Assert.Contains(string.Format(ApplicantInterviewValidation.InterviewDatAndTimeConflict, "John Doe", "johndoe@gmail.com"), exception.Message);
    }

    [Fact]
    public async Task ShouldUpdateApplicantInterviewStatusToCompleted()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.AddMinutes(-60).ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(-55).ToString("hh:mm tt"),
            Interviewers =
            [
                 new()
                 {
                     Id = 0,
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };
        long id = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(id > 0);

        //Todo : After UTC Implemented

        //var applicantInterviewNoteDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = id, Note = "Test Complete note", SendEmail = false, JobApplicationId = jobApplicationId };
        //var result = await _applicantInterviewController.CompleteAsync(applicantInterviewNoteDto);
        //Assert.IsType<OkObjectResult>(result);

        //var applicantInterview = await _applicantInterviewService.GetApplicantInterviewDetailsByIdAsync(id);
        //Assert.NotNull(applicantInterview);
        //Assert.Equal(applicantInterview.StatusId, (long)InterviewStatus.InterviewCompleted);
    }

    //[Fact]
    //public async Task ShouldUpdateNotesInApplicantInterview()
    //{
    //    var jobApplicationId = await CreateJobApplication();

    //    var applicantInterviewDto = new ApplicantInterviewDto
    //    {
    //        Id = 0,
    //        JobApplicationId = jobApplicationId,
    //        InterviewTypeId = (long)InterviewType.Phone,
    //        InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
    //        StartDateTime = DateTime.Now.AddMinutes(-400).ToString("hh:mm tt"),
    //        EndDateTime = DateTime.Now.AddMinutes(-350).ToString("hh:mm tt"),
    //        Interviewers =
    //        [
    //             new()
    //             {
    //                 Id = 0,
    //                 InterviewerId =2,
    //             }
    //        ],
    //        MeetingLink = null,
    //        WorksiteLocationId = 1,
    //        LocationTypeId = (long)LocationType.WorksiteLocation,
    //        IsEmailSent = false,
    //    };
    //    long id = await CreateApplicantInterviewDto(applicantInterviewDto);
    //    Assert.True(id > 0);

    //    var applicantInterviewDto1 = new ApplicantInterviewNotesDto { ApplicantInterviewId = id, Note = "Test Update note", SendEmail = false, JobApplicationId = jobApplicationId, Rating = 3 };
    //    var result = await _applicantInterviewController.CompleteAsync(applicantInterviewDto1);
    //    var applicantInterviewResult = Assert.IsType<OkObjectResult>(result);
    //    var applicantInterviewResultValue = Assert.IsType<CreatedResponse>(applicantInterviewResult.Value);

    //    var applicantInterviewNote = await _jobApplicationNoteService.GetByIdAsync(applicantInterviewResultValue.Id);
    //    Assert.NotNull(applicantInterviewNote);
    //    var applicantInterviewNoteDto = new ApplicantInterviewNotesDto
    //    {
    //        Id = applicantInterviewNote.Id,
    //        ApplicantInterviewId = applicantInterviewNote.ApplicantInterviewId,
    //        Note = "Updating Note",
    //        Rating = applicantInterviewNote.Rating,
    //        JobApplicationId = applicantInterviewNote.JobApplicationId,
    //        ApplicantInterviewStatusId = applicantInterviewNote.ApplicantInterviewStatusId,
    //    };

    //    var applicantInterviewUpdate = await _applicantInterviewController.UpdateNoteAsync(applicantInterviewNoteDto);
    //    var applicantInterviewUpdateResult = Assert.IsType<OkResult>(applicantInterviewUpdate);

    //    var applicantInterviewNoteUpdated = await _jobApplicationNoteService.GetByIdAsync(applicantInterviewResultValue.Id);
    //    Assert.NotNull(applicantInterviewNoteUpdated);
    //    Assert.Equal(applicantInterviewNoteDto.Note, applicantInterviewNoteUpdated.Note);
    //}

    [Fact]
    public async Task ShouldThrowExceptionForInValidApplicantInterviewId()
    {
        var applicantInterviewNoteDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = 0, Note = "Test note", SendEmail = false, JobApplicationId = 1 };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantInterviewController.CompleteAsync(applicantInterviewNoteDto));
        Assert.Equal(JobApplicationNoteValidation.InvalidApplicantInterviewId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForApplicantInterviewRecordNotFound()
    {
        var applicantInterviewNoteDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = 1, Note = "Test note", SendEmail = false, JobApplicationId = 1 };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantInterviewController.CompleteAsync(applicantInterviewNoteDto));
        Assert.Equal(JobApplicationNoteValidation.InvalidApplicantInterviewId, exception.Message);
    }

    [Fact]
    public async Task ShouldFailUpdateWhenInvalidRecord()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantInterviewService.GetApplicantInterviewDetailsByIdAsync(long.MaxValue));
        Assert.Equal(ApplicantInterviewValidation.InvalidApplicantInterviewId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInvalidJobApplicationId()
    {
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(7).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =3,
             }
            ],
            TimeZone = "PST"
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantInterviewService.UpdateApplicantInterviewAsync(applicantInterviewDto));
        Assert.Equal(InvalidRecordId, exception.Message);
    }

    [Fact]
    public async Task ShouldFailForApplicantInterviewRecordNotFound()
    {
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = long.MaxValue,
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(7).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =5,
             }
            ],
            TimeZone = "PST"
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantInterviewService.UpdateApplicantInterviewAsync(applicantInterviewDto));
        Assert.Equal(ApplicantInterviewValidation.InvalidApplicantInterviewId, exception.Message);
    }

    [Fact]
    public async Task ShouldFailDynamicStatusTransitionWhenInvalidFromStatusIdGiven()
    {
        var jobApplicationId = await CreateJobApplication();

        var jobApplication = await _jobApplicationService.GetDetailsByIdAsync(jobApplicationId);

        var jobApplicationManualStatusUpdateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = jobApplicationId,
            StatusId = (long)JobApplicationStatuses.NotSelected,
            Note = "Not Selected",
            SendEmail = true,
            Version= jobApplication!.Version
        };

        await _jobApplicationService.UpdateStatusAsync(jobApplicationManualStatusUpdateDto);

        var result = await _jobApplicationService.GetProgressBarStatusListAsync(jobApplicationId);
        Assert.NotNull(result);
        Assert.True(result.Count > 0);
        Assert.Contains(result, result => result.StatusId == (long)JobApplicationStatuses.NotSelected);

        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(18).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId = 1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty,
        };

        await CreateApplicantInterviewDto(applicantInterviewDto);

        var jobApplicationStatusHistories = await _atsBaseRepository.GetListAsync<JobApplicationStatusHistory>
                                                                           (history => history.JobApplicationId == jobApplicationId);

        Assert.NotNull(jobApplicationStatusHistories);
        Assert.Contains(jobApplicationStatusHistories, result => result.ToStatusId == (long)JobApplicationStatuses.InterviewScheduled
                                                            && result.IsManualUpdate);
    }

    [Fact]
    public async Task ShouldSendEmailToApplicantWhenInterviewScheduled()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(3).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = true,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };
        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var emailServiceMock = new Mock<IEmailClient>();
        const bool expectedResult = true;
        emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<InterviewNotificationDto>()))
                       .ReturnsAsync(expectedResult);

        var templateData = GetInterviewMockObject();
        var emailMessage = GetMockEmail();
        var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);
        Assert.Equal(expectedResult, isEmailSent);
    }

    [Fact]
    public async Task ShouldSendEmailToInterviewerAndApplicantWhenInterviewIsUpdated()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(111).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = true,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };

        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var emailServiceMock = new Mock<IEmailClient>();
        var expectedResult = true;

        emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<InterviewNotificationDto>()))
                       .ReturnsAsync(expectedResult);

        var templateData = new InterviewNotificationDto
        {
            ApplicantFirstName = "Test Applicant",
            JobPostTitle = "Software Engineer",
            InterviewType = "In-Person",
            InterviewDate = "15th August 2024",
            StartTime = "10:00 AM - 10:45 AM",
            Location = "Company HQ, Office 1",
            CompanyName = "MyBBSI"
        };

        var emailMessage = new List<EmailDto>
        {
            new() { ToEmail = "applicant@example.com", ToName = "Test Applicant", CCEMail = "interviewer1@example.com" }
        };

        var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);

        // Assert
        Assert.Equal(expectedResult, isEmailSent);
        Assert.Single(emailMessage);
        Assert.Contains(emailMessage, e => e.ToEmail == "applicant@example.com" && e.ToName == "Test Applicant" && e.CCEMail == "interviewer1@example.com");
    }

    [Fact]
    public async Task ShouldSendEmailToInterviewersWhenInterviewScheduled()
    {
        // Arrange
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(10).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId = 1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = true,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };
        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        // Act
        var emailServiceMock = new Mock<IEmailClient>();
        var expectedResult = true;

        emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<InterviewNotificationDto>()))
                       .ReturnsAsync(expectedResult);

        var templateData = GetInterviewMockObject();
        var emailMessage = new List<EmailDto>
        {
            new EmailDto { ToEmail = "interviewer1@example.com", ToName = "Interviewer One" },
        };

        var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);

        // Assert
        Assert.Equal(expectedResult, isEmailSent);
        Assert.True(emailMessage.Count == 1);
        Assert.Contains(emailMessage, e => e.ToEmail == "interviewer1@example.com" && e.ToName == "Interviewer One");
    }

    //TODO need to handle time zone issue
    //[Fact]
    //public async Task ShouldSendEmailToApplicantWhenInterviewScheduleUpdated()
    //{
    //    var jobApplicationId = await CreateJobApplication();
    //    var applicantInterviewDto = new ApplicantInterviewDto
    //    {
    //        Id = 0,
    //        JobApplicationId = jobApplicationId,
    //        InterviewTypeId = (long)InterviewType.Phone,
    //        InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
    //        StartDateTime = DateTime.Now.ToString("hh:mm tt"),
    //        EndDateTime = DateTime.Now.AddMinutes(20).ToString("hh:mm tt"),
    //        Interviewers =
    //        [
    //             new()
    //             {
    //                 Id = 0,
    //                 InterviewerId =2,
    //             }
    //        ],
    //        MeetingLink = null,
    //        WorksiteLocationId = 1,
    //        LocationTypeId = (long)LocationType.WorksiteLocation,
    //        IsEmailSent = false,
    //    };
    //    long id = await CreateApplicantInterviewDto(applicantInterviewDto);

    //    Assert.True(id > 0);

    //    var getInterviewAfterSave = await _applicantInterviewController.GetById(id);
    //    Assert.NotNull(getInterviewAfterSave.Result);
    //    var savedInterviewResult = Assert.IsType<OkObjectResult>(getInterviewAfterSave.Result);
    //    Assert.NotNull(savedInterviewResult.Value);
    //    ApplicantInterviewDto savedInterviewFromDB = (ApplicantInterviewDto)savedInterviewResult.Value;
    //    Assert.NotNull(savedInterviewFromDB);

    //    var UpdateApplicantInterviewDto = new ApplicantInterviewDto
    //    {
    //        Id = savedInterviewFromDB.Id,
    //        JobApplicationId = savedInterviewFromDB.JobApplicationId,
    //        InterviewTypeId = (long)InterviewType.Video,
    //        InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(1).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
    //        StartDateTime = DateTime.Now.AddMinutes(10).ToString(ApplicantInterviewFields.TimeFormat),
    //        EndDateTime = DateTime.Now.AddMinutes(40).ToString(ApplicantInterviewFields.TimeFormat),
    //        Interviewers =
    //        [
    //             new()
    //             {
    //                 InterviewerId =4,
    //             }
    //        ],
    //        StatusId = (long)InterviewStatus.InterviewNoShow,
    //        MeetingLink = "test",
    //        WorksiteLocationId = null,
    //        LocationTypeId = (long)LocationType.CustomLocation,
    //        Location = "Custom locaton",
    //        Address1 = "Test address1",
    //        Address2 = "Test address1",
    //        City = "Test city",
    //        StateId = 1,
    //        ZipCode = "12345",
    //        IsEmailSent = true,
    //    };
    //    await _applicantInterviewController.UpdateAsync(UpdateApplicantInterviewDto);
    //    var afterUpdateGetInterview = await _applicantInterviewController.GetById(savedInterviewFromDB.Id);
    //    Assert.NotNull(afterUpdateGetInterview.Result);
    //    var afterUpdateGetInterviewResult = Assert.IsType<OkObjectResult>(afterUpdateGetInterview.Result);
    //    Assert.NotNull(afterUpdateGetInterviewResult.Value);
    //    ApplicantInterviewDto afterUpdateformFromDB = (ApplicantInterviewDto)afterUpdateGetInterviewResult.Value;
    //    Assert.NotNull(afterUpdateformFromDB);
    //    Assert.True(afterUpdateformFromDB?.Interviewers?.Count() > 0);
    //    Assert.True(afterUpdateformFromDB.InterviewTypeId == UpdateApplicantInterviewDto.InterviewTypeId);
    //    Assert.True(afterUpdateformFromDB.InterviewDate == UpdateApplicantInterviewDto.InterviewDate);
    //    Assert.True(afterUpdateformFromDB.StatusId == UpdateApplicantInterviewDto.StatusId);
    //    Assert.True(afterUpdateformFromDB.StartDateTime == UpdateApplicantInterviewDto.StartDateTime);
    //    Assert.True(afterUpdateformFromDB.EndDateTime == UpdateApplicantInterviewDto.EndDateTime);
    //    Assert.True(afterUpdateformFromDB.Interviewers.First().InterviewerId == UpdateApplicantInterviewDto.Interviewers.First().InterviewerId);
    //    Assert.True(afterUpdateformFromDB.WorksiteLocationId == UpdateApplicantInterviewDto.WorksiteLocationId);
    //    Assert.True(afterUpdateformFromDB.LocationTypeId == UpdateApplicantInterviewDto.LocationTypeId);
    //    Assert.True(afterUpdateformFromDB.Location == UpdateApplicantInterviewDto.Location);
    //    Assert.True(afterUpdateformFromDB.Address1 == UpdateApplicantInterviewDto.Address1);
    //    Assert.True(afterUpdateformFromDB.Address2 == UpdateApplicantInterviewDto.Address2);
    //    Assert.True(afterUpdateformFromDB.City == UpdateApplicantInterviewDto.City);
    //    Assert.True(afterUpdateformFromDB.StateId == UpdateApplicantInterviewDto.StateId);
    //    Assert.True(afterUpdateformFromDB.ZipCode == UpdateApplicantInterviewDto.ZipCode);

    //    var emailServiceMock = new Mock<IEmailClient>();
    //    var expectedResult = true;
    //    var result = emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<InterviewNotificationDto>()))
    //                   .ReturnsAsync(expectedResult);

    //    var templateData = GetInterviewMockObject();
    //    var emailMessage = GetMockEmail();
    //    var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);
    //    Assert.Equal(expectedResult, isEmailSent);
    //}

    //TODO need to handle time zone issue
    //[Fact]
    //public async Task ShouldNotSendEmailToApplicantWhenOnlyInterviewersAreUpdated()
    //{
    //    var jobApplicationId = await CreateJobApplication();
    //    var applicantInterviewDto = new ApplicantInterviewDto
    //    {
    //        Id = 0,
    //        JobApplicationId = jobApplicationId,
    //        InterviewTypeId = (long)InterviewType.Phone,
    //        InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
    //        StartDateTime = DateTime.Now.ToString("hh:mm tt"),
    //        EndDateTime = DateTime.Now.AddMinutes(10).ToString("hh:mm tt"),
    //        Interviewers =
    //        [
    //             new()
    //             {
    //                 Id = 0,
    //                 InterviewerId =3,
    //             }
    //        ],
    //        MeetingLink = null,
    //        WorksiteLocationId = 1,
    //        LocationTypeId = (long)LocationType.WorksiteLocation,
    //        IsEmailSent = false,
    //    };
    //    long id = await CreateApplicantInterviewDto(applicantInterviewDto);
    //    Assert.True(id > 0);

    //    var getInterviewAfterSave = await _applicantInterviewController.GetById(id);
    //    Assert.NotNull(getInterviewAfterSave.Result);
    //    var savedInterviewResult = Assert.IsType<OkObjectResult>(getInterviewAfterSave.Result);
    //    Assert.NotNull(savedInterviewResult.Value);
    //    ApplicantInterviewDto savedInterviewFromDB = (ApplicantInterviewDto)savedInterviewResult.Value;
    //    Assert.NotNull(savedInterviewFromDB);

    //    var UpdateApplicantInterviewDto = new ApplicantInterviewDto
    //    {
    //        Id = savedInterviewFromDB.Id,
    //        JobApplicationId = savedInterviewFromDB.JobApplicationId,
    //        InterviewTypeId = (long)InterviewType.Phone,
    //        InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
    //        StartDateTime = DateTime.Now.ToString("hh:mm tt"),
    //        EndDateTime = DateTime.Now.AddMinutes(60).ToString("hh:mm tt"),

    //        Interviewers =
    //        [
    //             new()
    //             {
    //                 InterviewerId =3,
    //             }
    //        ],
    //        StatusId = (long)InterviewStatus.InterviewNoShow,
    //        MeetingLink = "test",
    //        WorksiteLocationId = null,
    //        LocationTypeId = (long)LocationType.CustomLocation,
    //        Location = "Custom locaton",
    //        Address1 = "Test address1",
    //        Address2 = "Test address1",
    //        City = "Test city",
    //        StateId = 1,
    //        ZipCode = "12345",
    //        IsEmailSent = true,
    //    };
    //    await _applicantInterviewController.UpdateAsync(UpdateApplicantInterviewDto);
    //    var afterUpdateGetInterview = await _applicantInterviewController.GetById(savedInterviewFromDB.Id);
    //    Assert.NotNull(afterUpdateGetInterview.Result);
    //    var afterUpdateGetInterviewResult = Assert.IsType<OkObjectResult>(afterUpdateGetInterview.Result);
    //    Assert.NotNull(afterUpdateGetInterviewResult.Value);
    //    ApplicantInterviewDto afterUpdateformFromDB = (ApplicantInterviewDto)afterUpdateGetInterviewResult.Value;
    //    Assert.NotNull(afterUpdateformFromDB);
    //    Assert.True(afterUpdateformFromDB?.Interviewers?.Count() > 0);
    //    Assert.True(afterUpdateformFromDB.InterviewTypeId == UpdateApplicantInterviewDto.InterviewTypeId);
    //    Assert.True(afterUpdateformFromDB.InterviewDate == UpdateApplicantInterviewDto.InterviewDate);
    //    Assert.True(afterUpdateformFromDB.StatusId == UpdateApplicantInterviewDto.StatusId);
    //    Assert.True(afterUpdateformFromDB.StartDateTime == UpdateApplicantInterviewDto.StartDateTime);
    //    Assert.True(afterUpdateformFromDB.EndDateTime == UpdateApplicantInterviewDto.EndDateTime);
    //    Assert.True(afterUpdateformFromDB.Interviewers.First().InterviewerId == UpdateApplicantInterviewDto.Interviewers.First().InterviewerId);
    //    Assert.True(afterUpdateformFromDB.WorksiteLocationId == UpdateApplicantInterviewDto.WorksiteLocationId);
    //    Assert.True(afterUpdateformFromDB.LocationTypeId == UpdateApplicantInterviewDto.LocationTypeId);
    //    Assert.True(afterUpdateformFromDB.Location == UpdateApplicantInterviewDto.Location);
    //    Assert.True(afterUpdateformFromDB.Address1 == UpdateApplicantInterviewDto.Address1);
    //    Assert.True(afterUpdateformFromDB.Address2 == UpdateApplicantInterviewDto.Address2);
    //    Assert.True(afterUpdateformFromDB.City == UpdateApplicantInterviewDto.City);
    //    Assert.True(afterUpdateformFromDB.StateId == UpdateApplicantInterviewDto.StateId);
    //    Assert.True(afterUpdateformFromDB.ZipCode == UpdateApplicantInterviewDto.ZipCode);

    //    var emailServiceMock = new Mock<IEmailClient>();
    //    var expectedResult = false;
    //    var result = emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<InterviewNotificationDto>()))
    //                   .ReturnsAsync(expectedResult);

    //    var templateData = GetInterviewMockObject();
    //    var emailMessage = GetMockEmail();
    //    var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);
    //    Assert.Equal(expectedResult, isEmailSent);
    //}

    [Fact]
    public async Task ShouldNotSendEmailToApplicantWhenSendEmailIsFalse()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(8).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            Interviewers =
            [
                 new()
             {
                 InterviewerId =1,
             }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };
        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);
    }

    [Fact]
    public async Task ShouldUpdateApplicantInterviewStatusToNoShow()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.AddDays(40).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            EndDateTime = DateTime.Now.AddDays(40).AddMinutes(30).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };
        long id = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(id > 0);

        var result = await _applicantInterviewController.NoShowAsync(id);
        Assert.IsType<OkResult>(result);

        var applicantInterview = await _applicantInterviewService.GetApplicantInterviewDetailsByIdAsync(id);
        Assert.NotNull(applicantInterview);
        Assert.Equal((long)InterviewStatus.InterviewNoShow, applicantInterview.StatusId);
    }

    [Fact]
    public async Task ShouldFailToUpdateApplicantInterviewStatusToNoShowWhenInvalidRecord()
    {
        await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _applicantInterviewController.NoShowAsync(long.MaxValue));
    }

    [Fact]
    public async Task ShouldFailToUpdateApplicantInterviewStatusToNoShowWhenRecordIdIsZero()
    {
        await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _applicantInterviewController.NoShowAsync(0));
    }

    [Fact]
    public async Task ShouldSendEmailWhenCancelInterview()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(13).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };

        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var applicantInterview = await _applicantInterviewController.GetById(applicantInterviewId);
        var applicantInterviewResult = Assert.IsType<OkObjectResult>(applicantInterview.Result);
        Assert.NotNull(applicantInterviewResult.Value);
        ApplicantInterviewDto applicantInterviewResultValue = (ApplicantInterviewDto)applicantInterviewResult.Value;
        Assert.NotNull(applicantInterviewResultValue);

        var cancelDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, Note = "Cancellation note", SendEmail = true, JobApplicationId = jobApplicationId,Version= applicantInterviewResultValue.Version };
        await _applicantInterviewService.UpdateStatusAsync(cancelDto, (long)InterviewStatus.InterviewCancelled);

        var emailServiceMock = new Mock<IEmailClient>();
        const bool expectedResult = true;
        emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<InterviewNotificationDto>()))
                       .ReturnsAsync(expectedResult);

        var templateData = GetInterviewMockObject();
        var emailMessage = GetMockEmail();
        var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);
        Assert.Equal(expectedResult, isEmailSent);
    }

    [Fact]
    public async Task ShouldSendFeedbackEmailAfterInterviewCompletion()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (int)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.UtcNow.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.UtcNow.AddMinutes(-2).ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.UtcNow.AddMinutes(-1).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId = _currentUserContext.UserId,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (int)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };

        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var applicantInterview = await _applicantInterviewController.GetById(applicantInterviewId);
        var applicantInterviewResult = Assert.IsType<OkObjectResult>(applicantInterview.Result);
        Assert.NotNull(applicantInterviewResult.Value);
        ApplicantInterviewDto applicantInterviewResultValue = (ApplicantInterviewDto)applicantInterviewResult.Value;
        Assert.NotNull(applicantInterviewResultValue);

        var applicantInterviewNotesDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, JobApplicationId = jobApplicationId, Note = "Note", Rating = 3 , Version= applicantInterviewResultValue .Version};

        var noteId = await CompleteInterview(applicantInterviewNotesDto);
        Assert.True(noteId > 0);
    }

    [Fact]
    public void ShouldGetInPersonEmailPreview()
    {
        var result = _applicantInterviewController.GetEmailPreviewByType((int)InterviewType.InPerson);
        Assert.NotNull(result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var emailPreviewDto = Assert.IsType<EmailPreviewDto>(okResult.Value);
        Assert.NotNull(emailPreviewDto);
        Assert.NotNull(emailPreviewDto.Template);
        var inPersonTemplate = InterviewScheduledNotificationTemplateTypes.NotificationTemplates.FirstOrDefault(template => template.Key == (int)InterviewType.InPerson);
        var expectedTemplate = _templates.FirstOrDefault(template => template.Key == inPersonTemplate.Value);
        var expected = CleanHtmlContent(expectedTemplate.Value);
        Assert.Equal(expected, emailPreviewDto.Template);
    }

    [Fact]
    public void ShouldGetVideoEmailPreview()
    {
        var result = _applicantInterviewController.GetEmailPreviewByType((int)InterviewType.Video);
        Assert.NotNull(result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var emailPreviewDto = Assert.IsType<EmailPreviewDto>(okResult.Value);
        Assert.NotNull(emailPreviewDto);
        Assert.NotNull(emailPreviewDto.Template);
        var inPersonTemplate = InterviewScheduledNotificationTemplateTypes.NotificationTemplates.FirstOrDefault(template => template.Key == (int)InterviewType.Video);
        var expectedTemplate = _templates.FirstOrDefault(template => template.Key == inPersonTemplate.Value);
        var expected = CleanHtmlContent(expectedTemplate.Value);
        Assert.Equal(expected, emailPreviewDto.Template);
    }

    [Fact]
    public void ShouldGetPhoneEmailPreview()
    {
        var result = _applicantInterviewController.GetEmailPreviewByType((int)InterviewType.Phone);
        Assert.NotNull(result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var emailPreviewDto = Assert.IsType<EmailPreviewDto>(okResult.Value);
        Assert.NotNull(emailPreviewDto);
        Assert.NotNull(emailPreviewDto.Template);
        var inPersonTemplate = InterviewScheduledNotificationTemplateTypes.NotificationTemplates.FirstOrDefault(template => template.Key == (int)InterviewType.Phone);
        var expectedTemplate = _templates.FirstOrDefault(template => template.Key == inPersonTemplate.Value);
        var expected = CleanHtmlContent(expectedTemplate.Value);
        Assert.Equal(expected, emailPreviewDto.Template);
    }

    [Fact]
    public async Task ShouldUpdateStatusToInterviewCompleted()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (int)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.UtcNow.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.UtcNow.AddMinutes(-2).ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.UtcNow.AddMinutes(-1).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId = _currentUserContext.UserId,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (int)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };

        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var applicantInterview = await _applicantInterviewController.GetById(applicantInterviewId);
        var applicantInterviewResult = Assert.IsType<OkObjectResult>(applicantInterview.Result);
        Assert.NotNull(applicantInterviewResult.Value);
        ApplicantInterviewDto applicantInterviewResultValue = (ApplicantInterviewDto)applicantInterviewResult.Value;
        Assert.NotNull(applicantInterviewResultValue);

        var applicantInterviewNotesDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, JobApplicationId = jobApplicationId, Note = "Note", Rating = 3, SendEmail = true,Version= applicantInterviewResultValue.Version };

        var noteId = await CompleteInterview(applicantInterviewNotesDto);
        Assert.True(noteId > 0);
    }

    [Fact]
    public async Task ShouldUpdateInterviewNote()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (int)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.UtcNow.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.UtcNow.AddMinutes(-20).ToString(ApplicantInterviewFields.TimeFormat),
            EndDateTime = DateTime.UtcNow.AddMinutes(-10).ToString(ApplicantInterviewFields.TimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId = _currentUserContext.UserId,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (int)LocationType.WorksiteLocation,
            IsEmailSent = false,
            SendEmail = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
        };

        long applicantInterviewId = await CreateApplicantInterviewDto(applicantInterviewDto);
        Assert.True(applicantInterviewId > 0);

        var applicantInterview = await _applicantInterviewController.GetById(applicantInterviewId);
        var applicantInterviewResult = Assert.IsType<OkObjectResult>(applicantInterview.Result);
        Assert.NotNull(applicantInterviewResult.Value);
        ApplicantInterviewDto applicantInterviewResultValue = (ApplicantInterviewDto)applicantInterviewResult.Value;
        Assert.NotNull(applicantInterviewResultValue);

        var applicantInterviewNotesDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, JobApplicationId = jobApplicationId, Note = "Note", Rating = 3,Version= applicantInterviewResultValue.Version };

        var noteId = await CompleteInterview(applicantInterviewNotesDto);

        var jobApplicationNoteDto = await _jobApplicationNoteService.GetByIdAsync(noteId);

        var applicantInterviewNotesDtoToUpdate = new ApplicantInterviewNotesDto { Id = noteId, ApplicantInterviewStatusId = (int)InterviewStatus.InterviewCompleted, ApplicantInterviewId = applicantInterviewId, JobApplicationId = jobApplicationId, Note = "Update Note", Rating = 4,Version= jobApplicationNoteDto!.Version };
        await _applicantInterviewController.UpdateNoteAsync(applicantInterviewNotesDtoToUpdate);

        var applicationNotes = await _jobApplicationNoteService.GetByIdAsync(noteId);
        Assert.NotNull(applicationNotes);
        Assert.IsType<JobApplicationNoteDto>(applicationNotes);
        Assert.Equal(noteId, applicationNotes.Id);
        Assert.Equal(applicantInterviewNotesDtoToUpdate.Note, applicationNotes.Note);
    }

    #region Private Methods

    private InterviewNotificationDto GetInterviewMockObject()
    {
        InterviewNotificationDto interviewScheduledNotification = new InterviewNotificationDto()
        {
            JobPostTitle = "Jobpost-" + DateTime.Now.Ticks,
            ApplicantFirstName = "Azure application form",
            ApplicantLastName = "Azure last name",
            ApplicantEmail = "testuser@test.com",
            CompanyName = "testcompanyname",
            InterviewDate = "07/22/2024",
            StartTime = "02:00 PM",
            EndTime = "03:00 PM",
            Subject = "test subject",
            InterviewType = "In Person",
            Label = "Location",
            Content = "test location, test city, test state, 43545",
            TimeZone = TimeZoneConstants.UTC_ZONE,
            Users = [
             new()
             {
                FirstName = "ABC",
                LastName = "abc last name",
                Email = "testuser@gmail.com",
                IsActive = true,
             },
             new(){
                FirstName="DEF",
                LastName="DEF last name",
                Email="testuserdef@gmail.com",
                IsActive=true
             }
            ]
        };
        return interviewScheduledNotification;
    }

    private static List<EmailDto> GetMockEmail()
    {
        return new()
        {
            new()
            {
                ToEmail = "testemail@test.com",
                ToName = "test applicant",
            }
        };
    }

    private async Task<long> CreateApplicationForm()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                        new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        }
                ]
        };

        var formId = await _applicationFormService.AddAsync(formDTO);
        Assert.NotNull(formId);
        Assert.True(formId > 0);

        return formId.Value;
    }

    private async Task<long> CreateJobPost(long? formId)
    {
        var jobPostDto = new JobPostDto { Title = "jobPost1" + DateTime.Now.Ticks, IsSubmitted = false, ApplicationFormId = formId, HiringManagerId = _currentUserContext.UserId };
        //Act
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.NotNull(jobPostId);
        Assert.True(jobPostId > 0);

        return jobPostId.Value;
    }

    private async Task<long> CompleteInterview(ApplicantInterviewNotesDto applicantInterviewNotesDto)
    {
        var result = await _applicantInterviewController.CompleteAsync(applicantInterviewNotesDto);
        Assert.NotNull(result);
        var okObjectResult = Assert.IsType<OkObjectResult>(result);
        Assert.NotNull(okObjectResult.Value);
        var response = Assert.IsType<CreatedResponse>(okObjectResult.Value);
        Assert.True(response.Id > 0);
        return response.Id;
    }

    private async Task<long> CreateJobApplication()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await CreateJobPost(formId);
        var form = await _applicationFormService.GetByIdAsync(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestFirstName",
                    },
                    new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestMiddleName",
                    },
                    new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestLastname",
                    },
                    new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test@test.com",
                    },
                ],
        };
        var jobApplicationId = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.NotNull(jobApplicationId);
        Assert.True(jobApplicationId > 0);
        return jobApplicationId.Value;
    }

    private async Task<long> CreateApplicantInterview()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                 new()
                 {
                     Id = 0,
                     InterviewerId =_currentUserContext.UserId,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = string.Empty,
            EndTime = string.Empty
            
        };
        long id = await CreateApplicantInterviewDto(applicantInterviewDto);
        return id;
    }

    private async Task<long> CreateApplicantInterviewDto(ApplicantInterviewDto applicantInterviewDto)
    {
        var newApplicantInterviewResult = await _applicantInterviewController.Create(applicantInterviewDto);
        var okResult = Assert.IsType<OkObjectResult>(newApplicantInterviewResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);
        Assert.True(response.Id > 0);
        return response.Id;
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}