﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;

namespace BBSI.ATS.UnitTests;

public class ApplicantInterviewDtoValidatiorTests
{
    private readonly ApplicantInterviewDtoValidator _validator;

    public ApplicantInterviewDtoValidatiorTests()
    {
        _validator = new ApplicantInterviewDtoValidator();
    }

    [Fact]
    public void ShouldPasswhenRequriedFieldsEntered()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.JobApplicationId);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.InterviewTypeId);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.InterviewDate);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.StartDateTime);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.EndDateTime);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.Interviewers);
    }

    [Fact]
    public void ShouldFailwhenInterviewDateisPastDate()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(-1).ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.UtcNow.AddDays(-1).AddMinutes(30).ToString(),
            EndDateTime = DateTime.UtcNow.AddDays(-1).AddMinutes(40).ToString(),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.StartDateTime);
    }

    [Fact]
    public void ShouldFailwhenJobApplicationIdNull()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = null,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.JobApplicationId);
    }

    [Fact]
    public void ShouldFailWhenInterviewTypeIdNull()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = null,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.InterviewTypeId);
    }

    [Fact]
    public void ShouldFailMeetingLinkRequriedWhenInterviewTypeIdIsVideo()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Video,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            MeetingLink = ""
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.MeetingLink);
    }

    [Fact]
    public void ShouldFailMeetingLinkIsEmptyWhenInterviewTypeIdIsVideo()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Video,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.MeetingLink);
    }

    [Fact]
    public void ShouldPassMeetingLinkkwhenInterviewTypeIdIsVideo()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Video,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            MeetingLink = "testlink"
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.MeetingLink);
    }

    [Fact]
    public void ShouldFailLocationTypeIdIsNullWhenInterviewTypeIdIsInPerson()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.LocationTypeId);
    }

    [Fact]
    public void ShouldFailWorksiteLocationIdIsRequriedWhenLocationTypeIdIsWorkSiteLocation()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.WorksiteLocation
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.WorksiteLocationId);
    }

    [Fact]
    public void ShouldPassWorksiteLocationWhenLocationTypeIdIsWorkSiteLocation()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.WorksiteLocation,
            WorksiteLocationId = 1
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.WorksiteLocationId);
    }

    [Fact]
    public void ShouldFailCustomeLocationWhenLocationTypeIdIsCustome()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.CustomLocation,
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.Address1);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.StateId);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.City);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.ZipCode);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.Address2);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.IsEmailSent);
    }

    [Fact]
    public void ShouldPassCustomeLocationWhenLocationTypeIdIsCustome()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.CustomLocation,
            Address1 = "test Address",
            StateId = 38,
            City = "test City",
            ZipCode = "12345",
            Location = "Test Location"
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.Address1);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.StateId);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.City);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.ZipCode);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.Address2);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.IsEmailSent);
    }

    [Fact]
    public void ShouldFailAddress1MaxWhenLocationTypeIdIsCustome()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.CustomLocation,
            Address1 = "testAddressasdfghjklkjhgfdsqwertyuiopoiuytrewqasdfghjklkjhgfdswertyuiopiuytrewqasdfghjklkjhgfdslkjhgfdsqwertyuiopoiuyt",
            StateId = 38,
            City = "test City",
            ZipCode = "12345",
            Location = "Test Location"
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.Address1);
    }

    [Fact]
    public void ShouldFailStateIdIsNullhenLocationTypeIdIsCustome()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.CustomLocation,
            Address1 = "test Address",
            StateId = null,
            City = "test City",
            ZipCode = "12345",
            Location = "Test Location"
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);

        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.StateId);
    }

    [Fact]
    public void ShouldFailCityMaxLengthWhenLocationTypeIdIsCustome()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.CustomLocation,
            Address1 = "test Address",
            StateId = 38,
            City = "testqwertyuiopoiuytrewqasdfghjklkjhgfdsaqwertyuiopoiuywqasdfghjkjhgfdwertyuio",
            ZipCode = "12345",
            Location = "Test Location"
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldNotHaveValidationErrorFor(interviewResult => interviewResult.City);
    }

    [Fact]
    public void ShouldFailZipCodeMaxLengthWhenLocationTypeIdIsCustome()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ],
            LocationTypeId = (long)LocationType.CustomLocation,
            Address1 = "test Address",
            StateId = 38,
            City = "test City",
            ZipCode = "123456",
            Location = "Test Location"
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.ZipCode);
    }

    [Fact]
    public void ShouldFailInterviewerIdIsNull()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.InPerson,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [

            ],
            LocationTypeId = (long)LocationType.CustomLocation,
            Address1 = "test Address",
            StateId = 38,
            City = "test City",
            ZipCode = "12345",
            Location = "Test Location"
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        var resultValue = Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.Interviewers);
    }

    [Fact]
    public void ShouldFailwhenInterviewDateIsEmpty()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = null,
            StartDateTime = "",
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.InterviewDate);
    }

    [Fact]
    public void ShouldFailwhenStartDateTimeIsEmpty()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = "",
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.StartDateTime);
    }

    [Fact]
    public void ShouldFailwhenEndDateTimeIsEmpty()
    {
        var applicantInterview = new ApplicantInterviewDto
        {
            JobApplicationId = 1,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.ToString("yyyy-MM-dd"), "yyyy-MM-dd"),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = "",
            Interviewers =
            [
                new()
                {
                    InterviewerId =1,
                }
            ]
        };
        var result = _validator.TestValidate(applicantInterview);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantInterviewDto>>(result);
        result.ShouldHaveValidationErrorFor(interviewResult => interviewResult.EndDateTime);
    }
}