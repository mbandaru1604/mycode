﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests
{
    public class ApplicantInterviewNotesDtoValidatorTests
    {
        private readonly ApplicantInterviewNotesDtoValidator _validator;

        public ApplicantInterviewNotesDtoValidatorTests()
        {
            _validator = new ApplicantInterviewNotesDtoValidator();
        }

        [Fact]
        public void ShouldFailNotesNull()
        {
            var applicantInterviewNotesDto = new ApplicantInterviewNotesDto { Note = string.Empty, SendEmail = false };
            var result = _validator.TestValidate(applicantInterviewNotesDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<ApplicantInterviewNotesDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(applicantInterview => applicantInterview.Note);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == ApplicantInterviewValidation.NoteRequried);
        }

        [Fact]
        public void ShouldReturnErrorNotesMaxLengthExceeded()
        {
            string stringNotesMaxLengtExceeded = "ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. onsectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua";
            var applicantInterviewNotesDto = new ApplicantInterviewNotesDto { Note = stringNotesMaxLengtExceeded, SendEmail = false };
            var result = _validator.TestValidate(applicantInterviewNotesDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<ApplicantInterviewNotesDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(applicantInterview => applicantInterview.Note);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == ApplicantInterviewValidation.NotesMaxLengthExceededMessage);
        }
    }
}