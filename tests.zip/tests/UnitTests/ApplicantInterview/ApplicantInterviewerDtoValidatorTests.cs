﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;

namespace BBSI.ATS.UnitTests;

public class ApplicantInterviewerDtoValidatorTests
{
    private readonly ApplicantInterviewerDtoValidator _validator;

    public ApplicantInterviewerDtoValidatorTests()
    {
        _validator = new ApplicantInterviewerDtoValidator();
    }

    [Fact]
    public void ShouldPasswhenInterviewerIdIsMentioned()
    {
        var applicantInterviewer = new ApplicantInterviewerDto()
        {
            InterviewerId = 1,
        };
        var result = _validator.TestValidate(applicantInterviewer);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantInterviewerDto>>(result);
        result.ShouldNotHaveValidationErrorFor(interviewerResult => interviewerResult.InterviewerId);
    }
}