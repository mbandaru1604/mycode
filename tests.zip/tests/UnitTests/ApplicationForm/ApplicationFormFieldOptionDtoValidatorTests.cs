﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests
{
    public class ApplicationFormFieldOptionDtoValidatorTests
    {
        private readonly ApplicationFormFieldOptionDtoValidator _validator;

        public ApplicationFormFieldOptionDtoValidatorTests()
        {
            _validator = new ApplicationFormFieldOptionDtoValidator();
        }

        [Fact]
        public void ShouldFailForCustomFieldOptionNameMaxLengthExceeded()
        {
            List<ApplicationFormFieldOptionDto> formFieldOptionDto = [
             new ApplicationFormFieldOptionDto { Name = "012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789" },
                new ApplicationFormFieldOptionDto { Name = "23536364LKHFUYIHKNKJN_5678901234567890123456789012345678_hUGIYUHNJKNJ_012345678901234567890123456789012345678901234567890123456789" }
             ];
            formFieldOptionDto.ForEach(option =>
            {
                var result = _validator.TestValidate(option);
                Assert.IsType<TestValidationResult<ApplicationFormFieldOptionDto>>(result);
                var validationResult = result.ShouldHaveValidationErrorFor(option => option.Name);
                Assert.True(validationResult.Any());
                Assert.True(validationResult.First() != null);
                Assert.True(!string.IsNullOrWhiteSpace(validationResult.First().ErrorMessage));
                Assert.True(validationResult.First().ErrorMessage == DropdownValidation.OptionMaxLengthErrorMessage);
            });
        }
    }
}