﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.Domain.Entities;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Data.Repositories.Interfaces;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class ApplicationFormControllerTests : IDisposable
{
    private readonly ApplicationFormsController _formController;
    private readonly JobPostsController _jobPostsController;
    private readonly MetaDataService _metaDataService;
    private readonly AtsDbContext _dbContext;
    private bool disposed = false;
    private readonly CurrentUserContext _currentUserContext;
    private readonly ApplicationFormService _applicationFormService;
    private readonly ApplicationFormRepository _applicationFormRepository;
    private readonly IAtsBaseRepository _atsBaseRepository;

    public ApplicationFormControllerTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        _applicationFormRepository = new ApplicationFormRepository(_dbContext, _currentUserContext);
        var _jobPostRepository = new JobPostRepository(_dbContext, _currentUserContext);
        var repository = new MetaDataRepository(_dbContext, _currentUserContext);
        _atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var applicantQuizRepository = new ApplicantQuizRepository(_dbContext, _currentUserContext);

        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        IMapper mapper = mappingConfig.CreateMapper();

        var mockCosmosDbService = new Mock<ICosmosDbService>();

        var formFieldComparer = new ApplicationFormFieldComparer();
        var applicationFormComparer = new ApplicationFormComparer(formFieldComparer);
        _applicationFormService = new ApplicationFormService(_applicationFormRepository, mapper, _currentUserContext, mockCosmosDbService.Object, applicationFormComparer);
        _formController = new ApplicationFormsController(_applicationFormService);

        var companyRepository = new CompanyRepository(_dbContext, _currentUserContext);
        var userRepository = new UserRepository(_dbContext, _currentUserContext);
        var userService = new UserService(_atsBaseRepository, null, userRepository, _currentUserContext);
        var companyService = new CompanyService(companyRepository, userService, null, mapper, null);
        var appConfig = new AppConfig();
        var jobPostService = new JobPostService(_jobPostRepository, mapper, _applicationFormService, _currentUserContext,
                                                mockCosmosDbService.Object, applicantQuizRepository, companyService, appConfig);
        _jobPostsController = new JobPostsController(jobPostService);

        _metaDataService = new MetaDataService(repository, mapper);
    }

    #region Create Form Tests

    [Fact]
    public async Task ShouldCreateApplicationFormWithGivenName()
    {
        var formDTO = new ApplicationFormDto { Name = "form-" + DateTime.Now.Ticks };
        var result = await _formController.Create(formDTO);

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdFormDTO = Assert.IsType<CreatedResponse>(okResult.Value);
        Assert.True(createdFormDTO.Id > 0);

        var newForm = await _applicationFormRepository.GetByIdAsync<ApplicationForm>(createdFormDTO.Id);
        Assert.NotNull(newForm);
        Assert.Equal(newForm.CompanyId, _currentUserContext.CompanyId);
    }

    [Fact]
    public async Task ShouldCreateFormWithGivenCustomFieldOptions()
    {
        var Options = new List<ApplicationFormFieldOptionDto> {
                            new() {Name = "Washington"},
                            new () {Name = "New York"} };

        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "state", TypeId = (long)ApplicationFormFieldTypes.Dropdown, Options = Options } };
        var formDto = new ApplicationFormDto { Name = "form2", Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);
    }

    [Fact]
    public async Task ShouldCreateFormWithGivenCustomTextBoxWithAttributeValue()
    {
        var fieldName = "Alternate Phone Number";
        var attributeValue = "100";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form01", Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);
        var getForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getForm.Result);
        var formResult = Assert.IsType<OkObjectResult>(getForm.Result);
        Assert.NotNull(formResult);

        ApplicationFormDto? formFromDB = formResult.Value as ApplicationFormDto;
        Assert.NotNull(formFromDB);
        Assert.True(IsValid(formFromDB.Name));
        Assert.True(formFromDB.Name == formDto.Name);
        Assert.True(formFromDB.Fields?.Count > 0);
        var formFromDBField = formFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(formFromDBField);
        Assert.True(IsValid(formFromDBField.Name));
        Assert.True(formFromDBField.Name == fieldName);
        Assert.True(formFromDBField.TypeId == (long)ApplicationFormFieldTypes.SingleLineInput);

        Assert.NotNull(formFromDBField.AttributeValues);
        var formFieldAttributeFromDB = formFromDBField.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.True(IsValid(formFieldAttributeFromDB.AttributeValue));
        Assert.True(!string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldCreateFormWithGivenCustomTextBoxWithOutAttributeValue()
    {
        const string fieldName = "Alternate Phone Number";
        var attributeValue = "";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form3", Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);
        var getForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getForm.Result);
        var formResult = Assert.IsType<OkObjectResult>(getForm.Result);
        Assert.NotNull(formResult.Value);
        ApplicationFormDto formFromDB = (ApplicationFormDto)formResult.Value;
        Assert.NotNull(formFromDB);
        Assert.NotNull(formFromDB.Name);
        Assert.NotEmpty(formFromDB.Name);
        Assert.True(formFromDB.Name == formDto.Name);
        Assert.True(formFromDB.Fields?.Count > 0);
        var formFromDBFields = formFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.Name);
        Assert.NotEmpty(formFromDBFields.Name);
        Assert.True(formFromDBFields.Name == fieldName);
        Assert.True(formFromDBFields.TypeId == (long)ApplicationFormFieldTypes.SingleLineInput);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.AttributeValues);
        var formFieldAttributeFromDB = formFromDBFields.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.NotNull(formFieldAttributeFromDB.AttributeValue);
        Assert.Empty(formFieldAttributeFromDB.AttributeValue);
        Assert.True(string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldCreateFormWithGivenCustomTextAreaWithAttributeValue()
    {
        const string fieldName = "Previous Organization Address";
        var attributeValue = "500";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.ParagraphField, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form4", Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);
        var getForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getForm.Result);
        var formResult = Assert.IsType<OkObjectResult>(getForm.Result);
        Assert.NotNull(formResult.Value);
        ApplicationFormDto formFromDB = (ApplicationFormDto)formResult.Value;
        Assert.NotNull(formFromDB);
        Assert.NotNull(formFromDB.Name);
        Assert.NotEmpty(formFromDB.Name);
        Assert.True(formFromDB.Name == formDto.Name);
        Assert.True(formFromDB.Fields?.Count > 0);
        var formFromDBFields = formFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.Name);
        Assert.NotEmpty(formFromDBFields.Name);
        Assert.True(formFromDBFields.Name == fieldName);
        Assert.True(formFromDBFields.TypeId == (long)ApplicationFormFieldTypes.ParagraphField);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.AttributeValues);
        var formFieldAttributeFromDB = formFromDBFields.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.NotNull(formFieldAttributeFromDB.AttributeValue);
        Assert.NotEmpty(formFieldAttributeFromDB.AttributeValue);
        Assert.True(!string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldCreateFormWithGivenCustomTextAreaWithOutAttributeValue()
    {
        const string fieldName = "Previous Organization Address";
        var attributeValue = "";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.ParagraphField, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form5", Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);
        var getForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getForm.Result);
        var formResult = Assert.IsType<OkObjectResult>(getForm.Result);
        Assert.NotNull(formResult.Value);
        ApplicationFormDto formFromDB = (ApplicationFormDto)formResult.Value;
        Assert.NotNull(formFromDB);
        Assert.NotNull(formFromDB.Name);
        Assert.NotEmpty(formFromDB.Name);
        Assert.True(formFromDB.Name == formDto.Name);
        Assert.True(formFromDB.Fields?.Count > 0);
        var formFromDBFields = formFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.Name);
        Assert.NotEmpty(formFromDBFields.Name);
        Assert.True(formFromDBFields.Name == fieldName);
        Assert.True(formFromDBFields.TypeId == (long)ApplicationFormFieldTypes.ParagraphField);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.AttributeValues);
        var formFieldAttributeFromDB = formFromDBFields.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.NotNull(formFieldAttributeFromDB.AttributeValue);
        Assert.Empty(formFieldAttributeFromDB.AttributeValue);
        Assert.True(string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldCreateFormWithGivenCustomFileUploadWithAttributeValue()
    {
        var fieldName = "Resume Upload";
        var attributeValue = "1 MB";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.FileUpload, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form6", Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);
        var getForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getForm.Result);
        var formResult = Assert.IsType<OkObjectResult>(getForm.Result);
        Assert.NotNull(formResult.Value);
        ApplicationFormDto formFromDB = (ApplicationFormDto)formResult.Value;
        Assert.NotNull(formFromDB);
        Assert.NotNull(formFromDB.Name);
        Assert.NotEmpty(formFromDB.Name);
        Assert.True(formFromDB.Name == formDto.Name);
        Assert.True(formFromDB.Fields?.Count > 0);
        var formFromDBFields = formFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.Name);
        Assert.NotEmpty(formFromDBFields.Name);
        Assert.True(formFromDBFields.Name == fieldName);
        Assert.True(formFromDBFields.TypeId == (long)ApplicationFormFieldTypes.FileUpload);
        Assert.NotNull(formFromDBFields.AttributeValues);
        var formFieldAttributeFromDB = formFromDBFields.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxFileUploadSize);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.NotNull(formFieldAttributeFromDB.AttributeValue);
        Assert.NotEmpty(formFieldAttributeFromDB.AttributeValue);
        Assert.True(!string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxFileUploadSize);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldCreateFormWithGivenCustomFileUploadWithOutAttributeValue()
    {
        const string fieldName = "Resume Upload";
        const string attributeValue = "";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.FileUpload, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form7", Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);
        var getForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getForm.Result);
        var formResult = Assert.IsType<OkObjectResult>(getForm.Result);
        Assert.NotNull(formResult.Value);
        ApplicationFormDto formFromDB = (ApplicationFormDto)formResult.Value;
        Assert.NotNull(formFromDB);
        Assert.NotNull(formFromDB.Name);
        Assert.NotEmpty(formFromDB.Name);
        Assert.True(formFromDB.Name == formDto.Name);
        Assert.True(formFromDB.Fields?.Count > 0);
        var formFromDBFields = formFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(formFromDBFields);
        Assert.NotNull(formFromDBFields.Name);
        Assert.NotEmpty(formFromDBFields.Name);
        Assert.True(formFromDBFields.Name == fieldName);
        Assert.True(formFromDBFields.TypeId == (long)ApplicationFormFieldTypes.FileUpload);
        Assert.NotNull(formFromDBFields.AttributeValues);
        var formFieldAttributeFromDB = formFromDBFields.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxFileUploadSize);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.NotNull(formFieldAttributeFromDB.AttributeValue);
        Assert.Empty(formFieldAttributeFromDB.AttributeValue);
        Assert.True(string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxFileUploadSize);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenAlwaysActiveFieldIsMadeInActiveInCreateForm()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
            [
                new()
                {
                    Name = "First Name",
                    DisplayOrder = 1,
                    IsSystemDefault = true,
                    IsAlwaysActiveAndRequired = true,
                    IsActive = false,
                    IsRequired = true,
                    SectionId = 1,
                    TypeId = 4
                },
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _formController.Create(formDTO));
        Assert.Equal(string.Format(ErrorMessages.FormFieldInactive, "First Name"), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenRequiredFieldIsMadeOptionalInCreateForm()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
            [
                new()
                {
                    Name = "First Name",
                    DisplayOrder = 1,
                    IsSystemDefault = true,
                    IsAlwaysActiveAndRequired = true,
                    IsActive = true,
                    IsRequired = false,
                    SectionId = 1,
                    TypeId = 4
                },
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _formController.Create(formDTO));
        Assert.Equal(string.Format(ErrorMessages.FormFieldOptionalMandatory, "First Name"), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenFormCreatedWithExistingFormName()
    {
        var formName = "form" + DateTime.Now.Ticks;
        var formDTO = new ApplicationFormDto
        {
            Name = formName,
            Fields =
            [
                new()
                {
                    Name = "First Name",
                    DisplayOrder = 1,
                    IsSystemDefault = true,
                    IsAlwaysActiveAndRequired = true,
                    IsActive = true,
                    IsRequired = true,
                    SectionId = 1,
                    TypeId = 4
                },
            ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = newFormResult.Result as OkObjectResult;
        var response = okResult?.Value as CreatedResponse;
        var formId = response?.Id;
        Assert.True(formId > 0);

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _formController.Create(formDTO));
        Assert.Equal(ErrorMessages.ApplicationFormNameExists, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenExceededMaxAllowedCustomFieldsInCreateForm()
    {
        var fields = new List<ApplicationFormFieldDto>();
        for (int i = 0; i < FormFieldValidation.MaxAllowedCustomFields + 1; i++)
        {
            fields.Add(new() { Name = string.Format("custom_field_{0}", i.ToString()) });
        }
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields = fields
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _formController.Create(formDTO));
        Assert.Equal(FormFieldValidation.ExceededMaxAllowedCustomFields, exception.Message);
    }

    [Fact]
    public async Task ShouldAssociateApplicationForActiveJobPost()
    {
        var id = await CreateApplicationForm();
        Assert.True(id > 0);

        var jobPostTitle = $"JobPostTitle-{DateTime.Now.Ticks}";
        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = jobPostTitle, Description = "JobPost Description", CategoryId = 1, EEOClassId = 6, EmployeeTypeId = 1, PayGroupId = (long)PayGroup.Weekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Now), IsActive = true, IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var okResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostDTO = Assert.IsType<CreatedResponse>(okResult.Value);
        Assert.True(createdJobPostDTO.Id > 0);

        var jobPostList = await _formController.GetJobPostsById((long)id);
        Assert.NotNull(jobPostList);
        Assert.NotNull(jobPostList.Result);
        var activeJobPosts = Assert.IsType<OkObjectResult>(jobPostList.Result);
        var activeJobPostsFromDB = Assert.IsType<List<JobPostListDto>>(activeJobPosts.Value);
        Assert.NotNull(activeJobPostsFromDB);
        Assert.True(activeJobPostsFromDB.Count > 0);

        var formsList = await _applicationFormService.GetAllForms();
        Assert.NotNull(formsList);
        Assert.True(formsList.Count() > 0);

        foreach (var dtoForm in formsList)
        {
            var matchForm = formsList.First(dbForm => dbForm.Id == id);
            Assert.NotNull(matchForm);
            Assert.NotNull(matchForm.CreatedOn);
            Assert.NotNull(matchForm.IsActive);
            Assert.True(matchForm.Name == matchForm.Name);
            Assert.True(matchForm.OpenPositions == 1);
            Assert.True(activeJobPostsFromDB.Count == matchForm.OpenPositions);
        }
    }

    [Fact]
    public async Task ShouldAssociateApplicationForInActiveJobPost()
    {
        var id = await CreateApplicationForm();
        Assert.True(id > 0);

        var jobPostTitle = $"JobPostTitle-{DateTime.Now.Ticks}";
        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = jobPostTitle, Description = "JobPost Description", IsActive = true, IsSubmitted = false };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var okResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostDTO = Assert.IsType<CreatedResponse>(okResult.Value);
        Assert.True(createdJobPostDTO.Id > 0);

        var jobPostList = await _applicationFormService.GetJobPostsByIdAsync((long)id);
        Assert.NotNull(jobPostList);
        Assert.True(jobPostList.Count() == 0);

        var formsList = await _applicationFormService.GetAllForms();
        Assert.NotNull(formsList);
        Assert.True(formsList.Count() > 0);

        foreach (var dtoForm in formsList)
        {
            var matchForm = formsList.First(dbForm => dbForm.Id == id);
            Assert.NotNull(matchForm);
            Assert.NotNull(matchForm.CreatedOn);
            Assert.NotNull(matchForm.IsActive);
            Assert.True(matchForm.Name == matchForm.Name);
            Assert.True(matchForm.OpenPositions == 0);
            Assert.True(jobPostList.Count() == matchForm.OpenPositions);
        }
    }

    [Fact]
    public async Task ShouldCreateFormWithAllDefaultFields()
    {
        //create form
        var formId = await CreateApplicationFormWithAllDefaultFields();
        Assert.NotNull(formId);

        //get the form
        var form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);
        var formFromDBFields = form.Fields;
        var defaultFields = await GetApplicationFormDefaultFields();

        // filter education hx

        Assert.NotNull(defaultFields);
        foreach (var field in defaultFields)
        {
            var formField = form.Fields.First(field => field.Name == field.Name);
            Assert.NotNull(formField);
            Assert.Contains(formFromDBFields, field => field.Name == field.Name);
            Assert.Contains(formFromDBFields, fld => fld.IsSystemDefault == true);
            Assert.Contains(formFromDBFields, fld => fld.DisplayOrder == field.DisplayOrder);
            Assert.Contains(formFromDBFields, fld => fld.TypeId == field.TypeId);
            Assert.Contains(formFromDBFields, fld => fld.SectionId == field.SectionId);
            Assert.Contains(formFromDBFields, fld => fld.IsActive == field.IsActive);
            Assert.Contains(formFromDBFields, fld => fld.IsRequired == field.IsRequired);
        }
    }

    [Fact]
    public async Task ShouldThrowValidationWhenTextFieldMaxLengthExceeds()
    {
        var formDto = new ApplicationFormDto() { Name = "form" + DateTime.Now, IsActive = true, Fields = [new() { Name = "ShortField", TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, IsSystemDefault = false, AttributeValues = [new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "150" }] }] };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _formController.Create(formDto));
        Assert.Equal("Single Line Input max Length cannot exceed 100 characters", exception.Message);
    }

    #endregion Create Form Tests

    #region Get Form Tests

    [Fact]
    public async Task ShouldGetAllForms()
    {
        List<ApplicationFormDto> applicationFormDTOs = [];
        var fieldName = "Location";
        var maxNumberAttributeValue = "100";
        var form1FieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = maxNumberAttributeValue } };
        var form1Fields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = form1FieldAttributeValues } };
        var form1Dto = new ApplicationFormDto { Name = "form11", IsActive = true, Fields = form1Fields };
        applicationFormDTOs.Add(form1Dto);
        var result = await _formController.Create(form1Dto);

        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        maxNumberAttributeValue = "100";
        var form2FieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = maxNumberAttributeValue } };
        var form2Fields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = form2FieldAttributeValues } };
        var form2Dto = new ApplicationFormDto { Name = "form12", IsActive = true, Fields = form2Fields };
        result = await _formController.Create(form2Dto);

        insertResult = Assert.IsType<OkObjectResult>(result.Result);
        createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        maxNumberAttributeValue = "100";
        var form3FieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = maxNumberAttributeValue } };
        var form3Fields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = form3FieldAttributeValues } };
        var form3Dto = new ApplicationFormDto { Name = "form13", IsActive = true, Fields = form3Fields };
        result = await _formController.Create(form3Dto);

        insertResult = Assert.IsType<OkObjectResult>(result.Result);
        createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);
        var formsList = await _formController.GetAllForms();
        var forms = Assert.IsType<OkObjectResult>(formsList.Result);
        var formsFromDB = Assert.IsType<List<ApplicationFormListDto>>(forms.Value);
        Assert.NotNull(formsFromDB);
        Assert.True(formsFromDB.Count > 0);
        foreach (var dtoForm in applicationFormDTOs)
        {
            var matchForm = formsFromDB.Find(dbForm => dbForm.Name == dtoForm.Name);
            Assert.NotNull(matchForm);
            Assert.NotNull(matchForm.CreatedOn);
            Assert.NotNull(matchForm.IsActive);
            Assert.True(matchForm.OpenPositions == 0);
        }
    }

    [Fact]
    public async Task ShouldGetFormDetailsById()
    {
        var formName = "form10";
        var fieldName = "Zip";
        var attributeValue = "8";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = formName, Fields = formFields };
        var result = await _formController.Create(formDto);

        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        var form = await _formController.GetById(createdResponse.Id);
        var appForm = Assert.IsType<OkObjectResult>(form.Result);
        var formFromDB = Assert.IsType<ApplicationFormDto>(appForm.Value);
        Assert.NotNull(formFromDB);
        Assert.True(formFromDB.Name == formName);
        Assert.NotNull(formFromDB.CreatedOn);

        var formFromDBFields = formFromDB.Fields;
        Assert.NotNull(formFromDBFields);
        Assert.Contains(formFromDBFields, field => field.Name == fieldName);
        Assert.Contains(formFromDBFields, fld => fld.TypeId == (long)ApplicationFormFieldTypes.SingleLineInput);
        var fieldsMatchingName = formFromDBFields.Find(fn => fn.Name == fieldName);
        Assert.NotNull(fieldsMatchingName);
        Assert.NotNull(fieldsMatchingName.AttributeValues);
        var formFieldAttributeFromDB = fieldsMatchingName.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.NotNull(formFieldAttributeFromDB.AttributeValue);
        Assert.NotEmpty(formFieldAttributeFromDB.AttributeValue);
        Assert.True(!string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldGetFormWithEducationHistoryWorkHistoryDetailsById()
    {
        //create form
        var formId = await CreateApplicationFormWithAllDefaultFields();
        Assert.NotNull(formId);

        //get the form
        var formFromDB = await GetApplicationFormById(formId.Value);
        Assert.NotNull(formFromDB);
        Assert.NotNull(formFromDB.CreatedOn);

        var formFromDBFields = formFromDB.Fields;
        Assert.NotNull(formFromDBFields);

        var defaultFields = await GetApplicationFormDefaultFields();
        Assert.NotNull(defaultFields);
        foreach (var field in defaultFields)
        {
            var formField = formFromDBFields.First(field => field.Name == field.Name);
            Assert.NotNull(formField);
            Assert.Contains(formFromDBFields, field => field.Name == field.Name);
            Assert.Contains(formFromDBFields, fld => fld.IsSystemDefault == true);
            Assert.Contains(formFromDBFields, fld => fld.DisplayOrder == field.DisplayOrder);
            Assert.Contains(formFromDBFields, fld => fld.TypeId == field.TypeId);
            Assert.Contains(formFromDBFields, fld => fld.SectionId == field.SectionId);
            Assert.Contains(formFromDBFields, fld => fld.IsActive == field.IsActive);
            Assert.Contains(formFromDBFields, fld => fld.IsRequired == field.IsRequired);
        }
    }

    [Fact]
    public async Task ShouldFailGetFormWithInvalidFormIdAndNullFormIsActiveFlag()
    {
        var fieldName = "Zip";
        var attributeValue = "8";
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = attributeValue } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form" + DateTime.Now.Ticks, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);
        var form = await _formController.GetById(20000);
        var formResult = Assert.IsType<BadRequestObjectResult>(form.Result);
        Assert.True(formResult.GetType().Name == "BadRequestObjectResult");
    }

    [Fact]
    public async Task ShouldReturnTrueOnSearchingAnExistingForm()
    {
        var formDTO = new ApplicationFormDto { Name = "form1" + DateTime.Now.Ticks };
        await _formController.Create(formDTO);
        var result = await _formController.Exists(formDTO.Name);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var okResultValue = okResult.Value as AtsRecordExistsResponse;
        Assert.NotNull(okResultValue);
        Assert.True(okResultValue.Exists);
    }

    [Fact]
    public async Task ShouldReturnFalseOnSearchingForNonExistingApplicationForm()
    {
        var formDTO = new ApplicationFormDto { Name = "form1" + DateTime.Now.Ticks };
        await _formController.Create(formDTO);

        var result = await _formController.Exists("form2");
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var okResultValue = okResult.Value as AtsRecordExistsResponse;
        Assert.NotNull(okResultValue);
        Assert.False(okResultValue.Exists);
    }

    [Fact]
    public async Task ShouldGetApplicationFormWithAddedNewCustomField()
    {
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "" } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "Alternate Phone Number", TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form" + DateTime.Now.Ticks, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);

        var getFormAfterSave = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getFormAfterSave.Result);
        var savedFormResult = Assert.IsType<OkObjectResult>(getFormAfterSave.Result);
        Assert.NotNull(savedFormResult.Value);
        ApplicationFormDto savedFormFromDB = (ApplicationFormDto)savedFormResult.Value;
        Assert.NotNull(savedFormFromDB);
        Assert.NotNull(savedFormFromDB.Name);
        Assert.NotEmpty(savedFormFromDB.Name);
        Assert.True(savedFormFromDB.Name == formDto.Name);
        Assert.True(savedFormFromDB.Fields?.Count > 0);

        var forUpdateFormFromDBFields = savedFormFromDB.Fields;
        var fieldName = "Resume Upload";
        var attributeValue = "";
        var newFormFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = attributeValue } };
        forUpdateFormFromDBFields.Add(new ApplicationFormFieldDto { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.FileUpload, AttributeValues = newFormFieldAttributeValues });
        savedFormFromDB.Id = createdResponse.Id;
        await _formController.Update(savedFormFromDB);
        var afterUpdateGetForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(afterUpdateGetForm.Result);

        var afterUpdateFormResult = Assert.IsType<OkObjectResult>(afterUpdateGetForm.Result);
        Assert.NotNull(afterUpdateFormResult.Value);
        ApplicationFormDto afterUpdateformFromDB = (ApplicationFormDto)afterUpdateFormResult.Value;
        Assert.NotNull(afterUpdateformFromDB);
        Assert.NotNull(afterUpdateformFromDB.Fields);
        var updatedFormFromDBFields = afterUpdateformFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(updatedFormFromDBFields);
        Assert.NotNull(updatedFormFromDBFields.Name);
        Assert.NotEmpty(updatedFormFromDBFields.Name);
        Assert.True(updatedFormFromDBFields.Name == fieldName);
        Assert.True(updatedFormFromDBFields.TypeId == (long)ApplicationFormFieldTypes.FileUpload);

        Assert.NotNull(updatedFormFromDBFields.AttributeValues);
        var formFieldAttributeFromDB = updatedFormFromDBFields.AttributeValues.Find(attribute => attribute.AttributeId == (long)ApplicationFormFieldAttributes.MaxFileUploadSize);
        Assert.NotNull(formFieldAttributeFromDB);
        Assert.NotNull(formFieldAttributeFromDB.AttributeValue);
        Assert.Empty(formFieldAttributeFromDB.AttributeValue);
        Assert.True(string.IsNullOrWhiteSpace(formFieldAttributeFromDB.AttributeValue));
        Assert.True(formFieldAttributeFromDB.AttributeId == (long)ApplicationFormFieldAttributes.MaxFileUploadSize);
        Assert.True(formFieldAttributeFromDB.AttributeValue == attributeValue);
    }

    [Fact]
    public async Task ShouldGetApplicationForm()
    {
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "" } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "Alternate Phone Number", TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form" + DateTime.Now.Ticks, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getForm.Result);
        var formResult = Assert.IsType<OkObjectResult>(getForm.Result);
        Assert.NotNull(formResult.Value);
        ApplicationFormDto formFromDB = (ApplicationFormDto)formResult.Value;
        Assert.NotNull(formFromDB);
        Assert.NotNull(formFromDB.Name);
        Assert.NotEmpty(formFromDB.Name);
        Assert.True(formFromDB.Name == formDto.Name);
    }

    [Fact]
    public async Task ShouldReturnNullWhenFormNotExists()
    {
        var formDto = await _applicationFormService.GetApplicationFormWithActiveFieldsByIdAsync(0);
        Assert.Null(formDto);
    }

    #endregion Get Form Tests

    #region Update Form Tests

    [Fact]
    public async Task ShouldPersistNewOrderInDBWhenFieldsAreReordered()
    {
        //create new form with two fields and set some order, setting few other mandatory properties for each field
        //to avoid exception
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
            [
                new()
                { Name = "First Name", DisplayOrder = 1, IsSystemDefault = true, IsAlwaysActiveAndRequired = true, IsActive = true, IsRequired = true, SectionId = 1, TypeId = 4 },
                new()
                { Name = "Last Name", DisplayOrder = 2, IsSystemDefault = true, IsAlwaysActiveAndRequired = true, IsActive = true, IsRequired = true, SectionId = 1, TypeId = 4 }
            ]
        };
        var newFormResult = await _formController.Create(formDTO);
        var okResult = newFormResult.Result as OkObjectResult;
        var response = okResult?.Value as CreatedResponse;
        var formId = response?.Id;

        Assert.NotNull(formId);

        //get the form
        var getFormResult = await _formController.GetById((long)formId);
        okResult = getFormResult.Result as OkObjectResult;
        var dbForm = okResult?.Value as ApplicationFormDto;

        Assert.NotNull(dbForm);
        Assert.NotNull(dbForm.Fields);

        //change the order of the fields in the form
        dbForm.Fields[0].DisplayOrder = 2;
        dbForm.Fields[1].DisplayOrder = 1;
        await _formController.Update(dbForm);

        //get the form again
        getFormResult = await _formController.GetById((long)formId);
        okResult = getFormResult.Result as OkObjectResult;
        dbForm = okResult?.Value as ApplicationFormDto;

        Assert.NotNull(dbForm);
        Assert.NotNull(dbForm.Fields);

        //check if the order is saved in database correctly
        Assert.True(dbForm.Fields[0].DisplayOrder == 2 && dbForm.Fields[1].DisplayOrder == 1);
    }

    [Fact]
    public async Task ShouldNotUpdateCompanyId()
    {
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "" } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "Alternate Phone Number", TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form" + DateTime.Now.Ticks, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getFormAfterSave = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getFormAfterSave.Result);
        var savedFormResult = Assert.IsType<OkObjectResult>(getFormAfterSave.Result);
        Assert.NotNull(savedFormResult.Value);
        ApplicationFormDto savedFormFromDB = (ApplicationFormDto)savedFormResult.Value;
        Assert.NotNull(savedFormFromDB);

        savedFormFromDB.Name = "Form04";
        savedFormFromDB.Id = createdResponse.Id;
        await _formController.Update(savedFormFromDB);
        var form = await _applicationFormRepository.GetByIdAsync<ApplicationForm>(createdResponse.Id);
        Assert.NotNull(form);
        Assert.Equal(form.CompanyId, _currentUserContext.CompanyId);
    }

    [Fact]
    public async Task ShouldNotUpdateFormName()
    {
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "" } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "Alternate Phone Number", TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form" + DateTime.Now.Ticks, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getFormAfterSave = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getFormAfterSave.Result);
        var savedFormResult = Assert.IsType<OkObjectResult>(getFormAfterSave.Result);
        Assert.NotNull(savedFormResult.Value);
        ApplicationFormDto savedFormFromDB = (ApplicationFormDto)savedFormResult.Value;
        Assert.NotNull(savedFormFromDB);
        Assert.NotNull(savedFormFromDB.Name);
        Assert.NotEmpty(savedFormFromDB.Name);
        Assert.True(savedFormFromDB.Name == formDto.Name);
        Assert.True(savedFormFromDB.Fields?.Count > 0);

        savedFormFromDB.Name = "Form04";
        savedFormFromDB.Id = createdResponse.Id;
        await _formController.Update(savedFormFromDB);
        var afterUpdateGetForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(afterUpdateGetForm.Result);
        var afterUpdateFormResult = Assert.IsType<OkObjectResult>(afterUpdateGetForm.Result);
        Assert.NotNull(afterUpdateFormResult.Value);
        ApplicationFormDto afterUpdateformFromDB = (ApplicationFormDto)afterUpdateFormResult.Value;
        Assert.NotNull(afterUpdateformFromDB);
        Assert.NotNull(afterUpdateformFromDB.Name);
        Assert.NotEmpty(afterUpdateformFromDB.Name);
        Assert.True(afterUpdateformFromDB.Name == formDto.Name);
        Assert.True(afterUpdateformFromDB.Name != savedFormFromDB.Name);
    }

    [Fact]
    public async Task ShouldUpdateFormFieldToActiveStatus()
    {
        var fieldName = "Alternate Phone Number";
        bool isActive = true;
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "" } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = isActive, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = fieldName, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form04", IsActive = true, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);
        var getFormAfterSave = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getFormAfterSave.Result);
        var savedFormResult = Assert.IsType<OkObjectResult>(getFormAfterSave.Result);
        Assert.NotNull(savedFormResult.Value);
        ApplicationFormDto savedFormFromDB = (ApplicationFormDto)savedFormResult.Value;
        Assert.NotNull(savedFormFromDB);
        Assert.True(savedFormFromDB.Name == formDto.Name);
        Assert.True(savedFormFromDB.Fields?.Count > 0);

        var savedFormFromDBFields = savedFormFromDB.Fields.Find(field => field.Name == fieldName);
        bool updateStatus = false;
        Assert.NotNull(savedFormFromDBFields);
        savedFormFromDBFields.IsActive = updateStatus;
        savedFormFromDB.Id = createdResponse.Id;
        await _formController.Update(savedFormFromDB);
        var afterUpdateGetForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(afterUpdateGetForm.Result);
        var afterUpdateFormResult = Assert.IsType<OkObjectResult>(afterUpdateGetForm.Result);
        Assert.NotNull(afterUpdateFormResult.Value);
        ApplicationFormDto afterUpdateformFromDB = (ApplicationFormDto)afterUpdateFormResult.Value;
        Assert.NotNull(afterUpdateformFromDB);
        Assert.NotNull(afterUpdateformFromDB.Name);
        Assert.NotEmpty(afterUpdateformFromDB.Name);
        Assert.NotNull(afterUpdateformFromDB.Fields);
        var updatedFromFromDBFields = afterUpdateformFromDB.Fields.Find(field => field.Name == fieldName);
        Assert.NotNull(updatedFromFromDBFields);
        Assert.True(updatedFromFromDBFields.IsActive != isActive);
        Assert.True(updatedFromFromDBFields.IsActive == updateStatus);
    }

    [Fact]
    public async Task ShouldFailToUpdateApplicationFormWhenRecordIdIsZero()
    {
        var formDto = new ApplicationFormDto { Name = "form1", IsActive = true };

        await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _formController.Update(formDto));
    }

    [Fact]
    public async Task ShouldFailToUpdateApplicationFormWhenInvalidRecordIdPassed()
    {
        var formDto = new ApplicationFormDto { Id = 1000000, Name = "form1", IsActive = true };

        await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _formController.Update(formDto));
    }

    [Fact]
    public async Task ShouldUpdateFormToActiveStatus()
    {
        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "" } };
        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "Alternate Phone Number", TypeId = (long)ApplicationFormFieldTypes.SingleLineInput, AttributeValues = formFieldAttributeValues } };
        var formDto = new ApplicationFormDto { Name = "form004", IsActive = true, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);
        var getFormAfterSave = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(getFormAfterSave.Result);
        var savedFormResult = Assert.IsType<OkObjectResult>(getFormAfterSave.Result);
        Assert.NotNull(savedFormResult.Value);
        ApplicationFormDto savedFormFromDB = (ApplicationFormDto)savedFormResult.Value;
        Assert.NotNull(savedFormFromDB);
        Assert.True(savedFormFromDB.IsActive == formDto.IsActive);
        Assert.True(savedFormFromDB.Name == formDto.Name);
        Assert.True(savedFormFromDB.Fields?.Count > 0);
        savedFormFromDB.Id = createdResponse.Id;
        savedFormFromDB.IsActive = false;
        await _formController.Update(savedFormFromDB);
        var afterUpdateGetForm = await _formController.GetById(createdResponse.Id);
        Assert.NotNull(afterUpdateGetForm.Result);
        var afterUpdateFormResult = Assert.IsType<OkObjectResult>(afterUpdateGetForm.Result);
        Assert.NotNull(afterUpdateFormResult.Value);
        ApplicationFormDto afterUpdateformFromDB = (ApplicationFormDto)afterUpdateFormResult.Value;
        Assert.NotNull(afterUpdateformFromDB);
        Assert.NotNull(afterUpdateformFromDB.Name);
        Assert.NotEmpty(afterUpdateformFromDB.Name);
        Assert.True(afterUpdateformFromDB.IsActive != formDto.IsActive);
        Assert.True(afterUpdateformFromDB.IsActive == savedFormFromDB.IsActive);
    }

    [Fact]
    public async Task ShouldDeleteFieldsFromDatabaseWhenFieldsRemoved()
    {
        //create form
        var formId = await CreateApplicationForm();
        Assert.NotNull(formId);
        Assert.True(formId.Value > 0);

        //get the form
        var dbForm = await GetApplicationFormById(formId.Value);
        Assert.NotNull(dbForm);
        Assert.NotNull(dbForm.Fields);

        //remove a field
        dbForm.Fields.RemoveAll(field => field.Name == "city" || field.Name == "state");
        await _formController.Update(dbForm);

        //get the form again
        dbForm = await GetApplicationFormById(formId.Value);
        Assert.NotNull(dbForm);
        Assert.NotNull(dbForm.Fields);

        //check if the field deleted successfully
        Assert.True(dbForm.Fields.Exists(field => field.Name == "First Name"));
        Assert.False(dbForm.Fields.Exists(field => field.Name == "city"));
        Assert.False(dbForm.Fields.Exists(field => field.Name == "state"));
    }

    [Fact]
    public async Task ShouldRemoveFormFieldAttributeValuesFromDBWhenRemovedFromDTO()
    {
        //create form
        var formId = await CreateApplicationForm();
        Assert.NotNull(formId);

        //get the form
        var form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        //remove attributes for city fields
        var cityField = form.Fields.Find(field => field.Name == "city");
        Assert.True(cityField != null && cityField.AttributeValues != null);
        cityField.AttributeValues.Clear();

        await _formController.Update(form);

        //get the form
        form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        cityField = form.Fields.Find(field => field.Name == "city");

        //make sure that city field doesn't have any attribute values
        Assert.True(cityField != null && (cityField.AttributeValues == null || cityField.AttributeValues.Count == 0));
    }

    [Fact]
    public async Task ShouldRemoveFormFieldOptionsFromDBWhenRemovedFromDTO()
    {
        //create form
        var formId = await CreateApplicationForm();
        Assert.NotNull(formId);

        //get the form
        var form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        //remove attributes for city fields
        var stateField = form.Fields.Find(field => field.Name == "state");
        Assert.True(stateField != null && stateField.Options != null);
        stateField.Options.Clear();

        await _formController.Update(form);

        //get the form
        form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        stateField = form.Fields.Find(field => field.Name == "state");

        //make sure that city field doesn't have any attribute values
        Assert.True(stateField != null && (stateField.Options == null || stateField.Options.Count == 0));
    }

    [Fact]
    public async Task ShouldAddFormFieldOptionsInDBWhenAddedInDTO()
    {
        //create form
        var formId = await CreateApplicationForm();
        Assert.NotNull(formId);

        //get the form
        var form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        var stateField = form.Fields.Find(field => field.Name == "state");
        Assert.True(stateField != null && stateField.Options != null);

        //add new option for state field
        stateField.Options.Add(new() { Name = "New York" });

        //update existing option for state field
        var existingOption = stateField.Options.Find(option => option.Name == "Illinois");
        Assert.NotNull(existingOption);
        existingOption.Name = "Washington";

        await _formController.Update(form);

        //get the form
        form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        stateField = form.Fields.Find(field => field.Name == "state");
        Assert.True(stateField != null && stateField.Options != null);

        //assert that new option is added
        var newYorkStateOption = stateField.Options.Find(option => option.Name == "New York");
        Assert.NotNull(newYorkStateOption);

        //assert no option exists with old name
        var illinoisStateOption = stateField.Options.Find(option => option.Name == "Illinois");
        Assert.Null(illinoisStateOption);

        //assert that option exists with new name
        var washingtonStateOption = stateField.Options.Find(option => option.Name == "Washington");
        Assert.NotNull(washingtonStateOption);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenAlwaysActiveFieldIsMadeInActive()
    {
        //create form
        var formId = await CreateApplicationForm();
        Assert.NotNull(formId);

        //get the form
        var form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        var firstNameField = form.Fields.First(field => field.Name == "First Name");
        Assert.NotNull(firstNameField);

        firstNameField.IsActive = false;

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _formController.Update(form));
        Assert.Equal(string.Format(ErrorMessages.FormFieldInactive, "First Name"), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenRequiredFieldIsMadeOptional()
    {
        //create form
        var formId = await CreateApplicationForm();
        Assert.NotNull(formId);

        //get the form
        var form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        var firstNameField = form.Fields.First(field => field.Name == "First Name");
        Assert.NotNull(firstNameField);

        firstNameField.IsRequired = false;

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _formController.Update(form));
        Assert.Equal(string.Format(ErrorMessages.FormFieldOptionalMandatory, "First Name"), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenADefaultFieldWhichHasIsAlwaysActiveAndRequiredFlagMadeAsOptional()
    {
        //create form
        var formId = await CreateApplicationForm();
        Assert.NotNull(formId);

        //get the form
        var form = await GetApplicationFormById(formId.Value);
        Assert.True(form != null && form.Fields != null);

        var firstNameField = form.Fields.First(field => field.Name == "First Name");
        Assert.NotNull(firstNameField);

        firstNameField.IsRequired = false;

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _formController.Update(form));
        Assert.Equal(string.Format(ErrorMessages.FormFieldOptionalMandatory, "First Name"), exception.Message);
    }

    [Fact]
    public async Task ShouldUpdateWhenOptionalDefaultFieldIsMadeActive()
    {
        //create form
        var formDto = new ApplicationFormDto
        {
            Name = "form004" + DateTime.Now.Ticks,
            Fields =
            [
                new()
                {
                    Name = "First Name",
                    DisplayOrder = 1,
                    IsSystemDefault = true,
                    IsAlwaysActiveAndRequired = true,
                    IsActive = true,
                    IsRequired = true,
                    SectionId = 1,
                    TypeId = 4
                },
                new()
                {
                    Name = "Cover Letter",
                    DisplayOrder = 15,
                    IsSystemDefault = true,
                    IsAlwaysActiveAndRequired = false,
                    IsActive = false,
                    IsRequired = false,
                    SectionId = 1,
                    TypeId = 4
                }]
        };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        //get the form
        var form = await GetApplicationFormById(createdResponse.Id);
        Assert.True(form != null && form.Fields != null);

        var coverLetterField = form.Fields.First(field => field.Name == "Cover Letter");
        Assert.NotNull(coverLetterField);

        coverLetterField.IsActive = true;

        await _formController.Update(form);

        //get the form
        var formAfterUpdate = await GetApplicationFormById(createdResponse.Id);
        Assert.True(formAfterUpdate != null && formAfterUpdate.Fields != null);

        var coverLetterFieldAfterUpdate = formAfterUpdate.Fields.Find(field => field.Name == "Cover Letter");
        Assert.NotNull(coverLetterFieldAfterUpdate);
        Assert.NotNull(coverLetterFieldAfterUpdate.Name);
        Assert.NotEmpty(coverLetterFieldAfterUpdate.Name);
        Assert.True(coverLetterFieldAfterUpdate.IsActive == coverLetterField.IsActive);
    }

    [Fact]
    public async Task ShouldUpdateWhenOptionalDefaultFieldIsMadeInActive()
    {
        //create form
        var formDto = new ApplicationFormDto
        {
            Name = "form004" + DateTime.Now.Ticks,
            Fields =
            [
               new()
               {
                   Name = "Cover Letter",
                   DisplayOrder = 15,
                   IsSystemDefault = true,
                   IsAlwaysActiveAndRequired = false,
                   IsActive = true,
                   IsRequired = false,
                   SectionId = 1,
                   TypeId = 4
               }]
        };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);

        //get the form
        var form = await GetApplicationFormById(createdResponse.Id);
        Assert.True(form != null && form.Fields != null);

        var coverLetterField = form.Fields.First(field => field.Name == "Cover Letter");
        Assert.NotNull(coverLetterField);

        coverLetterField.IsActive = false;

        await _formController.Update(form);

        //get the form
        var formAfterUpdate = await GetApplicationFormById(createdResponse.Id);
        Assert.True(formAfterUpdate != null && formAfterUpdate.Fields != null);

        var coverLetterFieldAfterUpdate = formAfterUpdate.Fields.Find(field => field.Name == "Cover Letter");
        Assert.NotNull(coverLetterFieldAfterUpdate);
        Assert.NotNull(coverLetterFieldAfterUpdate.Name);
        Assert.NotEmpty(coverLetterFieldAfterUpdate.Name);
        Assert.True(coverLetterFieldAfterUpdate.IsActive == coverLetterField.IsActive);
    }

    #endregion Update Form Tests

    #region Private Methods

    private async Task<long?> CreateApplicationForm()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                    new()
                    {
                        Name = "First Name",
                        DisplayOrder = 1,
                        IsSystemDefault = true,
                        IsAlwaysActiveAndRequired = true,
                        IsActive = true,
                        IsRequired = true,
                        SectionId = 1,
                        TypeId = 4
                    },
                    new()
                    {
                        Name = "city",
                        DisplayOrder = 2,
                        IsSystemDefault = false,
                        IsAlwaysActiveAndRequired = false,
                        IsActive = true,
                        IsRequired = false,
                        SectionId = 4,
                        TypeId = 4,
                        AttributeValues =
                    [
                        new() { AttributeId = (long)ApplicationFormFieldAttributes.TextValue, AttributeValue = "100" }
                    ]
                    },
                    new()
                    {
                        Name = "state",
                        DisplayOrder = 3,
                        IsSystemDefault = false,
                        IsAlwaysActiveAndRequired = false,
                        IsActive = true,
                        IsRequired = false,
                        SectionId = 4,
                        TypeId = 1,
                        Options =
                    [
                        new() { Name = "Illinois" },
                        new() { Name = "California" }
                    ]
                    },
                ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = newFormResult.Result as OkObjectResult;
        var response = okResult?.Value as CreatedResponse;
        var formId = response?.Id;
        return formId;
    }

    private async Task<ApplicationFormDto?> GetApplicationFormById(long formId)
    {
        var getFormResult = await _formController.GetById(formId);
        var okResult = getFormResult.Result as OkObjectResult;
        var formDTO = okResult?.Value as ApplicationFormDto;
        return formDTO;
    }

    private async Task<long?> CreateApplicationFormWithAllDefaultFields()
    {
        var defaultFields = await GetApplicationFormDefaultFields();
        Assert.NotNull(defaultFields);
        var fields = defaultFields.Select(field => new ApplicationFormFieldDto
        {
            Name = field.Name,
            DisplayOrder = field.DisplayOrder,
            IsSystemDefault = true,
            IsActive = field.IsActive,
            IsAlwaysActiveAndRequired = field.IsAlwaysActiveAndRequired,
            IsRequired = field.IsRequired,
            SectionId = field.SectionId,
            TypeId = field.TypeId
        })
        .ToList();

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields = fields
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);
        return response.Id;
    }

    public async Task<IEnumerable<ApplicationFormDefaultFieldDto>?> GetApplicationFormDefaultFields()
    {
        //Act
        return await _metaDataService.GetApplicationFormDefaultFieldsAsync();
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}