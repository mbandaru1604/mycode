﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests
{
    public class ApplicationFormFieldDTOValidatorTests
    {
        private readonly ApplicationFormFieldDtoValidator _validator;

        public ApplicationFormFieldDTOValidatorTests()
        {
            _validator = new ApplicationFormFieldDtoValidator();
        }

        [Fact]
        public void Name_Valid_NoEror()
        {
            var formFieldDTO = new ApplicationFormFieldDto { Name = "Location" };
            var result = _validator.TestValidate(formFieldDTO);
            result.ShouldNotHaveValidationErrorFor(field => field.Name);
        }

        [Fact]
        public void Name_Null_ReturnEror()
        {
            var formFieldDTO = new ApplicationFormFieldDto { Name = null };
            var result = _validator.TestValidate(formFieldDTO);
            result.ShouldHaveValidationErrorFor(field => field.Name);
        }

        [Fact]
        public void Name_Empty_ReturnEror()
        {
            var formFieldDTO = new ApplicationFormFieldDto { Name = string.Empty };
            var result = _validator.TestValidate(formFieldDTO);
            result.ShouldHaveValidationErrorFor(field => field.Name);
        }

        [Fact]
        public void Name_MaxLengthExceeded_ReturnEror()
        {
            var formFieldDTO = new ApplicationFormFieldDto { Name = "012345678901234567890123456789012345678901234567890123456789" };
            var result = _validator.TestValidate(formFieldDTO);
            result.ShouldHaveValidationErrorFor(field => field.Name);
        }

        [Fact]
        public void ShouldFailForDuplicateCustomFieldOptionName()
        {
            var duplicateOptionName = "New York";
            var Options = new List<ApplicationFormFieldOptionDto> {
                            new() {Name = "Washington Washington Washington"},
                            new() {Name = "New York"},
                            new() {Name = "New York"}};
            var formFieldDto = new ApplicationFormFieldDto { Name = "state", TypeId = (long)ApplicationFormFieldTypes.Dropdown, Options = Options };
            var result = _validator.TestValidate(formFieldDto);
            Assert.IsType<TestValidationResult<ApplicationFormFieldDto>>(result);
            var validationResult = result.ShouldHaveValidationErrorFor(formFieldOption => formFieldOption.Options);
            Assert.True(validationResult.Any());
            Assert.True(validationResult.First() != null);
            Assert.True(!string.IsNullOrWhiteSpace(validationResult.First().ErrorMessage));
            Assert.True(validationResult.First().ErrorMessage == string.Format(DropdownValidation.OptionNameExists, duplicateOptionName));
        }

        [Fact]
        public void ShouldFailForEmptyCustomFieldOption()
        {
            var Options = new List<ApplicationFormFieldOptionDto>();
            var formFieldDto = new ApplicationFormFieldDto { Name = "state", TypeId = (long)ApplicationFormFieldTypes.Dropdown, Options = Options };
            var result = _validator.TestValidate(formFieldDto);
            Assert.IsType<TestValidationResult<ApplicationFormFieldDto>>(result);
            var validationResult = result.ShouldHaveValidationErrorFor(formFieldOption => formFieldOption.Options);
            Assert.True(validationResult.Any());
            Assert.True(validationResult.First() != null);
            Assert.True(!string.IsNullOrWhiteSpace(validationResult.First().ErrorMessage));
            Assert.True(validationResult.First().ErrorMessage == FormFieldValidation.DropdownOptionsEmptyErrorMessage);
        }
    }
}