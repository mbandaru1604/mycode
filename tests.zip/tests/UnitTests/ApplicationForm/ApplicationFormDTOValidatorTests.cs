﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests
{
    public class ApplicationFormDTOValidatorTests
    {
        private readonly ApplicationFormDtoValidator _validator;

        public ApplicationFormDTOValidatorTests()
        {
            _validator = new ApplicationFormDtoValidator();
        }

        [Fact]
        public void Name_Valid_NoEror()
        {
            var formDTO = new ApplicationFormDto { Name = "form1" };
            var result = _validator.TestValidate(formDTO);
            result.ShouldNotHaveValidationErrorFor(f => f.Name);
        }

        [Fact]
        public void Name_Null_ReturnEror()
        {
            var formDTO = new ApplicationFormDto { Name = null };
            var result = _validator.TestValidate(formDTO);
            result.ShouldHaveValidationErrorFor(f => f.Name);
        }

        [Fact]
        public void Name_Empty_ReturnEror()
        {
            var formDTO = new ApplicationFormDto { Name = string.Empty };
            var result = _validator.TestValidate(formDTO);
            result.ShouldHaveValidationErrorFor(f => f.Name);
        }

        [Fact]
        public void Name_MaxLengthExceeded_ReturnEror()
        {
            var formDTO = new ApplicationFormDto { Name = "012345678901234567890123456789012345678901234567890123456789" };
            var result = _validator.TestValidate(formDTO);
            result.ShouldHaveValidationErrorFor(f => f.Name);
        }

        [Fact]
        public void ShouldFailForDuplicateFormFieldName()
        {
            var duplicatefieldName = "state";
            var fields = new List<ApplicationFormFieldDto> {
                new() {Name = "state"},
                new() {Name = "state"}
               };
            var formDTO = new ApplicationFormDto { Name = "form1", Fields = fields };
            var result = _validator.TestValidate(formDTO);
            Assert.IsType<TestValidationResult<ApplicationFormDto>>(result);
            var validationResult = result.ShouldHaveValidationErrorFor(formFields => formFields.Fields);
            Assert.True(validationResult.Any());
            Assert.True(validationResult.First() != null);
            Assert.True(!string.IsNullOrWhiteSpace(validationResult.First().ErrorMessage));
            Assert.True(validationResult.First().ErrorMessage == string.Format(FormFieldValidation.FormFieldNameExists, duplicatefieldName));
        }
    }
}