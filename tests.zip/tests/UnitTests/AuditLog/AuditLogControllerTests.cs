﻿using BBSI.ATS.API.Controllers;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Moq;

namespace BBSI.ATS.UnitTests.AuditLog
{
    public class AuditLogControllerTests : IDisposable
    {
        private readonly Mock<IAuditLogService> _mockAuditLogService;
        private readonly Mock<ICosmosDbService> _mockCosmosDbService;
        private readonly CurrentUserContext _currentUserContext;
        private readonly AuditLogService _auditLogService;
        private readonly Mock<Container> _mockContainer;
        private readonly CosmosDbService _cosmosDbService;

        private readonly AuditLogsController _controller;

        private bool disposed = false;

        public AuditLogControllerTests()
        {
            _mockCosmosDbService = new Mock<ICosmosDbService>();
            _auditLogService = new AuditLogService(_mockCosmosDbService.Object);
            _mockAuditLogService = new Mock<IAuditLogService>();
            _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
            _controller = new AuditLogsController(_mockAuditLogService.Object, _currentUserContext);
            _mockContainer = new Mock<Container>();
        }

        [Fact]
        public async Task ShouldGetListWhenAuditLogsExist()
        {
            // Arrange
            var auditLogRequestDto = new AuditLogRequestDto();
            var auditLogs = new PaginatedAuditLogDto(); // Assuming this is a valid response
            _mockAuditLogService.Setup(service => service.GetListAsync(auditLogRequestDto))
                .ReturnsAsync(auditLogs);

            // Act
            var result = await _controller.GetListAsync(auditLogRequestDto);

            // Assert
            var actionResult = Assert.IsType<ActionResult<PaginatedAuditLogDto>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            Assert.Equal(auditLogs, okResult.Value);
        }

        [Fact]
        public async Task ShouldReturnsNoContentWhenNoAuditLogsExist()
        {
            // Arrange
            var auditLogRequestDto = new AuditLogRequestDto();
            _mockAuditLogService.Setup(service => service.GetListAsync(auditLogRequestDto))
                .ReturnsAsync((PaginatedAuditLogDto)null);

            // Act
            var result = await _controller.GetListAsync(auditLogRequestDto);

            // Assert
            var actionResult = Assert.IsType<ActionResult<PaginatedAuditLogDto>>(result);
            Assert.IsType<NoContentResult>(actionResult.Result);
        }

        [Fact]
        public async Task ShouldReturnPaginatedAuditLogResults()
        {
            // Arrange
            var auditLogs = new List<AuditLogListDto>
            {
                new AuditLogListDto {  Id= "60e9ff15-d69a-453b-a29f-80604fa33ef2", EventDateTime=DateTime.UtcNow, Identifier= "PR Manager",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.JobPosts.ToString(),Section= SectionName.EditJobPost.ToString(),
                    FieldChanged= "Work Arrangement",BeforeValue= "Remote",AfterValue= "Hybrid"},

                new AuditLogListDto {  Id= "d07c4580-ff22-4251-b3db-be18c1f5370d", EventDateTime=DateTime.UtcNow, Identifier= "John Doe",
                                     ModifiedByUserEmail = _currentUserContext.UserEmail, Page= PageName.JobPosts.ToString(),Section= SectionName.EditJobPost.ToString(),
                    FieldChanged= "Job Title",BeforeValue= "Fullstack developer twentyone 4434",AfterValue= "Fullstack developer twentyone 3468 one"
                }
            };
            var requestDto = new AuditLogRequestDto { PageNumber = 1, PageSize = 1, SortByField = "eventDateTime", IsAscendingOrder = true };

            _mockCosmosDbService
                .Setup(s => s.GetListAsync(requestDto))
                .ReturnsAsync(auditLogs);

            // Act
            var result = await _auditLogService.GetListAsync(requestDto);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result.AuditLogs); // Only one item per page
            Assert.Equal(2, result.TotalCount);
            Assert.Equal(1, result.PageNumber);
            Assert.Equal(1, result.PageSize);
        }

        [Fact]
        public async Task ShouldReturnPagedResultsWhenSearchParametersAreValid()
        {
            // Arrange
            var requestDto = new AuditLogRequestDto
            {
                PageNumber = 1,
                PageSize = 10,
                SearchTerm = "Remote",
                SortByField = "EventDateTime",
                IsAscendingOrder = true,
                Pages = new List<string> { PageName.JobPosts.ToString() },
                Sections = new List<string> { SectionName.EditJobPost.ToString() },
                ModifiedByUsers = new List<string> { "eyoung@bbsi.com" },
                FromDate = new DateOnly(2023, 1, 1),
                ToDate = new DateOnly(2023, 12, 31)
            };

            var auditLogs = new List<AuditLogListDto>
            {
                new AuditLogListDto {  Id= "60e9ff15-d69a-453b-a29f-80604fa33ef2", EventDateTime=DateTime.UtcNow, Identifier= "PR Manager",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.JobPosts.ToString(),
                    Section=SectionName.EditJobPost.ToString(),
                    FieldChanged= "Work Arrangement",BeforeValue= "Remote",AfterValue= "Hybrid"}
              };

            // Act
            _mockCosmosDbService
            .Setup(s => s.GetListAsync(requestDto))
            .ReturnsAsync(auditLogs);

            var result = await _auditLogService.GetListAsync(requestDto);
            // Assert
            Assert.NotNull(result);
            Assert.Single(result.AuditLogs); // Verify that the correct number of logs is returned.
            Assert.Equal(1, result.TotalCount);
        }

        [Fact]
        public async Task SearchAuditLogsShouldHandleEmptyResultsWhenNoLogsMatch()
        {
            // Arrange
            var requestDto = new AuditLogRequestDto
            {
                PageNumber = 1,
                PageSize = 10,
                SearchTerm = "NonExistent",
                SortByField = "Date",
                IsAscendingOrder = true,
                Pages = new List<string> { "Home" },
                Sections = new List<string> { "Auth" },
                ModifiedByUsers = new List<string> { _currentUserContext.UserEmail },
                FromDate = new DateOnly(2023, 1, 1),
                ToDate = new DateOnly(2023, 12, 31)
            };

            // Act
            var result = await _auditLogService.GetListAsync(requestDto);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task ShouldReturnAuditLogList()
        {
            // Arrange
            var auditLogRequestDto = new AuditLogRequestDto()
            {
                PageNumber = 1,
                PageSize = 100
            };

            // Act
            var auditLogs = new List<AuditLogListDto>
            {
                new AuditLogListDto {  Id= "60e9ff15-d69a-453b-a29f-80604fa33ef2", EventDateTime=DateTime.UtcNow, Identifier= "PR Manager",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.JobPosts.ToString(),Section= SectionName.EditJobPost.ToString(),
                    FieldChanged= "Work Arrangement",BeforeValue= "Remote",AfterValue= "Hybrid"},

                new AuditLogListDto {  Id= "d07c4580-ff22-4251-b3db-be18c1f5370d", EventDateTime=DateTime.UtcNow, Identifier= "John Doe",
                                     ModifiedByUserEmail = _currentUserContext.UserEmail, Page= PageName.JobPosts.ToString(),Section= SectionName.EditJobPost.ToString(),
                    FieldChanged= "Job Title",BeforeValue= "Fullstack developer twentyone 4434",AfterValue= "Fullstack developer twentyone 3468 one"
                }
            };

            var mockCosmosDbService = new Mock<ICosmosDbService>();
            mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                               .ReturnsAsync(auditLogs);

            var auditLogService = new AuditLogService(mockCosmosDbService.Object);

            var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

            var result = await auditLogsController.GetListAsync(auditLogRequestDto);

            // Assert
            Assert.IsType<OkObjectResult>(result.Result);
        }

        [Fact]
        public async Task ShouldReturnPagedResultsWhenFilterParametersAreValid()
        {
            // Arrange
            var requestDto = new AuditLogRequestDto
            {
                PageNumber = 1,
                PageSize = 10,
                SearchTerm = "",
                SortByField = "EventDateTime",
                IsAscendingOrder = true,
                Pages = new List<string> { PageName.JobPosts.ToString(), PageName.JobCategories.ToString() },
                Sections = new List<string> { SectionName.EditJobPost.ToString(), SectionName.AddCategory.ToString() },
                ModifiedByUsers = new List<string> { "eyoung@bbsi.com" },
                FromDate = new DateOnly(2023, 1, 1),
                ToDate = new DateOnly(2023, 12, 31)
            };

            var auditLogs = new List<AuditLogListDto>
            {
                new AuditLogListDto {  Id= "60e9ff15-d69a-453b-a29f-80604fa33ef2", EventDateTime=DateTime.UtcNow, Identifier= "PR Manager",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.JobPosts.ToString(),
                    Section=SectionName.EditJobPost.ToString(),
                    FieldChanged= "Work Arrangement",BeforeValue= "Remote",AfterValue= "Hybrid"}
              };

            // Act
            _mockCosmosDbService
            .Setup(cosmosService => cosmosService.GetListAsync(requestDto))
            .ReturnsAsync(auditLogs);

            var result = await _auditLogService.GetListAsync(requestDto);
            // Assert
            Assert.NotNull(result);
            Assert.Single(result.AuditLogs); // Verify that the correct number of logs is returned.
            Assert.Equal(1, result.TotalCount);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}