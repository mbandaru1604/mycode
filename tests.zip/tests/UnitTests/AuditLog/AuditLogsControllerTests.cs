﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Extensions;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace BBSI.ATS.UnitTests;

public class AuditLogsControllerTests : IDisposable
{
    private readonly AtsDbContext _dbContext;
    private readonly CurrentUserContext _currentUserContext;
    private readonly JobPostCategoryService _jobPostCategoryService;
    private readonly JobPostCategoryRepository _jobPostCategoryRepository;
    private readonly ApplicationFormService _applicationFormService;
    private readonly ApplicationFormsController _formController;

    private bool disposed = false;

    public AuditLogsControllerTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1, CompanyCode = 111111, UserEmail = "johndue@bbsi.com" };
        _jobPostCategoryRepository = new JobPostCategoryRepository(_dbContext, _currentUserContext);
        var applicationFormRepository = new ApplicationFormRepository(_dbContext, _currentUserContext);

        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        IMapper mapper = mappingConfig.CreateMapper();

        var mockCosmosDbService = new Mock<ICosmosDbService>();
        var formFieldComparer = new ApplicationFormFieldComparer();
        var applicationFormComparer = new ApplicationFormComparer(formFieldComparer);

        _applicationFormService = new ApplicationFormService(applicationFormRepository, mapper, _currentUserContext, mockCosmosDbService.Object, applicationFormComparer);
        _formController = new ApplicationFormsController(_applicationFormService);

        _jobPostCategoryService = new JobPostCategoryService(_jobPostCategoryRepository, mapper, _currentUserContext, mockCosmosDbService.Object);
    }

    #region Application Form tests

    [Fact]
    public async Task AddItemForApplicationFormShouldReturnCreatedAtActionResult()
    {
        var formDto = new ApplicationFormDto()
        {
            Name = "Form1",
            IsActive = true,
            Fields = [
                new(){
                    DefaultFieldId = (long)ApplicationFormDefaultFields.FirstName,
                    Name = ApplicationFormDefaultFields.FirstName.GetEnumDisplayName(),
                    DisplayOrder = 1,
                    IsActive = true,
                    IsRequired = true,
                    IsAlwaysActiveAndRequired = true,
                    IsSystemDefault = true,
                    SectionId = (long)ApplicationFormSections.PersonalInformation,
                    TypeId = (long)ApplicationFormFieldTypes.SingleLineInput
                }
                ]
        };

        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);

        var requestDto = new AuditLogRequestDto
        {
            PageNumber = 1,
            PageSize = 10,
            SortByField = "userName",
            IsAscendingOrder = true,
            Pages = new List<string> { PageName.AddFormOrEditForm.GetEnumDisplayName() },
            Sections = new List<string> { SectionName.Application.ToString() },
            ModifiedByUsers = new List<string> { _currentUserContext.UserEmail! },
        };

        var auditLogs = new List<AuditLogListDto>
            {
                new AuditLogListDto {  Id= Guid.NewGuid().ToString(), EventDateTime=DateTime.UtcNow, Identifier= "Test Form for Cosmos DB",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.AddFormOrEditForm.ToString(),
                    Section=SectionName.Application.ToString(),
                    FieldChanged= "Name",BeforeValue= "",AfterValue= "Form1"},
                new AuditLogListDto {  Id= Guid.NewGuid().ToString(), EventDateTime=DateTime.UtcNow, Identifier= "Test Form for Cosmos DB",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.AddFormOrEditForm.ToString(),
                    Section=SectionName.Application.ToString(),
                    FieldChanged= "IsActive",BeforeValue= "false",AfterValue= "true"},
                new AuditLogListDto {  Id= Guid.NewGuid().ToString(), EventDateTime=DateTime.UtcNow, Identifier= "Test Form for Cosmos DB",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.AddFormOrEditForm.ToString(),
                    Section=SectionName.Application.ToString(),
                    FieldChanged= "Name",BeforeValue= "",AfterValue= "FirstName"},
              };

        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(auditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var auditListResult = await auditLogsController.GetListAsync(requestDto);

        var okResult = Assert.IsType<OkObjectResult>(auditListResult.Result);
        var paginatedDto = Assert.IsType<PaginatedAuditLogDto>(okResult.Value);
        Assert.NotNull(paginatedDto);
        Assert.NotNull(paginatedDto.AuditLogs);
        Assert.Equal(auditLogs.Count, paginatedDto.AuditLogs.Count());
    }

    [Fact]
    public async Task AddAuditItemForApplicationFormOnUpdate()
    {
        var formDto = new ApplicationFormDto()
        {
            Name = "Form2",
            IsActive = true,
            Fields = [
                new(){
                    DefaultFieldId = (long)ApplicationFormDefaultFields.FirstName,
                    Name = ApplicationFormDefaultFields.FirstName.GetEnumDisplayName(),
                    DisplayOrder = 1,
                    IsActive = true,
                    IsRequired = true,
                    IsAlwaysActiveAndRequired = true,
                    IsSystemDefault = true,
                    SectionId = (long)ApplicationFormSections.PersonalInformation,
                    TypeId = (long)ApplicationFormFieldTypes.SingleLineInput
                }
                ]
        };

        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);

        var getFormDto = await _applicationFormService.GetByIdAsync(createdResponse.Id);
        Assert.NotNull(getFormDto);
        Assert.Equal(formDto.Name, getFormDto.Name);
        Assert.NotNull(getFormDto.Fields);
        Assert.Equal(formDto.Fields.Count, getFormDto.Fields.Count);

        var updateformDto = new ApplicationFormDto()
        {
            Id = createdResponse.Id,
            Name = "Form2",
            IsActive = true,
            Fields = [
                new(){
                    DefaultFieldId = (long)ApplicationFormDefaultFields.LastName,
                    Name = ApplicationFormDefaultFields.LastName.GetEnumDisplayName(),
                    DisplayOrder = 1,
                    IsActive = true,
                    IsRequired = true,
                    IsAlwaysActiveAndRequired = true,
                    IsSystemDefault = true,
                    SectionId = (long)ApplicationFormSections.PersonalInformation,
                    TypeId = (long)ApplicationFormFieldTypes.SingleLineInput,
                    
                }
                ],
            Version = getFormDto.Version
        };

        await _formController.Update(updateformDto);

        var getFormDtoAfterUpdate = await _applicationFormService.GetByIdAsync(createdResponse.Id);
        Assert.NotNull(getFormDtoAfterUpdate);
        Assert.Equal(updateformDto.Name, getFormDtoAfterUpdate.Name);
        Assert.NotNull(getFormDtoAfterUpdate.Fields);
        Assert.Equal(updateformDto.Fields.Count, getFormDtoAfterUpdate.Fields.Count);

        var requestDto = new AuditLogRequestDto
        {
            PageNumber = 1,
            PageSize = 10,
            SortByField = "page",
            IsAscendingOrder = true,
            Pages = new List<string> { PageName.AddFormOrEditForm.GetEnumDisplayName() },
            Sections = new List<string> { SectionName.Application.ToString() },
            ModifiedByUsers = new List<string> { _currentUserContext.UserEmail! },
        };

        var auditLogs = new List<AuditLogListDto>
            {
                new() {  Id= Guid.NewGuid().ToString(), EventDateTime=DateTime.UtcNow, Identifier= "Test Form for Cosmos DB",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.AddFormOrEditForm.ToString(),
                    Section=SectionName.Application.ToString(),
                    FieldChanged= "Name",BeforeValue= "",AfterValue= "Form2"},
                new() {  Id= Guid.NewGuid().ToString(), EventDateTime=DateTime.UtcNow, Identifier= "Test Form for Cosmos DB",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.AddFormOrEditForm.ToString(),
                    Section=SectionName.Application.ToString(),
                    FieldChanged= "Name",BeforeValue= "",AfterValue= "FirstName"},
                new() {  Id= Guid.NewGuid().ToString(), EventDateTime=DateTime.UtcNow, Identifier= "Test Form for Cosmos DB",
                                     ModifiedByUserEmail= _currentUserContext.UserEmail, Page= PageName.AddFormOrEditForm.ToString(),
                    Section=SectionName.Application.ToString(),
                    FieldChanged= "Name",BeforeValue= "",AfterValue= "LastName"},
              };

        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(auditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var auditListResult = await auditLogsController.GetListAsync(requestDto);

        var okResult = Assert.IsType<OkObjectResult>(auditListResult.Result);
        var paginatedDto = Assert.IsType<PaginatedAuditLogDto>(okResult.Value);
        Assert.NotNull(paginatedDto);
        Assert.NotNull(paginatedDto.AuditLogs);
        Assert.Equal(auditLogs.Count, paginatedDto.AuditLogs.Count());
    }

    #endregion Application Form tests

    [Fact]
    public async Task AddItemShouldReturnsCreatedAtActionResult()
    {
        var jobCategoryId = await _jobPostCategoryService.AddAsync(new JobPostCategoryDto()
        {
            IsActive = true,
            Name = "TestJobForCosmosDbTest"
        });
        Assert.NotNull(jobCategoryId);
        Assert.True(jobCategoryId > 0);

        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100,
            FromDate = DateOnly.FromDateTime(DateTime.Now.Date),
            IsAscendingOrder = true,
            ToDate = DateOnly.FromDateTime(DateTime.Now.Date),
            SortByField = "fieldName"
        };

        var result = await GetAuditLogListAsync(auditLogRequestDto);
        Assert.NotNull(result);
        Assert.True(result.PageNumber == auditLogRequestDto.PageNumber);
        Assert.True(result.PageSize == auditLogRequestDto.PageSize);
    }

    [Fact]
    public async Task AddItemForJobPostCategoryOnUpdate()
    {
        var jobCategoryId = await _jobPostCategoryService.AddAsync(new JobPostCategoryDto()
        {
            IsActive = true,
            Name = "TestJobForCosmosDbTest2"
        });

        Assert.NotNull(jobCategoryId);
        Assert.True(jobCategoryId > 0);

        var jobPostCategoryDto = await _jobPostCategoryService.GetByIdAsync(jobCategoryId.Value);

        await _jobPostCategoryService.UpdateJobPostCategoryAsync(new JobPostCategoryDto()
        {
            Id = jobCategoryId.Value,
            IsActive = false,
            Name = "TestJobForCosmosDbTest2",
            Version = jobPostCategoryDto!.Version
        });

        jobPostCategoryDto = await _jobPostCategoryService.GetByIdAsync(jobCategoryId.Value);

        Assert.NotNull(jobPostCategoryDto);
        Assert.False(jobPostCategoryDto.IsActive);

        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100,
            SortByField = "section",
            SearchTerm = "TestJobForCosmosDbTest2",
            IsAscendingOrder = false
        };

        var result = await GetAuditLogListAsync(auditLogRequestDto);
        Assert.NotNull(result);
        Assert.True(result.PageNumber == auditLogRequestDto.PageNumber);
        Assert.True(result.PageSize == auditLogRequestDto.PageSize);
    }

    [Fact]
    public async Task AddItemForJobPostCategoryOnDelete()
    {
        var jobCategoryId = await _jobPostCategoryService.AddAsync(new JobPostCategoryDto()
        {
            IsActive = true,
            Name = "TestJobForCosmosDbTest3"
        });

        Assert.NotNull(jobCategoryId);
        Assert.True(jobCategoryId > 0);

        await _jobPostCategoryService.DeleteAsync(jobCategoryId.Value);

        var jobPostCategoryDto = await _jobPostCategoryService.GetByIdAsync(jobCategoryId.Value);
        Assert.Null(jobPostCategoryDto);

        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 10,
            SortByField = "identifier",
            IsAscendingOrder = false
        };

        var result = await GetAuditLogListAsync(auditLogRequestDto);
        Assert.NotNull(result);
        Assert.True(result.PageNumber == auditLogRequestDto.PageNumber);
        Assert.True(result.PageSize == auditLogRequestDto.PageSize);
    }

    [Fact]
    public async Task ShouldReturnsOkObjectResultWhenGettingAuditLogList()
    {
        // Arrange
        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100
        };

        // Act
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "Name",
                BeforeValue = "",
                AfterValue = "TestJobForCosmosDbTest"
            },
        };
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var result = await auditLogsController.GetListAsync(auditLogRequestDto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task ShouldReturnFileResultWhenAuditLogsExist()
    {
        // Arrange
        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100,
            SortByField = "eventDateTime"
        };

        // Act
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "Name",
                BeforeValue = "",
                AfterValue = "TestJobForCosmosDbTest"
            },
        };
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        // Act
        var result = await auditLogsController.GetListExportToCsv(auditLogRequestDto);

        // Assert
        var fileResult = Assert.IsType<FileContentResult>(result);
        Assert.Equal("text/csv", fileResult.ContentType);
        Assert.Equal("111111_Audit Log.csv", fileResult.FileDownloadName);
    }

    [Fact]
    public async Task ShouldReturnFileResultWhenAuditLogsExistAndSortByFieldUnKnown()
    {
        // Arrange
        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100,
            SortByField = "unknown"
        };

        // Act
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "Name",
                BeforeValue = "",
                AfterValue = "TestJobForCosmosDbTest"
            },
        };
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        // Act
        var result = await auditLogsController.GetListExportToCsv(auditLogRequestDto);

        // Assert
        var fileResult = Assert.IsType<FileContentResult>(result);
        Assert.Equal("text/csv", fileResult.ContentType);
        Assert.Equal("111111_Audit Log.csv", fileResult.FileDownloadName);
    }

    [Fact]
    public async Task ShouldReturnEmptyAuditLogListWhenNoAuditLogsExist()
    {
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(new List<AuditLogListDto>());

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var result = await auditLogsController.GetListAsync(new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100
        });

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var paginatedDto = Assert.IsType<PaginatedAuditLogDto>(okResult.Value);
        Assert.NotNull(paginatedDto);
        Assert.NotNull(paginatedDto.AuditLogs);
        Assert.Empty(paginatedDto.AuditLogs);
    }

    [Fact]
    public async Task ShouldReturnsOkWhenGettingApplicantInterviewDetailsAuditLogList()
    {
        // Arrange
        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100
        };

        // Act
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "test user name",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.ApplicantDetails.GetEnumDisplayName(),
                Section = "Interviews.Schedule Interview",
                FieldChanged = "Type of Interview",
                BeforeValue = "",
                AfterValue = "Phone"
            },
        };
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var result = await auditLogsController.GetListAsync(auditLogRequestDto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task ShouldReturnsOkWhenGettingApplicantAttachmentDetailsAuditLogList()
    {
        // Arrange
        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100
        };

        // Act
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "test user name",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.ApplicantDetails.GetEnumDisplayName(),
                Section = "Attachments.Add Attachment",
                FieldChanged = "File Name",
                BeforeValue = "",
                AfterValue = "testfile.docx"
            },
        };
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var result = await auditLogsController.GetListAsync(auditLogRequestDto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task ShouldReturnsOkWhenGettingApplicantNotesAuditLogList()
    {
        // Arrange
        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100
        };

        // Act
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "test user name",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.ApplicantDetails.GetEnumDisplayName(),
                Section = "Notes",
                FieldChanged = "Note",
                BeforeValue = "",
                AfterValue = "test notes"
            },
        };
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var result = await auditLogsController.GetListAsync(auditLogRequestDto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }
    [Fact]
    public async Task ShouldReturnsOkWhenDownLoadApplicationAuditLogList()
    {
        // Arrange
        var auditLogRequestDto = new AuditLogRequestDto()
        {
            PageNumber = 1,
            PageSize = 100
        };

        // Act
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "test user name",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.ApplicantDetails.GetEnumDisplayName(),
                Section = "Application",
                FieldChanged = "Download Application",
                BeforeValue = "",
                AfterValue = ""
            },
        };
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        var auditLogsController = new AuditLogsController(auditLogService, _currentUserContext);

        var result = await auditLogsController.GetListAsync(auditLogRequestDto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    #region Private Methods

    private async Task<PaginatedAuditLogDto?> GetAuditLogListAsync(AuditLogRequestDto auditLogRequestDto)
    {
        var mockAuditLogs = new List<AuditLogListDto>
        {
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "Name",
                BeforeValue = "",
                AfterValue = "TestJobForCosmosDbTest"
            },
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "IsActive",
                BeforeValue = "false",
                AfterValue = "true"
            },
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest2",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "Name",
                BeforeValue = "",
                AfterValue = "TestJobForCosmosDbTest2"
            },
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest2",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "IsActive",
                BeforeValue = "false",
                AfterValue = "true"
            },
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest2",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.EditCategory.ToString(),
                FieldChanged = "IsActive",
                BeforeValue = "true",
                AfterValue = "false"
            },
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest3",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "Name",
                BeforeValue = "",
                AfterValue = "TestJobForCosmosDbTest3"
            },
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest3",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.AddCategory.ToString(),
                FieldChanged = "IsActive",
                BeforeValue = "false",
                AfterValue = "true"
            },
            new() {
                Id = Guid.NewGuid().ToString(),
                EventDateTime = DateTime.UtcNow,
                Identifier = "TestJobForCosmosDbTest3",
                ModifiedByUserEmail = _currentUserContext.UserEmail,
                Page = PageName.JobCategories.GetEnumDisplayName(),
                Section = SectionName.EditCategory.ToString(),
                FieldChanged = "IsActive",
                BeforeValue = "true",
                AfterValue = "false"
            },
            new()
        {
            Id = Guid.NewGuid().ToString(),
            EventDateTime = DateTime.UtcNow,
            Identifier = "Test for cosmos Db Software Engineer",
            ModifiedByUserEmail = _currentUserContext.UserEmail,
            Page = PageName.JobPosts.ToString(),
            Section = SectionName.AddJobPost.ToString(),
            FieldChanged = "Title",
            BeforeValue = "",
            AfterValue = "Test for cosmos Db Software Engineer"
        },
        new()
        {
            Id = Guid.NewGuid().ToString(),
            EventDateTime = DateTime.UtcNow,
            Identifier = "Test for cosmos Db Software Engineer",
            ModifiedByUserEmail = _currentUserContext.UserEmail,
            Page = PageName.JobPosts.ToString(),
            Section = SectionName.AddJobPost.ToString(),
            FieldChanged = "Title",
            BeforeValue = "false",
            AfterValue = "Test for cosmos Db Software Engineer"
        },
        new()
        {
            Id = Guid.NewGuid().ToString(),
            EventDateTime = DateTime.UtcNow,
            Identifier = "Updated Title",
            ModifiedByUserEmail = _currentUserContext.UserEmail,
            Page = PageName.JobPosts.ToString(),
            Section = SectionName.AddJobPost.ToString(),
            FieldChanged = "Title",
            BeforeValue = "",
            AfterValue = "Updated Title"
        },
        new()
        {
            Id = Guid.NewGuid().ToString(),
            EventDateTime = DateTime.UtcNow,
            Identifier = "Updated Title",
            ModifiedByUserEmail = _currentUserContext.UserEmail,
            Page = PageName.JobPosts.ToString(),
            Section = SectionName.AddJobPost.ToString(),
            FieldChanged = "Title",
            BeforeValue = "false",
            AfterValue = "Initial Title"
        },
        new()
        {
            Id = Guid.NewGuid().ToString(),
            EventDateTime = DateTime.UtcNow,
            Identifier = "Updated Title",
            ModifiedByUserEmail = _currentUserContext.UserEmail,
            Page = PageName.JobPosts.ToString(),
            Section = SectionName.AddJobPost.ToString(),
            FieldChanged = "Title",
            BeforeValue = "Initial Title",
            AfterValue = "Updated Title"
        },
        };

        var mockCosmosDbService = new Mock<ICosmosDbService>();
        mockCosmosDbService.Setup(s => s.GetListAsync(It.IsAny<AuditLogRequestDto>()))
                           .ReturnsAsync(mockAuditLogs);

        var auditLogService = new AuditLogService(mockCosmosDbService.Object);

        return await auditLogService.GetListAsync(auditLogRequestDto);
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}