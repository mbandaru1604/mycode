﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class LoginRequestDtoValidatorTests
{
    private readonly LoginRequestDtoValidator _validator;
    public LoginRequestDtoValidatorTests()
    {
        _validator = new LoginRequestDtoValidator();
    }
    [Fact]
    public void ShouldFailWhenTokenIsNull()
    {
        var loginRequestDto = new LoginRequestDto()
        {
            Token = null
        };
        var result = _validator.TestValidate(loginRequestDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<LoginRequestDto>>(result);
        var testValidationResult = result.ShouldHaveValidationErrorFor(result => result.Token);
        Assert.Contains(testValidationResult, result => result.ErrorMessage == UserAuthenticationValidation.TokenIsRequired);
    }
}
