﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Integrations.Interfaces;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests.Auth;

public class AuthenticationControllerTests
{
    private readonly AtsDbContext _dbContext;
    private readonly CurrentUserContext _currentUserContext;
    private readonly Mock<ITokenService> _mockTokenService;
    private readonly IUserService _userService;
    private readonly ICompanyService _companyService;
    private readonly AuthController _authController;
    private readonly IAuthenticationService _authenticationService;
    public AuthenticationControllerTests()
    {
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        _dbContext = DBHelper.GetInMemoryDbContext();
        var atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var unitOfWork = new UnitOfWork(_dbContext);
        var userRepository = new UserRepository(_dbContext, _currentUserContext);
        _userService = new UserService(atsBaseRepository, unitOfWork, userRepository, _currentUserContext);
        var companyRepository = new CompanyRepository(_dbContext, _currentUserContext);
        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        IMapper mapper = mappingConfig.CreateMapper();
        var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
        _companyService = new CompanyService(companyRepository, _userService, unitOfWork, mapper, mockLoggerCompanyService.Object);
        _mockTokenService = new Mock<ITokenService>();
        _mockTokenService
        .Setup(service => service.GenerateToken(It.IsAny<TokenClaimsDto>()))
        .Returns("dummyToken");
        var mockRedisCacheProvider = new Mock<IRedisCacheProvider>();
        var mockJwtConfig = new Mock<IOptions<JwtConfig>>();
        mockJwtConfig.Setup(m => m.Value).Returns(new JwtConfig { ExpiryTimeInMinutes = 30 });
        _authenticationService = new AuthenticationService(_mockTokenService.Object, _userService, _companyService,
                                                            mockRedisCacheProvider.Object, mockJwtConfig.Object,
                                                            _currentUserContext);
        _authController = new AuthController(_authenticationService);
    }

    [Fact]
    public async Task ShouldReturnOkWhenSwitchingValidCompanys()
    {
        // Arrange
        var productDto1 = new ProductDto
        {
            Name = "Product 1",
            Start = "2024-01-01",
            End = "2024-12-31",
            Company = new CompanyDto
            {
                CompanyCode = 101,
                DbaName = "Company-one",
                LegalName = "First Company",
                StatusCode = "Active",
                Start = "2024-01-01",
                End = "2024-12-31",
                Locations = new List<WorksiteLocationDto>
                {
                    new WorksiteLocationDto { Code = "LOC001", Name = "First Location", IsActive = true }
                },
                Users = new List<UserDto>
                {
                    new UserDto
                    {
                        FirstName = "Danny",
                        LastName = "Daniel",
                        Email = "dd@gmail.com",
                        UserType = "Employee",
                        RoleCode = "Company Admin",
                        RoleName = "Company Admin",
                        IsActive = true
                    }
                }
            }
        };

        await _companyService.EnableProductAsync(productDto1);
        var comapnyDto1 = await _companyService.GetByCodeAsync(productDto1.Company.CompanyCode.Value);
        Assert.NotNull(comapnyDto1);

        var user = await _userService.GetUserByEmailAsync("dd@gmail.com");
        Assert.NotNull(user);

        var productDto2 = new ProductDto
        {
            Name = "Product 2",
            Start = "2024-01-01",
            End = "2024-12-31",
            Company = new CompanyDto
            {
                CompanyCode = 201,
                DbaName = "Company-two",
                LegalName = "Second Company",
                StatusCode = "Active",
                Start = "2024-01-01",
                End = "2024-12-31",
                Locations = new List<WorksiteLocationDto>
                {
                    new WorksiteLocationDto { Code = "LOC002", Name = "Second Location", IsActive = true }
                },
                Users = new List<UserDto>
                {
                    new UserDto
                    {
                        Id = productDto1.Company.Users.First().Id,
                        FirstName = "Danny",
                        LastName = "Daniel",
                        Email = "dd@gmail.com",
                        UserType = "Employee",
                        RoleCode = "Company Admin",
                        RoleName = "Company Admin",
                        IsActive = true
                    }
                }
            }
        };

        await _companyService.EnableProductAsync(productDto2);
        var comapnyDto2 = await _companyService.GetByCodeAsync(productDto2.Company.CompanyCode.Value);
        Assert.NotNull(comapnyDto2);

        _currentUserContext.UserId = user.Id;

        // Act
        var result = await _authController.SwitchCompany(comapnyDto2.CompanyCode.Value);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedValue = Assert.IsType<TokenDto>(okResult.Value);
        Assert.Equal("dummyToken", returnedValue.Token);

        _mockTokenService.Verify(ts => ts.GenerateToken(It.IsAny<TokenClaimsDto>()), Times.Once);
    }

    [Fact]
    public async Task ShouldReturnOkResultWithValidToken()
    {
        var loginRequestDto = new LoginRequestDto { Token = "validToken" };

        _mockTokenService
        .Setup(service => service.ValidateTokenAsync(It.IsAny<string>()))
        .ReturnsAsync((true, new PortalUserDetailsDto
        {
            Principal = new Principal
            {
                Email = "johndoe@gmail.com",
                ClientCode = "12345"
            }
        }));

        var result = await _authController.Login(loginRequestDto);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedValue = Assert.IsType<TokenDto>(okResult.Value);
        Assert.Equal("dummyToken", returnedValue.Token);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenTokenIsInValid()
    {
        var loginRequestDto = new LoginRequestDto { Token = "InvalidToken" };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _authController.Login(loginRequestDto));
        Assert.Equal(UserAuthenticationValidation.InvalidToken, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenUserDetailsIsNull()
    {
        var loginRequestDto = new LoginRequestDto { Token = "validToken" };
        _mockTokenService
        .Setup(service => service.ValidateTokenAsync(It.IsAny<string>()))
        .ReturnsAsync((true, null));

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _authenticationService.Login(loginRequestDto));
        Assert.Equal(UserAuthenticationValidation.UserEmailOrCompanyCodeNotFound, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenUserRoleIsNull()
    {
        var loginRequestDto = new LoginRequestDto { Token = "validToken" };
        var userEmail = "janesmith@test.com";
        var companyCode = "12345";
        _mockTokenService
        .Setup(service => service.ValidateTokenAsync(It.IsAny<string>()))
        .ReturnsAsync((true, new PortalUserDetailsDto
        {
            Principal = new Principal
            {
                Email = userEmail,
                ClientCode = companyCode
            }
        }));

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _authenticationService.Login(loginRequestDto));
        Assert.Equal(string.Format(UserAuthenticationValidation.UserCompanyRolesNotFound, userEmail, companyCode), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExcpetionWhenClientCodeIsNotValid()
    {
        var loginRequestDto = new LoginRequestDto { Token = "validToken" };
        var userEmail = "test@example.com";
        var companyCode = "123AE";
        _mockTokenService
        .Setup(service => service.ValidateTokenAsync(It.IsAny<string>()))
        .ReturnsAsync((true, new PortalUserDetailsDto
        {
            Principal = new Principal
            {
                Email = userEmail,
                ClientCode = companyCode
            }
        }));

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _authenticationService.Login(loginRequestDto));
        Assert.Equal(UserAuthenticationValidation.CompanyCodeInvalidType, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenUserNotFound()
    {
        var loginRequestDto = new LoginRequestDto { Token = "validToken" };
        var userEmail = "test@example.com";
        var companyCode = "123";
        _mockTokenService
        .Setup(service => service.ValidateTokenAsync(It.IsAny<string>()))
        .ReturnsAsync((true, new PortalUserDetailsDto
        {
            Principal = new Principal
            {
                Email = userEmail,
                ClientCode = companyCode
            }
        }));

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _authController.Login(loginRequestDto));
        Assert.Equal(string.Format(UserAuthenticationValidation.UserNotFound, userEmail), exception.Message);
    }
    [Fact]
    public async Task ShouldThrowExceptionWhenCompanyNotFound()
    {
        var loginRequestDto = new LoginRequestDto { Token = "validToken" };
        var userEmail = "johndoe@gmail.com";
        var companyCode = "1234";
        _mockTokenService
        .Setup(service => service.ValidateTokenAsync(It.IsAny<string>()))
        .ReturnsAsync((true, new PortalUserDetailsDto
        {
            Principal = new Principal
            {
                Email = userEmail,
                ClientCode = companyCode
            }
        }));

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _authController.Login(loginRequestDto));
        Assert.Equal(string.Format(CompanyValidation.CompanyNotFound, companyCode), exception.Message);
    }
}
