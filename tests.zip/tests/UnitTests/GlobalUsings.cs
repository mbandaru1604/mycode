global using Xunit;
global using static BBSI.ATS.Common.Helpers.UtilityHelper;