﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.Common;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.Extensions.Logging;
using Moq;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class CompanyControllerTests : IDisposable
{
    private readonly CompanyController _companyController;
    private readonly AtsDbContext _dbContext;
    private readonly CompanyService _companyService;
    private bool disposed = false;

    public CompanyControllerTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();

        var currentUserContext = new CurrentUserContext();
        var repository = new CompanyRepository(_dbContext, currentUserContext);
        var applicationFormRepository = new ApplicationFormRepository(_dbContext, currentUserContext);

        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        IMapper mapper = mappingConfig.CreateMapper();
        var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
        var unitOfWork = new UnitOfWork(_dbContext);
        _companyService = new CompanyService(repository, null, unitOfWork, mapper, mockLoggerCompanyService.Object);
        _companyController = new CompanyController(_companyService, currentUserContext);
    }

    [Fact]
    public async Task ShouldFailToGetWorksiteLocationNameById()
    {
        var location = await _companyService.GetWorksiteLocationNameByIdAsync(999);
        Assert.Null(location);
    }

    [Fact]
    public async Task ShouldDeactivateWorksiteLocationsThatAreRemoved()
    {
        var companyCode = 111817;
        var companyId = await CreateCompany(companyCode);
        Assert.True(companyId > 0);

        var initialWorksiteLocations = new List<WorksiteLocationDto>
        {
            new WorksiteLocationDto { Code = "LOC1", Name = "Location 1", IsActive = true },
            new WorksiteLocationDto { Code = "LOC2", Name = "Location 2", IsActive = true },
            new WorksiteLocationDto { Code = "LOC3", Name = "Location 3", IsActive = true }
        };

        await _companyService.SaveWorksiteLocationsAsync(companyCode, initialWorksiteLocations);

        var updatedWorksiteLocations = new List<WorksiteLocationDto>
        {
            new WorksiteLocationDto { Code = "LOC1", Name = "Location 1", IsActive = true }
        };

        await _companyService.SaveWorksiteLocationsAsync(companyCode, updatedWorksiteLocations);

        //Act
        var worksiteLocationDtos = await _companyService.GetWorksiteLocationsByCodeAsync(companyCode);

        // Assert
        var activeLocations = worksiteLocationDtos.Where(location => location.IsActive.GetValueOrDefault()).ToList();
        Assert.Single(activeLocations);
        Assert.Contains(activeLocations, location => location.Code == "LOC1");

        var allLocations = await _companyService.GetWorksiteLocationsByCodeAsync(companyCode);
        var inactiveLocations = allLocations.Where(location => !updatedWorksiteLocations.Any(dto => dto.Code == location.Code)).ToList();

        Assert.All(inactiveLocations, location => Assert.False(location.IsActive.GetValueOrDefault()));
    }

    [Fact]
    public async Task ShouldGetWorksiteLocationsByCompanyCode()
    {
        var companyCode = 112233;
        var companyId = await CreateCompany(companyCode);
        Assert.True(companyId > 0);

        var worksiteLocations = CreateWorksiteLocationDtoListObject();

        await _companyService.SaveWorksiteLocationsAsync(companyCode, worksiteLocations);

        var worksiteLocationDtos = await _companyService.GetWorksiteLocationsByCodeAsync(companyCode);

        Assert.NotEmpty(worksiteLocationDtos);
        Assert.NotNull(worksiteLocationDtos);
        Assert.Equal(worksiteLocationDtos.Count(), worksiteLocations.Count);

        for (int i = 0; i < worksiteLocations.Count; i++)
        {
            var expectedLocation = worksiteLocations[i];
            var actualLocation = worksiteLocationDtos.FirstOrDefault(loc =>
                loc.Code == expectedLocation.Code &&
                loc.Name == expectedLocation.Name &&
                loc.Addr1 == expectedLocation.Addr1 &&
                loc.Addr2 == expectedLocation.Addr2 &&
                loc.City == expectedLocation.City &&
                loc.State == expectedLocation.State &&
                loc.Country == expectedLocation.Country);

            Assert.NotNull(actualLocation);
        }
    }

    [Fact]
    public async Task ShouldThrowValidationExceptionWhileGettingWorkSiteLocationWhenCompanyCodeNotFound()
    {
        var nonExistentCompanyCode = 9999;

        var exception = await Assert.ThrowsAsync<System.ComponentModel.DataAnnotations.ValidationException>(() => _companyService.GetWorksiteLocationsByCodeAsync(nonExistentCompanyCode));

        Assert.Equal(string.Format(CompanyValidation.CompanyNotFound, nonExistentCompanyCode), exception.Message);
    }

    #region Private Methods

    private async Task<long> CreateCompany(int companyCode)
    {
        var companyDto = new CompanyDto
        {
            CompanyCode = companyCode,
            LegalName = "Company Legal Name",
            DbaName = "Company DBA Name",
            StatusCode = "A"
        };

        var createdCompanyId = await _companyService.SaveAsync(companyDto);
        Assert.True(createdCompanyId > 0);
        return createdCompanyId;
    }

    private List<WorksiteLocationDto> CreateWorksiteLocationDtoListObject()
    {
        return new List<WorksiteLocationDto>
                    {
                        new()
                        {
                            Code = "11118",
                            Addr1 = "Test Address 122",
                            Addr2 = "Test Address 222",
                            City = "TestCity",
                            State = "NY",
                            Country = "United States",
                            IsActive = true,
                            Name = "Test Location1",
                            ZipCode = "000101"
                        },
                        new()
                        {
                            Code = "11111",
                            Addr1 = "Test Address 12",
                            Addr2 = "Test Address 22",
                            City = "TestCity2",
                            State = "NY",
                            Country = "United States",
                            IsActive = true,
                            Name = "TestLocation12",
                            ZipCode = "000102"
                        }
                    };
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}