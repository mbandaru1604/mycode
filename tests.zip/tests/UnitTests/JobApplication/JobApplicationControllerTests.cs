﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.Common.Extensions;
using BBSI.ATS.Common.Helpers;
using BBSI.ATS.Domain.Entities;
using BBSI.ATS.DTO;
using BBSI.ATS.DTO.JobApplication;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Data.Repositories.Interfaces;
using BBSI.ATS.Infrastructure.Integrations.Concrete;
using BBSI.ATS.Infrastructure.Integrations.Interfaces;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System.Reflection;
using WkHtmlToPdfDotNet.Contracts;
using Xunit.Abstractions;
using static BBSI.ATS.Common.Constants;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class JobApplicationControllerTests : IDisposable
{
    private readonly JobPostsController _jobPostsController;
    private readonly ApplicationFormsController _formController;
    private readonly JobApplicationsController _jobApplicationsController;
    private readonly IApplicationFormService _applicationFormService;
    private readonly IJobPostService _jobPostService;
    private readonly AtsDbContext _dbContext;
    private readonly JobApplicationService _jobApplicationService;
    private readonly CurrentUserContext _currentUserContext;
    private readonly MetaDataService _metadataService;
    private readonly IMapper _mapper;
    private bool disposed = false;
    private readonly IJobApplicationRepository _jobApplicationRepository;
    private readonly IUserService _userService;
    private readonly Mock<IBlobService> _blobServiceMock;
    private readonly Dictionary<string, string> _templates;
    private readonly ICompanyService _companyService;
    private readonly IAtsBaseRepository _repository;
    private readonly IApplicantQuizRepository _applicantQuizRepository;
    private readonly IApplicantQuizService _applicantQuizService;

    public JobApplicationControllerTests(ITestOutputHelper output)
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        _jobApplicationRepository = new JobApplicationRepository(_dbContext, _currentUserContext);
        var applicationFormRepository = new ApplicationFormRepository(_dbContext, _currentUserContext);
        var jobPostRepository = new JobPostRepository(_dbContext, _currentUserContext);
        var metaDataRepository = new MetaDataRepository(_dbContext, _currentUserContext);
        _repository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var userRepository = new UserRepository(_dbContext, _currentUserContext);
        var jobApplicationNoteRepository = new JobApplicationNoteRepository(_dbContext, _currentUserContext);
        var companyRepository = new CompanyRepository(_dbContext, _currentUserContext);
        _applicantQuizRepository = new ApplicantQuizRepository(_dbContext, _currentUserContext);

        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        _mapper = mappingConfig.CreateMapper();

        // builder.Services.Configure<EmailTemplateConfig>(builder.Configuration.GetSection("EmailTemplateConfig"));

        _metadataService = new MetaDataService(metaDataRepository, _mapper);
        var mockCosmosDbService = new Mock<ICosmosDbService>();

        _userService = new UserService(_repository, null, userRepository, _currentUserContext);

        var formFieldComparer = new ApplicationFormFieldComparer();
        var applicationFormComparer = new ApplicationFormComparer(formFieldComparer);
        _applicationFormService = new ApplicationFormService(applicationFormRepository, _mapper, _currentUserContext, mockCosmosDbService.Object, applicationFormComparer);
        _formController = new ApplicationFormsController(_applicationFormService);

        _companyService = new CompanyService(companyRepository, _userService, null, _mapper, null);
        var appConfig = new AppConfig();
        _jobPostService = new JobPostService(jobPostRepository, _mapper, _applicationFormService, _currentUserContext,
                          mockCosmosDbService.Object, _applicantQuizRepository, _companyService, appConfig);
        _jobPostsController = new JobPostsController(_jobPostService);
        _blobServiceMock = new Mock<IBlobService>();
        var jobApplicationNoteService = new JobApplicationNoteService(_repository, _mapper, _jobApplicationRepository,
                                        _currentUserContext, jobApplicationNoteRepository, _userService, mockCosmosDbService.Object);
        var mockLogger = new Mock<ILogger<JobApplicationService>>();
        var mockConfig = new Mock<IOptions<EmailTemplateConfig>>();
        var mockLoggerEmailClient = new Mock<ILogger<EmailClient>>();
        var emailConcig = new SendGridEmailConfig();
        emailConcig.ApiKey = "testkey";
        emailConcig.SenderEmail = "ats-no-reply@mybbsi.com";
        var notificationTemplates = ResourceReader.ReadEmbeddedResource(Assembly.LoadFrom(Assembly.GetExecutingAssembly().Location.Replace(Assembly.GetExecutingAssembly().Location.Split("\\").Last(), string.Empty) + "BBSI.ATS.Common.dll"), $"BBSI.ATS.Common.NotificationTemplates");
        _templates = notificationTemplates.ToDictionary(template => Path.GetFileNameWithoutExtension(template.Key.Replace($"BBSI.ATS.Common.NotificationTemplates.", string.Empty)), template => template.Value);
        var emailClient = new EmailClient(emailConcig, mockLoggerEmailClient.Object);

        _jobApplicationService = new JobApplicationService(_jobApplicationRepository, _mapper, _applicationFormService, _blobServiceMock.Object, null, jobApplicationNoteService, _metadataService, mockLogger.Object, emailClient, mockConfig.Object, _templates, null, _currentUserContext, _userService, mockCosmosDbService.Object, _applicantQuizRepository);
        _jobApplicationsController = new JobApplicationsController(_jobApplicationService);

        var comparer = new ApplicantQuizComparer();
        _applicantQuizService = new ApplicantQuizService(_repository, _mapper, _applicantQuizRepository, _currentUserContext, jobPostRepository, comparer, mockCosmosDbService.Object);
    }

    [Fact]
    public async Task ShouldFailToGetApplicantName()
    {
        var applicantName = await _jobApplicationService.GetApplicantNameAsync(9999);
        Assert.Null(applicantName);
    }

    [Fact]
    public async Task ShouldGetApplicantName()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);

        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);
        var applicantName = await _jobApplicationService.GetApplicantNameAsync(jobApplicationId);
        Assert.NotNull(applicantName);
    }

    [Fact]
    public async Task ShouldReturnOkResultAttachmentById()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);

        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var fileName = $"Attachment_{DateTime.Now.Ticks}";
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        _blobServiceMock.Setup(s => s.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
               .ReturnsAsync("https://example.com/resume.pdf");
        var attachmentId = await AddAttachment(fileName, jobApplicationId, fileStream, JobApplicationAttachmentType.Resume);
        Assert.True(attachmentId > 0);

        _blobServiceMock.Setup(s => s.GetFileStreamAsync(It.IsAny<string>()))
                .ReturnsAsync(fileStream);
        var result = await _jobApplicationsController.GetJobApplicationAttachmentById(attachmentId);
        Assert.NotNull(result);
        Assert.NotNull(result.Result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        Assert.NotNull(okResult.Value);
        var filebase64 = Assert.IsType<string>(okResult.Value);
        Assert.Equal(FileUploadsContent.base64StringPDF, filebase64);
    }

    [Fact]
    public async Task ShouldReturnApplicationFieldValueByFieldId()
    {
        var formId = await CreateApplicationFormWithAllDefaultFields();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "First Name",
                },
                new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "last Name",
                },new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@test.com",
                },
                new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.Resume ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = FileUploadsContent.base64StringPDF,
                    FileName = $"Attachment_{DateTime.Now.Ticks}.pdf"
                },
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                                    new(){
                                        QuestionId =1,
                                        AnswerId =1,
                                    },
                                    new(){
                                        QuestionId =2,
                                        AnswerId =2
                                    }
                                ]
            }
        };
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        _blobServiceMock.Setup(s => s.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
               .ReturnsAsync("https://example.com/resume.pdf");
        _blobServiceMock.Setup(s => s.GetFileStreamAsync(It.IsAny<string>()))
                .ReturnsAsync(fileStream);
        var jobApplicationId = await CreateJobApplication(jobApplicationDto);
        var attachments = await _jobApplicationService.GetAttachmentsByIdAsync(jobApplicationId);
        Assert.NotNull(attachments);
        var resumeFieldId = attachments.Select(s => s.Id).FirstOrDefault();
        var result = await _jobApplicationsController.GetJobApplicationFieldValueByIdAsync(resumeFieldId);
        Assert.NotNull(result);
        Assert.NotNull(result.Result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        Assert.NotNull(okResult.Value);
        Assert.Equal(FileUploadsContent.base64StringPDF, okResult.Value);
    }

   

    [Fact]
    public async Task ShouldNotifyHiringManagerViaEmailWhenApplicantApplies()
    {
        var formId = await CreateApplicationFormWithAllDefaultFields();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "First Name",
                },
                new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "last Name",
                },new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@test.com",
                }
                ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var jobApplicationId = await CreateJobApplication(jobApplicationDto);
        Assert.True(jobApplicationId > 0);
    }

    [Fact]
    public async Task ShouldReturnPreviewOfOfferExtendedWhenCalled()
    {
        var result = _jobApplicationsController.PreviewOfOfferExtended();
        Assert.NotNull(result);
        var previewDto = Assert.IsType<EmailPreviewDto>(result);
        Assert.NotNull(previewDto.Template);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenFormNotExist()
    {
        var jobApplication = new JobApplicationDto()
        {
            JobPostId = 5000,
            FieldValues = [
                new() {FormFieldId = 1, FormFieldValue = "First Name"}
                ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.Create(jobApplication));
        Assert.Equal(ApplicationFormFieldValidation.InvalidApplicationForm, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenFormIsInactive()
    {
        var formDto = new ApplicationFormDto() { Name = "Form" + DateTime.Now, IsActive = false };
        var formId = await _applicationFormService.AddAsync(formDto);
        Assert.NotNull(formId);
        Assert.True(formId > 0);
        var jobpostId = await AssertCreateJobPost(formId);
        var jobApplicationDto = new JobApplicationDto() { JobPostId = jobpostId };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.Create(jobApplicationDto));
        Assert.Equal(ApplicationFormFieldValidation.InvalidApplicationForm, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenFormModifiedDateIsGreaterThanJobApplication()
    {
        var formDto = new ApplicationFormDto() { Name = "Form" + DateTime.Now, IsActive = true };
        var formId = await _applicationFormService.AddAsync(formDto);
        Assert.NotNull(formId);
        Assert.True(formId > 0);
        var jobpostId = await AssertCreateJobPost(formId);
        var jobApplicationDto = new JobApplicationDto() { JobPostId = jobpostId, FormModifiedOn = DateTime.Now.AddDays(-2) };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.Create(jobApplicationDto));
        Assert.Equal(ApplicationFormFieldValidation.InvalidApplicationField, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowValidationExceptionWhenAttachmentIsNullOnDelete()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _jobApplicationsController.DeleteAttachmentByIdAsync(1000));
        Assert.Equal(string.Format(JobApplicationAttachmentValidation.InvalidAttachmentId), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowValidationExceptionWhenFormFieldIsNullInFieldSet()
    {
        var formId = await CreateApplicationForm();
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues = [
                new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "First Name",
                },
                new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "last Name",
                },new()
                {
                    FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@test.com",
                },
                ],
            FieldSets = new List<JobApplicationFieldSetDto> { new() { FieldValues = new List<JobApplicationFieldValueDto> { new() { FormFieldId = 9999, FormFieldValue = "Test Value" } } } }
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.InvalidApplicationField), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenStartDateIsNotInCorrectFormat()
    {
        var formFields = new List<ApplicationFormFieldDto>
        {
            new()
            {
                DefaultFieldId = (long)ApplicationFormDefaultFields.StartDate,
                DisplayOrder = 1,
                IsActive = true,
                IsRequired = true,
                IsAlwaysActiveAndRequired = true,
                IsSystemDefault = true,
                Name = "Start Date",
                TypeId = (long)ApplicationFormFieldTypes.DatePicker,
                SectionId = (long)ApplicationFormSections.WorkHistory
            }
        };

        var formDto = new ApplicationFormDto
        {
            Name = "Form" + DateTime.Now.Ticks,
            IsActive = true,
            Fields = formFields
        };

        var formId = await _applicationFormService.AddAsync(formDto);
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields((long)formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldSets = new List<JobApplicationFieldSetDto>
        {
            new()
            {
                FieldValues = new List<JobApplicationFieldValueDto>
                {
                    new()
                    {
                        FormFieldId = form.Fields?.First(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.StartDate)?.Id,
                        FormFieldValue = "11/11/2k",
                    }
                }
            }
        },
            FormModifiedOn = DateTime.Now
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));

        var expectedException = string.Format(JobApplicationValidation.WorkHistoryDateRequired, formFields[0].Name);
        Assert.Equal(expectedException, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenEndDateIsNotInCorrectFormat()
    {
        var formFields = new List<ApplicationFormFieldDto>
        {
            new()
            {
                DefaultFieldId = (long)ApplicationFormDefaultFields.StartDate,
                DisplayOrder = 1,
                IsActive = true,
                IsRequired = true,
                IsAlwaysActiveAndRequired = true,
                IsSystemDefault = true,
                Name = "Start Date",
                TypeId = (long)ApplicationFormFieldTypes.DatePicker,
                SectionId = (long)ApplicationFormSections.WorkHistory
            },
            new()
            {
                DefaultFieldId = (long)ApplicationFormDefaultFields.EndDate,
                DisplayOrder = 2,
                IsActive = true,
                IsRequired = true,
                IsAlwaysActiveAndRequired = true,
                IsSystemDefault = true,
                Name = "End Date",
                TypeId = (long)ApplicationFormFieldTypes.DatePicker,
                SectionId = (long)ApplicationFormSections.WorkHistory
            }
        };

        var formDto = new ApplicationFormDto
        {
            Name = "Form" + DateTime.Now.Ticks,
            IsActive = true,
            Fields = formFields
        };

        var formId = await _applicationFormService.AddAsync(formDto);
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields((long)formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldSets = new List<JobApplicationFieldSetDto>
        {
            new()
            {
                FieldValues = new List<JobApplicationFieldValueDto>
                {
                    new()
                    {
                        FormFieldId = form.Fields?.First(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.StartDate)?.Id,
                        FormFieldValue = "10/10/2000",
                    },
                    new()
                    {
                        FormFieldId = form.Fields?.First(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.EndDate)?.Id,
                        FormFieldValue = "11/11/2k",
                    }
                }
            }
        },
            FormModifiedOn = DateTime.Now
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));

        var expectedException = string.Format(JobApplicationValidation.WorkHistoryDateRequired, formFields[1].Name);
        Assert.Equal(expectedException, exception.Message);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithCostomFileWithSizeLimitAsNull()
    {
        var formId = await CreateApplicationForm();
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields((long)formId);
        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues =
            [
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "FirstName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "LastName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@email.com",
                },
                new()
                {
                    FormFieldId = form.Fields?.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.Resume).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue =  FileUploadsContent.base64StringPDF,
                    FileName = "resume-sample.pdf"
                }
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            },
            FormModifiedOn = DateTime.Now
        };

        var jobApplicationId = await CreateJobApplication(jobApplicationDto);
        Assert.True(jobApplicationId > 0);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenApplicationFormFieldIsNull()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields = null
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var JobPostId = await AssertCreateJobPost(response.Id);
        var form = await _applicationFormService.GetFormWithActiveFields(response.Id);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                {
                    FormFieldId = form.Fields?.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "",
                }
            ],
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.InvalidApplicationField), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenAttachmentNotExist()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.GetJobApplicationAttachmentById(9999));
        Assert.Equal(JobApplicationAttachmentValidation.InvalidAttachmentId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenFieldValueNotExist()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.GetJobApplicationFieldValueByIdAsync(9999));
        Assert.Equal(JobApplicationAttachmentValidation.InvalidAttachmentId, exception.Message);
    }

    [Fact]
    public async Task ShouldReturnOkResultWhenAttachmentIsDeletedFromBlobAndJobApplication()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var fileName = $"Attachment_{DateTime.Now.Ticks}";
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        var attachmentId = await AddAttachment(fileName, jobApplicationId, fileStream, JobApplicationAttachmentType.Resume);
        Assert.True(attachmentId > 0);
        var returnFlag = true;
        _blobServiceMock.Setup(service => service.DeleteBlobAsync(It.IsAny<string>()))
                                                             .ReturnsAsync(returnFlag);

        var result = await _jobApplicationsController.DeleteAttachmentByIdAsync(attachmentId);
        Assert.IsType<OkResult>(result);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenJobApplicationNotExist()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.GetById(9999));
        Assert.Equal(JobApplicationValidation.InvalidJobApplicationId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenJobApplicationNotExistOnUpdateStatus()
    {
        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = 999,
            NewHireTypeId = (long)NewHireType.Electronic,
            StatusId = (long)JobApplicationStatuses.NotSelected
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.UpdateStatusAsync(updateDto));
        Assert.Equal(JobApplicationValidation.InvalidJobApplicationId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenjobApplicationStatusIdNotExist()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues = [new() { FormFieldId = form.Fields?.Where(a => a.DefaultFieldId == (int)ApplicationFormDefaultFields.PersonalEmailAddress).Select(a => a.Id).FirstOrDefault(), FormFieldValue = "test@tsdt.com", }],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = Id,
            NewHireTypeId = (long)NewHireType.Electronic,
            StatusId = 9999
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.UpdateStatusAsync(updateDto));
        Assert.Equal(JobApplicationValidation.InvalidJobApplicationStatusId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenjobApplicationManualStatusUpdateNewHireTypeIsNullOrZero()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues = [new() { FormFieldId = form.Fields?.Where(a => a.DefaultFieldId == (int)ApplicationFormDefaultFields.PersonalEmailAddress).Select(a => a.Id).FirstOrDefault(), FormFieldValue = "test@tsdt.com", }],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = Id,
            NewHireTypeId = null,
            StatusId = (long)JobApplicationStatuses.Onboarding
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.UpdateStatusAsync(updateDto));
        Assert.Equal(JobApplicationValidation.InvalidNewHireTypeId, exception.Message);
    }

    [Fact]
    public async Task ShouldUpdatejobApplicationNewHireTypeWhenApplicatanOfferIsExtended()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        //save a job post  and assert it
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        var Id = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.True(Id > 0);
        var jobApplication = await _jobApplicationService.GetByIdAsync(Id.Value);
        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = Id,
            NewHireTypeId = (long)NewHireType.Electronic,
            StatusId = (long)JobApplicationStatuses.OfferExtended,
            SendEmail = true,
            Version = jobApplication!.Version
        };
        var result = await _jobApplicationsController.UpdateStatusAsync(updateDto);
        Assert.IsType<OkResult>(result);
    }

    [Fact]
    public async Task ShouldNotifyInterviewerViaEmailWhenOfferIsDeclined()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        var Id = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.True(Id > 0);
        var jobApplication = await _jobApplicationService.GetByIdAsync(Id.Value);
        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = Id,
            NewHireTypeId = (long)NewHireType.Electronic,
            StatusId = (long)JobApplicationStatuses.OfferExtended,
            SendEmail = true,
            Version= jobApplication!.Version
        };
        var result = await _jobApplicationsController.UpdateStatusAsync(updateDto);
        Assert.IsType<OkResult>(result);

        var offerTokens = await _repository.GetListAsync<JobApplicationOfferToken>(
            filterExpression: filter => filter.JobApplicationId == Id.Value
        );

        var offerToken = _mapper.Map<JobApplicationOfferTokenDto>(offerTokens.FirstOrDefault());
        Assert.NotNull(offerToken);
        Assert.NotNull(offerToken.Token);

        var declinedResponse = await _jobApplicationsController.DeclineOffer(offerToken.Token);
        Assert.NotNull(declinedResponse);
        Assert.NotNull(declinedResponse.Value);
        var responseObject = declinedResponse.Value;
        var responseProperty = responseObject.GetType().GetProperty("Response");

        Assert.NotNull(responseProperty);

        var responseContent = responseProperty.GetValue(responseObject) as string;

        Assert.NotNull(responseContent);
        Assert.Equal(OfferExtendedEmailValidation.ResponseToApplicant, responseContent);

        var offerTokenStatus = await _repository.GetByIdAsync<JobApplicationOfferToken>(offerTokens!.FirstOrDefault()!.Id);
        Assert.NotNull(offerTokenStatus);
        Assert.NotNull(offerTokenStatus.Status);
        Assert.Equal(JobApplicationConstants.OfferRejected, offerTokenStatus.Status);
    }

    [Fact]
    public async Task ShouldNotifyInterviewerViaEmailWhenOfferIsAccepted()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        var Id = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.True(Id > 0);

        var jobApplication = await _jobApplicationService.GetByIdAsync(Id.Value);

        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = Id,
            NewHireTypeId = (long)NewHireType.Electronic,
            StatusId = (long)JobApplicationStatuses.OfferExtended,
            SendEmail = true,
            Version = jobApplication!.Version
        };
        var result = await _jobApplicationsController.UpdateStatusAsync(updateDto);
        Assert.IsType<OkResult>(result);

        var offerTokens = await _repository.GetListAsync<JobApplicationOfferToken>(
            filterExpression: filter => filter.JobApplicationId == Id.Value
        );

        var offerToken = _mapper.Map<JobApplicationOfferTokenDto>(offerTokens.FirstOrDefault());
        Assert.NotNull(offerToken);
        Assert.NotNull(offerToken.Token);

        var acceptedResponse = await _jobApplicationsController.AcceptOffer(offerToken.Token);
        Assert.NotNull(acceptedResponse);
        Assert.NotNull(acceptedResponse.Value);
        var responseObject = acceptedResponse.Value;
        var responseProperty = responseObject.GetType().GetProperty("Response");

        Assert.NotNull(responseProperty);

        var responseContent = responseProperty.GetValue(responseObject) as string;

        Assert.NotNull(responseContent);
        Assert.Equal(OfferExtendedEmailValidation.ResponseToApplicant, responseContent);

        var offerTokenStatus = await _repository.GetByIdAsync<JobApplicationOfferToken>(offerTokens.FirstOrDefault()!.Id);
        Assert.NotNull(offerTokenStatus);
        Assert.NotNull(offerTokenStatus.Status);
        Assert.Equal(JobApplicationConstants.OfferAccepted, offerTokenStatus.Status);
    }

    [Fact]
    public async Task ShouldReturnExpiredOfferLinkStatusMessage()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        var Id = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.True(Id > 0);
        var jobApplication = await _jobApplicationService.GetByIdAsync(Id.Value);
        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = Id,
            NewHireTypeId = (long)NewHireType.Electronic,
            StatusId = (long)JobApplicationStatuses.OfferExtended,
            SendEmail = true,
            Version = jobApplication!.Version
        };
        var result = await _jobApplicationsController.UpdateStatusAsync(updateDto);
        Assert.IsType<OkResult>(result);

        var offerTokens = await _repository.GetListAsync<JobApplicationOfferToken>(
            filterExpression: filter => filter.JobApplicationId == Id.Value
        );

        var offerToken = await _jobApplicationRepository.GetJobApplicationOfferDetailsAsync(offerTokens.FirstOrDefault()!.Token);
        Assert.NotNull(offerToken);
        offerToken.CreatedOn = offerToken.CreatedOn!.Value.AddDays(-5);
        await _repository.SaveChangesAsync();

        var declinedResponse = await _jobApplicationsController.DeclineOffer(offerToken.Token!);
        Assert.NotNull(declinedResponse);
        Assert.NotNull(declinedResponse.Value);
        var responseObject = declinedResponse.Value;
        var responseProperty = responseObject.GetType().GetProperty("Response");

        Assert.NotNull(responseProperty);

        var responseContent = responseProperty.GetValue(responseObject) as string;

        Assert.NotNull(responseContent);
        Assert.Equal(OfferExtendedEmailValidation.OfferLinkExpired, responseContent);
    }

    [Fact]
    public async Task ShouldReturnStatusMessageForAlreadyChangedOfferStatus()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        var Id = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.True(Id > 0);
        var jobApplication = await _jobApplicationService.GetByIdAsync(Id.Value);
        var updateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = Id,
            NewHireTypeId = (long)NewHireType.Electronic,
            StatusId = (long)JobApplicationStatuses.OfferExtended,
            SendEmail = true,
            Version = jobApplication!.Version
        };
        var result = await _jobApplicationsController.UpdateStatusAsync(updateDto);
        Assert.IsType<OkResult>(result);

        var offerTokens = await _repository.GetListAsync<JobApplicationOfferToken>(
            filterExpression: filter => filter.JobApplicationId == Id.Value
        );

        var offerToken = await _jobApplicationRepository.GetJobApplicationOfferDetailsAsync(offerTokens.FirstOrDefault()!.Token!);
        Assert.NotNull(offerToken);

        var firstOfferResponse = await _jobApplicationsController.DeclineOffer(offerToken.Token!);
        Assert.NotNull(firstOfferResponse);
        Assert.NotNull(firstOfferResponse.Value);

        var firstResponseObject = firstOfferResponse.Value;
        var firstResponseProperty = firstResponseObject.GetType().GetProperty("Response");

        Assert.NotNull(firstResponseProperty);

        var firstResponseContent = firstResponseProperty.GetValue(firstResponseObject) as string;

        Assert.NotNull(firstResponseContent);
        Assert.Equal(OfferExtendedEmailValidation.ResponseToApplicant, firstResponseContent);

        var secondOfferResponse = await _jobApplicationsController.DeclineOffer(offerToken.Token);
        Assert.NotNull(secondOfferResponse);
        Assert.NotNull(secondOfferResponse.Value);

        var secondResponseObject = secondOfferResponse.Value;
        var secondResponseProperty = secondResponseObject.GetType().GetProperty("Response");

        Assert.NotNull(secondResponseProperty);

        var secondResponseContent = secondResponseProperty.GetValue(secondResponseObject) as string;

        Assert.NotNull(secondResponseContent);
        Assert.Equal(OfferExtendedEmailValidation.OfferStatusAlreadyChanged, secondResponseContent);

        var offerTokenStatus = await _repository.GetByIdAsync<JobApplicationOfferToken>(offerToken.Id);
        Assert.NotNull(offerTokenStatus);
        Assert.NotNull(offerTokenStatus.Status);
        Assert.Equal(JobApplicationConstants.OfferRejected, offerTokenStatus.Status);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithPhoneAndEmail()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues = new List<JobApplicationFieldValueDto>
        {
            new JobApplicationFieldValueDto
            {
                FormFieldId = form.Fields!.Where(applicationformfield => applicationformfield.DefaultFieldId == (long)ApplicationFormDefaultFields.FirstName).Select(a => a.Id).FirstOrDefault(),
                FormFieldValue = "FirstName",
            },
            new JobApplicationFieldValueDto
            {
                FormFieldId = form.Fields!.Where(applicationformfield => applicationformfield.DefaultFieldId == (long)ApplicationFormDefaultFields.LastName).Select(a => a.Id).FirstOrDefault(),
                FormFieldValue = "LastName",
            },
            new JobApplicationFieldValueDto
            {
                FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.PersonalEmailAddress).Select(a => a.Id).FirstOrDefault(),
                FormFieldValue = "test@tsdt.com",
            },
            new JobApplicationFieldValueDto
            {
                FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.HomeTelephoneNumber).Select(a => a.Id).FirstOrDefault(),
                FormFieldValue = "9999999999",
            },
            new JobApplicationFieldValueDto
            {
                FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.MobilePhoneNumber).Select(a => a.Id).FirstOrDefault(),
                FormFieldValue = "9999999991",
            }
        },
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };

        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithApplicantName()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestFirstName",
                    },
                    new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestMiddleName",
                    },
                    new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestLastname",
                    },
                    new JobApplicationFieldValueDto
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.PersonalEmailAddress).Select(a => a.Id).FirstOrDefault(),
                        FormFieldValue = "test@tsdt.com",
                    },
                ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenFirstNameIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.FirstName), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenLastNameIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.LastName), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenEmailIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Contains(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.PresonalEmailAddress), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenMobileIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Contains(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.MobilePhoneNumber), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenInvalidEmailAddress()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test@test"
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.InvalidField, Constants.ApplicationFormFields.PresonalEmailAddress), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenFirstNamelLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test2121sssswe3cxzcsdfetrcgrssssssssssssssssssssssssssqwertyuiopljhgfdsasdfghjklmnbvcxzaqwertyuio",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.FirstName), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenLastNameLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test2121sssswe3cxzcsdfetrcgrssssssssssssssssssssssssssqwertyuiopljhgfdsasdfghjklmnbvcxzaqwertyuio",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.LastName), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenMiddleNameLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test2121sssswe3cxzcsdfetrcgrssssssssssssssssssssssssssqwertyuiopljhgfdsasdfghjklmnbvcxzaqwertyuio",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.MiddleName), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenEmailLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test2121sssswe3cxzcsdfetrcgrssssssssssssssssssssssssssqwertyuiopljhgfdsasdfghjklmnbvcxzaqwertyuiopolkjhgfdsasdfsssssss@test.com",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.PresonalEmailAddress), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenPhoneNumberLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "123456789123",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.LengthNotEqual, Constants.ApplicationFormFields.MobilePhoneNumber, DefaultFieldsValidation.PhoneNumberLength), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenPhoneNumberMinimunLength()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "12345678",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.LengthNotEqual, Constants.ApplicationFormFields.MobilePhoneNumber, DefaultFieldsValidation.PhoneNumberLength), error.Message);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithAddressFields()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "FirstName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "LastName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@email.com",
                },
                new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.AddressLine1).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "Address1",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.AddressLine2).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "Address2",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.City).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "city",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.State).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "State",
                    },
                     new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.ZipCode).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "12345",
                    }
            ],
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenAddressLine1IsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
            new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.AddressLine1).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.AddressLine1), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenCityIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.City).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.City), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenStateIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.State).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.State), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenZipCodeIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.ZipCode).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.ZipCode), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenAddressLine1LimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.AddressLine1).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test2121sssswe3cxzcsdfetrcgrssssssssssssssssssssssssssqwertyuiopljhgfdsasdfghjklmnbvcxzaqwertyuioasdfasdfa",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.AddressLine1), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenAddressLine2LimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.AddressLine2).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test2121sssswe3cxzcsdfetrcgrssssssssssssssssssssssssssqwertyuiopljhgfdsasdfghjklmnbvcxzaqwertyuiodfasdfaasdfa",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.AddressLine2), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenCityLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.City).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test2121sssswe3cxzcsdfetrcgrssssssssssssssssssssssssssqwertyuioplqwertyuiopoiuytrewqjhgfdsasdfghjklmnbvcxzaqwertyuio",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.City), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenZipCodeLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.ZipCode).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test212aqwertyuio",
                    }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.ZipCode), error.Message);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithWhenAreYouAvailableToStartWork()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "FirstName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "LastName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@email.com",
                },
                new()
                    {
                        FormFieldId = form.Fields.Where(field => field.DefaultFieldId == (long) ApplicationFormDefaultFields.WhenAreYouAvailableToStartWork).Select(field =>field.Id).FirstOrDefault(),
                        FormFieldValue = DateOnly.FromDateTime(DateTime.Today).ToString()
                    }

            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenAvailableToStartWorkOnPastdates()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
            new()
                {
                    FormFieldId = form.Fields.Where(field => field.DefaultFieldId ==(long) ApplicationFormDefaultFields.WhenAreYouAvailableToStartWork).Select(field =>field.Id).FirstOrDefault(),
                    FormFieldValue = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)).ToString()
                }
            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.WhenAreYouAvailableToStartWork, Constants.ApplicationFormFields.WhenAreYouAvailableToStartWork), error.Message);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithPhoto()
    {
        var fileContent = FileUploadsContent.FileWithBase64;
        var fileBytes = Convert.FromBase64String(fileContent);
        var fileStream = new MemoryStream(fileBytes);
        string fileName = "testfile.png";

        var blobServiceMock = new Mock<IBlobService>();
        var expectedResult = "https://example.blob.core.windows.net/container/" + fileName;
        blobServiceMock.Setup(service => service.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                       .ReturnsAsync(expectedResult);

        var result = await blobServiceMock.Object.UploadFileAsync(fileStream, fileName);

        Assert.Equal(expectedResult, result);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithResume()
    {
        var fileContent = FileUploadsContent.FileWithBase64;
        var fileBytes = Convert.FromBase64String(fileContent);
        var fileStream = new MemoryStream(fileBytes);
        string fileName = "TestResume.pdf";

        var blobServiceMock = new Mock<IBlobService>();
        var expectedResult = "https://example.blob.core.windows.net/container/" + fileName;
        blobServiceMock.Setup(service => service.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                       .ReturnsAsync(expectedResult);

        var result = await blobServiceMock.Object.UploadFileAsync(fileStream, fileName);

        Assert.Equal(expectedResult, result);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithCoverLetter()
    {
        var fileContent = FileUploadsContent.FileWithBase64;
        var fileBytes = Convert.FromBase64String(fileContent);
        var fileStream = new MemoryStream(fileBytes);
        string fileName = "coverletter.docx";

        var blobServiceMock = new Mock<IBlobService>();
        var expectedResult = "https://example.blob.core.windows.net/container/" + fileName;
        blobServiceMock.Setup(service => service.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                       .ReturnsAsync(expectedResult);

        var result = await blobServiceMock.Object.UploadFileAsync(fileStream, fileName);

        Assert.Equal(expectedResult, result);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenPhotoIsInvalidFormat()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Photo).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = FileUploadsContent.FileWithBase64,
                        FileName="Test.txt"
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.InvalidFileFormat, Constants.ApplicationFormFields.Photo), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenFileUploadFileNameIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Photo).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = FileUploadsContent.FileWithBase64,
                        FileName=""
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.FormFieldFileNameMissing, Constants.ApplicationFormFields.Photo), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenPhotoIsExceedsLimit()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Photo).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = FileUploadsContent.FileWithContentMoreThan1MB,
                        FileName="Test2.4mb.png"
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.FileSizeExceeds, Constants.ApplicationFormFields.Photo), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenResumeAndCoverLetterIsInvalidFormat()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Resume).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = FileUploadsContent.FileWithBase64,
                        FileName="CoverLetter.csv"
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.InvalidFileFormat, Constants.ApplicationFormFields.Resume), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenResumeIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Resume).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                        FileName="TestResume.pdf"
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.Resume), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenResumeIsExcelFormat()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.CoverLetter).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = FileUploadsContent.FileWithBase64,
                        FileName="TestCoverLetter.xls"
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.InvalidFileFormat, Constants.ApplicationFormFields.CoverLetter), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenCustomFieldIsRequiredAndIsEmpty()
    {
        var formFieldTextBoxAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "100" } };
        var customFieldName = "Alternate Phone Number";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                    new()
                    {
                        Name = customFieldName,
                        DisplayOrder = 8,
                        IsSystemDefault = false,
                        IsAlwaysActiveAndRequired = true,
                        IsActive = true,
                        IsRequired = true,
                        SectionId = 2,
                        TypeId = 3,
                        AttributeValues=formFieldTextBoxAttributeValues
                    }
                ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var formId = response.Id;
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var customFormField = form.Fields.Find(a => a.IsSystemDefault == false && a.Name == customFieldName);
        Assert.NotNull(customFormField);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = customFormField.Id,
                        FormFieldValue = "",
                    }
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, customFormField.Name), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenCustomFieldMaxLengthExceed()
    {
        var formFieldTextBoxAreaAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "10" } };
        var customFieldName = "Details";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                  new()
                    {
                        Name = customFieldName,
                        DisplayOrder = 8,
                        IsSystemDefault = false,
                        IsAlwaysActiveAndRequired = true,
                        IsActive = true,
                        IsRequired = true,
                        SectionId = 2,
                        TypeId = 4,
                        AttributeValues=formFieldTextBoxAreaAttributeValues
                    }
                ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var formId = response.Id;
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var customFormField = form.Fields.Find(a => a.IsSystemDefault == false && a.Name == customFieldName);
        Assert.NotNull(customFormField);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = customFormField.Id,
                        FormFieldValue = "12345678901",
                    }
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, customFormField.Name), exception.Message);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithCustomFieldValues()
    {
        var formFieldTextBoxAreaAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "10" } };
        var customFieldName = "Details";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                 new()
                    {
                        Name = "Details",
                        DisplayOrder = 8,
                        IsSystemDefault = false,
                        IsAlwaysActiveAndRequired = true,
                        IsActive = true,
                        IsRequired = true,
                        SectionId = 2,
                        TypeId = 4,
                        AttributeValues=formFieldTextBoxAreaAttributeValues
                    },
                 new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var formId = response.Id;
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var customFormField = form.Fields.Find(a => a.IsSystemDefault == false && a.Name == customFieldName);
        Assert.NotNull(customFormField);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "FirstName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "LastName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@email.com",
                },
                new()
                    {
                        FormFieldId = customFormField.Id,
                        FormFieldValue = "123456789",
                    }
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };

        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenCustomFieldFileUploadIsRequiredAndIsEmpty()
    {
        var formFieldFileUploadAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = "1048576" } };
        var customFieldName = "Additional file";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
              [
               new()
                 {
                     Name = customFieldName,
                     DisplayOrder = 8,
                     IsSystemDefault = false,
                     IsAlwaysActiveAndRequired = true,
                     IsActive = true,
                     IsRequired = true,
                     SectionId = 3,
                     TypeId = 2,
                     AttributeValues=formFieldFileUploadAttributeValues
                 }
              ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var formId = response.Id;
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var customFormField = form.Fields.Find(a => a.IsSystemDefault == false && a.Name == customFieldName);
        Assert.NotNull(customFormField);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                 {
                     FormFieldId = customFormField.Id,
                     FormFieldValue = "",
                     FileName=""
                 }
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, customFormField.Name), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenCustomFileUplodIsInvalidFormat()
    {
        var formFieldFileUploadAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = "1048576" } };
        var customFieldName = "Additional file1";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
              [
               new()
                 {
                     Name = customFieldName,
                     DisplayOrder = 8,
                     IsSystemDefault = false,
                     IsAlwaysActiveAndRequired = true,
                     IsActive = true,
                     IsRequired = true,
                     SectionId = 3,
                     TypeId = 2,
                     AttributeValues=formFieldFileUploadAttributeValues
                 }
              ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var formId = response.Id;
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var customFormField = form.Fields.Find(a => a.IsSystemDefault == false && a.Name == customFieldName);
        Assert.NotNull(customFormField);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = customFormField.Id,
                        FormFieldValue = FileUploadsContent.FileWithBase64,
                        FileName="Test.txt"
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.InvalidFileFormat, customFormField.Name), exception.Message);
    }

    [Fact]
    public async Task ShouldUploadCustomFieldFileUplodAttributeValueIsEmpty()
    {
        var formFieldFileUploadAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = "" } };
        var customFieldName = "Additional file2";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
              [
               new()
                 {
                     Name = customFieldName,
                     DisplayOrder = 8,
                     IsSystemDefault = false,
                     IsAlwaysActiveAndRequired = true,
                     IsActive = true,
                     IsRequired = true,
                     SectionId = 3,
                     TypeId = 2,
                     AttributeValues=formFieldFileUploadAttributeValues
                 }
              ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var formId = response.Id;
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var customFormField = form.Fields.Find(a => a.IsSystemDefault == false && a.Name == customFieldName);
        Assert.NotNull(customFormField);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = customFormField.Id,
                        FormFieldValue = FileUploadsContent.FileWithBase64,
                        FileName="Test.pdf"
                    }
            ]
        };
        var fileContent = jobApplicationDto.FieldValues[0].FormFieldValue;
        var fileBytes = Convert.FromBase64String(fileContent);
        var fileStream = new MemoryStream(fileBytes);
        string fileName = jobApplicationDto.FieldValues[0].FileName;

        var blobServiceMock = new Mock<IBlobService>();
        var expectedResult = "https://example.blob.core.windows.net/container/" + fileName;
        blobServiceMock.Setup(service => service.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                       .ReturnsAsync(expectedResult);

        var result = await blobServiceMock.Object.UploadFileAsync(fileStream, fileName);

        Assert.Equal(expectedResult, result);
    }

    [Fact]
    public async Task ShouldSaveCustomFieldTextAreaAttributeValueIsEmpty()
    {
        var formFieldTextBoxAreaAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "" } };
        var customFieldName = "Address";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
              [
                new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
               new()
                 {
                     Name = customFieldName,
                     DisplayOrder = 5,
                     IsSystemDefault = false,
                     IsAlwaysActiveAndRequired = true,
                     IsActive = true,
                     IsRequired = true,
                     SectionId = 3,
                     TypeId = 4,
                     AttributeValues=formFieldTextBoxAreaAttributeValues
                 }
              ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);

        var formId = response.Id;
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var customFormField = form.Fields!.Find(a => a.IsSystemDefault == false && a.Name == customFieldName);
        Assert.NotNull(customFormField);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                     {
                         FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test First Name",
                     },
                     new()
                     {
                         FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test Last Name",
                     },
                     new()
                     {
                         FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test@test.com",
                     },
                    new()
                    {
                        FormFieldId = customFormField.Id,
                        FormFieldValue = "test address details",
                        FileName=""
                    }
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var jobApplicationInsertResult = await _jobApplicationsController.Create(jobApplicationDto);
        var jobApplicationSuccessResult = Assert.IsType<OkObjectResult>(jobApplicationInsertResult.Result);
        var jobApplicationSuccessResponse = Assert.IsType<CreatedResponse>(okResult.Value);
        Assert.NotNull(jobApplicationSuccessResponse);
        Assert.True(jobApplicationSuccessResponse.Id > 0);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithCustomFileUpload()
    {
        var fileContent = FileUploadsContent.FileWithBase64;
        var fileBytes = Convert.FromBase64String(fileContent);
        var fileStream = new MemoryStream(fileBytes);
        string fileName = "additionaldocuments.docx";

        var blobServiceMock = new Mock<IBlobService>();
        var expectedResult = "https://example.blob.core.windows.net/container/" + fileName;
        blobServiceMock.Setup(service => service.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                       .ReturnsAsync(expectedResult);

        var result = await blobServiceMock.Object.UploadFileAsync(fileStream, fileName);

        Assert.Equal(expectedResult, result);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithCompanyNameJobTitleAndIndustryType()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues = [
                    new(){
                         FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "FirstName",
                    },
                    new(){
                         FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "LastName",
                    },
                    new(){
                         FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test@email.com",
                    },
                ],
            FieldSets =
            [
                    new()
                    {
                            FieldValues =
                            [
                                new()
                                {
                                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.CompanyName).Select(a =>a.Id).FirstOrDefault(),
                                    FormFieldValue = "Test Company",
                                },
                                new()
                                {
                                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.JobTitle).Select(a =>a.Id).FirstOrDefault(),
                                    FormFieldValue = "Test Job Title",
                                },
                                new()
                                {
                                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.IndustryType).Select(a =>a.Id).FirstOrDefault(),
                                    FormFieldValue = "Test Industry Type",
                                }
                            ]
                    }

            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenCompanyNameLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues = [],
            FieldSets =
            [
                new()
                {
                    FieldValues=
                    [
                        new()
                        {
                            FormFieldId = form.Fields!.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.CompanyName).Select(a =>a.Id).FirstOrDefault(),
                            FormFieldValue = "Test Companyqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmqwertyuiopoiuytrewqasdfghjkl",
                        }
                    ]
                }

            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.CompanyName), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenJobTitleLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues = [],
            FieldSets =
            [
                new()
                {
                    FieldValues=
                    [
                        new()
                        {
                            FormFieldId = form.Fields!.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.JobTitle).Select(a =>a.Id).FirstOrDefault(),
                            FormFieldValue = "Test Companyqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmqwertyuiopoiuytrewqasdfghjkl",
                        }
                    ]
                }

            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.JobTitle), error.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorWhenIndustryTypeLimitExceeds()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues = [],
            FieldSets =
            [
                new()
                {
                    FieldValues=
                    [
                        new()
                        {
                            FormFieldId = form.Fields!.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.IndustryType).Select(a =>a.Id).FirstOrDefault(),
                            FormFieldValue = "TestCompanyqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmqwertyuiopoiuytrewqasdfghjkl",
                        }
                    ]
                }

            ]
        };
        var error = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.MaxLengthExceeded, Constants.ApplicationFormFields.IndustryType), error.Message);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWhenValidSchoolNameAndEducationLevelPassed()
    {
        var formId = await CreateApplicationFormWithAllDefaultFields();
        var jobPostId = await CreateJobPostWithForm(formId);
        var form = await GetApplicationFormByJobPostId(jobPostId);
        var jobApplicationDto = await CreateJobApplicationDtoWithEducationalHistoryFields(form, jobPostId);
        await CreateJobApplication(jobApplicationDto);
    }

    [Fact]
    public async Task ShouldFailJobApplicationCreationWhenSchoolNameMaxLengthExceeded()
    {
        var formId = await CreateApplicationFormWithAllDefaultFields();
        var jobPostId = await CreateJobPostWithForm(formId);
        var form = await GetApplicationFormByJobPostId(jobPostId);
        var jobApplicationDto = await CreateJobApplicationDtoWithEducationalHistoryFields(form, jobPostId);

        var schoolNameField = form.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.SchoolName);
        var fieldSet = jobApplicationDto?.FieldSets?.FirstOrDefault();
        var fieldValue = fieldSet?.FieldValues?.FirstOrDefault();
        fieldValue!.FormFieldValue = new string('*', 101); //create a string of 101 characters to validate max lengh
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.Create(jobApplicationDto!));
        exception.Message.Should().Be(string.Format(JobApplicationValidation.MaxLengthExceeded, schoolNameField?.Name));
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithWorkHistoryStartAndEndDate()
    {
        var formId = await CreateApplicationForm();
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        List<JobApplicationFieldValueDto> jobApplicationFieldSet = new()
        {
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.StartDate,  "06/2018"),
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.EndDate,  "04/2020")
        };

        var jobApplicationDto = PrepareJobApplication(jobPostId,
            [
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.FirstName,  "First Name"),
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.LastName,  "Last Name"),
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.PersonalEmailAddress,  "test@test.coom")
            ], jobApplicationFieldSet);
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldFailCreateJobApplicationWithWorkHistoryFutureStartDate()
    {
        var formId = await CreateApplicationForm();
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var defaultFieldName = "Start Date";
        var defaultField = form.Fields?.Find(a => a.IsSystemDefault == true && a.Name == defaultFieldName);
        List<JobApplicationFieldValueDto> jobApplicationFieldSet = new()
        {
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.StartDate,  "06/2025"),
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.EndDate,  "04/2020")
        };
        var jobApplicationDto = PrepareJobApplication(jobPostId, [], jobApplicationFieldSet);
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.True(exception.Message?.Contains(string.Format(JobApplicationValidation.WorkHistoryInvalidStartDate, defaultField?.Name)));
    }

    [Fact]
    public async Task ShouldFailCreateJobApplicationWithWorkHistoryWhenEndDateLessThanStartDate()
    {
        var formId = await CreateApplicationForm();
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var defaultFieldName = "End Date";
        var defaultField = form.Fields?.Find(a => a.IsSystemDefault == true && a.Name == defaultFieldName);
        List<JobApplicationFieldValueDto> jobApplicationFieldSet = new()
        {
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.StartDate,  "06/2023"),
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.EndDate,  "04/2020")
        };
        var jobApplicationDto = PrepareJobApplication(jobPostId, [], jobApplicationFieldSet);
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.True(exception.Message?.Contains(string.Format(JobApplicationValidation.WorkHistoryInvalidEndDate, defaultField?.Name)));
    }

    [Fact]
    public async Task ShouldFailCreateJobApplicationWithWorkHistoryWhenStartDateIsNull()
    {
        var formId = await CreateApplicationForm();
        var jobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var defaultFieldName = "Start Date";
        var defaultField = form.Fields?.Find(a => a.IsSystemDefault == true && a.Name == defaultFieldName);
        List<JobApplicationFieldValueDto> jobApplicationFieldSet = new()
        {
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.StartDate, null),
            PrepareFieldValue(form.Fields, ApplicationFormDefaultFields.EndDate,  "06/2023")
        };
        var jobApplicationDto = PrepareJobApplication(jobPostId, [], jobApplicationFieldSet);
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.True(exception.Message?.Contains(string.Format(JobApplicationValidation.WorkHistoryDateRequired, defaultField?.Name)));
    }

    [Fact]
    public async Task ShouldGetAllActiveJobPostAndApplication()
    {
        var formId = await CreateApplicationForm();
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobStatus = true;
        var jobPost = new JobPostDto { ApplicationFormId = formId, Title = "Title2000", IsActive = jobStatus, Description = "Descrption For the Given Job Post", IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), HiringManagerId = _currentUserContext.UserId, StartDateTime = DateTime.UtcNow };
        var jobPostId = await _jobPostService.AddAsync(jobPost);
        Assert.True(jobPostId > 0);

        var fieldValues = new List<JobApplicationFieldValueDto> {
                   new()
                     {
                         FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test First Name",
                     },
                    new()
                     {
                         FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName ).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test Middle Name",
                     },
                    new()
                     {
                         FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test Last Name",
                     },
                     new()
                     {
                         FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "test1@tsdt.com",
                     },
                     new()
                     {
                         FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.HomeTelephoneNumber).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "9999999000",
                     },
                     new()
                     {
                         FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
                         FormFieldValue = "9999999001",
                     },
                 };

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues = fieldValues,
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var jobApplicationId = await CreateJobApplication(jobApplicationDto);
        Assert.True(jobApplicationId > 0);

        var jobApplicationResponseResult = await _jobApplicationsController.GetAllAsync(jobStatus);
        Assert.IsType<ActionResult<IEnumerable<JobApplicationListDto>>>(jobApplicationResponseResult);
        var okResult = Assert.IsType<OkObjectResult>(jobApplicationResponseResult.Result);
        var jobApplications = Assert.IsAssignableFrom<IEnumerable<JobApplicationListDto>>(okResult.Value);

        Assert.NotEmpty(jobApplications);
        Assert.True(jobApplications.ToList().Count > 0);

        foreach (var jobApplication in jobApplications)
        {
            Assert.Equal(jobApplication.FirstName, fieldValues.FirstOrDefault(field => field.FormFieldId == form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.FirstName).Select(a => a.Id).FirstOrDefault())!.FormFieldValue);
            Assert.Equal(jobApplication.LastName, fieldValues.FirstOrDefault(field => field.FormFieldId == form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.LastName).Select(a => a.Id).FirstOrDefault())!.FormFieldValue);
            Assert.Equal(jobApplication.MiddleName, fieldValues.FirstOrDefault(field => field.FormFieldId == form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.MiddleName).Select(a => a.Id).FirstOrDefault())!.FormFieldValue);
        }
    }

    //[Fact]
    //public async Task ShouldGetAllInActiveJobPostAndApplication()
    //{
    //    var formId = await CreateApplicationForm();
    //    var form = await _applicationFormService.GetFormWithActiveFields(formId);
    //    Assert.NotNull(form);

    //    var jobStatus = false;
    //    var jobPost = new JobPostDto { ApplicationFormId = formId, Title = "Title2008", IsActive = jobStatus, Description = "Descrption For the Given Job Post", IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), HiringManagerId = _currentUserContext.UserId, StartDateTime = DateTime.UtcNow };
    //    var jobPostId = await _jobPostService.AddAsync(jobPost);
    //    Assert.True(jobPostId > 0);

    //    var fieldValues = new List<JobApplicationFieldValueDto> {
    //               new()
    //                 {
    //                     FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
    //                     FormFieldValue = "test First Name",
    //                 },
    //                new()
    //                 {
    //                     FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName ).Select(a =>a.Id).FirstOrDefault(),
    //                     FormFieldValue = "test Middle Name",
    //                 },
    //                new()
    //                 {
    //                     FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
    //                     FormFieldValue = "test Last Name",
    //                 },
    //                 new()
    //                 {
    //                     FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
    //                     FormFieldValue = "test1@tsdt.com",
    //                 },
    //                 new()
    //                 {
    //                     FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.HomeTelephoneNumber).Select(a =>a.Id).FirstOrDefault(),
    //                     FormFieldValue = "9999999000",
    //                 },
    //                 new()
    //                 {
    //                     FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
    //                     FormFieldValue = "9999999001",
    //                 },
    //             };

    //    var jobApplicationDto = new JobApplicationDto
    //    {
    //        JobPostId = jobPostId,
    //        FieldValues = fieldValues,
    //        ApplicantQuizResult = new ApplicantQuizResultDto()
    //        {
    //            QuizId = 1,
    //            QuizAnswers = [
    //                new(){
    //                    QuestionId =1,
    //                    AnswerId =1,
    //                },
    //                new(){
    //                    QuestionId =2,
    //                    AnswerId =2
    //                }
    //            ]
    //        }
    //    };
    //    var jobApplicationId = await CreateJobApplication(jobApplicationDto);
    //    Assert.True(jobApplicationId > 0);

    //    var jobApplicationResponseResult = await _jobApplicationsController.GetAllAsync(jobStatus);
    //    Assert.IsType<ActionResult<IEnumerable<JobApplicationListDto>>>(jobApplicationResponseResult);
    //    var okResult = Assert.IsType<OkObjectResult>(jobApplicationResponseResult.Result);
    //    var jobApplications = Assert.IsAssignableFrom<IEnumerable<JobApplicationListDto>>(okResult.Value);

    //    Assert.NotEmpty(jobApplications);
    //    Assert.True(jobApplications.ToList().Count > 0);

    //    foreach (var jobApplication in jobApplications)
    //    {
    //        Assert.Equal(jobApplication.FirstName, fieldValues.Find(field => field.FormFieldId == form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.FirstName).Select(a => a.Id).FirstOrDefault())!.FormFieldValue);
    //        Assert.Equal(jobApplication.LastName, fieldValues.Find(field => field.FormFieldId == form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.LastName).Select(a => a.Id).FirstOrDefault())!.FormFieldValue);
    //        Assert.Equal(jobApplication.MiddleName, fieldValues.Find(field => field.FormFieldId == form.Fields!.Where(a => a.DefaultFieldId == (long)ApplicationFormDefaultFields.MiddleName).Select(a => a.Id).FirstOrDefault())!.FormFieldValue);
    //    }
    //}

    [Fact]
    public async Task ShouldAddJobApplicationAttachment()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);

        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var fileName = $"Attachment_{DateTime.Now.Ticks}";
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        var attachmentId = await AddAttachment(fileName, jobApplicationId, fileStream, JobApplicationAttachmentType.Resume);
        Assert.True(attachmentId > 0);

        var attachmentsDb = await _jobApplicationService.GetAttachmentsByIdAsync(jobApplicationId);
        var attachmentDb = attachmentsDb.FirstOrDefault(attachment => attachment.Id == attachmentId);
        Assert.NotNull(attachmentDb);
        Assert.True(attachmentDb.Id > 0);

        var blobServiceMock = new Mock<IBlobService>();
        var expectedResult = "https://example.blob.core.windows.net/container/" + fileName;
        blobServiceMock.Setup(service => service.UploadFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                       .ReturnsAsync(expectedResult);

        var result = await blobServiceMock.Object.UploadFileAsync(fileStream, fileName);
        Assert.Equal(expectedResult, result);
    }

    [Fact]
    public async Task ShouldViewAttachmentById()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var fileName = $"Attachment_{DateTime.Now.Ticks}";
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        var attachmentId = await AddAttachment(fileName, jobApplicationId, fileStream, JobApplicationAttachmentType.CoverLetter);
        Assert.True(attachmentId > 0);

        var blobServiceMock = new Mock<IBlobService>();
        var result = blobServiceMock.Setup(service => service.GetFileStreamAsync(It.IsAny<string>()))
                                                             .ReturnsAsync(fileStream);

        var blobFileStream = await blobServiceMock.Object.GetFileStreamAsync(fileName);
        Assert.Equal(fileStream, blobFileStream);
        using var memoryStream = new MemoryStream();
        await blobFileStream.CopyToAsync(memoryStream);
        var byteArray = memoryStream.ToArray();
        var blobFileString = Convert.ToBase64String(byteArray);
        Assert.Equal(FileUploadsContent.base64StringPDF, blobFileString);
    }

    [Fact]
    public async Task ShouldThrowErrorInAddAttachmentWhenFileNameAlreadyExists()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var fileName = $"Attachment_{DateTime.Now.Ticks}";
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        JobApplicationAttachmentDto attachment = new()
        {
            Name = fileName,
            JobApplicationId = jobApplicationId,
            TypeId = (long)JobApplicationAttachmentType.Resume,
            File = GenerateFormFileFromStream(fileName, fileStream),
        };
        var attachmentId = await _jobApplicationService.AddAttachment(attachment);
        Assert.True(attachmentId > 0);

        var existResult = await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _jobApplicationService.AddAttachment(attachment));
        Assert.NotNull(existResult);
        Assert.Equal(JobApplicationAttachmentValidation.FileAlreadyExist, existResult.Message);
    }

    [Fact]
    public async Task ShouldThrowErrorInAddAttachmentWhenJobApplicationAttachmentDtoIsNull()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);
        JobApplicationAttachmentDto attachment = null;

        var existResult = await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _jobApplicationService.AddAttachment(attachment));
        Assert.NotNull(existResult);
        Assert.Equal(JobApplicationAttachmentValidation.AttachmentRequired, existResult.Message);
    }

    [Fact]
    public async Task ShouldGetJobApplicationAttachmentsList()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var fileName = $"Attachment_{DateTime.Now.Ticks}";
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        var attachmentOne = await AddAttachment(fileName, jobApplicationId, fileStream, JobApplicationAttachmentType.Resume);
        Assert.True(attachmentOne > 0);

        fileName = $"Attachment_{DateTime.Now.Ticks}";
        fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        var attachmentIdTwo = await AddAttachment(fileName, jobApplicationId, fileStream, JobApplicationAttachmentType.CoverLetter);
        Assert.True(attachmentIdTwo > 0);

        var attachmentsDbResult = await _jobApplicationsController.GetAttachmentByIdAsync(jobApplicationId);
        var okResult = Assert.IsType<OkObjectResult>(attachmentsDbResult.Result);
        var attachmentsDb = Assert.IsType<List<JobApplicationAttachmentListDto>?>(okResult.Value);
        var attachmentDb = attachmentsDb?.Find(attachment => attachment.Id == attachmentOne);
        Assert.NotNull(attachmentDb);
        Assert.True(attachmentDb.Id > 0);
        Assert.Equal(attachmentDb.Id, attachmentOne);
        Assert.Equal(attachmentDb.Type, JobApplicationAttachmentType.Resume.ToString());

        var attachmentTwoDb = attachmentsDb?.Find(attachment => attachment.Id == attachmentIdTwo);
        Assert.NotNull(attachmentTwoDb);
        Assert.True(attachmentTwoDb.Id > 0);
        Assert.Equal(attachmentTwoDb.Id, attachmentIdTwo);
        var coverLetter = JobApplicationAttachmentType.CoverLetter;
        Assert.Equal(attachmentTwoDb.Type, coverLetter.GetEnumDisplayName());
    }

    [Fact]
    public async Task ShouldDeleteAttachmentById()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var fileName = $"Attachment_{DateTime.Now.Ticks}";
        var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
        var attachmentId = await AddAttachment(fileName, jobApplicationId, fileStream, JobApplicationAttachmentType.Resume);
        Assert.True(attachmentId > 0);

        await _jobApplicationsController.DeleteAttachmentByIdAsync(attachmentId);

        var returnFlag = true;
        var blobServiceMock = new Mock<IBlobService>();
        var result = blobServiceMock.Setup(service => service.DeleteBlobAsync(It.IsAny<string>()))
                                                             .ReturnsAsync(returnFlag);

        var blobFlag = await blobServiceMock.Object.DeleteBlobAsync(fileName);
        Assert.True(blobFlag);
    }

    [Fact]
    public async Task ShouldReturnPdfFileContentWhenValidJobApplicationIdIsProvided()
    {
        var formId = await CreateApplicationFormWithAllDefaultFields();
        var jobPostId = await CreateJobPostWithForm(formId);
        var form = await GetApplicationFormByJobPostId(jobPostId);
        var _atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var jobApplicationNoteRepository = new JobApplicationNoteRepository(_dbContext, _currentUserContext);
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        var jobApplicationFieldSetDto = await CreateJobApplicationDtoWithEducationalHistoryFields(form, jobPostId);
        jobApplicationDto.FieldSets = _mapper.Map<List<JobApplicationFieldSetDto>>(jobApplicationFieldSetDto.FieldSets);
        var jobApplicationId = await CreateJobApplication(jobApplicationDto);

        var mockPdfConverter = new Mock<IConverter>();
        var pdfContent = new byte[] { 1, 2, 3, 4 };
        var expectedBase64pdfContent = Convert.ToBase64String(pdfContent);
        mockPdfConverter.Setup(m => m.Convert(It.IsAny<IDocument>()))
                        .Returns(pdfContent);

        var mockRazorLightEngineWrapper = new Mock<IRazorLightEngineWrapper>();
        mockRazorLightEngineWrapper
            .Setup(m => m.RenderRazorTemplate(It.IsAny<string>(), It.IsAny<object>()))
            .ReturnsAsync("<html>Job Application HTML</html>");

        var mockCosmosDbService = new Mock<ICosmosDbService>();

        var jobApplicationNoteService = new JobApplicationNoteService(_atsBaseRepository, _mapper, _jobApplicationRepository,
                                        _currentUserContext, jobApplicationNoteRepository, null, mockCosmosDbService.Object);
        var mockLogger = new Mock<ILogger<JobApplicationService>>();

        var mockConfig = new Mock<IOptions<EmailTemplateConfig>>();
        var mockLoggerEmailClient = new Mock<ILogger<EmailClient>>();
        var emailConfig = new SendGridEmailConfig();
        emailConfig.ApiKey = "testkey";
        emailConfig.SenderEmail = "ats-no-reply@mybbsi.com";
        var emailClient = new EmailClient(emailConfig, mockLoggerEmailClient.Object);

        var htmlToPdfConverterService = new HtmlToPdfConverterService(mockPdfConverter.Object, mockRazorLightEngineWrapper.Object);
        var jobApplicationService = new JobApplicationService(_jobApplicationRepository, _mapper, _applicationFormService,
                                                               null, htmlToPdfConverterService, jobApplicationNoteService, null,
                                                               mockLogger.Object, emailClient, mockConfig.Object, null, null, _currentUserContext, null, mockCosmosDbService.Object, _applicantQuizRepository);

        var jobApplicationsController = new JobApplicationsController(jobApplicationService);

        var result = await jobApplicationsController.DownloadApplication(jobApplicationId, true);
        var okResult = Assert.IsType<OkObjectResult>(result);
        var base64Pdf = Assert.IsType<string>(okResult.Value);
        Assert.Equal(expectedBase64pdfContent, base64Pdf);
    }

    [Fact]
    public async Task ShouldReturnPdfFileContentWhenValidJobApplicationIdIsProvidedWithoutPreview()
    {
        var formId = await CreateApplicationFormWithAllDefaultFields();
        var jobPostId = await CreateJobPostWithForm(formId);
        var form = await GetApplicationFormByJobPostId(jobPostId);
        var _atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var jobApplicationNoteRepository = new JobApplicationNoteRepository(_dbContext, _currentUserContext);
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        var jobApplicationFieldSetDto = await CreateJobApplicationDtoWithEducationalHistoryFields(form, jobPostId);
        jobApplicationDto.FieldSets = _mapper.Map<List<JobApplicationFieldSetDto>>(jobApplicationFieldSetDto.FieldSets);
        var jobApplicationId = await CreateJobApplication(jobApplicationDto);

        var mockPdfConverter = new Mock<IConverter>();
        var pdfContent = new byte[] { 1, 2, 3, 4 };
        var expectedBase64pdfContent = Convert.ToBase64String(pdfContent);
        mockPdfConverter.Setup(m => m.Convert(It.IsAny<IDocument>()))
                        .Returns(pdfContent);

        var mockRazorLightEngineWrapper = new Mock<IRazorLightEngineWrapper>();
        mockRazorLightEngineWrapper
            .Setup(m => m.RenderRazorTemplate(It.IsAny<string>(), It.IsAny<object>()))
            .ReturnsAsync("<html>Job Application HTML</html>");

        var mockCosmosDbService = new Mock<ICosmosDbService>();

        var jobApplicationNoteService = new JobApplicationNoteService(_atsBaseRepository, _mapper, _jobApplicationRepository,
                                        _currentUserContext, jobApplicationNoteRepository, null, mockCosmosDbService.Object);
        var mockLogger = new Mock<ILogger<JobApplicationService>>();

        var mockConfig = new Mock<IOptions<EmailTemplateConfig>>();
        var mockLoggerEmailClient = new Mock<ILogger<EmailClient>>();
        var emailConfig = new SendGridEmailConfig();
        emailConfig.ApiKey = "testkey";
        emailConfig.SenderEmail = "ats-no-reply@mybbsi.com";
        var emailClient = new EmailClient(emailConfig, mockLoggerEmailClient.Object);

        var htmlToPdfConverterService = new HtmlToPdfConverterService(mockPdfConverter.Object, mockRazorLightEngineWrapper.Object);
        var jobApplicationService = new JobApplicationService(_jobApplicationRepository, _mapper, _applicationFormService,
                                                               null, htmlToPdfConverterService, jobApplicationNoteService, null,
                                                               mockLogger.Object, emailClient, mockConfig.Object, null, null, _currentUserContext, null, mockCosmosDbService.Object, _applicantQuizRepository);

        var jobApplicationsController = new JobApplicationsController(jobApplicationService);

        var result = await jobApplicationsController.DownloadApplication(jobApplicationId);
        var okResult = Assert.IsType<FileContentResult>(result);
    }

    [Fact]
    public async Task ShouldFailWhenJobApplicationIdIsInvalid()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationsController.DownloadApplication(0, true));
        Assert.Equal(JobApplicationValidation.InvalidJobApplicationId, exception.Message);
    }

    [Fact]
    public async Task ShouldGetJobApplicationDetailsByIdWithCustomField()
    {
        var customFieldTextBoxName = "Title";
        var customFieldDropDownName = "Test City";
        var customFieldInFieldSetDropDownName = "Grade";

        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            IncludeEducationHistory = true,
            Fields =
              [
                        new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },

                        new ()
                        {
                            Name = customFieldTextBoxName,
                            DisplayOrder = 7,
                            IsSystemDefault = false,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 2,
                            TypeId = (long)ApplicationFormFieldTypes.SingleLineInput,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new ()
                        {
                            Name = customFieldDropDownName,
                            DisplayOrder = 8,
                            IsSystemDefault = false,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 2,
                            TypeId = (long)ApplicationFormFieldTypes.Dropdown,
                            Options = new List<ApplicationFormFieldOptionDto>
                                          {
                                             new() {Name = "Washington"},
                                             new () {Name = "New York"}
                                          }
                        },

                        new()
                       {
                           Name = "School Name",
                           DisplayOrder = 12,
                           IsSystemDefault = true,
                           DefaultFieldId = 18,
                           IsAlwaysActiveAndRequired = true,
                           IsActive = true,
                           IsRequired = true,
                           SectionId = 5,
                           TypeId = (long)ApplicationFormFieldTypes.SingleLineInput,
                           LookupTypeId = 8,
                           AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                                                {
                                                    {new() {AttributeId = 1, AttributeValue = "100"} }
                                                }
                       },
                        new ()
                        {
                            Name = customFieldInFieldSetDropDownName,
                            DisplayOrder = 15,
                            IsSystemDefault = false,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 5,
                            TypeId = (long)ApplicationFormFieldTypes.Dropdown,
                            Options = new List<ApplicationFormFieldOptionDto>
                                          {
                                            new() {Name = "Option 1"},
                                            new () {Name = "Option 2"}
                                          }
                        },
              ],
        };
        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);
        var formId = response.Id;

        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobPostDto = new JobPostDto { ApplicationFormId = formId, Title = "Technical Manager", IsActive = true, Description = "Descrption For the Given Job Post", IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), HiringManagerId = _currentUserContext.UserId, StartDateTime = DateTime.UtcNow };
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.True(jobPostId > 0);

        var schoolNameFormField = form.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.SchoolName);
        Assert.NotNull(schoolNameFormField);
        Assert.True(schoolNameFormField.Id > 0);

        var fieldValueOption = form.Fields?.Find(field => field.IsSystemDefault == false && field.TypeId == (long)ApplicationFormFieldTypes.Dropdown && field.Name == customFieldDropDownName).Options.First();
        Assert.NotNull(fieldValueOption);
        Assert.True(fieldValueOption.Id > 0);

        var fieldSetFieldValueOption = form.Fields?.Find(field => field.IsSystemDefault == false && field.TypeId == (long)ApplicationFormFieldTypes.Dropdown && field.Name == customFieldInFieldSetDropDownName).Options.First();
        Assert.NotNull(fieldSetFieldValueOption);
        Assert.True(fieldSetFieldValueOption.Id > 0);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues =
            [
                   new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test First Name",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test Last Name",
                    },
                     new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test Middle Name",
                    },
                  new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test@tsdt.com",
                    },

                    new()
                    {
                        FormFieldId = form.Fields.Where(field => field.IsSystemDefault == false && field.TypeId==(long)ApplicationFormFieldTypes.SingleLineInput && field.Name==customFieldTextBoxName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test custom title",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(field => field.IsSystemDefault == false && field.TypeId==(long)ApplicationFormFieldTypes.Dropdown && field.Name==customFieldDropDownName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = fieldValueOption.Id.ToString()
                    },
                ],
            FieldSets =
            [
                new()
                {
                    FieldValues =
                    [
                        new() {FormFieldId = schoolNameFormField.Id, FormFieldValue = "school1" },
                        new() {
                                FormFieldId = form.Fields.Where(field=> field.IsSystemDefault == false && field.TypeId==(long)ApplicationFormFieldTypes.Dropdown && field.SectionId==(long)ApplicationFormSections.EducationHistory && field.Name==customFieldInFieldSetDropDownName).Select(a =>a.Id).FirstOrDefault(),
                                FormFieldValue = fieldSetFieldValueOption.Id.ToString()
                              }
                    ]
                }
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);

        var getJobApplication = await _jobApplicationsController.GetById(Id);
        Assert.NotNull(getJobApplication.Result);
        var jobApplicationResult = Assert.IsType<OkObjectResult>(getJobApplication.Result);
        var jobApplicationResultValue = jobApplicationResult.Value;
        Assert.NotNull(jobApplicationResultValue);
        JobApplicationDetailsDto jobApplicationDetails = (JobApplicationDetailsDto)jobApplicationResultValue;
        Assert.NotNull(jobApplicationDetails);
        Assert.NotNull(jobApplicationDetails.FormFieldValues);
        Assert.NotNull(jobApplicationDetails.FieldSetFormFieldValues);
        Assert.NotEmpty(jobApplicationDetails.FirstName);
        Assert.True(jobApplicationDetails.FirstName == jobApplicationDetails.FormFieldValues.SingleOrDefault(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.FirstName).FormFieldValue);

        foreach (var jobFormFieldValue in jobApplicationDetails.FormFieldValues)
        {
            Assert.NotNull(jobFormFieldValue);

            var formField = form.Fields.SingleOrDefault(field => field.Id == jobFormFieldValue.FormFieldId);
            Assert.NotNull(formField);

            var applicationFormField = jobApplicationDto.FieldValues.FirstOrDefault(field => field.FormFieldId == formField.Id);
            Assert.NotNull(applicationFormField);

            var applicationFormFieldValue = applicationFormField.FormFieldValue;
            Assert.NotNull(applicationFormFieldValue);

            if (formField.TypeId == (long)ApplicationFormFieldTypes.Dropdown)
            {
                if (formField.IsSystemDefault == false)
                {
                    var optionId = Convert.ToInt32(applicationFormField.FormFieldValue);
                    var optionDetails = formField.Options.Find(option => option.Id == optionId);
                    applicationFormFieldValue = optionDetails?.Name ?? applicationFormFieldValue;
                }
            }

            Assert.NotNull(applicationFormFieldValue);
            Assert.Contains(applicationFormFieldValue, jobFormFieldValue.FormFieldValue);
        }

        foreach (var jobFieldSetFieldValue in jobApplicationDetails.FieldSetFormFieldValues)
        {
            Assert.NotNull(jobFieldSetFieldValue);

            var formField = form.Fields.FirstOrDefault(field => field.Id == jobFieldSetFieldValue.FormFieldId);
            Assert.NotNull(formField);

            var jobFieldValue = jobFieldSetFieldValue.FormFieldValue;

            var applicationFieldValues = jobApplicationDto.FieldSets.First().FieldValues
                .FirstOrDefault(field => field.FormFieldId == jobFieldSetFieldValue.FormFieldId);
            Assert.NotNull(applicationFieldValues);

            var fieldValue = applicationFieldValues.FormFieldValue;
            Assert.NotNull(fieldValue);

            if (jobFieldSetFieldValue.TypeId == (long)ApplicationFormFieldTypes.Dropdown)
            {
                if (jobFieldSetFieldValue.IsSystemDefault == false)
                {
                    var optionId = Convert.ToInt32(applicationFieldValues.FormFieldValue);
                    fieldValue = formField.Options.FirstOrDefault(option => option.Id == optionId)?.Name ?? fieldValue;
                }
            }

            Assert.NotNull(jobFieldValue);
            Assert.Contains(jobFieldValue, fieldValue);
        }
    }

    [Fact]
    public async Task ShouldGetJobApplicationDetailsById()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            IncludeEducationHistory = true,
            Fields =
              [
                        new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new()
                        {
                            Name = "State",
                            DisplayOrder = 6,
                            IsSystemDefault = true,
                            DefaultFieldId = 11,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            LookupTypeId=7,
                            SectionId = 2,
                            TypeId = 1,
                        },

                        new()
                        {
                            Name = "Education Level",
                            DisplayOrder = 10,
                            IsSystemDefault = true,
                            DefaultFieldId=16,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 5,
                            TypeId = (long)ApplicationFormFieldTypes.Dropdown,
                            LookupTypeId=8
                        },
                        new()
                       {
                           Name = "School Name",
                           DisplayOrder = 12,
                           IsSystemDefault = true,
                           DefaultFieldId = 18,
                           IsAlwaysActiveAndRequired = true,
                           IsActive = true,
                           IsRequired = true,
                           SectionId = 5,
                           TypeId = (long)ApplicationFormFieldTypes.SingleLineInput,
                           LookupTypeId = 8,
                           AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                                                {
                                                    {new() {AttributeId = 1, AttributeValue = "100"} }
                                                }
                       }
              ],
        };
        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);
        var formId = response.Id;

        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobPostDto = new JobPostDto { ApplicationFormId = formId, Title = "Technical Manager", IsActive = true, Description = "Descrption For the Given Job Post", IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), HiringManagerId = _currentUserContext.UserId, StartDateTime = DateTime.UtcNow };
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.True(jobPostId > 0);

        var stateList = await _metadataService.GetLookupData(LookupTypes.State);
        Assert.NotNull(stateList);
        Assert.True(stateList.Any());

        var educationLevels = await _metadataService.GetLookupData(LookupTypes.EducationLevel);
        Assert.NotNull(educationLevels);
        Assert.True(educationLevels.Any());

        var schoolNameFormField = form.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.SchoolName);
        Assert.NotNull(schoolNameFormField);
        Assert.True(schoolNameFormField.Id > 0);

        var educationLevelFormField = form.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.EducationLevel);
        Assert.NotNull(educationLevelFormField);
        Assert.True(educationLevelFormField.Id > 0);

        var educationLevel = educationLevels.FirstOrDefault();

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues =
            [
                   new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test First Name",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test Last Name",
                    },
                     new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test Middle Name",
                    },
                  new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test@tsdt.com",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(field =>field.DefaultFieldId == (long) ApplicationFormDefaultFields.State ).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = (stateList.First().Id).ToString(),
                    }

                ],
            FieldSets =
            [
                new()
                {
                    FieldValues =
                    [
                        new() {FormFieldId = schoolNameFormField.Id, FormFieldValue = "school1" },
                        new() {FormFieldId = educationLevelFormField.Id, FormFieldValue = educationLevel?.Id.ToString() }

                    ]
                }
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);

        var getJobApplication = await _jobApplicationsController.GetById(Id);
        Assert.NotNull(getJobApplication.Result);
        var jobApplicationResult = Assert.IsType<OkObjectResult>(getJobApplication.Result);
        var jobApplicationResultValue = jobApplicationResult.Value;
        Assert.NotNull(jobApplicationResultValue);
        JobApplicationDetailsDto jobApplicationDetails = (JobApplicationDetailsDto)jobApplicationResultValue;
        Assert.NotNull(jobApplicationDetails);
        Assert.NotNull(jobApplicationDetails.FormFieldValues);
        Assert.NotNull(jobApplicationDetails.FieldSetFormFieldValues);
        Assert.NotEmpty(jobApplicationDetails.FirstName);
        Assert.True(jobApplicationDetails.FirstName == jobApplicationDetails.FormFieldValues.SingleOrDefault(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.FirstName).FormFieldValue);

        foreach (var jobFormFieldValue in jobApplicationDetails.FormFieldValues)
        {
            Assert.NotNull(jobFormFieldValue);

            var formField = form.Fields.SingleOrDefault(field => field.Id == jobFormFieldValue.FormFieldId);
            Assert.NotNull(formField);

            var applicationFormField = jobApplicationDto.FieldValues.FirstOrDefault(field => field.FormFieldId == formField.Id);
            Assert.NotNull(applicationFormField);

            var applicationFormFieldValue = applicationFormField.FormFieldValue;
            Assert.NotNull(applicationFormFieldValue);

            if (formField.TypeId == (long)ApplicationFormFieldTypes.Dropdown)
            {
                if (formField.IsSystemDefault == true)
                {
                    var stateId = Convert.ToInt32(applicationFormField.FormFieldValue);
                    var state = stateList.FirstOrDefault(lookup => lookup.Id == stateId);
                    applicationFormFieldValue = state?.Name ?? applicationFormFieldValue;
                }

                Assert.NotNull(applicationFormFieldValue);
                Assert.Contains(applicationFormFieldValue, jobFormFieldValue.FormFieldValue);
            }
        }
        foreach (var jobFieldSetFieldValue in jobApplicationDetails.FieldSetFormFieldValues)
        {
            Assert.NotNull(jobFieldSetFieldValue);

            var formField = form.Fields.FirstOrDefault(field => field.Id == jobFieldSetFieldValue.FormFieldId);
            Assert.NotNull(formField);

            var jobFieldValue = jobFieldSetFieldValue.FormFieldValue;

            var applicationFieldValues = jobApplicationDto.FieldSets.First().FieldValues
                .FirstOrDefault(field => field.FormFieldId == jobFieldSetFieldValue.FormFieldId);
            Assert.NotNull(applicationFieldValues);

            var fieldValue = applicationFieldValues.FormFieldValue;
            Assert.NotNull(fieldValue);

            if (jobFieldSetFieldValue.TypeId == (long)ApplicationFormFieldTypes.Dropdown)
            {
                if (jobFieldSetFieldValue.IsSystemDefault == true)
                {
                    var lookupId = Convert.ToInt32(applicationFieldValues.FormFieldValue);
                    fieldValue = educationLevels.FirstOrDefault(lookup => lookup.Id == lookupId)?.Name ?? fieldValue;
                }
            }

            Assert.NotNull(jobFieldValue);
            Assert.Contains(jobFieldValue, fieldValue);
        }
    }

    [Fact]
    public async Task ShouldGetProgressBarStatusListById()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var actionResult = await _jobApplicationsController.GetProgressBarStatusListAsync(jobApplicationId);
        Assert.IsType<ActionResult<IEnumerable<ApplicantStatusProgressBarDto>>>(actionResult);
        var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
        var result = Assert.IsAssignableFrom<IEnumerable<ApplicantStatusProgressBarDto>>(okResult.Value);
        Assert.NotNull(result);
        Assert.IsType<List<ApplicantStatusProgressBarDto>>(result);
        Assert.True(result?.Count() > 0);
        Assert.Contains(result, result => result.StatusId == (long)JobApplicationStatuses.Applied);
    }

    [Fact]
    public async Task ShouldSendApplicantNotSelectedEmailNotification()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);
        var jobApplication = await _jobApplicationService.GetByIdAsync(jobApplicationId);
        var jobApplicationManualStatusUpdateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = jobApplicationId,
            StatusId = (long)JobApplicationStatuses.NotSelected,
            Note = "Not Selected",
            SendEmail = true,
            Version = jobApplication!.Version
        };

        var statusResult = await _jobApplicationsController.UpdateStatusAsync(jobApplicationManualStatusUpdateDto);

        var result = await _jobApplicationService.GetProgressBarStatusListAsync(jobApplicationId);
        Assert.NotNull(result);
        Assert.True(result.Count > 0);
        Assert.Contains(result, result => result.StatusId == (long)JobApplicationStatuses.NotSelected);

        var jobApplicationStatusHistories = await _jobApplicationRepository.GetListAsync<JobApplicationStatusHistory>
                                                                            (history => history.JobApplicationId == jobApplicationId);

        Assert.NotNull(jobApplicationStatusHistories);
        Assert.Contains(jobApplicationStatusHistories, result => result.ToStatusId == (long)JobApplicationStatuses.Applied
                                                              && !result.IsManualUpdate);
        Assert.Contains(jobApplicationStatusHistories, result => result.ToStatusId == (long)JobApplicationStatuses.NotSelected
                                                              && result.IsManualUpdate);
    }

    [Fact]
    public async Task ShouldNotSendNotificationWhenSendEmailIsFalse()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);
        var jobApplication = await _jobApplicationService.GetByIdAsync(jobApplicationId);
        var jobApplicationManualStatusUpdateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = jobApplicationId,
            StatusId = (long)JobApplicationStatuses.NotSelected,
            Note = "Not Selected",
            SendEmail = false,
            Version = jobApplication!.Version
        };

        var statusResult = await _jobApplicationsController.UpdateStatusAsync(jobApplicationManualStatusUpdateDto);

        var result = await _jobApplicationService.GetProgressBarStatusListAsync(jobApplicationId);
        Assert.NotNull(result);
        Assert.True(result.Count > 0);
        Assert.Contains(result, result => result.StatusId == (long)JobApplicationStatuses.NotSelected);

        var jobApplicationStatusHistories = await _jobApplicationRepository.GetListAsync<JobApplicationStatusHistory>
                                                                            (history => history.JobApplicationId == jobApplicationId);

        Assert.NotNull(jobApplicationStatusHistories);
        Assert.Contains(jobApplicationStatusHistories, result => result.ToStatusId == (long)JobApplicationStatuses.NotSelected
                                                           && !result.IsEmailSent && result.IsManualUpdate);
    }

    [Fact]
    public async Task ShouldFailGetProgressBarStatusListByInvalidId()
    {
        var jobApplicationId = 10101;

        var exception = await Assert.ThrowsAsync<ValidationException>(() =>
                                                    _jobApplicationService.GetProgressBarStatusListAsync(jobApplicationId));
        Assert.Equal(JobApplicationValidation.InvalidJobApplicationId, exception.Message);
    }

    [Fact]
    public async Task ShouldCreateAutoResponseEmailsToApplicants()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var emailServiceMock = new Mock<IEmailClient>();
        var expectedResult = true;
        var result = emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<JobApplicationNotificationDto>()))
                       .ReturnsAsync(expectedResult);

        var templateData = GetJobApplicationNotificationMockObject();
        var emailMessage = GetMockEmail();
        var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);
        Assert.Equal(expectedResult, isEmailSent);
    }

    [Fact]
    public async Task ShouldCreateAutoResponseEmailsToHiringManager()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        var emailServiceMock = new Mock<IEmailClient>();
        var expectedResult = true;
        var result = emailServiceMock.Setup(service => service.SendEmailAsync(It.IsAny<List<EmailDto>>(), It.IsAny<string>(), It.IsAny<JobApplicationNotificationDto>()))
                       .ReturnsAsync(expectedResult);

        var templateData = GetJobApplicationNotificationHiringMockObject();
        var emailMessage = GetMockEmail();
        var isEmailSent = await emailServiceMock.Object.SendEmailAsync(emailMessage, "d-test-345", templateData);
        Assert.Equal(expectedResult, isEmailSent);
    }

    [Fact]
    public async Task ShouldSendApplicantOfferExtendedEmailNotification()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        await SendOfferExtendedEmail(jobApplicationId);
    }

    [Fact]
    public async Task ShouldNotSendOfferExtendedWhenSendEmailIsFalse()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        await SendOfferExtendedEmail(jobApplicationId);
    }

    [Fact]
    public async Task ShouldFailJobApplicationAcceptOfferWithInvalidToken()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        await SendOfferExtendedEmail(jobApplicationId);

        var acceptOffer = await _jobApplicationsController.AcceptOffer(Guid.NewGuid().ToString());
        Assert.NotNull(acceptOffer);

        var acceptOfferTokenResultValue = acceptOffer.Value;
        Assert.NotNull(acceptOfferTokenResultValue);
    }

    [Fact]
    public async Task ShouldFailJobApplicationDeclineOfferWithInvalidToken()
    {
        var formId = await CreateApplicationForm();
        Assert.True(formId > 0);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        var jobApplicationId = await CreateJobApplication(jobPostId, form);
        Assert.True(jobApplicationId > 0);

        await SendOfferExtendedEmail(jobApplicationId);

        var declineOffer = await _jobApplicationsController.DeclineOffer(Guid.NewGuid().ToString());
        Assert.NotNull(declineOffer);

        var acceptOfferTokenResultValue = declineOffer.Value;
        Assert.NotNull(acceptOfferTokenResultValue);
    }

    [Fact]
    public async Task ShouldCreateJobApplicationWithVoluntourySelfDecleration()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "FirstName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "LastName",
                },
                new(){
                    FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "test@email.com",
                },
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.VoluntarySelfIdentification).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "122",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Gender).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "125",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.EthnicityRace).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "128",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Veteran).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "134",
                    },
                     new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.VeteranStatus).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "137",
                    },
                     new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Disability).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "Test for Disability",
                    }
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var Id = await CreateJobApplication(jobApplicationDto);
        Assert.True(Id > 0);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenGenderIsEmptyAtVoluntarySelfIdentificationIsYes()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.VoluntarySelfIdentification).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "122",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.Gender).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }

            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.Gender), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenEthnicityRaceIsEmptyAtVoluntarySelfIdentificationIsYes()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.VoluntarySelfIdentification).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "122",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(applicationformfield => applicationformfield.DefaultFieldId == (long) ApplicationFormDefaultFields.EthnicityRace).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.EthnicityRace), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenVeteranStatusIsEmptyIfVeteranIsIamVeteran()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields!.Where(applicationFormField => applicationFormField.DefaultFieldId == (long) ApplicationFormDefaultFields.VoluntarySelfIdentification).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "122",
                    },
                    new()
                    {
                        FormFieldId = form.Fields!.Where(applicationFormField => applicationFormField.DefaultFieldId == (long) ApplicationFormDefaultFields.Veteran).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "134",
                    },
                     new()
                    {
                        FormFieldId = form.Fields!.Where(applicationFormField => applicationFormField.DefaultFieldId == (long) ApplicationFormDefaultFields.VeteranStatus).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(ApplicationFormFieldValidation.FieldEmptyErrorMessage, Constants.ApplicationFormFields.VeteranStatus), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenGraduationYearIsEmpty()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await AssertCreateJobPost(formId);
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                    new()
                    {
                        FormFieldId = form.Fields!.Where(applicationFormField => applicationFormField.DefaultFieldId == (long) ApplicationFormDefaultFields.GraduationYear).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "2025",
                    }
            ]
        };
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await CreateJobApplication(jobApplicationDto));
        Assert.Equal(string.Format(JobApplicationValidation.GraduationYear, ApplicationFormFields.GraduationYear), exception.Message);
    }

    [Fact]
    public async Task ShouldGetCountByStatus()
    {
        var filteredStatuses = new[]
        {
            (long)JobApplicationStatuses.Applied,
            (long)JobApplicationStatuses.InterviewScheduled,
            (long)JobApplicationStatuses.OfferExtended,
            (long)JobApplicationStatuses.OfferAccepted,
            (long)JobApplicationStatuses.Hired
        }.ToList();

        var formId = await CreateApplicationForm();
        var form = await _applicationFormService.GetFormWithActiveFields(formId);
        Assert.NotNull(form);
        var jobPostId = await CreateJobPostWithForm(formId);
        foreach (var status in filteredStatuses)
        {
            await createAndUpdateJobApplicationWithStatus(status, jobPostId, form);
        }
        var actionResult = await _jobApplicationsController.GetCountByStatus();
        Assert.IsType<ActionResult<List<NameCountPairDto>>>(actionResult);
        var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
        var result = Assert.IsAssignableFrom<List<NameCountPairDto>>(okResult.Value);
        Assert.NotNull(result);
        Assert.True(result.Count > 0);
        foreach (var status in filteredStatuses)
        {
            var statusCountResult = result.Find(result => result.Id == status);
            Assert.NotNull(statusCountResult);
            Assert.True(statusCountResult.Count > 0);
        }
    }

    //[Fact]
    //public async Task ShouldGetOfferStatusCount()
    //{
    //    var filteredStatuses = new[]
    //    {
    //        (long)JobApplicationStatuses.OfferExtended,
    //        (long)JobApplicationStatuses.OfferAccepted,
    //        (long)JobApplicationStatuses.OfferDeclined
    //    }.ToList();

    //    var formId = await CreateApplicationForm();
    //    var form = await _applicationFormService.GetFormWithActiveFields(formId);
    //    Assert.NotNull(form);

    //    var jobStatus = true;
    //    var jobPost = new JobPostDto { ApplicationFormId = formId, Title = $"Jobpost-{DateTime.Now.Ticks}", IsActive = jobStatus, Description = "Descrption For the Given Job Post", IsSubmitted = true, CategoryId = 1, Location = "Hyderabad", HiringManagerId = _currentUserContext.UserId };
    //    var jobPostId = await _jobPostService.AddAsync(jobPost);
    //    Assert.True(jobPostId > 0);

    //    foreach (var status in filteredStatuses)
    //    {
    //        await createAndUpdateJobApplicationWithStatus(status, jobPostId.Value, form);
    //    }
    //    await _jobApplicationsController.GetAllAsync(jobStatus);
    //    WidgetFilterCriteriaDto offerStatusCountRequestDto = new WidgetFilterCriteriaDto()
    //    {
    //        Locations = ["Hyderabad"],
    //        JobCategoryIds = [1],
    //        JobPostIds = [jobPostId.Value],
    //        FromDate = DateOnly.FromDateTime(DateTime.Now.AddDays(-1)),
    //        ToDate = DateOnly.FromDateTime(DateTime.Now.AddDays(1)),
    //    };
    //    var offerStatusCount = await _jobApplicationsController.GetOfferStatusCount(offerStatusCountRequestDto);
    //    var offerStatusCountResult = Assert.IsType<OkObjectResult>(offerStatusCount.Result);
    //    var offerStatusCountResultValue = offerStatusCountResult.Value as OfferStatusCountDto;
    //    Assert.NotNull(offerStatusCountResultValue);
    //    Assert.True(offerStatusCountResultValue.OffersAccepted > 0);
    //    Assert.True(offerStatusCountResultValue.OffersExtended > 0);
    //    Assert.True(offerStatusCountResultValue.OffersDeclined > 0);
    //}

    [Fact]
    public async Task ShouldHandleMissingStatusesInOfferStatusCount()
    {
        var offerStatusCountRequestDto = new WidgetFilterCriteriaDto()
        {
            Locations = new List<string> { "UnknownLocation" },
            FromDate = DateOnly.FromDateTime(DateTime.Now.AddDays(-10)),
            ToDate = DateOnly.FromDateTime(DateTime.Now.AddDays(10))
        };

        var offerStatusCount = await _jobApplicationsController.GetOfferStatusCount(offerStatusCountRequestDto);
        var offerStatusCountResult = Assert.IsType<OkObjectResult>(offerStatusCount.Result);
        var offerStatusCountResultValue = offerStatusCountResult.Value as OfferStatusCountDto;

        Assert.NotNull(offerStatusCountResultValue);
        Assert.Equal(0, offerStatusCountResultValue.OffersAccepted);
        Assert.Equal(0, offerStatusCountResultValue.OffersExtended);
        Assert.Equal(0, offerStatusCountResultValue.OffersDeclined);
    }

    //[Fact]
    //public async Task ShouldHandlePartialStatusesInOfferStatusCount()
    //{
    //    var filteredStatuses = new[]
    //    {
    //        (int)JobApplicationStatuses.OfferExtended,
    //    }.ToList();

    //    var formId = await CreateApplicationForm();
    //    var form = await _applicationFormService.GetFormWithActiveFields(formId);
    //    Assert.NotNull(form);

    //    var jobStatus = true;
    //    var jobPost = new JobPostDto { ApplicationFormId = formId, Title = $"Jobpost-{DateTime.Now.Ticks}", IsActive = jobStatus, Description = "Descrption For the Given Job Post", IsSubmitted = true, CategoryId = 1, Location = "Hyderabad", HiringManagerId = _currentUserContext.UserId };
    //    var jobPostId = await _jobPostService.AddAsync(jobPost);
    //    Assert.True(jobPostId > 0);

    //    foreach (var status in filteredStatuses)
    //    {
    //        await createAndUpdateJobApplicationWithStatus(status, jobPostId.Value, form);
    //    }
    //    await _jobApplicationsController.GetAllAsync(jobStatus);
    //    var offerStatusCountRequestDto = new WidgetFilterCriteriaDto()
    //    {
    //        Locations = ["Hyderabad"],
    //        JobCategoryIds = [],
    //        JobPostIds = [jobPostId.Value],
    //        FromDate = DateOnly.FromDateTime(DateTime.Now.AddDays(-5)),
    //        ToDate = DateOnly.FromDateTime(DateTime.Now.AddDays(5))
    //    };

    //    var offerStatusCount = await _jobApplicationsController.GetOfferStatusCount(offerStatusCountRequestDto);
    //    var offerStatusCountResult = Assert.IsType<OkObjectResult>(offerStatusCount.Result);
    //    var offerStatusCountResultValue = offerStatusCountResult.Value as OfferStatusCountDto;

    //    Assert.NotNull(offerStatusCountResultValue);
    //    Assert.Equal(0, offerStatusCountResultValue.OffersAccepted);
    //    Assert.True(offerStatusCountResultValue.OffersExtended > 0);
    //    Assert.Equal(0, offerStatusCountResultValue.OffersDeclined);
    //}

    [Fact]
    public async Task ShouldThrowExceptionWhenRequiredQuestionIsMissing()
    {
        var quizId = await CreateApplicantQuiz();
        var formId = await CreateApplicationForm();
        var jobPostId = await CreateJobPost(formId, quizId);
        var linkId = await GetJobPostLinkId(jobPostId);

        var quizDto = await _applicantQuizService.GetDetailsByJobPostLinkIdAsync(linkId);
        Assert.NotNull(quizDto);

        var quizQuestionId = quizDto.QuizQuestions!
                            .Where(question => question.IsRequired == false).Select(question => question.Id).FirstOrDefault();

        var answerId = quizDto.QuizQuestions!.Where(question => question.Id == quizQuestionId).SelectMany(question => question.Answers)
                        .Select(answer => answer.Id).FirstOrDefault();

        var jobApplicationDto = await CreateJobApplication(formId, jobPostId);

        jobApplicationDto.ApplicantQuizResult = new ApplicantQuizResultDto()
        {
            QuizId = quizId,
            QuizAnswers = [
                    new(){
                         QuestionId = quizQuestionId,
                         AnswerId = answerId
                     },
                ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobApplicationService.AddAsync(jobApplicationDto));
        Assert.Equal(ApplicantQuizAnswers.RequiredAnswersMissing, exception.Message);
    }

    #region Private Methods

    private JobApplicationNotificationDto GetJobApplicationNotificationMockObject()
    {
        JobApplicationNotificationDto jobApplicationNotification = new JobApplicationNotificationDto()
        {
            JobPostTitle = "Jobpost-" + DateTime.Now.Ticks,
            ApplicantFirstName = "Azure application form",
            ApplicantLastName = "Azure last Name",
            ApplicantEmail = "testuser@test.com",
            CompanyName = "testcompanyname",
            Subject = "test subject"
        };
        return jobApplicationNotification;
    }

    private JobApplicationNotificationDto GetJobApplicationNotificationHiringMockObject()
    {
        JobApplicationNotificationDto jobApplicationNotification = new JobApplicationNotificationDto()
        {
            JobPostTitle = "Jobpost-" + DateTime.Now.Ticks,
            ApplicantFirstName = "Azure application form",
            ApplicantLastName = "Azure Last Name",
            ApplicantEmail = "testuser@test.com",
            CompanyName = "testcompanyname",
            Subject = "test subject",
            ApplicantDetailsUrl = "teams.com"
        };
        return jobApplicationNotification;
    }

    private List<EmailDto> GetMockEmail()
    {
        List<EmailDto> emailMessages = new List<EmailDto>()
        {
            new()
            {
                ToEmail = "testemail@test.com",
                ToName = "test applicant",
            }
        };

        return emailMessages;
    }

    private async Task<long> CreateJobApplication(long? jobPostId, ApplicationFormDto? form)
    {
        var jobApplicationDto = CreateJobApplicationDtoWithDefaultFields(jobPostId, form);
        return await CreateJobApplication(jobApplicationDto);
    }

    private async Task SendOfferExtendedEmail(long jobApplicationId)
    {
        var jobApplication = await _jobApplicationsController.GetById(jobApplicationId);

        Assert.NotNull(jobApplication.Result);
        var jobApplicationResult = Assert.IsType<OkObjectResult>(jobApplication.Result);
        var jobApplicationResultValue = jobApplicationResult.Value;
        Assert.NotNull(jobApplicationResultValue);
        JobApplicationDetailsDto jobApplicationDetails = (JobApplicationDetailsDto)jobApplicationResultValue;
        Assert.NotNull(jobApplicationDetails);

        var jobApplicationManualStatusUpdateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = jobApplicationId,
            StatusId = (long)JobApplicationStatuses.OfferExtended,
            Note = "Offer Extended",
            SendEmail = false,
            Version= jobApplicationDetails.Version
        };

        await _jobApplicationsController.UpdateStatusAsync(jobApplicationManualStatusUpdateDto);

        var result = await _jobApplicationService.GetProgressBarStatusListAsync(jobApplicationId);
        Assert.NotNull(result);
        Assert.True(result.Count > 0);
        Assert.Contains(result, result => result.StatusId == (long)JobApplicationStatuses.OfferExtended);

        var jobApplicationStatusHistories = await _jobApplicationRepository.GetListAsync<JobApplicationStatusHistory>
                                                                            (history => history.JobApplicationId == jobApplicationId);

        Assert.NotNull(jobApplicationStatusHistories);
        Assert.Contains(jobApplicationStatusHistories, result => result.ToStatusId == (long)JobApplicationStatuses.OfferExtended
                                                           && !result.IsEmailSent && result.IsManualUpdate);
    }

    private static JobApplicationDto CreateJobApplicationDtoWithDefaultFields(long? jobPostId, ApplicationFormDto? form)
    {
        return new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues =
                [
                   new()
                  {
                      FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                      FormFieldValue = "test First Name",
                  },
                 new()
                  {
                      FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName ).Select(a =>a.Id).FirstOrDefault(),
                      FormFieldValue = "test Middle Name",
                  },
                 new()
                  {
                      FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                      FormFieldValue = "test Last Name",
                  },
                  new()
                  {
                      FormFieldId = form.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                      FormFieldValue = "test1@tsdt.com",
                  },
                  new()
                  {
                      FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.HomeTelephoneNumber).Select(a =>a.Id).FirstOrDefault(),
                      FormFieldValue = "9999999000",
                  },
                  new()
                  {
                      FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
                      FormFieldValue = "9999999001",
                  },
                  new()
                  {
                      FormFieldId = form.Fields!.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.State).Select(a =>a.Id).FirstOrDefault(),
                      FormFieldValue = States.ALABAMA.ToString(),
                  },
              ],
        };
    }

    private static Stream GenerateFileStream(string base64String)
    {
        byte[] fileBytes = Convert.FromBase64String(base64String);
        return new MemoryStream(fileBytes);
    }

    private static IFormFile GenerateFormFileFromStream(string fileName, Stream memoryStream)
    {
        var formFile = new FormFile(memoryStream, 0, memoryStream.Length, null, fileName)
        {
            Headers = new HeaderDictionary(),
            ContentType = "application/octet-stream"
        };
        return formFile;
    }

    private async Task<long> CreateApplicationForm()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                        new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new()
                        {
                            Name = "Home Telephone Number",
                            DisplayOrder = 5,
                            IsSystemDefault = true,
                            DefaultFieldId = 5,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 7,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 4, AttributeValue = "10"} }
                            }
                        },
                        new()
                        {
                            Name = "Mobile Phone Number",
                            DisplayOrder = 6,
                            IsSystemDefault = true,
                            DefaultFieldId = 6,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 7,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 4, AttributeValue = "10"} }
                            }
                        },
                        new()
                        {
                            Name = "Address Line 1",
                            DisplayOrder = 7,
                            IsSystemDefault = true,
                            DefaultFieldId = 7,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 2,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new()
                        {
                            Name = "Address Line 2",
                            DisplayOrder = 8,
                            IsSystemDefault = true,
                            DefaultFieldId = 8,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 2,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new()
                        {
                            Name = "Zip Code",
                            DisplayOrder = 11,
                            IsSystemDefault = true,
                            DefaultFieldId = 9,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 2,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "5"} }
                            }
                        },
                        new()
                        {
                            Name = "City",
                            DisplayOrder = 9,
                            IsSystemDefault = true,
                            DefaultFieldId = 10,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 2,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "State",
                            DisplayOrder = 10,
                            IsSystemDefault = true,
                            DefaultFieldId = 11,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 2,
                            TypeId = 1,
                        },
                        new()
                        {
                            Name = "When are you available to start work?",
                            DisplayOrder = 7,
                            IsSystemDefault = true,
                            DefaultFieldId = 15,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 2,
                            TypeId = 6
                        },
                        new()
                        {
                            Name = "Photo",
                            DisplayOrder = 12,
                            IsSystemDefault = true,
                            DefaultFieldId = 12,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 3,
                            TypeId = 2,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 2, AttributeValue = "1048576"} },
                                {new() {AttributeId = 5, AttributeValue = "jpeg,png,jpg"} }
                            }
                        },
                        new()
                        {
                            Name = "Resume",
                            DisplayOrder = 13,
                            IsSystemDefault = true,
                            DefaultFieldId = 13,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 3,
                            TypeId = 2,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 2, AttributeValue = "1048576"} },
                                {new() {AttributeId = 5, AttributeValue = "doc,docx,pdf"} }
                            }
                        },
                        new()
                        {
                            Name = "Cover Letter",
                            DisplayOrder = 14,
                            IsSystemDefault = true,
                            DefaultFieldId = 14,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 3,
                            TypeId = 2,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 2, AttributeValue = "1048576"} },
                                {new() {AttributeId = 5, AttributeValue = "doc,docx,pdf"} }
                            }
                        },
                        new()
                        {
                            Name = "Graduation Year",
                            DisplayOrder = 19,
                            IsSystemDefault = true,
                            DefaultFieldId = 19,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 5,
                            TypeId = 6,
                        },
                        new ()
                        {
                            Name = "Company Name",
                            DisplayOrder = 21,
                            IsSystemDefault = true,
                            DefaultFieldId = 21,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 6,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new () {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new()
                        {
                            Name = "Job Title",
                            DisplayOrder = 22,
                            IsSystemDefault = true,
                            DefaultFieldId = 22,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 6,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new()
                        {
                            Name = "Industry Type",
                            DisplayOrder = 23,
                            IsSystemDefault = true,
                            DefaultFieldId = 23,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 6,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        },
                        new()
                        {
                            Name = "Start Date",
                            DisplayOrder = 24,
                            IsSystemDefault = true,
                            DefaultFieldId = 24,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 6,
                            TypeId = 6
                        },
                        new()
                        {
                            Name = "End Date",
                            DisplayOrder = 25,
                            IsSystemDefault = true,
                            DefaultFieldId = 25,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 6,
                            TypeId = 6
                        },
                        new()
                        {
                            Name = "Voluntary Self-Identification",
                            DisplayOrder = 26,
                            IsSystemDefault = true,
                            DefaultFieldId = 26,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 7,
                            TypeId = 9
                        }
                        ,
                        new()
                        {
                            Name = "Gender",
                            DisplayOrder = 27,
                            IsSystemDefault = true,
                            DefaultFieldId = 27,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 7,
                            TypeId = 1
                        },
                        new()
                        {
                            Name = "Ethnicity Race",
                            DisplayOrder = 28,
                            IsSystemDefault = true,
                            DefaultFieldId = 28,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 7,
                            TypeId = 1
                        },
                        new()
                        {
                            Name = "Veteran",
                            DisplayOrder = 29,
                            IsSystemDefault = true,
                            DefaultFieldId = 29,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 7,
                            TypeId = 9
                        },
                        new()
                        {
                            Name = "Veteran Status",
                            DisplayOrder = 30,
                            IsSystemDefault = true,
                            DefaultFieldId = 30,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 7,
                            TypeId = 1
                        },
                        new()
                        {
                            Name = "Disability",
                            DisplayOrder = 31,
                            IsSystemDefault = true,
                            DefaultFieldId = 31,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 7,
                            TypeId = 4
                        }

                ]
        };

        var newFormResult = await _formController.Create(formDTO);
        var okResult = Assert.IsType<OkObjectResult>(newFormResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);
        return response.Id;
    }

    private async Task<long> AssertCreateJobPost(long? formId)
    {
        var jobPostDto = new JobPostDto { Title = "jobPost1" + DateTime.Now.Ticks, IsSubmitted = false, ApplicationFormId = formId, HiringManagerId = _currentUserContext.UserId };
        //Act
        var result = await _jobPostsController.Create(jobPostDto);

        //Assert
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        return createdResponse.Id;
    }

    private async Task<long> CreateJobApplication(JobApplicationDto jobApplicationDto)
    {
        var newJobApplicationResult = await _jobApplicationsController.Create(jobApplicationDto);
        var okResult = Assert.IsType<OkObjectResult>(newJobApplicationResult.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);
        Assert.True(response.Id > 0);
        return response.Id;
    }

    private async Task<long> CreateApplicationFormWithAllDefaultFields()
    {
        var defaultFields = await _metadataService.GetApplicationFormDefaultFieldsAsync();
        Assert.NotNull(defaultFields);
        Assert.True(defaultFields.Any());

        var formDto = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            IncludeEducationHistory = true,
            Fields = _mapper.Map<List<ApplicationFormFieldDto>>(defaultFields)
        };

        //leaving the commented code here intentionally to troubleshoot issues when multiple tests are executed together
        //var formOutput = JsonConvert.SerializeObject(formDto);
        //_output.WriteLine($"CreateApplicationFormWithAllDefaultFields formDto: {formOutput}");

        var formId = await _applicationFormService.AddAsync(formDto);
        Assert.NotNull(formId);
        Assert.True(formId > 0);
        return formId.Value;
    }

    private async Task<long> CreateJobPostWithForm(long formId)
    {
        var jobPost = new JobPostDto { Title = "JP" + DateTime.Now.Ticks, ApplicationFormId = formId, HiringManagerId = _currentUserContext.UserId, IsActive = true, Description = "Descrption For the Given Job Post", IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostId = await _jobPostService.AddAsync(jobPost);
        Assert.NotNull(jobPostId);
        Assert.True(jobPostId > 0);
        return jobPostId.Value;
    }

    private async Task<ApplicationFormDto> GetApplicationFormByJobPostId(long jobPostId)
    {
        var formDto = await _jobPostService.GetApplicationFormByJobPostIdAsync(jobPostId);
        Assert.NotNull(formDto);
        Assert.NotNull(formDto.Fields);
        Assert.True(!formDto.Fields.Exists(field => field.IsActive == false)); //form should not have any inactive fields
        return formDto;
    }

    private async Task<JobApplicationDto> CreateJobApplicationDtoWithEducationalHistoryFields(ApplicationFormDto formDto, long jobPostId)
    {
        var educationLevels = await _metadataService.GetLookupData(LookupTypes.EducationLevel);
        Assert.NotNull(educationLevels);
        Assert.True(educationLevels.Any());

        var firstNameFormField = formDto.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.FirstName);
        Assert.NotNull(firstNameFormField);
        Assert.True(firstNameFormField.Id > 0);

        var lastNameFormField = formDto.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.LastName);
        Assert.NotNull(lastNameFormField);
        Assert.True(lastNameFormField.Id > 0);

        var emailFormField = formDto.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.PersonalEmailAddress);
        Assert.NotNull(emailFormField);
        Assert.True(emailFormField.Id > 0);

        var schoolNameFormField = formDto.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.SchoolName);
        Assert.NotNull(schoolNameFormField);
        Assert.True(schoolNameFormField.Id > 0);

        var educationLevelFormField = formDto.Fields?.Find(field => field.DefaultFieldId == (long)ApplicationFormDefaultFields.EducationLevel);
        Assert.NotNull(educationLevelFormField);
        Assert.True(educationLevelFormField.Id > 0);

        var educationLevel = educationLevels.FirstOrDefault();
        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues = [
                new() {FormFieldId = firstNameFormField.Id, FormFieldValue = "FirstName" },
                new() {FormFieldId = lastNameFormField.Id, FormFieldValue = "LastName" },
                new() {FormFieldId = emailFormField.Id, FormFieldValue = "test@email.com" },
            ],
            FieldSets =
            [
                new()
                {
                    FieldValues =
                    [

                        new() {FormFieldId = schoolNameFormField.Id, FormFieldValue = "school1" },
                        new() {FormFieldId = educationLevelFormField.Id, FormFieldValue = educationLevel?.Id.ToString() },
                    ]
                }
            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };

        return jobApplicationDto;
    }

    private JobApplicationFieldValueDto PrepareFieldValue(List<ApplicationFormFieldDto>? formFields, ApplicationFormDefaultFields applicationFormDefaultFields, string? fieldValue)
    {
        return new JobApplicationFieldValueDto()
        {
            FormFieldId = formFields?.FirstOrDefault(formField => formField.DefaultFieldId == (long)applicationFormDefaultFields)?.Id,
            FormFieldValue = fieldValue,
        };
    }

    private JobApplicationDto PrepareJobApplication(long jobPostId, List<JobApplicationFieldValueDto>? fieldValues, List<JobApplicationFieldValueDto>? fieldSets)
    {
        return new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues = fieldValues,
            FieldSets =
            [
                new()
                {
                    FieldValues = fieldSets
                }

            ],
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
    }

    private async Task<long> AddAttachment(string fileName, long jobApplicationId, Stream fileStream, JobApplicationAttachmentType type)
    {
        JobApplicationAttachmentDto attachment = new()
        {
            Name = fileName,
            JobApplicationId = jobApplicationId,
            TypeId = (long)type,
            File = GenerateFormFileFromStream(fileName, fileStream),
        };

        var attachmentResult = await _jobApplicationsController.AddAttachment(attachment);
        var attachmentOkResult = Assert.IsType<OkObjectResult>(attachmentResult.Result);
        var createdAttachment = Assert.IsType<CreatedResponse>(attachmentOkResult.Value);
        return createdAttachment.Id;
    }

    private async Task createAndUpdateJobApplicationWithStatus(long statusId, long jobPostId, ApplicationFormDto form)
    {
        var fieldValues = new List<JobApplicationFieldValueDto> {
               new()
                 {
                     FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test First Name",
                 },
               new()
                 {
                     FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test Middle Name",
                 },
               new()
                 {
                     FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test Last Name",
                 },
                 new()
                 {
                     FormFieldId = form.Fields.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test1@tsdt.com",
                 },
                 new()
                {
                    FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MobilePhoneNumber).Select(a =>a.Id).FirstOrDefault(),
                    FormFieldValue = "9999999991",
                }
             };

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues = fieldValues,
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = 1,
                QuizAnswers = [
                    new(){
                        QuestionId =1,
                        AnswerId =1,
                    },
                    new(){
                        QuestionId =2,
                        AnswerId =2
                    }
                ]
            }
        };
        var jobApplicationId = await CreateJobApplication(jobApplicationDto);
        Assert.True(jobApplicationId > 0);

        var jobApplication = await _jobApplicationService.GetByIdAsync(jobApplicationId);

        var updateDto = new JobApplicationManualStatusUpdateDto
        {
            JobApplicationId = jobApplicationId,
            StatusId = statusId,
            NewHireTypeId = (long)NewHireType.Manual,
            Version= jobApplication!.Version
        };

        await _jobApplicationsController.UpdateStatusAsync(updateDto);
    }

    private async Task<long> CreateApplicantQuiz()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "New Quiz" + DateTime.Now,
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
            QuizQuestions =
            [
                new()
                {
                    Question ="Test Question",
                    TypeId = (int)QuestionType.MultipleChoice,
                    Score = 21,
                    IsActive = true,
                    IsRequired = true,
                    Answers =
                    [
                        new()
                        {
                            Answer="test answer 1",
                            IsCorrect=true,
                        },
                        new()
                        {
                            Answer="test answer 2",
                            IsCorrect=false,
                        },
                        new()
                        {
                            Answer="test answer 3",
                            IsCorrect=false,
                        },
                    ]
                },
                new()
                {
                    Question ="Test Question 2",
                    TypeId = (int)QuestionType.TrueFalse,
                    Score = 21,
                    IsActive = true,
                    IsRequired = false,
                    Answers =
                    [
                        new()
                        {
                            Answer="True",
                            IsCorrect=true,
                        },
                        new()
                        {
                            Answer="False",
                            IsCorrect=false,
                        },
                    ]
                }
            ]
        };

        var applicantQuizId = await _applicantQuizService.AddAsync(applicantQuiz);
        Assert.NotNull(applicantQuizId);
        Assert.True(applicantQuizId > 0);
        return applicantQuizId.Value;
    }

    private async Task<long> CreateJobPost(long formId, long? quizId)
    {
        var jobPostDto = new JobPostDto { Title = "jobPost1" + DateTime.Now.Ticks, IsSubmitted = true, IsActive = true, ApplicationFormId = formId, HiringManagerId = _currentUserContext.UserId, ApplicantQuizId = quizId, StartDateTime = DateTime.UtcNow };
        //Act
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.NotNull(jobPostId);
        Assert.True(jobPostId > 0);

        return jobPostId.Value;
    }

    private async Task<Guid> GetJobPostLinkId(long jobPostId)
    {
        var jobPostDto = await _jobPostService.GetByIdAsync(jobPostId);
        Assert.NotNull(jobPostDto);
        Assert.NotNull(jobPostDto.LinkId);
        return jobPostDto.LinkId.Value;
    }

    private async Task<JobApplicationDto> CreateJobApplication(long formId, long jobPostId)
    {
        var formDto = await _applicationFormService.GetByIdAsync(formId);
        Assert.NotNull(formDto);

        var fieldValues = new List<JobApplicationFieldValueDto> {
               new()
                 {
                     FormFieldId = formDto.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test First Name",
                 },
               new()
                 {
                     FormFieldId = formDto.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test Middle Name",
                 },
               new()
                 {
                     FormFieldId = formDto.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test Last Name",
                 },
                 new()
                 {
                     FormFieldId = formDto.Fields!.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test1@tsdt.com",
                 }
             };

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues = fieldValues,
        };
        return jobApplicationDto;

    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}