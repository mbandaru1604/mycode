﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class WidgetFilterCriteriaDtoValidatorTests
{
    private readonly WidgetFilterCriteriaDtoValidator _validator;
    public WidgetFilterCriteriaDtoValidatorTests()
    {
        _validator = new WidgetFilterCriteriaDtoValidator();
    }

    [Fact]
    public void ShouldSuccessfullyValidateFilterDto()
    {
        var filterDto = new WidgetFilterCriteriaDto()
        {
            FromDate = DateOnly.FromDateTime(DateTime.Now),
            ToDate = DateOnly.FromDateTime(DateTime.Now.AddDays(10)),
            JobCategoryIds = [1],
            JobPostIds = [1],
            Locations = ["Location"]
        };
        var result = _validator.TestValidate(filterDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<WidgetFilterCriteriaDto>>(result);
    }

    [Fact]
    public void ShouldFailGetOfferStatusDtoIfFromDateIsNull()
    {
        var filterDto = new WidgetFilterCriteriaDto()
        {
            FromDate = null,
            ToDate = DateOnly.FromDateTime(DateTime.Now.AddDays(10)),
            JobCategoryIds = [1],
            JobPostIds = [1],
            Locations = ["Location"]
        };
        var result = _validator.TestValidate(filterDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<WidgetFilterCriteriaDto>>(result);
        var testValidationResult = result.ShouldHaveValidationErrorFor(filter => filter.FromDate);
        Assert.Contains(testValidationResult, result => result.ErrorMessage == OfferStatusCountValidation.FromDateOfferExtendedIsRequired);
    }

    [Fact]
    public void ShouldFailGetOfferStatusDtoIfToDateIsNull()
    {
        var filterDto = new WidgetFilterCriteriaDto()
        {
            FromDate = DateOnly.FromDateTime(DateTime.Now),
            ToDate = null,
            JobCategoryIds = [1],
            JobPostIds = [1],
            Locations = ["Location"]
        };
        var result = _validator.TestValidate(filterDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<WidgetFilterCriteriaDto>>(result);
        var testValidationResult = result.ShouldHaveValidationErrorFor(filter => filter.ToDate);
        Assert.Contains(testValidationResult, result => result.ErrorMessage == OfferStatusCountValidation.ToDateOfferExtendedIsRequired);
    }

    [Fact]
    public void ShouldFailGetOfferStatusDtoIfToDateIsLessThenFromDate()
    {
        var filterDto = new WidgetFilterCriteriaDto()
        {
            FromDate = DateOnly.FromDateTime(DateTime.Now),
            ToDate = DateOnly.FromDateTime(DateTime.Now.AddDays(-10)),
            JobCategoryIds = [1],
            JobPostIds = [1],
            Locations = ["Location"]
        };
        var result = _validator.TestValidate(filterDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<WidgetFilterCriteriaDto>>(result);
        var testValidationResult = result.ShouldHaveValidationErrorFor(filter => filter);
        Assert.Contains(testValidationResult, result => result.ErrorMessage == string.Format(OfferStatusCountValidation.InvalidExtendedDates, filterDto.FromDate.ToString(), filterDto.ToDate.ToString()));
    }
}
