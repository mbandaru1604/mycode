﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class JobApplicationManualStatusUpdateDtoValidatorTests
{
    private readonly JobApplicationManualStatusUpdateDtoValidator _validator;
    public JobApplicationManualStatusUpdateDtoValidatorTests()
    {
        _validator = new JobApplicationManualStatusUpdateDtoValidator();
    }

    [Fact]
    public void ShouldFailToManualStatusUpdateWhenJobApplicationIdIsNull()
    {
        var statusUpdateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = null,
            NewHireTypeId = default,
            Note = default,
            SendEmail = default,
            StatusId = default,
        };
        var result = _validator.TestValidate(statusUpdateDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationManualStatusUpdateDto>>(result);
        var testValidationResult = result.ShouldHaveValidationErrorFor(result => result.JobApplicationId);
        Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationValidation.JobApplicationIdMandatory);
    }

    [Fact]
    public void ShouldFailWhenStatusIdIsNull()
    {
        var statusUpdateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = 1,
            NewHireTypeId = 1,
            Note = "Note",
            SendEmail = true,
            StatusId = null,
        };
        var result = _validator.TestValidate(statusUpdateDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationManualStatusUpdateDto>>(result);
        var testValidationResult = result.ShouldHaveValidationErrorFor(result => result.StatusId);
        Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationValidation.StatusIdMandatory);
    }

    [Fact]
    public void ShouldFailWhenNoteIsnull()
    {
        var statusUpdateDto = new JobApplicationManualStatusUpdateDto()
        {
            JobApplicationId = 1,
            NewHireTypeId = null,
            Note = null,
            SendEmail = true,
            StatusId = (int)JobApplicationStatuses.NotSelected,
        };
        var result = _validator.TestValidate(statusUpdateDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationManualStatusUpdateDto>>(result);
        var testValidationResult = result.ShouldHaveValidationErrorFor(result => result.Note);
        Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationValidation.NoteMandatory);
    }
}
