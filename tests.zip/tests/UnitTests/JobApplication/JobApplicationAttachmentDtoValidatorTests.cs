﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using Microsoft.AspNetCore.Http;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests
{
    public class JobApplicationAttachmentDtoValidatorTests
    {
        private readonly JobApplicationAttachmentDtoValidator _validator;

        public JobApplicationAttachmentDtoValidatorTests()
        {
            _validator = new JobApplicationAttachmentDtoValidator();
        }

        [Fact]
        public void ShouldFailAddAttachmentWhenFileNameIsNotProvided()
        {
            string fileName = null;
            var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
            JobApplicationAttachmentDto attachment = new()
            {
                Name = fileName,
                JobApplicationId = 1,
                TypeId = (long)JobApplicationAttachmentType.Resume,
                File = GenerateFormFileFromStream(fileStream),
            };
            var result = _validator.TestValidate(attachment);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobApplicationAttachmentDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(attachment => attachment.Name);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationAttachmentValidation.FileNameRequired);
        }

        [Fact]
        public void ShouldFailAddAttachmentWhenFileNameMaxLengthExceeded()
        {
            string fileName = "AttachfileChek_JVBERi0xLjQKMSAwIG9iago8PAovVGl0bGUgKP7KQovQ3JlYXRvciAov8AdwBrAGgAdABtAGwAdABvAHAAZABmACAAMAAuADEAMgAuADQpCi9Qcm9kdWNlciAoJVBERi0xLjQKMSAwIG9iago8PAovVGl0bGUgKP7KQovQ3JlYXRvciAov8AdwBrAGgAdABtAGwAdABvAHAAZABmACAAMAAuADEAMgAuADQpCi9Qcm9kdWNlciAo";
            var fileStream = GenerateFileStream(FileUploadsContent.base64StringPDF);
            JobApplicationAttachmentDto attachment = new()
            {
                Name = fileName,
                JobApplicationId = 1,
                TypeId = (long)JobApplicationAttachmentType.Resume,
                File = GenerateFormFileFromStream(fileStream),
            };
            var result = _validator.TestValidate(attachment);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobApplicationAttachmentDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(attachment => attachment.Name);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationAttachmentValidation.FileNameMaxLengthExceeded);
        }

        [Fact]
        public void ShouldFailAddAttachmentWhenFileIsNull()
        {
            JobApplicationAttachmentDto attachment = new()
            {
                Name = "test.pdf",
                JobApplicationId = 1,
                TypeId = (long)JobApplicationAttachmentType.Resume,
                File = null,
            };
            var result = _validator.TestValidate(attachment);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobApplicationAttachmentDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(attachment => attachment.File);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationAttachmentValidation.AttachmentRequired);
        }

        [Fact]
        public void ShouldFailAddAttachmentWhenUploadLargeFile()
        {
            var fileName = $"Attachment_{DateTime.Now.Ticks}";
            var fileStream = GenerateFileStream(FileUploadsContent.FileWithContentMoreThan1MB);
            JobApplicationAttachmentDto attachment = new()
            {
                Name = fileName,
                JobApplicationId = 1,
                TypeId = (long)JobApplicationAttachmentType.Resume,
                File = GenerateFormFileFromStream(fileStream),
            };
            var result = _validator.TestValidate(attachment);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobApplicationAttachmentDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(attachment => attachment.File.Length);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationAttachmentValidation.FileMaxLengthExceeded);
        }

        [Fact]
        public void ShouldFailAddAttachmentWhenUploadUnSupportedFile()
        {
            var fileName = $"Attachment_{DateTime.Now.Ticks}";
            var fileStream = GenerateFileStream(FileUploadsContent.FileWithBase64);
            JobApplicationAttachmentDto attachment = new()
            {
                Name = fileName,
                JobApplicationId = 1,
                TypeId = (long)JobApplicationAttachmentType.Resume,
                File = GenerateFormFileFromStream(fileStream),
            };
            var result = _validator.TestValidate(attachment);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobApplicationAttachmentDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(attachment => attachment.File.FileName);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationAttachmentValidation.UploadValidFile);
        }

        [Fact]
        public void ShouldFailAddAttachmentWhenTypeIdIsZero()
        {
            var fileName = $"Attachment_{DateTime.Now.Ticks}";
            var fileStream = GenerateFileStream(FileUploadsContent.FileWithBase64);
            JobApplicationAttachmentDto attachment = new()
            {
                Name = fileName,
                JobApplicationId = 1,
                TypeId = 0,
                File = GenerateFormFileFromStream(fileStream),
            };
            var result = _validator.TestValidate(attachment);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobApplicationAttachmentDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(attachment => attachment.TypeId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationAttachmentValidation.FileTypeRequired);
        }

        [Fact]
        public void ShouldFailAddAttachmentWhenJobApplicationIdIsZero()
        {
            var fileName = $"Attachment_{DateTime.Now.Ticks}";
            var fileStream = GenerateFileStream(FileUploadsContent.FileWithBase64);
            JobApplicationAttachmentDto attachment = new()
            {
                Name = fileName,
                JobApplicationId = 0,
                TypeId = 13,
                File = GenerateFormFileFromStream(fileStream),
            };
            var result = _validator.TestValidate(attachment);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobApplicationAttachmentDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(attachment => attachment.JobApplicationId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobApplicationAttachmentValidation.JobApplicationRequired);
        }

        private Stream GenerateFileStream(string base64String)
        {
            byte[] fileBytes = Convert.FromBase64String(base64String);
            return new MemoryStream(fileBytes);
        }

        private IFormFile GenerateFormFileFromStream(Stream memoryStream)
        {
            var formFile = new FormFile(memoryStream, 0, memoryStream.Length, "test.html", "test.html")
            {
                Headers = new HeaderDictionary(),
                ContentType = "text/html"
            };
            return formFile;
        }
    }
}