﻿using BBSI.ATS.Common;
using BBSI.ATS.Domain.Entities;
using BBSI.ATS.Infrastructure.Data.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace BBSI.ATS.UnitTests.Helpers;

public static class DBHelper
{
    public static AtsDbContext GetInMemoryDbContext()
    {
        AtsDbContext _dbContext;
        var options = new DbContextOptionsBuilder<AtsDbContext>()
                    .UseInMemoryDatabase(databaseName: "ATS")
                    .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                    .Options;
        _dbContext = new AtsDbContext(options, new CurrentUserContext { UserId = 1, CompanyId = 1 });
        _dbContext.Database.EnsureCreated();
        DataSeeder.SeedTestData(_dbContext);
        return _dbContext;
    }
}

public static class DataSeeder
{
    public static void SeedTestData(AtsDbContext context)
    {
        if (context.Users.Any())
        {
            return; // Data already exists, no need to seed again
        }
        // Add your seed data here
        var company = new Company { Code = 12345, DbaName = "TestCompany", LegalName = "TestCompany", StatusCode = "P", Identifier = Guid.NewGuid() };
        context.Companies.Add(company);

        var users = new List<User>
        {
            new() { FirstName = "John", LastName = "Doe", Email = "johndoe@gmail.com" },
            new() { FirstName = "Jane", LastName = "Smith", Email = "janesmith@test.com" },
            new() { FirstName = "Michael", LastName = "Johnson", Email = "micheljhonson@test.com" },
            new() { FirstName = "Emily", LastName = "Davis", Email = "emilydavis@test.com" },
            new() { FirstName = "Chris", LastName = "Brown", Email = "chrisbrown@test.com" }
        };
        context.Users.AddRange(users);
        context.SaveChanges();

        var user = users.First(u => u.Email == "johndoe@gmail.com");
        context.UserCompanyRoles.Add(new UserCompanyRole { CompanyId = company.Id, UserId = user.Id, RoleId = 1 });
        context.UserCompanyRoles.Add(new UserCompanyRole { CompanyId = company.Id, UserId = user.Id, RoleId = 4 });
        context.SaveChanges();

    }
}