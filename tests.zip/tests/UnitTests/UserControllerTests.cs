﻿//using BBSI.ATS.API.Controllers;
//using BBSI.ATS.Infrastructure.Data.Persistence;
//using BBSI.ATS.Services.Interfaces;
//using BBSI.ATS.UnitTests.Helpers;
//using Moq;

//namespace BBSI.ATS.UnitTests;

//public class UserControllerTests : IDisposable
//{
//    private readonly ATSDbContext _dbContext;

//    private readonly Mock<IUserService> _mockUserService;

//    private readonly UsersController _userController;
//    private bool disposed = false;

//    public UserControllerTests()
//    {
//        _dbContext = DBHelper.GetInMemoryDbContext();
//        _mockUserService = new Mock<IUserService>();
//        _userController = new UsersController(_mockUserService.Object, new Common.CurrentUserContext());
//    }

//    //[Fact]
//    //public async Task ValidUser_ReturnsToken()
//    //{
//    //    // Arrange
//    //    var tokenModel = new UserTokenDto { UserId = 1, CompanyId = 1 };
//    //    _mockUserService.Setup(service => service.ValidateUserAsync(tokenModel.UserId, tokenModel.CompanyId)).ReturnsAsync(true);
//    //    _mockTokenService.Setup(service => service.GenerateToken(It.IsAny<long>(), It.IsAny<long>())).Returns("fake-jwt-token");

//    //    // Act
//    //    var result = await _userController.ValidateUser(tokenModel);

//    //    // Assert
//    //    var okResult = Assert.IsType<OkObjectResult>(result);
//    //    Assert.NotNull(okResult.Value);
//    //    var tokenResultValue = okResult.Value;

//    //    var token = tokenResultValue.GetType().GetProperty("Token")?.GetValue(tokenResultValue)?.ToString();
//    //    var statusCode = (long?)tokenResultValue.GetType().GetProperty("StatusCode")?.GetValue(tokenResultValue);

//    //    Assert.Equal("fake-jwt-token", token);
//    //    Assert.Equal(200, statusCode);
//    //}

//    //[Fact]
//    //public async Task InvalidUser_ReturnsUnauthorized()
//    //{
//    //    // Arrange
//    //    var tokenModel = new UserTokenDto { UserId = 1, CompanyId = 1 };
//    //    _mockUserService.Setup(service => service.ValidateUserAsync(tokenModel.UserId, tokenModel.CompanyId)).ReturnsAsync(false);

//    //    // Act
//    //    var result = await _userController.ValidateUser(tokenModel);

//    //    // Assert
//    //    var unauthorizedResult = Assert.IsType<UnauthorizedResult>(result);
//    //}

//    protected virtual void Dispose(bool disposing)
//    {
//        if (!disposed)
//        {
//            if (disposing)
//            {
//                _dbContext.Dispose();
//            }
//            disposed = true;
//        }
//    }

//    public void Dispose()
//    {
//        Dispose(true);
//        GC.SuppressFinalize(this);
//    }
//}