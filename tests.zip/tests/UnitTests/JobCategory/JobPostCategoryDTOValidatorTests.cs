﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;

namespace BBSI.ATS.UnitTests
{
    public class JobPostCategoryDTOValidatorTests
    {
        private readonly JobPostCategoryDtoValidator _validator;

        public JobPostCategoryDTOValidatorTests()
        {
            _validator = new JobPostCategoryDtoValidator();
        }

        [Fact]
        public void ShouldSuccessValidName()
        {
            var jobPostCategoryDTO = new JobPostCategoryDto { Name = "Category1" };
            var result = _validator.TestValidate(jobPostCategoryDTO);
            result.ShouldNotHaveValidationErrorFor(category => category.Name);
        }

        [Fact]
        public void ShouldFailNameIsNull()
        {
            var jobPostCategoryDTO = new JobPostCategoryDto { Name = "" };
            var result = _validator.TestValidate(jobPostCategoryDTO);
            result.ShouldHaveValidationErrorFor(category => category.Name);
        }

        [Fact]
        public void ShouldReturnErrorNameIsEmpty()
        {
            var jobPostCategoryDTO = new JobPostCategoryDto { Name = string.Empty };
            var result = _validator.TestValidate(jobPostCategoryDTO);
            result.ShouldHaveValidationErrorFor(category => category.Name);
        }

        [Fact]
        public void ShouldReturnErrorNameMaxLengthExceeded()
        {
            var jobPostCategoryDTO = new JobPostCategoryDto { Name = "012345678901234567890123456789012345678901234567890123456789" };
            var result = _validator.TestValidate(jobPostCategoryDTO);
            result.ShouldHaveValidationErrorFor(category => category.Name);
        }
    }
}