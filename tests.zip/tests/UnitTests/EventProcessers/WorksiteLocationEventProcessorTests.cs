﻿using AutoMapper;
using BBSI.ATS.Common;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using BBSI.ESB;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests.EventProcessers;

public class WorksiteLocationEventProcessorTests : IDisposable
{
    private readonly WorksiteLocationEventHandler _worksiteLocationEventProcessor;
    private readonly AtsDbContext _dbContext;
    private bool disposed = false;
    private readonly ICompanyService _companyService;
    private int companyCode = 111130;

    public WorksiteLocationEventProcessorTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        var mapper = mappingConfig.CreateMapper();
        var companyRepository = new CompanyRepository(_dbContext, new CurrentUserContext());
        var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
        var unitOfWork = new UnitOfWork(_dbContext);
        _companyService = new CompanyService(companyRepository, null, unitOfWork, mapper, mockLoggerCompanyService.Object);
        var mockLogger = new Mock<ILogger<WorksiteLocationEventHandler>>();
        _worksiteLocationEventProcessor = new WorksiteLocationEventHandler(_companyService);
    }

    #region Positive tests

    [Fact]
    public async Task ShouldCreateWorksiteLocationWhenValidEventIsPublished()
    {
        var worksiteLocation = GetWorksiteLocationDto();
        await AssertSaveWorksiteLocationAsync(companyCode, worksiteLocation, Constants.AtsEventTypes.WorksiteLocationCreated);
        await AssertGetWorksiteLocationAsync(companyCode, worksiteLocation);
    }

    [Fact]
    public async Task ShouldUpdateWorksiteLocationWhenExistingWorksiteLocationEventIsPublished()
    {
        var worksiteLocation = GetWorksiteLocationDto();

        await AssertSaveWorksiteLocationAsync(companyCode, worksiteLocation, Constants.AtsEventTypes.WorksiteLocationCreated);
        await AssertGetWorksiteLocationAsync(companyCode, worksiteLocation);

        worksiteLocation.Name = "Modified Name";

        await AssertSaveWorksiteLocationAsync(companyCode, worksiteLocation, Constants.AtsEventTypes.WorksiteLocationUpdated);
        await AssertGetWorksiteLocationAsync(companyCode, worksiteLocation);
    }

    #endregion Positive tests

    #region Negative tests

    [Fact]
    public async Task ShouldFailCreateWorksiteLocationWhenInValidEventIsPublished()
    {
        var worksiteLocation = GetWorksiteLocationDto();
        await AssertSaveWorksiteLocationAsync(companyCode, worksiteLocation, "DOMAIN_COMPANY_WORKSITE  ");
    }

    [Fact]
    public async Task ShouldFailWhenWorksiteLocationCompanyCodeIsInvalid()
    {
        var companyCode = 900002;
        var exception = await Assert.ThrowsAsync<ValidationException>(async () =>
        {
            await AssertSaveWorksiteLocationAsync(companyCode, GetWorksiteLocationDto(), Constants.AtsEventTypes.WorksiteLocationCreated);
        });

        exception.Message.Should().Contain(string.Format(CompanyValidation.CompanyNotFound, companyCode));
    }

    [Fact]
    public async Task ShouldFailForNullPayload()
    {
        var worksiteLocation = GetWorksiteLocationDto();

        await AssertSaveWorksiteLocationAsync(companyCode, worksiteLocation, Constants.AtsEventTypes.WorksiteLocationCreated, true);
        var company = await _companyService.GetByCodeAsync(companyCode);
        var worksiteLocations = await _companyService.GetWorksiteLocationsByCompanyId(company.Id);
        Assert.True(worksiteLocations?.Count() == 0);
    }

    #endregion Negative tests

    #region Private Methods

    private async Task AssertSaveWorksiteLocationAsync(int? companyCode, WorksiteLocationDto worksiteLocationDto, string eventName, bool removePayload = false)
    {
        await _companyService.AddAsync(new CompanyDto()
        {
            CompanyCode = this.companyCode,
            StatusCode = "A",
            LegalName = "Legal Name 1",
            DbaName = "DBA name 1"
        });

        var eventJson = $@"
           {{
                  ""source"": ""PIE"",
                  ""userId"": 999,
                  ""filter"": ""ABC"",
                  ""id"": ""7ff7fcb9-ce2d-4fc4-9c7a-1eaed8456d7d"",
                  ""name"": ""{eventName}"",
                  ""timestamp"": ""2024-06-06T23:00:49.515"",
                  ""priority"": 1,
                  ""version"": 1.0,
                  ""companyCode"": {companyCode},
                  ""userType"": ""CLIENTUSER"",
                  ""payload"": {{
                    ""locations"": [
                      {{
                        ""code"":""{worksiteLocationDto.Code}"",
                        ""name"": ""{worksiteLocationDto.Name}"",
                        ""addr1"": ""{worksiteLocationDto.Addr1}"",
                        ""addr2"": ""{worksiteLocationDto.Addr2}"",
                        ""city"": ""{worksiteLocationDto.City}"",
                        ""state"": ""{worksiteLocationDto.State}"",
                        ""country"": ""{worksiteLocationDto.Country}"",
                        ""zipCode"": ""{worksiteLocationDto.ZipCode}"",
                        ""isActive"": true
                      }}
                    ]
                  }}
                }}";

        var atsEventDto = JsonConvert.DeserializeObject<EnterpriseBusEvent>(eventJson);
        Assert.NotNull(atsEventDto);
        if (removePayload)
            atsEventDto.Payload = null;
        await _worksiteLocationEventProcessor.ProcessAsync(atsEventDto);
    }

    private async Task AssertGetWorksiteLocationAsync(int companyCode, WorksiteLocationDto worksiteLocationDto)
    {
        var company = await _companyService.GetByCodeAsync(companyCode);
        var worksiteLocations = await _companyService.GetWorksiteLocationsByCompanyId(company.Id);
        Assert.NotNull(worksiteLocations);
        Assert.True(worksiteLocations?.Count() >= 1);
        Assert.Contains(worksiteLocations, location => location?.Code == worksiteLocationDto.Code);
        var location = worksiteLocations.Where(location => location?.Code == worksiteLocationDto.Code).FirstOrDefault();
        Assert.NotNull(location);
        Assert.Equal(location.Code, worksiteLocationDto.Code);
        Assert.Equal(location.Name, worksiteLocationDto.Name);
        Assert.Equal(location.IsActive, worksiteLocationDto.IsActive);
        Assert.Equal(location.Addr1, worksiteLocationDto.Addr1);
        Assert.Equal(location.Addr2, worksiteLocationDto.Addr2);
        Assert.Equal(location.City, worksiteLocationDto.City);
        Assert.Equal(location.State, worksiteLocationDto.State);
        Assert.Equal(location.Country, worksiteLocationDto.Country);
        Assert.Equal(location.ZipCode, worksiteLocationDto.ZipCode);
    }

    private WorksiteLocationDto GetWorksiteLocationDto()
    {
        return new WorksiteLocationDto()
        {
            Code = "111",
            Name = "Test location",
            IsActive = true,
            Addr1 = "Address line One",
            Addr2 = "Address line two",
            City = "New Jersey",
            State = "NewJersey",
            Country = "United States",
            ZipCode = "10101"
        };
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}