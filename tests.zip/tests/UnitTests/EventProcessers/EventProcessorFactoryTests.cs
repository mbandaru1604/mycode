﻿using AutoMapper;
using BBSI.ATS.Common;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using static BBSI.ATS.Common.Constants;

namespace BBSI.ATS.UnitTests.EventProcessers
{
    public class EventProcessorFactoryTests
    {
        private readonly Mock<IServiceScope> _serviceScopeMock;
        private readonly Mock<IServiceProvider> _serviceProviderMock;
        private readonly EventHandlerFactory _eventProcessorFactory;
        private readonly AtsDbContext _dbContext;
        private readonly ICompanyService _companyService;

        public EventProcessorFactoryTests()
        {
            _dbContext = DBHelper.GetInMemoryDbContext();
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });
            var mapper = mappingConfig.CreateMapper();
            var companyRepository = new CompanyRepository(_dbContext, new CurrentUserContext());

            var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
            var unitOfWork = new UnitOfWork(_dbContext);
            _companyService = new CompanyService(companyRepository, null, unitOfWork, mapper, mockLoggerCompanyService.Object);

            _serviceScopeMock = new Mock<IServiceScope>();
            _serviceProviderMock = new Mock<IServiceProvider>();
            _serviceScopeMock.Setup(x => x.ServiceProvider).Returns(_serviceProviderMock.Object);
            _eventProcessorFactory = new EventHandlerFactory();
        }

        [Theory]
        [InlineData(AtsEventTypes.CompanyCreated, typeof(CompanyEventHandler))]
        [InlineData(AtsEventTypes.CompanyUpdated, typeof(CompanyEventHandler))]
        [InlineData(AtsEventTypes.WorksiteLocationCreated, typeof(WorksiteLocationEventHandler))]
        [InlineData(AtsEventTypes.WorksiteLocationUpdated, typeof(WorksiteLocationEventHandler))]
        [InlineData(AtsEventTypes.DomainProductEnabledEvent, typeof(DomainProductEnabledEventHandler))]
        [InlineData(AtsEventTypes.NewHireCreatedEvent, typeof(NewHireCreatedEventHandler))]
        public void ShouldReturnAppropriateEventProcesserWhenValidEventTypeGiven(string eventType, Type expectedProcessorType)
        {
            // Arrange
            object processorInstance = expectedProcessorType switch
            {
                Type t when t == typeof(CompanyEventHandler) => new CompanyEventHandler(_companyService, null),
                Type t when t == typeof(WorksiteLocationEventHandler) => new WorksiteLocationEventHandler(_companyService),
                Type t when t == typeof(DomainProductEnabledEventHandler) => new DomainProductEnabledEventHandler(_companyService, null, null, null),
                Type t when t == typeof(NewHireCreatedEventHandler) => new NewHireCreatedEventHandler(null),

                _ => throw new ArgumentException("Unexpected processor type", nameof(expectedProcessorType))
            };

            _serviceProviderMock.Setup(x => x.GetService(expectedProcessorType)).Returns(processorInstance);

            // Act
            var result = _eventProcessorFactory.GetSubscriptionHandler(_serviceScopeMock.Object, eventType);

            // Assert
            Assert.NotNull(result);
            Assert.IsType(expectedProcessorType, result);
        }

        [Fact]
        public void ShouldThrowArgumentExceptionWhenInvalidEventTypeGiven()
        {
            // Arrange
            var invalidEventType = "InvalidEventType";

            // Act & Assert
            var exception = Assert.Throws<ArgumentException>(() => _eventProcessorFactory.GetSubscriptionHandler(_serviceScopeMock.Object, invalidEventType));
            Assert.Equal($"Invalid event type. No Event Processor found for: {invalidEventType} (Parameter 'eventType')", exception.Message);
            Assert.Equal("eventType", exception.ParamName);
        }
    }
}