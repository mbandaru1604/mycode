﻿using AutoMapper;
using BBSI.ATS.Common;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using BBSI.ESB;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using Xunit.Abstractions;

namespace BBSI.ATS.UnitTests.EventProcessers;

public class DomainProductEnabledEventProcessorTests : IDisposable
{
    private readonly DomainProductEnabledEventHandler _domainProductEnabledEventHandler;
    private readonly AtsDbContext _dbContext;
    private bool disposed = false;
    private readonly ICompanyService _companyService;
    private readonly ITestOutputHelper _output;

    public DomainProductEnabledEventProcessorTests(ITestOutputHelper output)
    {
        _output = output;
        _dbContext = DBHelper.GetInMemoryDbContext();
        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        var mapper = mappingConfig.CreateMapper();
        var currentUserContext = new CurrentUserContext();
        var companyRepository = new CompanyRepository(_dbContext, currentUserContext);
        var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
        var unitOfWork = new UnitOfWork(_dbContext);
        var userService = new UserService(new AtsBaseRepository(_dbContext, currentUserContext), unitOfWork, null, null);
        _companyService = new CompanyService(companyRepository, userService, unitOfWork, mapper, mockLoggerCompanyService.Object);
        var mockLogger = new Mock<ILogger<DomainProductEnabledEventHandler>>();
        _domainProductEnabledEventHandler = new DomainProductEnabledEventHandler(_companyService, null, mockLogger.Object, null);
    }

    #region Positive tests

    [Fact]
    public async Task ShouldEnableProductWhenValidEventIsPublished()
    {
        var companyCode = 911129;
        var user = GetUserDtoObject();

        await AssertEnableProductAsync(companyCode, user, Constants.AtsEventTypes.DomainProductEnabledEvent);
        await AssertCompanyDetailsAsync(companyCode, user);
    }

    [Fact]
    public async Task ShouldEnableProductWhenIsPublishedWithNoEndDate()
    {
        var companyCode = 911150;
        var user = GetUserDtoObject();

        await AssertEnableProductAsync(companyCode, user, Constants.AtsEventTypes.DomainProductEnabledEvent, true);
        await AssertCompanyDetailsAsync(companyCode, user, true);
    }

    #endregion Positive tests

    #region Negative tests

    [Fact]
    public async Task ShouldNotAllowDuplicateUsersWithSameEmail()
    {
        var companyCode = 911130;
        var user = GetUserDtoObject();

        await AssertEnableProductAsync(companyCode, user, Constants.AtsEventTypes.DomainProductEnabledEvent, false, false, true);
        await AssertCompanyDetailsAsync(companyCode, user, false);
    }

    [Fact]
    public async Task ShouldFailForNullPayload()
    {
        var companyCode = 911990;
        var user = GetUserDtoObject();

        await AssertEnableProductAsync(companyCode, user, Constants.AtsEventTypes.DomainProductEnabledEvent, false, false, true, true);
        var company = await _companyService.GetByCodeAsync(companyCode);
        Assert.Null(company);
    }

    #endregion Negative tests

    #region Private Methods

    private async Task AssertEnableProductAsync(int? companyCode, UserDto user, string eventName, bool isEndDateNotGiven = false, bool isInvalidUserDetails = false, bool addDuplicateUser = false, bool removePayload = false)
    {
        var end = @"""end"":""2025-01-01"",";
        if (isEndDateNotGiven)
        {
            end = string.Empty;
        }

        var firstName = $@" ""firstName"":""{user.FirstName}"",";
        if (isInvalidUserDetails)
        {
            firstName = string.Empty;
        }

        var SecondUser = string.Empty;
        if (addDuplicateUser)
        {
            SecondUser = $@",{{  ""email"":""{user.Email}"",
                                 ""firstName"":""{user.FirstName}"",
                                ""lastName"":""{user.LastName}"",
                                ""userType"":""{user.UserType}"",
                                ""roleCode"":""{user.RoleCode}"",
                                ""roleName"":""{user.RoleName}"",
                                ""isActive"": true
                            }}";
        }

        var eventJson = $@"{{
                           ""id"":""0528248e-76d7-47f9-afca-db04c3b75d25"",
                           ""name"":""{eventName}"",
                           ""timestamp"":""2024-06-11T08:00:00.000"",
                           ""source"":""myBBSI"",
                           ""filter"":""PIE"",
                           ""priority"":1,
                           ""version"":1.0,
                           ""companyCode"":{companyCode},
                           ""payload"":{{
                              ""product"":{{
                                 ""name"":""ATSNEW"",
                                 ""start"":""2024-01-01"",
                                 {end}
                                 ""company"":{{
                                    ""companyCode"":{companyCode},
                                    ""dbaName"":""DBA Name 1022"",
                                    ""legalName"":""Legal Name 1222"",
                                    ""statusCode"":""A"",
                                    ""locations"":[
                                       {{
                                          ""code"":""8646-5"",
                                          ""name"":""NA, INC."",
                                          ""addr1"":""621 West Division Street, Building 105"",
                                          ""addr2"":""6601 NORTHPARK BLVD STE P"",
                                          ""city"":""MT. PLEASANT"",
                                          ""state"":""NY"",
                                          ""zipCode"":""12345"",
                                          ""isActive"":true
                                       }},
			                            {{
                                          ""code"":""8646-6"",
                                          ""name"":""NEW YORK INC."",
                                          ""addr1"":""621 West Division Street, Building 105"",
                                          ""addr2"":""6601 NORTHPARK BLVD STE P"",
                                          ""city"":""MT. PLEASANT"",
                                          ""state"":""NY"",
                                          ""zipCode"":""12345"",
                                          ""isActive"":true
                                       }}
                                    ],
                                    ""users"":[
			                            {{
                                          ""email"":""{user.Email}"",
                                         {firstName}
                                          ""lastName"":""{user.LastName}"",
                                          ""userType"":""{user.UserType}"",
                                          ""roleCode"":""{user.RoleCode}"",
                                          ""roleName"":""{user.RoleName}"",
                                          ""isActive"": true
                                       }}{SecondUser}
                                    ]
                                 }}
                              }}
                           }}
                        }}";

        var atsEventDto = JsonConvert.DeserializeObject<EnterpriseBusEvent>(eventJson);
        Assert.NotNull(atsEventDto);
        if (removePayload)
            atsEventDto.Payload = null;
        await _domainProductEnabledEventHandler.ProcessAsync(atsEventDto);
    }

    private async Task AssertCompanyDetailsAsync(int companyCode, UserDto user, bool isEndDateNull = false)
    {
        var company = await _companyService.GetByCodeAsync(companyCode);
        Assert.NotNull(company);
        Assert.NotNull(company.Start);
        Assert.NotNull(company.DbaName);
        Assert.NotNull(company.LegalName);
        if (isEndDateNull)
        {
            _output.WriteLine(companyCode.ToString());
            Assert.Null(company.End);
        }
        else
        {
            Assert.NotNull(company.End);
        }
    }

    private UserDto GetUserDtoObject(bool isFailureCase = false)
    {
        return new UserDto
        {
            Email = "email@gmail.com",
            FirstName = "Thomas",
            LastName = "Jhon",
            UserType = "Branch",
            RoleCode = "Interviewer",
            RoleName = "Interviewer",
            IsActive = true
        };
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}