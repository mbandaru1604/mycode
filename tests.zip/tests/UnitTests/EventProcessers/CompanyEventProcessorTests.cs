﻿using AutoMapper;
using BBSI.ATS.Common;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using BBSI.ESB;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;

namespace BBSI.ATS.UnitTests.EventProcessers;

public class CompanyEventProcessorTests : IDisposable
{
    private readonly CompanyEventHandler _companyEventHandler;
    private readonly AtsDbContext _dbContext;
    private bool disposed = false;
    private readonly ICompanyService _companyService;

    public CompanyEventProcessorTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        var mapper = mappingConfig.CreateMapper();
        var companyRepository = new CompanyRepository(_dbContext, new CurrentUserContext());
        var unitOfWork = new UnitOfWork(_dbContext);
        var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
        _companyService = new CompanyService(companyRepository, null, unitOfWork, mapper, mockLoggerCompanyService.Object);
        var mockLogger = new Mock<ILogger<CompanyEventHandler>>();
        _companyEventHandler = new CompanyEventHandler(_companyService, mockLogger.Object);
    }

    #region Positive tests

    [Fact]
    public async Task ShouldCreateCompanyWhenValidEventIsPublished()
    {
        var companyCode = 111126;
        var dbaName = "DBA Name 1";
        var legalName = "Legal Name 1";
        var statusCode = "A";

        await AssertSaveCompanyAsync(companyCode, dbaName, legalName, statusCode, Constants.AtsEventTypes.CompanyCreated);
        await AssertGetCompanyAsync(companyCode, dbaName, legalName, statusCode);
    }

    [Fact]
    public async Task ShouldUpdateCompanyWhenExistingCompanyEventIsPublished()
    {
        var companyCode = 111126;
        var dbaName = "DBA Name 1";
        var legalName = "Legal Name 1";
        var statusCode = "A";

        await AssertSaveCompanyAsync(companyCode, dbaName, legalName, statusCode, Constants.AtsEventTypes.CompanyCreated);
        await AssertGetCompanyAsync(companyCode, dbaName, legalName, statusCode);

        dbaName = "DBA Name 2";
        legalName = "Legal Name 2";
        statusCode = "C";

        await AssertSaveCompanyAsync(companyCode, dbaName, legalName, statusCode, Constants.AtsEventTypes.CompanyUpdated);
        await AssertGetCompanyAsync(companyCode, dbaName, legalName, statusCode);
    }

    #endregion Positive tests

    #region Private Methods

    private async Task AssertSaveCompanyAsync(int? companyCode, string? dbaName, string? legalName, string? statusCode, string eventName)
    {
        var eventJson = $@"
            {{
                ""source"": ""PIE"",
                ""userId"": 123,
                ""filter"": ""ATS|PAYROLL|TESTDOMAIN"",
                ""id"": ""5590f00a-092f-4696-b9a5-aec133728691"",
                ""name"": ""{eventName}"",
                ""timestamp"": ""2024-05-19T23:18:31.718"",
                ""priority"": 1,
                ""version"": 1.0,
                ""companyCode"": {companyCode},
                ""userType"": ""Branch"",
                ""payload"":
                {{
                    ""company"":
                    {{
                      ""companyCode"": {companyCode},
                      ""dbaName"": ""{dbaName}"",
                      ""legalName"": ""{legalName}"",
                      ""statusCode"": ""{statusCode}""
                    }}
                }}
            }}";

        var atsEventDto = JsonConvert.DeserializeObject<EnterpriseBusEvent>(eventJson);
        Assert.NotNull(atsEventDto);
        await _companyEventHandler.ProcessAsync(atsEventDto);
    }

    private async Task AssertGetCompanyAsync(int companyCode, string dbaName, string legalName, string statusCode)
    {
        var company = await _companyService.GetByCodeAsync(companyCode);
        Assert.Equal(dbaName, company.DbaName);
        Assert.Equal(legalName, company.LegalName);
        Assert.Equal(statusCode, company.StatusCode);
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}