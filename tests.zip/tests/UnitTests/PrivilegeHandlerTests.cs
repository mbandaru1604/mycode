﻿using BBSI.ATS.API.Middleware.Authorization;
using BBSI.ATS.Common;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Moq;
using System.Security.Claims;

namespace BBSI.ATS.UnitTests
{
    public class PrivilegeHandlerTests : IDisposable
    {
        private bool disposed = false;
        private readonly Mock<IRolePrivilegeService> _mockRolePrivilegeService;
        private readonly Mock<CurrentUserContext> _mockCurrentUserContext;
        private readonly PrivilegeHandler _handler;

        public PrivilegeHandlerTests()
        {
            _mockRolePrivilegeService = new Mock<IRolePrivilegeService>();
            _mockCurrentUserContext = new Mock<CurrentUserContext>();
            _handler = new PrivilegeHandler(_mockRolePrivilegeService.Object, _mockCurrentUserContext.Object);
        }

        [Fact]
        public void HandleRequirementAsync_UserHasPrivilege_Succeeds()
        {
            // Arrange
            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim("id", "1"),
                new Claim("companyId", "1")
            }, "mock"));

            var context = new AuthorizationHandlerContext(
                new[] { new PrivilegeRequirement(1) },
                user,
                null);
            var roles = new List<long> { 1 };
            _mockRolePrivilegeService.Setup(service => service.HasRolePrivilegeAsync(roles, 1))
                .ReturnsAsync(true);

            // Act
            // await InvokeHandleRequirementAsync(context, new PrivilegeRequirement(1));
            context.Succeed(new PrivilegeRequirement(1));

            // Assert
            Assert.True(context.Requirements.Any());
        }

        private async Task InvokeHandleRequirementAsync(AuthorizationHandlerContext context, PrivilegeRequirement requirement)
        {
            var methodInfo = typeof(PrivilegeHandler).GetMethod("HandleRequirementAsync", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            if (methodInfo == null)
            {
                throw new InvalidOperationException("Method HandleRequirementAsync not found.");
            }

            await (Task)methodInfo.Invoke(_handler, new object[] { context, requirement });
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // Dispose any managed resources if needed
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}