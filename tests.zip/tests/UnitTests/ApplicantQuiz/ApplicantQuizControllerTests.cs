﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Data.Repositories.Interfaces;
using BBSI.ATS.Infrastructure.Integrations.Concrete;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class ApplicantQuizControllerTests : IDisposable
{
    private readonly ApplicantQuizzesController _applicantQuizzesController;

    private readonly IApplicantQuizService _applicantQuizService;
    private readonly IApplicantQuizRepository _applicantQuizRepository;
    private readonly IAtsBaseRepository _atsBaseRepository;
    private readonly AtsDbContext _dbContext;
    private readonly CurrentUserContext _currentUserContext;
    private readonly IJobPostRepository _jobPostRepository;
    private readonly IApplicationFormService _applicationFormService;
    private readonly IJobPostService _jobPostService;
    private readonly IJobApplicationService _jobApplicationService;

    private readonly IMapper _mapper;
    private bool disposed;

    public ApplicantQuizControllerTests()
    {
        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });

        _mapper = mappingConfig.CreateMapper();
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        _atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        _jobPostRepository = new JobPostRepository(_dbContext, _currentUserContext);
        _applicantQuizRepository = new ApplicantQuizRepository(_dbContext, _currentUserContext);
        var comparer = new ApplicantQuizComparer();
        var mockCosmosDbService = new Mock<ICosmosDbService>();
        _applicantQuizService = new ApplicantQuizService(_atsBaseRepository, _mapper, _applicantQuizRepository, _currentUserContext, _jobPostRepository, comparer, mockCosmosDbService.Object);
        _applicantQuizzesController = new ApplicantQuizzesController(_applicantQuizService);
        var applicationFormRepository = new ApplicationFormRepository(_dbContext, _currentUserContext);
        var applicationFormFieldComparer = new ApplicationFormFieldComparer();
        var applicationFormComparer = new ApplicationFormComparer(applicationFormFieldComparer);
        _applicationFormService = new ApplicationFormService(applicationFormRepository, _mapper, _currentUserContext, mockCosmosDbService.Object, applicationFormComparer);
        var companyRepository = new CompanyRepository(_dbContext, _currentUserContext);
        var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
        var unitOfWork = new UnitOfWork(_dbContext);
        var companyService = new CompanyService(companyRepository, null!, unitOfWork, _mapper, mockLoggerCompanyService.Object);
        var appConfig = new AppConfig();
        _jobPostService = new JobPostService(_jobPostRepository, _mapper, _applicationFormService, _currentUserContext, mockCosmosDbService.Object, _applicantQuizRepository, companyService, appConfig);
        var jobApplicationRepository = new JobApplicationRepository(_dbContext, _currentUserContext);
        var jobApplicationNoteRepository = new JobApplicationNoteRepository(_dbContext, _currentUserContext);
        var userRepository = new UserRepository(_dbContext, _currentUserContext);
        var userService = new UserService(_atsBaseRepository, null!, userRepository, _currentUserContext);
        var jobApplicationNoteService = new JobApplicationNoteService(_atsBaseRepository, _mapper, jobApplicationRepository,
                                        _currentUserContext, jobApplicationNoteRepository, userService, mockCosmosDbService.Object);
        var mockLogger = new Mock<ILogger<JobApplicationService>>();
        var mockConfig = new Mock<IOptions<EmailTemplateConfig>>();
        var mockLoggerEmailClient = new Mock<ILogger<EmailClient>>();
        var emailConfig = new SendGridEmailConfig();
        emailConfig.ApiKey = "testkey";
        emailConfig.SenderEmail = "ats-no-reply@mybbsi.com";
        var emailClient = new EmailClient(emailConfig, mockLoggerEmailClient.Object);
        var metaDataRepository = new MetaDataRepository(_dbContext, _currentUserContext);
        var metadataService = new MetaDataService(metaDataRepository, _mapper);
        _jobApplicationService = new JobApplicationService(jobApplicationRepository, _mapper, _applicationFormService, null!, null!, jobApplicationNoteService, metadataService, mockLogger.Object, emailClient, mockConfig.Object, null!, null!, _currentUserContext, null!, mockCosmosDbService.Object, _applicantQuizRepository);

    }

    [Fact]
    public async Task ShouldCreateApplicantQuizWithRequiredFieldsEntered()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);
    }

    [Fact]
    public async Task ShouldFailApplicantQuizWhenDuplicateAnswerEntered()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "New Quiz",
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
            QuizQuestions =
            [
                new()
                {
                    Question ="Test Question",
                    TypeId = (long)QuestionType.MultipleChoice,
                    Score = 21,
                    IsActive = true,
                    IsRequired = false,
                    Answers =
                    [
                        new()
                        {
                            Answer="test answer 1",
                            IsCorrect=true,
                        },
                        new()
                        {
                            Answer="test answer 1",
                            IsCorrect=false,
                        },
                        new()
                        {
                            Answer="test answer 3",
                            IsCorrect=false,
                        },
                    ]
                }
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantQuizzesController.Create(applicantQuiz));
        Assert.Equal(ApplicantQuizValidation.DuplicateAnswers, exception.Message);
    }

    [Fact]
    public async Task ShouldFailSavingApplicantQuizWhenDuplicateQuestionsEntered()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "New Quiz-1",
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
            QuizQuestions = new List<QuizQuestionDto>
            {
                new QuizQuestionDto
                {
                    Question = "Test Question 1",
                    TypeId = (int)QuestionType.MultipleChoice,
                    Score = 21,
                    IsActive = true,
                    IsRequired = false,
                    Answers = new List<QuizQuestionAnswerDto>
                    {
                        new QuizQuestionAnswerDto
                        {
                            Answer = "test answer 1",
                            IsCorrect = true,
                        },
                        new QuizQuestionAnswerDto
                        {
                            Answer = "test answer 2",
                            IsCorrect = false,
                        }
                    }
                },
                new QuizQuestionDto
                {
                    Question = "Test Question 1",
                    TypeId = (int)QuestionType.MultipleChoice,
                    Score = 15,
                    IsActive = true,
                    IsRequired = true,
                    Answers = new List<QuizQuestionAnswerDto>
                    {
                        new QuizQuestionAnswerDto
                        {
                            Answer = "test answer 3",
                            IsCorrect = false,
                        },
                        new QuizQuestionAnswerDto
                        {
                            Answer = "test answer 4",
                            IsCorrect = true,
                        }
                    }
                }
            }
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantQuizzesController.Create(applicantQuiz));
        Assert.Equal(ApplicantQuizValidation.DuplicateQuestions, exception.Message);
    }

    [Fact]
    public async Task ShouldGetApplicantQuizList()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuizList = await _applicantQuizzesController.GetAllQuizzes();
        Assert.IsType<ActionResult<List<ApplicantQuizListDto>>>(applicantQuizList);
        var okResult = Assert.IsType<OkObjectResult>(applicantQuizList.Result);
        var applicantQuizzes = Assert.IsAssignableFrom<List<ApplicantQuizListDto>>(okResult.Value);
        Assert.NotEmpty(applicantQuizzes);
        Assert.True(applicantQuizzes.Count > 0);
    }

    [Fact]
    public async Task ShouldEditApplicantQuizWithNewFields()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var okResult = Assert.IsType<OkObjectResult>(applicantQuiz.Result);
        var applicantQuizValue = Assert.IsAssignableFrom<ApplicantQuizDto>(okResult.Value);

        var updateApplicantQuiz = new ApplicantQuizDto()
        {
            Id = applicantQuizValue.Id,
            Name = "EditQuizName",
            Description = applicantQuizValue.Description,
            IsActive = applicantQuizValue.IsActive,
            MinimumPassingScore = applicantQuizValue.MinimumPassingScore,
            QuizQuestions =
            [
                new()
                {
                    Question = "New Question 1",
                    TypeId = 154,
                    Score=10,
                    IsActive = true,
                    IsRequired= false,
                    Answers=
                    [
                        new()
                        {
                            Answer = "New Answer 1",
                            IsCorrect= true,
                        },
                        new()
                        {
                            Answer = "New Answer 2",
                            IsCorrect= false,
                        },
                        new()
                        {
                            Answer = "New Answer 3",
                            IsCorrect= false,
                        }
                    ]
                }
            ],
            Version= applicantQuizValue.Version
        };

        await _applicantQuizzesController.UpdateAsync(updateApplicantQuiz);
        var afterUpdateApplicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var afterUpdateApplicantQuizResult = Assert.IsType<OkObjectResult>(afterUpdateApplicantQuiz.Result);
        var afterUpdateApplicantQuizResultValue = Assert.IsAssignableFrom<ApplicantQuizDto>(afterUpdateApplicantQuizResult.Value);
        Assert.True(afterUpdateApplicantQuizResultValue.Name == updateApplicantQuiz.Name);
    }

    [Fact]
    public async Task ShouldEditApplicantQuizForExistingFields()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var okResult = Assert.IsType<OkObjectResult>(applicantQuiz.Result);
        var applicantQuizValue = Assert.IsAssignableFrom<ApplicantQuizDto>(okResult.Value);
        applicantQuizValue.QuizQuestions[0].Question = "edit my question";
        applicantQuizValue.QuizQuestions[0].Answers[0].Answer = "edit my Answer";

        await _applicantQuizzesController.UpdateAsync(applicantQuizValue);
        var afterUpdateApplicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var afterUpdateApplicantQuizResult = Assert.IsType<OkObjectResult>(afterUpdateApplicantQuiz.Result);
        var afterUpdateApplicantQuizResultValue = Assert.IsAssignableFrom<ApplicantQuizDto>(afterUpdateApplicantQuizResult.Value);
        Assert.True(afterUpdateApplicantQuizResultValue.QuizQuestions[0].Question == applicantQuizValue.QuizQuestions[0].Question);
        Assert.True(afterUpdateApplicantQuizResultValue.QuizQuestions[0].Answers[0].Answer == applicantQuizValue.QuizQuestions[0].Answers[0].Answer);
    }

    [Fact]
    public async Task ShouldDeleteQuizQuestionAnswer()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var applicantQuizResult = applicantQuiz.Result as OkObjectResult;
        var applicantQuizDTO = applicantQuizResult?.Value as ApplicantQuizDto;
        Assert.True(applicantQuizDTO != null && applicantQuizDTO.QuizQuestions != null);

        var quizQuestionDto = applicantQuizDTO.QuizQuestions.Find(quizQuestion => quizQuestion.Question == "Test Question");
        Assert.True(quizQuestionDto != null && quizQuestionDto.Answers != null);

        quizQuestionDto.Answers[0].IsDeleted = true;

        await _applicantQuizzesController.UpdateAsync(applicantQuizDTO);
        var afterUpdateApplicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var afterUpdateApplicantQuizResult = Assert.IsType<OkObjectResult>(afterUpdateApplicantQuiz.Result);
        var afterUpdateApplicantQuizResultValue = Assert.IsAssignableFrom<ApplicantQuizDto>(afterUpdateApplicantQuizResult.Value);
        Assert.True(afterUpdateApplicantQuizResultValue != null && afterUpdateApplicantQuizResultValue.QuizQuestions != null);

        var quizQuestionDtoAfterUpdate = afterUpdateApplicantQuizResultValue.QuizQuestions.Find(quizQuestion => quizQuestion.Question == "Test Question");
        Assert.True(quizQuestionDtoAfterUpdate != null && (quizQuestionDtoAfterUpdate.Answers.Count == 2));
    }

    [Fact]
    public async Task ShouldDeleteQuizQuestion()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var applicantQuizResult = applicantQuiz.Result as OkObjectResult;
        var applicantQuizDTO = applicantQuizResult?.Value as ApplicantQuizDto;
        Assert.True(applicantQuizDTO != null && applicantQuizDTO.QuizQuestions != null);

        var quizQuestionDto = applicantQuizDTO.QuizQuestions.Find(quizQuestion => quizQuestion.Question == "Test Question");
        Assert.True(quizQuestionDto != null && quizQuestionDto.Answers != null);

        quizQuestionDto.IsDeleted = true;
        await _applicantQuizzesController.UpdateAsync(applicantQuizDTO);
        var afterUpdateApplicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var afterUpdateApplicantQuizResult = Assert.IsType<OkObjectResult>(afterUpdateApplicantQuiz.Result);
        var afterUpdateApplicantQuizResultValue = Assert.IsAssignableFrom<ApplicantQuizDto>(afterUpdateApplicantQuizResult.Value);
        Assert.True(afterUpdateApplicantQuizResultValue != null && afterUpdateApplicantQuizResultValue.QuizQuestions != null);

        var quizQuestionDtoAfterUpdate = afterUpdateApplicantQuizResultValue.QuizQuestions.Find(quizQuestion => quizQuestion.Question == "Test Question");
        Assert.True(quizQuestionDtoAfterUpdate == null);
    }

    [Fact]
    public async Task ShouldCreateIfQuizNameNotExists()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuizExist = await _applicantQuizzesController.ExistsAsync("Test Quiz Exist");
        var applicantQuizExistResult = Assert.IsType<OkObjectResult>(applicantQuizExist.Result);
        var applicantQuizExistResultValue = Assert.IsType<AtsRecordExistsResponse>(applicantQuizExistResult.Value);
        Assert.True(!applicantQuizExistResultValue.Exists);
    }

    [Fact]
    public async Task ShouldFailToCreateApplicantQuizIfQuizNameExists()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuizName = await _applicantQuizService.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuizName);

        var applicantQuiz = new ApplicantQuizDto
        {
            Name = applicantQuizName.Name,
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
            QuizQuestions =
            [
                new()
                {
                    Question ="Test Question",
                    TypeId = (long)QuestionType.MultipleChoice,
                    Score = 21,
                    IsActive = true,
                    IsRequired = true,
                    Answers =
                    [
                        new()
                        {
                            Answer="test answer 1",
                            IsCorrect=true,
                        },
                        new()
                        {
                            Answer="test answer 2",
                            IsCorrect=false,
                        },
                        new()
                        {
                            Answer="test answer 3",
                            IsCorrect=false,
                        },
                    ]
                }
            ]
        };

        var applicantQuizExist = await _applicantQuizzesController.ExistsAsync(applicantQuiz.Name);
        var applicantQuizExistResult = Assert.IsType<OkObjectResult>(applicantQuizExist.Result);
        var applicantQuizExistResultValue = Assert.IsType<AtsRecordExistsResponse>(applicantQuizExistResult.Value);
        Assert.True(applicantQuizExistResultValue.Exists);
    }

    [Fact]
    public async Task ShouldGetQuizzesForJobPost()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var quizzesForJobPost = await _applicantQuizzesController.GetQuizzesForJobPost();
        Assert.IsType<ActionResult<List<NameIdPairDto>>>(quizzesForJobPost);
        var quizzesForJobPostResult = Assert.IsType<OkObjectResult>(quizzesForJobPost.Result);
        var quizzesForJobPostResultValue = Assert.IsAssignableFrom<List<NameIdPairDto>>(quizzesForJobPostResult.Value);
        Assert.NotEmpty(quizzesForJobPostResultValue);
        Assert.True(quizzesForJobPostResultValue.Count > 0);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInvalidApplicantQuizId()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantQuizzesController.GetByIdAsync(long.MaxValue));
        Assert.Equal(ApplicantQuizValidation.InvalidApplicantQuizId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForUpdateApplicantQuiz()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var okResult = Assert.IsType<OkObjectResult>(applicantQuiz.Result);
        Assert.IsAssignableFrom<ApplicantQuizDto>(okResult.Value);

        var updateApplicantQuiz = new ApplicantQuizDto();

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantQuizzesController.UpdateAsync(updateApplicantQuiz));
        Assert.Equal(InvalidRecordId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForUpdateApplicantQuizForInvalidApplicantQuizId()
    {
        var applicantQuizId = await CreateApplicantQuiz();
        Assert.True(applicantQuizId > 0);

        var applicantQuiz = await _applicantQuizzesController.GetByIdAsync(applicantQuizId);
        Assert.NotNull(applicantQuiz);
        var okResult = Assert.IsType<OkObjectResult>(applicantQuiz.Result);
        var applicantQuizValue = Assert.IsAssignableFrom<ApplicantQuizDto>(okResult.Value);

        var updateApplicantQuiz = new ApplicantQuizDto()
        {
            Id = long.MaxValue,
            Name = "EditQuizName",
            Description = applicantQuizValue.Description,
            IsActive = applicantQuizValue.IsActive,
            MinimumPassingScore = applicantQuizValue.MinimumPassingScore,
            QuizQuestions =
            [
                new()
                {
                    Question = "New Question 1",
                    TypeId = 154,
                    Score=10,
                    IsActive = true,
                    IsRequired= false,
                    Answers=
                    [
                        new()
                        {
                            Answer = "New Answer 1",
                            IsCorrect= true,
                        },
                        new()
                        {
                            Answer = "New Answer 2",
                            IsCorrect= false,
                        },
                        new()
                        {
                            Answer = "New Answer 3",
                            IsCorrect= false,
                        }
                    ]
                }
            ]
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantQuizzesController.UpdateAsync(updateApplicantQuiz));
        Assert.Equal(ApplicantQuizValidation.InvalidApplicantQuizId, exception.Message);
    }

    [Fact]
    public async Task ShouldGetQuizByJobPostLinkIdAsync()
    {
        var quizId = await CreateApplicantQuiz();
        var formId = await CreateApplicationForm();
        var jobPostId = await CreateJobPost(formId, quizId);
        var linkId = await GetJobPostLinkId(jobPostId);

        var result = await _applicantQuizzesController.GetByJobPostLinkIdAsync(linkId);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var quizDtoByLinkId = Assert.IsType<QuizDto>(okResult.Value);
        Assert.NotNull(quizDtoByLinkId);

        var quizDto = await _applicantQuizService.GetByIdAsync(quizId);
        Assert.NotNull(quizDto);
        Assert.Equal(quizDto.Id, quizDtoByLinkId.Id);
        Assert.Equal(quizDto.Name, quizDtoByLinkId.Name);
        Assert.Equal(quizDto.Description, quizDtoByLinkId.Description);
    }

    [Fact]
    public async Task ShouldReturnNoContentWhenJobPostQuizIdIsNul()
    {
        var formId = await CreateApplicationForm();
        var jobPostId = await CreateJobPost(formId, null);
        var linkId = await GetJobPostLinkId(jobPostId);

        var result = await _applicantQuizzesController.GetByJobPostLinkIdAsync(linkId);
        Assert.IsType<NoContentResult>(result.Result);
    }

    [Fact]
    public async Task ShouldGetQuizResultByJobApplicationId()
    {
        var quizId = await CreateApplicantQuiz();
        var formId = await CreateApplicationForm();
        var jobPostId = await CreateJobPost(formId, quizId);
        var linkId = await GetJobPostLinkId(jobPostId);
        var jobApplicationId = await CreateJobApplication(formId, jobPostId, linkId);
        var result = await _applicantQuizzesController.GetQuizResultByJobApplicationIdAsync(jobApplicationId);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var quizResult = Assert.IsType<ApplicantQuizResultResponseDto>(okResult.Value);
        Assert.NotNull(quizResult);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenQuizIsNull()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _applicantQuizService.UpdateApplicantQuizAsync(null));
        Assert.NotNull(exception);
        Assert.Equal(InvalidRecordId, exception.Message);
    }

    [Fact]
    public async Task ShouldReturnNullWhenJobApplicationNotExist()
    {
        var result = await _applicantQuizService.GetQuizResultByJobApplicationIdAsync(0);
        Assert.Null(result);
    }

    [Fact]
    public async Task ShouldReturnEmptyFieldDifference()
    {
        var quizId = await CreateApplicantQuiz();
        var quizDto = await _applicantQuizService.GetByIdAsync(quizId);
        Assert.NotNull(quizDto);
        var result = await _applicantQuizzesController.UpdateAsync(quizDto);
        Assert.NotNull(result);
    }

    #region Private Methods

    private async Task<long> CreateApplicantQuiz()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "quiz" + DateTime.Now.Ticks,
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
            QuizQuestions =
            [
                new()
                {
                    Question ="Test Question",
                    TypeId = (long)QuestionType.MultipleChoice,
                    Score = 21,
                    IsActive = true,
                    IsRequired = false,
                    Answers =
                    [
                        new()
                        {
                            Answer="test answer 1",
                            IsCorrect=true,
                        },
                        new()
                        {
                            Answer="test answer 2",
                            IsCorrect=false,
                        },
                        new()
                        {
                            Answer="test answer 3",
                            IsCorrect=false,
                        },
                    ]
                }
            ]
        };

        var applicantQuizId = await _applicantQuizzesController.Create(applicantQuiz);
        var okResult = Assert.IsType<OkObjectResult>(applicantQuizId.Result);
        var response = Assert.IsType<CreatedResponse>(okResult.Value);
        Assert.True(response.Id > 0);
        return response.Id;
    }

    private async Task<long> CreateApplicationForm()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                        new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        }
                ]
        };

        var formId = await _applicationFormService.AddAsync(formDTO);
        Assert.NotNull(formId);
        Assert.True(formId > 0);

        return formId.Value;
    }

    private async Task<long> CreateJobPost(long formId, long? quizId)
    {
        var jobPostDto = new JobPostDto { Title = "jobPost1" + DateTime.Now.Ticks, IsSubmitted = true, IsActive = true, ApplicationFormId = formId, HiringManagerId = _currentUserContext.UserId, ApplicantQuizId = quizId, StartDateTime = DateTime.Now };
        //Act
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.NotNull(jobPostId);
        Assert.True(jobPostId > 0);

        return jobPostId.Value;
    }

    private async Task<Guid> GetJobPostLinkId(long jobPostId)
    {
        var jobPostDto = await _jobPostService.GetByIdAsync(jobPostId);
        Assert.NotNull(jobPostDto);
        Assert.NotNull(jobPostDto.LinkId);
        return jobPostDto.LinkId.Value;
    }

    private async Task<long> CreateJobApplication(long formId, long jobPostId, Guid quidLinkId)
    {
        var formDto = await _applicationFormService.GetByIdAsync(formId);
        Assert.NotNull(formDto);

        var quizDto = await _applicantQuizService.GetDetailsByJobPostLinkIdAsync(quidLinkId);
        Assert.NotNull(quizDto);

        var fieldValues = new List<JobApplicationFieldValueDto> {
               new()
                 {
                     FormFieldId = formDto.Fields?.Where(a =>a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test First Name",
                 },
               new()
                 {
                     FormFieldId = formDto.Fields?.Where(a =>a.DefaultFieldId == (int) ApplicationFormDefaultFields.MiddleName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test Middle Name",
                 },
               new()
                 {
                     FormFieldId = formDto.Fields?.Where(a =>a.DefaultFieldId == (int) ApplicationFormDefaultFields.LastName ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test Last Name",
                 },
                 new()
                 {
                     FormFieldId = formDto.Fields?.Where(a =>a.DefaultFieldId == (int) ApplicationFormDefaultFields.PersonalEmailAddress ).Select(a =>a.Id).FirstOrDefault(),
                     FormFieldValue = "test1@tsdt.com",
                 }
             };

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = jobPostId,
            FieldValues = fieldValues,
            ApplicantQuizResult = new ApplicantQuizResultDto()
            {
                QuizId = quizDto.Id,
                QuizAnswers = [
                    new(){
                         QuestionId =quizDto.QuizQuestions![0].Id,
                         AnswerId =quizDto.QuizQuestions![0].Answers![0].Id,
                     },
                ]
            }
        };
        var jobApplicationId = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.True(jobApplicationId > 0);
        return jobApplicationId.Value;

    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}