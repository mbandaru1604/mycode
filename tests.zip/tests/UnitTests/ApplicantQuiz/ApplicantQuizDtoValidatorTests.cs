﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;

namespace BBSI.ATS.UnitTests;

public class ApplicantQuizDtoValidatorTests
{
    private readonly ApplicantQuizDtoValidator _validator;

    public ApplicantQuizDtoValidatorTests()
    {
        _validator = new ApplicantQuizDtoValidator();
    }

    [Fact]
    public void ShouldFailSavingApplicantQuizWhenNoQuestionIsAdded()
    {
        var applicantQuiz = new ApplicantQuizDto()
        {
            Name = "New Quiz-1",
            MinimumPassingScore = 10,
            Description = "description",
            IsActive = true,
            QuizQuestions = new List<QuizQuestionDto>(),
        };

        var result = _validator.TestValidate(applicantQuiz);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.QuizQuestions);
    }

    [Fact]
    public void ShouldFailWhenMoreThanMaxQuizQuestionsProvided()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "New Quiz",
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
            QuizQuestions = Enumerable.Range(1, 16) 
                .Select(i => new QuizQuestionDto
                {
                    Question = $"Test Question {i}",
                    TypeId = (int)QuestionType.MultipleChoice,
                    Score = 10,
                    IsActive = true,
                    IsRequired = true,
                    Answers = new List<QuizQuestionAnswerDto>
                    {
                        new QuizQuestionAnswerDto { Answer = "Answer 1", IsCorrect = true },
                        new QuizQuestionAnswerDto { Answer = "Answer 2", IsCorrect = false }
                    }
                }).ToList()
        };

        var result = _validator.TestValidate(applicantQuiz);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.QuizQuestions);
    }

    [Fact]
    public void ShouldPassWhenRequriedFieldsEntered()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "New Quiz",
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
            QuizQuestions =
            [
                new()
                {
                    Question ="Test Question",
                    TypeId = (long)QuestionType.MultipleChoice,
                    Score = 21,
                    IsActive = true,
                    IsRequired = true,
                    Answers =
                    [
                        new()
                        {
                            Answer="test answer 1",
                            IsCorrect=true,
                        },
                        new()
                        {
                            Answer="test answer 2",
                            IsCorrect=false,
                        },
                        new()
                        {
                            Answer="test answer 3",
                            IsCorrect=false,
                        },
                    ]
                }
            ]
        };

        var result = _validator.TestValidate( applicantQuiz );
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldNotHaveValidationErrorFor(applicantQuiz=>applicantQuiz.Name);
        result.ShouldNotHaveValidationErrorFor(applicantQuiz => applicantQuiz.MinimumPassingScore);
        result.ShouldNotHaveValidationErrorFor(applicantQuiz => applicantQuiz.Description);
        result.ShouldNotHaveValidationErrorFor(applicantQuiz => applicantQuiz.QuizQuestions);
    }

    [Fact]
    public void ShouldFailWhenQuizNameIsEmpty()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "",
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
        };

        var result = _validator.TestValidate(applicantQuiz);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.Name);
    }

    [Fact]
    public void ShouldFailWhenQuizNameMaxLength()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = TextAreaContent.Stringwith500Chracters,
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = true,
        };

        var result = _validator.TestValidate(applicantQuiz);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.Name);
    }

    [Fact]
    public void ShouldFailWhenMinimumScoreIsEmpty()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "Test Quiz",
            MinimumPassingScore = null,
            Description = "Description",
            IsActive = true,
        };

        var result = _validator.TestValidate(applicantQuiz);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.MinimumPassingScore);
    }

    [Fact]
    public void ShouldFailWhenDescriptionMaxLenght()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "Test Quiz",
            MinimumPassingScore = null,
            Description = TextAreaContent.Stringwith500Chracters,
            IsActive = true,
        };

        var result = _validator.TestValidate(applicantQuiz);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.Description);
    }

    [Fact]
    public void ShouldFailWhenQuestionScoreDoesNotMeetMinimumScore()
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = "New Quiz",
            MinimumPassingScore = 210,
            Description = "Description",
            IsActive = true,
            QuizQuestions =
            [
                new()
                {
                    Question ="Test Question",
                    TypeId = (long)QuestionType.MultipleChoice,
                    Score = 21,
                    IsActive = true,
                    IsRequired = true,
                    Answers =
                    [
                        new()
                        {
                            Answer="test answer 1",
                            IsCorrect=true,
                        },
                        new()
                        {
                            Answer="test answer 2",
                            IsCorrect=false,
                        }
                    ]
                }
            ]
        };

        var result = _validator.TestValidate(applicantQuiz);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<ApplicantQuizDto>>(result);
        result.ShouldNotHaveValidationErrorFor(applicantQuiz => applicantQuiz.Name);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.MinimumPassingScore);
        result.ShouldNotHaveValidationErrorFor(applicantQuiz => applicantQuiz.Description);
        result.ShouldHaveValidationErrorFor(applicantQuiz => applicantQuiz.QuizQuestions);
    }
}
