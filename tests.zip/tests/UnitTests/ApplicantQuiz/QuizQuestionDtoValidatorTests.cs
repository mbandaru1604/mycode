﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;

namespace BBSI.ATS.UnitTests;

public class QuizQuestionDtoValidatorTests
{
    private readonly QuizQuestionDtoValidator _validator;
    
    public QuizQuestionDtoValidatorTests()
    {
        _validator = new QuizQuestionDtoValidator();
    }

    [Fact]
    public void ShouldPassWhenRequriedFieldsEntered()
    {
        var quizQuestion = new QuizQuestionDto()
        {
            Question = "test question 1",
            TypeId = (long)QuestionType.MultipleChoice,
            Score = 21,
            Answers =
            [
                new ()
                {
                    Answer="test answer 1",
                    IsCorrect=true,
                },
                new ()
                {
                    Answer="test answer 2",
                    IsCorrect=false,
                }
            ]
        };

        var result = _validator.TestValidate(quizQuestion);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionDto>>(result);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.TypeId);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Question);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Score);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Answers);
    }

    [Fact]
    public void ShouldFailWhenQuestionIsNullOrEmpty()
    {
        var quizQuestion = new QuizQuestionDto()
        {
            Question = "",
            TypeId = (long)QuestionType.MultipleChoice,
            Score = 21,
            
        };

        var result = _validator.TestValidate(quizQuestion);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionDto>>(result);
        result.ShouldHaveValidationErrorFor(quizQuestion => quizQuestion.Question);
    }

    [Fact]
    public void ShouldFailWhenQuestionMaxLength()
    {
        var quizQuestion = new QuizQuestionDto()
        {
            Question = TextAreaContent.Stringwith500Chracters,
            TypeId = (long)QuestionType.MultipleChoice,
            Score = 21,

        };

        var result = _validator.TestValidate(quizQuestion);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionDto>>(result);
        result.ShouldHaveValidationErrorFor(quizQuestion => quizQuestion.Question);
    }

    [Fact]
    public void ShouldFailWhenTypeIdIsNull()
    {
        var quizQuestion = new QuizQuestionDto()
        {
            Question = "Test Question",
            TypeId= 0,
            Score = 21,
        };

        var result = _validator.TestValidate(quizQuestion);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionDto>>(result);
        result.ShouldHaveValidationErrorFor(quizQuestion => quizQuestion.TypeId);
    }

    [Fact]
    public void ShouldFailWhenAnswersAreLessThanTwoInMultipleChoice()
    {
        var quizQuestion = new QuizQuestionDto()
        {
            Question = "test question 1",
            TypeId = (long)QuestionType.MultipleChoice,
            Score = 21,
            Answers =
            [
                new ()
                {
                    Answer="test answer 1",
                    IsCorrect=true,
                }
            ]
        };

        var result = _validator.TestValidate(quizQuestion);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionDto>>(result);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.TypeId);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Question);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Score);
        result.ShouldHaveValidationErrorFor(quizQuestion => quizQuestion.Answers);
    }

    [Fact]
    public void ShouldFailWhenAnswersAreMoreThanInInMultipleChoice()
    {
        var quizQuestion = new QuizQuestionDto()
        {
            Question = "test question 1",
            TypeId = (long)QuestionType.MultipleChoice,
            Score = 21,
            Answers =
            [
                new ()
                {
                    Answer="test answer 1",
                    IsCorrect=true,
                },
                new ()
                {
                    Answer="test answer 2",
                    IsCorrect=true,
                },
                new ()
                {
                    Answer="test answer 3",
                    IsCorrect=true,
                },
                new ()
                {
                    Answer="test answer 4",
                    IsCorrect=true,
                },
                new ()
                {
                    Answer="test answer 5",
                    IsCorrect=true,
                },
                new ()
                {
                    Answer="test answer 6",
                    IsCorrect=true,
                }
            ]
        };

        var result = _validator.TestValidate(quizQuestion);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionDto>>(result);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.TypeId);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Question);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Score);
        result.ShouldHaveValidationErrorFor(quizQuestion => quizQuestion.Answers);
    }

    [Fact]
    public void ShouldFailWhenAtleastOneAnswersIsNotTrue()
    {
        var quizQuestion = new QuizQuestionDto()
        {
            Question = "test question 1",
            TypeId = (long)QuestionType.MultipleChoice,
            Score = 21,
            Answers =
            [
                new ()
                {
                    Answer="test answer 1",
                    IsCorrect=false,
                },
                new ()
                {
                    Answer="test answer 2",
                    IsCorrect=false,
                }
            ]
        };

        var result = _validator.TestValidate(quizQuestion);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionDto>>(result);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.TypeId);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Question);
        result.ShouldNotHaveValidationErrorFor(quizQuestion => quizQuestion.Score);
        result.ShouldHaveValidationErrorFor(quizQuestion => quizQuestion.Answers);
    }
}
