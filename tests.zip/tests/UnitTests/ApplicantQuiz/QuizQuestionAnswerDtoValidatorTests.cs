﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Domain.Entities;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;

namespace BBSI.ATS.UnitTests;

public class QuizQuestionAnswerDtoValidatorTests
{
    private readonly QuizQuestionAnswerDtoValidator _validator;

    public QuizQuestionAnswerDtoValidatorTests()
    {
        _validator = new QuizQuestionAnswerDtoValidator();
    }

    [Fact]
    public void ShouldPassWhenRequiedFieldsEntered()
    {
        var quizQuestionAnswer = new QuizQuestionAnswerDto()
        {
            Answer = "This is Answer",
            IsCorrect = true
        };

        var result = _validator.TestValidate(quizQuestionAnswer);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionAnswerDto>>(result);
        result.ShouldNotHaveValidationErrorFor(quizQuestionAnswer => quizQuestionAnswer.Answer);
    }

    [Fact]
    public void ShouldFailWhenAnswerIsNullOrEmpty()
    {
        var quizQuestionAnswer = new QuizQuestionAnswerDto()
        {
            Answer = "",
            IsCorrect = true
        };

        var result = _validator.TestValidate(quizQuestionAnswer);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<QuizQuestionAnswerDto>>(result);
        result.ShouldHaveValidationErrorFor(quizQuestionAnswer => quizQuestionAnswer.Answer);
    }
}
