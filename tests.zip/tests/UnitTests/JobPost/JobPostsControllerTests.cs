﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using static BBSI.ATS.Common.Constants;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class JobPostsControllerTests : IDisposable
{
    private readonly JobPostsController _jobPostsController;
    private readonly ApplicationFormsController _formController;
    private readonly AtsDbContext _dbContext;
    private readonly JobPostService _jobPostService;
    private readonly CompanyController _companyController;
    private readonly CompanyService _companyService;
    private readonly JobPostCategoriesController _jobPostCategoriesController;
    private readonly JobPostCategoryService _jobPostCategoryService;
    private readonly MetaDataController _metadataController;
    private readonly CurrentUserContext _currentUserContext;
    private readonly UsersController _userController;
    private readonly ApplicantQuizService _applicantQuizService;
    private readonly CompanyJobBoardService _companyJobBoardService;
    private bool disposed = false;

    public JobPostsControllerTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        var repository = new JobPostRepository(_dbContext, _currentUserContext);
        var applicationFormRepository = new ApplicationFormRepository(_dbContext, _currentUserContext);
        var userRepository = new UserRepository(_dbContext, _currentUserContext);
        var applicantQuizRepository = new ApplicantQuizRepository(_dbContext, _currentUserContext);

        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        IMapper mapper = mappingConfig.CreateMapper();

        var companyRepository = new CompanyRepository(_dbContext, _currentUserContext);

        var mockCosmosDbService = new Mock<ICosmosDbService>();

        var formFieldComparer = new ApplicationFormFieldComparer();
        var applicationFormComparer = new ApplicationFormComparer(formFieldComparer);
        var applicationFormService = new ApplicationFormService(applicationFormRepository, mapper, _currentUserContext, mockCosmosDbService.Object, applicationFormComparer);
        _formController = new ApplicationFormsController(applicationFormService);

        var mockLoggerCompanyService = new Mock<ILogger<CompanyService>>();
        var unitOfWork = new UnitOfWork(_dbContext);
        _companyService = new CompanyService(companyRepository, null!, unitOfWork, mapper, mockLoggerCompanyService.Object);
        _companyController = new CompanyController(_companyService, _currentUserContext);

        var genericRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var appConfig = new AppConfig();
        _jobPostService = new JobPostService(repository, mapper, applicationFormService, _currentUserContext, mockCosmosDbService.Object, applicantQuizRepository, _companyService, appConfig);
        _jobPostsController = new JobPostsController(_jobPostService);

        var jobPostCategoryRepository = new JobPostCategoryRepository(_dbContext, _currentUserContext);
        _jobPostCategoryService = new JobPostCategoryService(jobPostCategoryRepository, mapper, _currentUserContext, mockCosmosDbService.Object);
        _jobPostCategoriesController = new JobPostCategoriesController(_jobPostCategoryService);

        var metadataRepository = new MetaDataRepository(_dbContext, _currentUserContext);

        var metaDataService = new MetaDataService(metadataRepository, mapper);
        _metadataController = new MetaDataController(metaDataService);

        var userService = new UserService(genericRepository, unitOfWork, userRepository, _currentUserContext);
        _userController = new UsersController(userService);
        var comparer = new ApplicantQuizComparer();
        _applicantQuizService = new ApplicantQuizService(genericRepository, mapper, applicantQuizRepository, _currentUserContext, repository, comparer, mockCosmosDbService.Object);
        var atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        _companyJobBoardService = new CompanyJobBoardService(atsBaseRepository, mapper, _currentUserContext);
        var mockJobBoardConfig = new Mock<IOptions<JobBoardConfig>>();
        var jobBoardConfig = new JobBoardConfig
        {
            AppUrl = "https://dummyapp.com/",
            JobPostUrl = "job/{0}"
        };

        mockJobBoardConfig.Setup(m => m.Value).Returns(jobBoardConfig);
    }

    [Fact]
    public async Task ShouldGetActiveJobPostsByCompanyIdentifier()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);
        var companyIdentifier = await _dbContext.Companies.Where(c => c.Id == _currentUserContext.CompanyId).Select(c => c.Identifier).FirstAsync();
        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            IsSubmitted = true,
            IsActive = true,
            City = "city",
            Country = "Country",
            StateId = 60,
            EEOClassId = 6,
            EmployeeTypeId = 1,
            PayGroupId = 18,
            PayMethodId = 24,
            HiringManagerId = _currentUserContext.UserId,
            LocationTypeId = 31,
            Salary = 10000.00M,
            MinSalary = 40000.00M,
            MaxSalary = 15000.00M,
            StartDateTime = DateTime.UtcNow
        };
        await _jobPostService.AddAsync(jobPostDto);

        await CreateCompanyJobBoard();
        var xmlData = await _jobPostsController.GetByCompanyIdentifierForIndeedAsync(companyIdentifier.Value);
        Assert.NotNull(xmlData);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenCompanyIdentifierIsInvalid()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _jobPostsController.GetByCompanyIdentifierForIndeedAsync(Guid.NewGuid()));
        Assert.Equal(string.Format(CompanyJobBoardValidation.CompanyNotIntegratedWithJobBoard, CompanyJobBoards.Indeed), exception.Message);
    }

    [Fact]
    public async Task ShouldDeleteJobPostWithId()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = formId,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            IsSubmitted = true,
        };

        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);

        var deleteResult = await _jobPostsController.Delete(jobPostId);
        Assert.IsType<OkResult>(deleteResult);

        var retrievedJobPostResult = await _jobPostsController.GetById(jobPostId);
        Assert.IsType<BadRequestObjectResult>(retrievedJobPostResult.Result);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenDeletingWithInvalidId()
    {
        //Arrange
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = formId,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            IsSubmitted = true,
        };

        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);

        var invalidJobPostDto = new JobPostDto
        {
            Id = 0,
            CCEmailAddresses = "cc@gmail.com"
        };

        // Act 
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Delete(invalidJobPostDto.Id));

        //Assert
        Assert.Equal("Invalid Id", exception.Message);
    }

    [Fact]
    public async Task ShouldThrowValidationWhileGettingJobPostWithInvalidId()
    {
        //Arrange
        const long invalidJobId = 911019;

        //Act
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Delete(invalidJobId));

        //Assert
        Assert.Equal("Invalid Id", exception.Message);
    }

    [Fact]
    public async Task ShouldCreateJobPostWithGivenTitleAndDescription()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "JobPostTitle-" + DateTime.Now.Ticks, Description = "JobPost Description" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdFormDTO = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(createdFormDTO.Id > 0);
    }

    [Fact]
    public async Task ShouldCreateJobPostWithGivenPayGroupandPayMethod()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, PayGroupId = (long)PayGroup.Annually, PayMethodId = (long)PayMethod.Salary };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdFormDTO = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);

        Assert.True(createdFormDTO.Id > 0);
        Assert.Equal((long)PayMethod.Salary, jobPostDto.PayMethodId);
        Assert.Equal((long)PayGroup.Annually, jobPostDto.PayGroupId);
    }

    [Fact]
    public async Task ShouldReturnOkWhenJobPostExistsForCompanyId()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var companyCode = 111815;
        var companyId = await CreateCompany(companyCode);
        Assert.True(companyId > 0);
        _currentUserContext.CompanyId = companyId;

        var jobPostTitle = $"Title-{DateTime.Now.Ticks}";
        var jobPostDto = new JobPostDto { Title = jobPostTitle, Description = "Description", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), IsActive = true, IsSubmitted = true, WorkArrangementId = 27, WorksiteLocationId = null, LocationTypeId = null, CCEmailAddresses = "user1@company1.com", SalaryComments = "SalaryComment", Salary = 10000.00m, StartDateTime = DateTime.UtcNow };
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.True(jobPostId > 0);

        var company = _companyService.GetByCodeAsync(companyCode);
        var identifier = company.Result.Identifier;

        var result = await _jobPostsController.GetByCompanyIdentifierAsync(identifier!.Value);
        Assert.NotNull(result.Result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var jobPostsByCompany = Assert.IsType<List<CompanyJobPostsDto>>(okResult.Value);
        Assert.NotNull(jobPostsByCompany);

        var insertedJobPost = jobPostsByCompany.Find(jp => jp.Id == jobPostId);
        Assert.NotNull(insertedJobPost);
        Assert.NotNull(insertedJobPost.Title);
        Assert.Equal(insertedJobPost.Title, jobPostDto.Title);
        Assert.Equal(insertedJobPost.Description, jobPostDto.Description);
    }

    [Fact]
    public async Task ShouldReturnOkForUpdateStatusToActive()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            IsSubmitted = true,
            IsActive = false
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);
        await _jobPostService.UpdateStatusAsync();
        var jobPostFromDB = await _jobPostService.GetByIdAsync(jobPostId);
        Assert.NotNull(jobPostFromDB);
    }

    [Fact]
    public async Task ShouldThrowValidationExceptionWhenCCEmailAddressIsInvalid()
    {
        // Arrange
        var jobPostDto = new JobPostDto
        {
            Title = "Test Job",
            IsSubmitted = true,
            CCEmailAddresses = "valid1@example.com,invalid2example.com,valid3@example.com"
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Create(jobPostDto));
        Assert.NotNull(exception);
        Assert.Equal(string.Format(JobPostValidation.EmailInvalid, "invalid2example.com"), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenStartDateIsInvalid()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "JobPostTitle-" + DateTime.Now.Ticks, Description = "JobPost Description", StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-2)), IsSubmitted = true, StartDateTime = DateTime.UtcNow.AddDays(-2) };

        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Create(jobPostDto));

        Assert.Equal(string.Format(JobPostValidation.StartDateFutureDate), exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenCreatingJobPostWithInactiveWorksiteLocation()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now.AddDays(1)),
            IsSubmitted = true,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            WorksiteLocationId = 12,
            StartDateTime = DateTime.UtcNow
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Create(jobPostDto));

        Assert.Equal(JobPostValidation.JobPostWorksiteLocationInactive, exception.Message);
    }

    [Fact]
    public async Task ShouldCreateJobPostWithDefaultEndDate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            IsSubmitted = true,
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);
        var jobPostFromDB = await _jobPostService.GetByIdAsync(jobPostId);
        Assert.NotNull(jobPostFromDB);
        Assert.Equal(jobPostDto.StartDate.Value.AddDays(30), jobPostFromDB.EndDate);
        Assert.True(jobPostFromDB.IsActive);
    }

    [Fact]
    public async Task ShouldCreateInactiveJobPostWithDefaultEndDateAndCustomStartDate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now.AddDays(2)),
            IsSubmitted = true,
            StartDateTime = DateTime.Now.AddDays(2)
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);
        var jobPostFromDB = await _jobPostService.GetByIdAsync(jobPostId);
        Assert.NotNull(jobPostFromDB);
        Assert.Equal(jobPostDto.StartDate.Value.AddDays(30), jobPostFromDB.EndDate);
        Assert.False(jobPostFromDB.IsActive);
    }

    [Fact]
    public async Task ShouldUpdateJobPostAndApplyDefaultStartDateAndEndDate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            EndDate = DateOnly.FromDateTime(DateTime.Now.AddDays(2)),
            IsSubmitted = true,
            StartDateTime = DateTime.UtcNow
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);
        var jobPostDtoToUpdate = new JobPostDto
        {
            Id = jobPostId,
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            IsSubmitted = true,
            StartDateTime = DateTime.UtcNow
        };
        await _jobPostsController.Update(jobPostDtoToUpdate);
        var jobPostFromDB = await _jobPostService.GetByIdAsync(jobPostId);
        Assert.NotNull(jobPostFromDB);
        Assert.Equal(jobPostDto.StartDate, jobPostFromDB.StartDate);
        Assert.Equal(jobPostDto.StartDate.Value.AddDays(30), jobPostFromDB.EndDate);
        Assert.True(jobPostFromDB.IsActive);
    }

    [Fact]
    public async Task ShouldGetActiveJobPosts()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            IsSubmitted = true,
            StartDateTime = DateTime.UtcNow
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);
        var result = await _jobPostsController.GetActiveJobPosts();
        var OkResult = Assert.IsType<OkObjectResult>(result.Result);
        var activeJobPosts = Assert.IsType<List<NameIdPairDto>>(OkResult.Value);
        Assert.NotEmpty(activeJobPosts);
        var matchingJobPost = activeJobPosts.Find(jp => jp.Name == jobPostDto.Title && jp.Id == jobPostId);
        Assert.NotNull(matchingJobPost);
    }

    [Fact]
    public async Task ShouldRetrieveLocationFromSubmittedJobPost()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now),
            IsSubmitted = true,
            LocationTypeId = (long)LocationType.CustomLocation,
            Location = "Custom Location",
            StartDateTime = DateTime.UtcNow
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);
        var result = await _jobPostsController.GetLocationsForAllSubmittedJobsAsync();
        var OkResult = Assert.IsType<OkObjectResult>(result.Result);
        var activeJobPostsLocations = Assert.IsType<List<string>>(OkResult.Value);
        Assert.NotEmpty(activeJobPostsLocations);
        Assert.Contains("Custom Location", activeJobPostsLocations);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInvalidMinSalaryFormatOnHourlyPayMethodDuringUpdate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        var jobPostId = await CreateJobPostDto(new JobPostDto() { ApplicationFormId = formId, Title = "Title" + DateTime.Now, StartDateTime = DateTime.UtcNow });
        Assert.True(formId > 0);
        var jobPostDto = new JobPostDto { Id = jobPostId, Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = 3454.4545m, MaxSalary = 53234.54m, Salary = null, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var validationException = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Update(jobPostDto));
        Assert.Equal(JobPostValidation.JobPostInvalidMinSalaryFormat, validationException.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInvalidMaxSalaryFormatOnHourlyPayMethodDuringUpdate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        var jobPostId = await CreateJobPostDto(new JobPostDto() { ApplicationFormId = formId, Title = "Title" + DateTime.Now, StartDateTime = DateTime.UtcNow });
        Assert.True(jobPostId > 0);
        var jobPostDto = new JobPostDto { Id = jobPostId, Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = 3454.45m, MaxSalary = 53234.544m, Salary = null, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var validationException = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Update(jobPostDto));
        Assert.Equal(JobPostValidation.JobPostInvalidMaxSalaryFormat, validationException.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInvalidSingleSalaryFormatOnHourlyPayMethodDuringUpdate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        var jobPostId = await CreateJobPostDto(new JobPostDto() { ApplicationFormId = formId, Title = "Title" + DateTime.Now });
        Assert.True(jobPostId > 0);
        var jobPostDto = new JobPostDto { Id = jobPostId, Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = null, MaxSalary = null, Salary = 53234.5244m, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var validationException = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Update(jobPostDto));
        Assert.Equal(JobPostValidation.JobPostInvalidSalaryFormat, validationException.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInactiveWorksiteLocationDuringUpdate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Now.AddDays(1)),
            IsSubmitted = true,
        };

        var jobPostId = await CreateJobPostDto(jobPostDto);

        Assert.True(jobPostId > 0);

        var jobPostDto2 = new JobPostDto
        {
            Id = jobPostId,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            WorksiteLocationId = 12
        };

        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Update(jobPostDto2));

        Assert.Equal(JobPostValidation.JobPostWorksiteLocationInactive, exception.Message);
    }

    [Fact]
    public async Task ShouldSetIsActiveToTrueWhenStartDateIsTodayOrEarlierAndEndDateIsNullOnUpdate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto
        {
            ApplicationFormId = id,
            Title = "JobPostTitle-" + DateTime.Now.Ticks,
            Description = "JobPost Description",
            StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)),
            IsSubmitted = true,
            StartDateTime = DateTime.UtcNow.AddDays(1),
        };

        var jobPostId = await CreateJobPostDto(jobPostDto);

        Assert.True(jobPostId > 0);

        var jobPostDto2 = new JobPostDto
        {
            Id = jobPostId,
            StartDate = DateOnly.FromDateTime(DateTime.Today),
            EndDate = null,
            IsSubmitted = true,
            StartDateTime = DateTime.UtcNow
        };

        await _jobPostsController.Update(jobPostDto2);

        Assert.True(jobPostDto2.IsActive);
    }

    [Fact]
    public async Task ShouldInactivateJobPostsWhenEndDateIsPastOnUpdateStatus()
    {
        DateOnly activateStartDate = DateOnly.FromDateTime(DateTime.Now);
        DateOnly activateEndDate = DateOnly.FromDateTime(DateTime.Now.AddDays(-1));
        DateTimeOffset startDateTime = DateTime.UtcNow;
        DateTimeOffset endDateTime = DateTime.Now.AddDays(-1);
        bool isActive = true;
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayMethodId = 26, PayGroupId = 17, IsSubmitted = true, StartDate = activateStartDate, EndDate = activateEndDate, IsActive = isActive, StartDateTime = startDateTime, EndDateTime = endDateTime };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
        var activateJobPostId = jobPost.Id;

        await _jobPostService.UpdateStatusAsync();

        var getJobPost = await _jobPostsController.GetById(activateJobPostId);
        Assert.NotNull(getJobPost.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDtoDB.EndDate, jobPostDto.EndDate);
        //Assert.False(jobPostDtoDB.IsActive); //commenting it because EF core ExecuteUpdate method is not supported by in-memory db provider
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenApplicationFormDoesNotExistWhileGettingByLinkId()
    {
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now, IsActive = true, IsSubmitted = true, ApplicationFormId = 1000, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var id = await _jobPostService.AddAsync(jobPostDto);
        Assert.NotNull(id);
        var jobPostResult = await _jobPostService.GetByIdAsync(id.Value);
        Assert.NotNull(jobPostResult);
        Assert.NotNull(jobPostResult.LinkId);
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.GetByLinkIdAsync(jobPostResult.LinkId.Value));
        Assert.Equal(InActiveApplicationForm, exception.Message);
    }

    [Fact]
    public async Task ShouldAllowAlreadyExistsJobPostTitle()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title001", Description = "Descrption For the Given Job Post" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);

        var toCreateSameJobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title001", Description = "Descrption For the Given Job Post" };
        var duplicateJobPost = await _jobPostsController.Create(toCreateSameJobPostDto);
        var duplicateJobPostResult = Assert.IsType<OkObjectResult>(duplicateJobPost.Result);
        var duplicateResponse = Assert.IsType<CreatedResponse>(duplicateJobPostResult.Value);
        Assert.True(duplicateResponse.Id > 0);
    }

    [Fact]
    public async Task ShouldGetJobPostById()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title20", IsActive = true, Description = "Descrption For the Given Job Post" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getJobPostCategoryName = await _jobPostsController.GetById(createdResponse.Id);
        Assert.NotNull(getJobPostCategoryName.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(getJobPostCategoryName.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.True(jobPostDtoDB.Title == jobPostDto.Title);
    }

    [Fact]
    public async Task ShouldFailGetJobPostWithInvalidJobPostId()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title" + DateTime.Now.Ticks, IsActive = true, Description = "Descrption For the Given Job Post" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);
        var form = await _jobPostsController.GetById(2000);
        var formResult = Assert.IsType<BadRequestObjectResult>(form.Result);
        Assert.True(formResult.GetType().Name == "BadRequestObjectResult");
    }

    [Fact]
    public async Task ShouldCreateJobPostWithValidCCEmailAddresses()
    {
        var jobPostDto = new JobPostDto { Title = "JP" + DateTime.Now.Ticks, CCEmailAddresses = "user1@company1.com, user2@company2.com" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldValidRequestReturnsJobPostsList()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var hiringManagers = await GetHiringManagersAsync();
        Assert.NotNull(hiringManagers);

        var jobPosts = new List<JobPostDto>
            {
                new JobPostDto { ApplicationFormId = id, Title = "Title2000", IsActive = true, Description = "Descrption For the Given Job Post", HiringManagerId = hiringManagers?.FirstOrDefault()?.Id,IsSubmitted =true, StartDate =  DateOnly.FromDateTime(DateTime.Now) ,  StartDateTime = DateTime.UtcNow },
                new JobPostDto { ApplicationFormId = id, Title = "Title2001", IsActive = true, Description = "Sample Descrption  ",IsSubmitted =false, StartDate =  DateOnly.FromDateTime(DateTime.Now)  }
            };

        for (int i = 0; i < jobPosts.Count; i++)
        {
            var jobPost = jobPosts[i];
            var jobPostResult = await _jobPostsController.Create(jobPost);

            var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
            var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
            Assert.True(createdResponse.Id > 0);

            var result = await _jobPostsController.GetList(i == 0);
            Assert.IsType<ActionResult<IEnumerable<JobPostListDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var model = Assert.IsAssignableFrom<IEnumerable<JobPostListDto>>(okResult.Value);
            Assert.NotEmpty(model);

            Assert.Contains(model, jobPost => jobPost.Title == "Title200" + i.ToString());
            Assert.Contains(model, jobPost => jobPost.IsActive);
            Assert.Contains(model, jobPost => jobPost.IsSubmitted == (i == 0));
            Assert.Contains(model, jobPost => jobPost.HiringManager == model.First().HiringManager);
            Assert.Contains(model, jobPost => jobPost.WorksiteLocation == string.Empty);
        }
    }

    [Fact]
    public async Task ShouldSaveJobPostWithEmptyPayGroupId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayGroupId = null };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithEmptyPayMethodId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayGroupId = 17, PayMethodId = null };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithPayGroupIdAndPayMethodId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayGroupId = 17, PayMethodId = 26 };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithEmptyPayGroupIdAndEmptyPayMethodId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayGroupId = null, PayMethodId = null, StartDate = DateOnly.FromDateTime(DateTime.Now) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSubmitJobPostWithPayMethodIdAndPayGroupId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayMethodId = 26, PayGroupId = 17, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldUpdateJobPost()
    {
        var jobPostDto = await AssertCreateJobPostForSubmit();
        var title = jobPostDto.Title;
        Assert.True(jobPostDto.Id > 0);

        var jobPostFromDBResult = await _jobPostsController.GetById(jobPostDto.Id);
        var jobPostFromDBOkResult = Assert.IsType<OkObjectResult>(jobPostFromDBResult.Result);
        var jobPostFromDB = Assert.IsType<JobPostDto>(jobPostFromDBOkResult.Value);
        Assert.NotNull(jobPostFromDB);
        Assert.False(string.IsNullOrWhiteSpace(jobPostFromDB.Title));
        Assert.True(jobPostFromDB.Title == jobPostDto.Title);

        var updateTitle = "JobpostTitleUpdate_" + DateTime.Now.Ticks;
        jobPostFromDB.Title = updateTitle;
        jobPostFromDB.Id = jobPostDto.Id;
        await _jobPostsController.Update(jobPostFromDB);

        var afterUpdateJobPostFromDBResult = await _jobPostsController.GetById(jobPostDto.Id);
        var afterUpdateJobPostOkResult = Assert.IsType<OkObjectResult>(afterUpdateJobPostFromDBResult.Result);
        var afterUpdateJobPostFromDB = Assert.IsType<JobPostDto>(afterUpdateJobPostOkResult.Value);
        Assert.NotNull(afterUpdateJobPostFromDB);
        Assert.False(string.IsNullOrWhiteSpace(afterUpdateJobPostFromDB.Title));
        Assert.True(afterUpdateJobPostFromDB.Title != title);
        Assert.True(afterUpdateJobPostFromDB.Title == updateTitle);
    }

    [Fact]
    public async Task ShouldFailToUpdateJobPostWhenRecordIdIsZeroAndInvalid()
    {
        var jobPostDto = await AssertCreateJobPostForSubmit();
        Assert.True(jobPostDto.Id > 0);

        //Update JobPost when recordId Is Zero
        jobPostDto.Id = 0;
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Update(jobPostDto));
        Assert.Equal(ErrorMessages.InvalidRecordId, exception.Message);

        //Update JobPost when Invalid recordId
        jobPostDto.Id = long.MaxValue;
        var invalidException = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Update(jobPostDto));
        Assert.Equal(ErrorMessages.InvalidRecordId, invalidException.Message);
    }

    [Fact]
    public async Task ShouldGetJobPostPreviewById()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title21", IsActive = true, Description = "Descrption For the Given Job Post", CategoryId = 1, EEOClassId = 6, EmployeeTypeId = 1, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);
        var jobPostPreview = await _jobPostsController.GetJobPostPreviewById(createdResponse.Id);
        Assert.NotNull(jobPostPreview);
        var jobPostPreviewResult = Assert.IsType<OkObjectResult>(jobPostPreview.Result);
        var jobPostPreviewResultValue = jobPostPreviewResult.Value;
        Assert.NotNull(jobPostPreviewResultValue);
        JobPostPreviewDto jobPostPreviewDtoDB = (JobPostPreviewDto)jobPostPreviewResultValue;
        Assert.NotNull(jobPostPreviewDtoDB);
        Assert.True(jobPostPreviewDtoDB.Title == jobPostDto.Title);
    }

    [Fact]
    public async Task ShouldFailGetJobPostPreviewWithInvalidJobPostId()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title" + DateTime.Now.Ticks, IsActive = true, Description = "Descrption For the Given Job Post" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);
        var jobPostPreview = await _jobPostsController.GetJobPostPreviewById(2000);
        Assert.IsType<BadRequestObjectResult>(jobPostPreview.Result);
    }

    [Fact]
    public async Task ShouldGetJobPostByLink()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);


        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title22", IsActive = true, Description = "Descrption For the Given Job Post", CategoryId = 1, EEOClassId = 6, EmployeeTypeId = 1, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getjobpost = await _jobPostsController.GetById(createdResponse.Id);
        Assert.NotNull(getjobpost);
        var jobResult = Assert.IsType<OkObjectResult>(getjobpost.Result);
        var jobPostResultValue = jobResult.Value;
        Assert.NotNull(jobPostResultValue);

        JobPostDto jobPostDtoDB = (JobPostDto)jobPostResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.True(jobPostDtoDB.LinkId != null);
        var jobLink = await _jobPostsController.GetByLinkIdAsync((Guid)jobPostDtoDB.LinkId);
        Assert.NotNull(jobLink);
        var jobLinkResult = Assert.IsType<OkObjectResult>(jobLink.Result);
        var jobLinkResultValue = jobLinkResult.Value;
        Assert.NotNull(jobLinkResultValue);
    }

    [Fact]
    public async Task ShouldFailGetJobPostWithInvalidJobPostLink()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title23", IsActive = true, Description = "Descrption For the Given Job Post", CategoryId = 1, EEOClassId = 6, EmployeeTypeId = 1, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.GetByLinkIdAsync(Guid.NewGuid()));
        Assert.Equal(InvalidJobPost, exception.Message);
    }

    [Fact]
    public async Task ShouldFailGetJobPostForInActiveJobPosts()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title23", IsActive = false, Description = "Descrption For the Given Job Post", CategoryId = 1, EEOClassId = 6, EmployeeTypeId = 1, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), StartDateTime = DateTime.UtcNow.AddDays(2), IsSubmitted = true };
        var jobPostResult = await _jobPostService.AddAsync(jobPostDto);
        Assert.True(jobPostResult > 0);

        var getjobpost = await _jobPostService.GetByIdAsync(jobPostResult.Value);
        Assert.NotNull(getjobpost);
        Assert.True(getjobpost.LinkId != null);

        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.GetByLinkIdAsync((Guid)getjobpost.LinkId));
        Assert.Equal(InActiveJobPost, exception.Message);
    }

    [Fact]
    public async Task ShouldGeneratedJobLinkforSubmittedJobs()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title24", IsActive = true, Description = "Descrption For the Given Job Post", CategoryId = 1, EEOClassId = 6, EmployeeTypeId = 1, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getjobpost = await _jobPostsController.GetById(createdResponse.Id);
        Assert.NotNull(getjobpost);
        var jobResult = Assert.IsType<OkObjectResult>(getjobpost.Result);
        var jobPostResultValue = jobResult.Value;
        Assert.NotNull(jobPostResultValue);

        JobPostDto jobPostDtoDB = (JobPostDto)jobPostResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.True(jobPostDtoDB.LinkId != null);
    }

    [Fact]
    public async Task ShouldFailtoGenerateJobLinkforSavedJobs()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title25", IsActive = true, Description = "Descrption For the Given Job Post", CategoryId = 1, IsSubmitted = false };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getjobpost = await _jobPostsController.GetById(createdResponse.Id);
        Assert.NotNull(getjobpost);
        var jobResult = Assert.IsType<OkObjectResult>(getjobpost.Result);
        var jobPostResultValue = jobResult.Value;
        Assert.NotNull(jobPostResultValue);

        JobPostDto jobPostDtoDB = (JobPostDto)jobPostResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.True(jobPostDtoDB.LinkId == null);
    }

    [Fact]
    public async Task ShouldSubmitJobPostWithStartDateAndEndDate()
    {
        //save a job post  and assert it
        DateOnly startDate = DateOnly.FromDateTime(DateTime.Now);
        DateOnly endDate = DateOnly.FromDateTime(DateTime.Now.AddDays(1));
        DateTimeOffset startDateTime = DateTime.UtcNow;
        DateTimeOffset endDateTime = DateTime.UtcNow.AddDays(1);
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayMethodId = 26, PayGroupId = 17, IsSubmitted = true, StartDate = startDate, EndDate = endDate, StartDateTime = startDateTime, EndDateTime = endDateTime };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var getJobPostCategoryName = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPostCategoryName.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(getJobPostCategoryName.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDtoDB.EndDate, jobPostDto.EndDate);
    }

    [Fact]
    public async Task ShouldActivateInactivateJobPostBasedOnStartAndEndDate()
    {
        //save a job post  and assert it
        //This is to activate a jobpost
        DateOnly activateStartDate = DateOnly.FromDateTime(DateTime.Now);
        DateOnly activatEndDate = DateOnly.FromDateTime(DateTime.Now.AddDays(1));
        bool isActive = false;
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, PayMethodId = 26, PayGroupId = 17, IsSubmitted = true, StartDate = activateStartDate, EndDate = activatEndDate, IsActive = isActive, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        //Calling UpdateStatus service method to activate or inactivates jobpost based on start and end date
        await _jobPostService.UpdateStatusAsync();

        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDtoDB.EndDate, jobPostDto.EndDate);
        //Assert.True(jobPostDtoDB.IsActive); //commenting it because EF core ExecuteUpdate is not supported for in-memory database
    }

    [Fact]
    public async Task ShouldSubmitJobPostAndGetJobCode()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EmployeeTypeId = 1, PayMethodId = 26, PayGroupId = 17, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.NotNull(jobPostDtoDB.JobCode);
    }

    [Fact]
    public async Task ShouldSubmitSavedJobPostAndGetJobCode()
    {
        var jobPostDto = await AssertCreateJobPostForSubmit();
        Assert.True(jobPostDto.Id > 0);

        var jobPostFromDBResult = await _jobPostsController.GetById(jobPostDto.Id);
        var jobPostFromDBOkResult = Assert.IsType<OkObjectResult>(jobPostFromDBResult.Result);
        var jobPostFromDB = Assert.IsType<JobPostDto>(jobPostFromDBOkResult.Value);
        Assert.NotNull(jobPostFromDB);
        Assert.False(string.IsNullOrWhiteSpace(jobPostFromDB.Title));
        Assert.True(jobPostFromDB.Title == jobPostDto.Title);

        jobPostFromDB.Id = jobPostDto.Id;
        jobPostFromDB.EmployeeTypeId = 1;
        jobPostFromDB.PayMethodId = 26;
        jobPostFromDB.PayGroupId = 17;
        jobPostFromDB.IsSubmitted = true;
        jobPostFromDB.StartDate = DateOnly.FromDateTime(DateTime.Now);
        jobPostFromDB.StartDateTime = DateTime.UtcNow;
        await _jobPostsController.Update(jobPostFromDB);

        var afterUpdateJobPostFromDBResult = await _jobPostsController.GetById(jobPostDto.Id);
        var afterUpdateJobPostOkResult = Assert.IsType<OkObjectResult>(afterUpdateJobPostFromDBResult.Result);
        var afterUpdateJobPostFromDB = Assert.IsType<JobPostDto>(afterUpdateJobPostOkResult.Value);
        Assert.NotNull(afterUpdateJobPostFromDB);
        Assert.False(string.IsNullOrWhiteSpace(afterUpdateJobPostFromDB.Title));
        Assert.True(afterUpdateJobPostFromDB.IsSubmitted == jobPostFromDB.IsSubmitted);
        Assert.NotNull(afterUpdateJobPostFromDB.JobCode);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithoutGetJobCode()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EmployeeTypeId = 1, PayMethodId = 26, PayGroupId = 17, IsSubmitted = false };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Null(jobPostDtoDB.JobCode);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithEmptyEmployeeTypeId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EmployeeTypeId = null };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithEmptyEEOClassId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EEOClassId = null };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithEEOClassIdAndEmployeeTypeId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EmployeeTypeId = 4, EEOClassId = 12 };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSubmitJobPostWithEEOClassIdAndEmployeeTypeId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EmployeeTypeId = 4, EEOClassId = 12, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSubmitJobPostWithEmptyEEOClassIdAndEmployeeTypeId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EmployeeTypeId = 4, EEOClassId = null, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSubmitJobPostWithEmptyEEOClassId()
    {
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, EEOClassId = null, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
    }

    [Fact]
    public async Task ShouldSaveJobPostWithMandatoryFields()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), EndDate = DateOnly.FromDateTime(DateTime.Now), IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostGetResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostGetResultValue = jobPostGetResult.Value;
        Assert.NotNull(jobPostGetResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostGetResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDtoDB.EndDate, jobPostDto.EndDate);
        Assert.True(jobPostDtoDB.IsActive);
        Assert.Equal(jobPostDtoDB.EmployeeTypeId, jobPostDto.EmployeeTypeId);
        Assert.Equal(jobPostDtoDB.PayGroupId, jobPostDto.PayGroupId);
        Assert.Equal(jobPostDtoDB.PayMethodId, jobPostDto.PayMethodId);
        Assert.Equal(jobPostDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);
    }

    [Fact]
    public async Task ShouldAllowJobPostTitleIfAlreadyExistsDuringUpdate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        //save a job post  and assert it
        var jobTitle = "Salesforce Developer";
        var jobPostDto = new JobPostDto { Title = jobTitle, Description = "Salesforce Developer" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostGetResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostGetResultValue = jobPostGetResult.Value;
        Assert.NotNull(jobPostGetResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostGetResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobTitle);
        Assert.Equal(jobPostDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);

        //Update jobpost
        jobPostDto.Id = jobPost.Id;
        jobPostDto.Title = jobTitle;
        jobPostDto.IsActive = true;
        await _jobPostsController.Update(jobPostDto);

        var getJobUpdatePost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobUpdatePost.Result);
        var jobPostUpdateGetResult = Assert.IsType<OkObjectResult>(getJobUpdatePost.Result);
        var jobPostUpdateGetResultValue = jobPostUpdateGetResult.Value;
        Assert.NotNull(jobPostUpdateGetResultValue);
        JobPostDto jobPostUpdateDtoDB = (JobPostDto)jobPostUpdateGetResultValue;
        Assert.NotNull(jobPostUpdateDtoDB);
        Assert.NotEmpty(jobPostUpdateDtoDB.Title);
        Assert.Equal(jobPostUpdateDtoDB.Title, jobTitle);
        Assert.Equal(jobPostUpdateDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostUpdateDtoDB.EndDate, jobPostDto.EndDate);
        Assert.Equal(jobPostUpdateDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);
    }

    [Fact]
    public async Task ShouldSubmitJobpostWithIsActiveFalseForFutureStartDate()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostGetResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostGetResultValue = jobPostGetResult.Value;
        Assert.NotNull(jobPostGetResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostGetResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDtoDB.EndDate, jobPostDto.EndDate);
        Assert.True(!jobPostDtoDB.IsActive);
        Assert.Equal(jobPostDtoDB.EmployeeTypeId, jobPostDto.EmployeeTypeId);
        Assert.Equal(jobPostDtoDB.PayGroupId, jobPostDto.PayGroupId);
        Assert.Equal(jobPostDtoDB.PayMethodId, jobPostDto.PayMethodId);
        Assert.Equal(jobPostDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);
    }

    [Fact]
    public async Task ShouldUpdateJobpostWithIsActiveFalseForFutureStartDateWhenSubmit()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), IsSubmitted = true, StartDateTime = DateTime.UtcNow, EndDateTime = DateTime.UtcNow.AddDays(1) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostGetResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostGetResultValue = jobPostGetResult.Value;
        Assert.NotNull(jobPostGetResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostGetResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDtoDB.EndDate, jobPostDto.EndDate);
        Assert.True(jobPostDtoDB.IsActive);
        Assert.Equal(jobPostDtoDB.EmployeeTypeId, jobPostDto.EmployeeTypeId);
        Assert.Equal(jobPostDtoDB.PayGroupId, jobPostDto.PayGroupId);
        Assert.Equal(jobPostDtoDB.PayMethodId, jobPostDto.PayMethodId);
        Assert.Equal(jobPostDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);

        //Update jobpost
        jobPostDto.Id = jobPost.Id;
        jobPostDto.StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1));
        jobPostDto.EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2));
        jobPostDto.StartDateTime = DateTime.Today.AddDays(1);
        jobPostDto.EndDateTime = DateTime.Today.AddDays(2);

        await _jobPostsController.Update(jobPostDto);

        var getJobUpdatePost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobUpdatePost.Result);
        var jobPostUpdateGetResult = Assert.IsType<OkObjectResult>(getJobUpdatePost.Result);
        var jobPostUpdateGetResultValue = jobPostUpdateGetResult.Value;
        Assert.NotNull(jobPostUpdateGetResultValue);
        JobPostDto jobPostUpdateDtoDB = (JobPostDto)jobPostUpdateGetResultValue;
        Assert.NotNull(jobPostUpdateDtoDB);
        Assert.NotEmpty(jobPostUpdateDtoDB.Title);
        Assert.Equal(jobPostUpdateDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostUpdateDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostUpdateDtoDB.EndDate, jobPostDto.EndDate);
        Assert.True(!jobPostUpdateDtoDB.IsActive);
        Assert.Equal(jobPostUpdateDtoDB.EmployeeTypeId, jobPostDto.EmployeeTypeId);
        Assert.Equal(jobPostUpdateDtoDB.PayGroupId, jobPostDto.PayGroupId);
        Assert.Equal(jobPostUpdateDtoDB.PayMethodId, jobPostDto.PayMethodId);
        Assert.Equal(jobPostUpdateDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);
    }

    [Fact]
    public async Task ShouldUpdateJobpostWithIsActiveTrueForNullEndWhenSubmit()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Today), IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);
        var getJobPost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobPost.Result);
        var jobPostGetResult = Assert.IsType<OkObjectResult>(getJobPost.Result);
        var jobPostGetResultValue = jobPostGetResult.Value;
        Assert.NotNull(jobPostGetResultValue);
        JobPostDto jobPostDtoDB = (JobPostDto)jobPostGetResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.NotEmpty(jobPostDtoDB.Title);
        Assert.Equal(jobPostDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDtoDB.EndDate, jobPostDto.EndDate);
        Assert.True(jobPostDtoDB.IsActive);
        Assert.Equal(jobPostDtoDB.EmployeeTypeId, jobPostDto.EmployeeTypeId);
        Assert.Equal(jobPostDtoDB.PayGroupId, jobPostDto.PayGroupId);
        Assert.Equal(jobPostDtoDB.PayMethodId, jobPostDto.PayMethodId);
        Assert.Equal(jobPostDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);

        //Update jobpost
        jobPostDto.Id = jobPost.Id;
        jobPostDto.StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1));
        jobPostDto.EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2));
        jobPostDto.StartDateTime = DateTime.Today.AddDays(1);
        jobPostDto.EndDateTime = DateTime.Today.AddDays(2);

        await _jobPostsController.Update(jobPostDto);

        var getJobUpdatePost = await _jobPostsController.GetById(jobPost.Id);
        Assert.NotNull(getJobUpdatePost.Result);
        var jobPostUpdateGetResult = Assert.IsType<OkObjectResult>(getJobUpdatePost.Result);
        var jobPostUpdateGetResultValue = jobPostUpdateGetResult.Value;
        Assert.NotNull(jobPostUpdateGetResultValue);
        JobPostDto jobPostUpdateDtoDB = (JobPostDto)jobPostUpdateGetResultValue;
        Assert.NotNull(jobPostUpdateDtoDB);
        Assert.NotEmpty(jobPostUpdateDtoDB.Title);
        Assert.Equal(jobPostUpdateDtoDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostUpdateDtoDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostUpdateDtoDB.EndDate, jobPostDto.EndDate);
        Assert.True(!jobPostUpdateDtoDB.IsActive);
        Assert.Equal(jobPostUpdateDtoDB.EmployeeTypeId, jobPostDto.EmployeeTypeId);
        Assert.Equal(jobPostUpdateDtoDB.PayGroupId, jobPostDto.PayGroupId);
        Assert.Equal(jobPostUpdateDtoDB.PayMethodId, jobPostDto.PayMethodId);
        Assert.Equal(jobPostUpdateDtoDB.ApplicationFormId, jobPostDto.ApplicationFormId);
    }

    [Fact]
    public async Task ShouldCreateJobPostWithWorkArrangement()
    {
        var jobpostDto = new JobPostDto { Title = "JP-" + DateTime.Now.Ticks, WorkArrangementId = (long)WorkArrangement.Remote };
        var jobPostId = await CreateJobPostDto(jobpostDto);

        var jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);
        Assert.Equal((long)WorkArrangement.Remote, jobPostDto.WorkArrangementId);
    }

    [Fact]
    public async Task ShouldUpdateJobPostWithWorkArrangement()
    {
        var jobpostDto = new JobPostDto { Title = "JP-" + DateTime.Now.Ticks, WorkArrangementId = (long)WorkArrangement.Remote };
        var jobPostId = await CreateJobPostDto(jobpostDto);

        var jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);
        Assert.Equal((long)WorkArrangement.Remote, jobPostDto.WorkArrangementId);

        jobPostDto.WorkArrangementId = (long)WorkArrangement.Onsite;
        await AssertUpdateJobPostAsync(jobPostDto);

        jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);
        Assert.Equal((long)WorkArrangement.Onsite, jobPostDto.WorkArrangementId);
    }

    [Fact]
    public async Task ShouldFailSubmitJobPostWhenPastStartDateGivenForDraftedJobPost()
    {
        //This test case is for covering, drafted jobpost and now submitting with past start date
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var jobPostTitle = $"Title-{DateTime.Now.Ticks}";
        var jobPostSaveDto = new JobPostDto { Title = jobPostTitle, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), IsSubmitted = false, WorkArrangementId = 1, WorksiteLocationId = 2, StartDateTime = DateTime.Today.AddDays(-1), EndDateTime = DateTime.Today.AddDays(1) };
        var jobPostSaveResult = await _jobPostsController.Create(jobPostSaveDto);
        var jobPostOkSaveResult = Assert.IsType<OkObjectResult>(jobPostSaveResult.Result);
        var jobPostSave = Assert.IsType<CreatedResponse>(jobPostOkSaveResult.Value);
        Assert.True(jobPostSave.Id > 0);

        var jobPostDto = new JobPostDto { Id = jobPostSave.Id, Title = jobPostTitle, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), IsSubmitted = true, WorkArrangementId = 1, WorksiteLocationId = 2, StartDateTime = DateTime.Today.AddDays(-1), EndDateTime = DateTime.Today.AddDays(1) };
        var validationException = await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _jobPostsController.Update(jobPostDto));
        Assert.Equal(JobPostValidation.StartDateFutureDate, validationException.Message);
    }

    [Fact]
    public async Task ShouldGetJobPostsByCompanyId()
    {
        // This test case is for covering, drafted jobpost and now submitting with past start date
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var companyCode = 111815;
        var companyId = await CreateCompany(companyCode);
        Assert.True(companyId > 0);
        _currentUserContext.CompanyId = companyId;

        var jobPostTitle = $"Title-{DateTime.Now.Ticks}";

        var jobPostDto = new JobPostDto { Title = jobPostTitle, Description = "Description", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), IsActive = true, IsSubmitted = true, WorkArrangementId = 27, WorksiteLocationId = null, LocationTypeId = null, CCEmailAddresses = "user1@company1.com", SalaryComments = "SalaryComment", Salary = 10000.00m, StartDateTime = DateTime.UtcNow };
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.True(jobPostId > 0);

        var company = _companyService.GetByCodeAsync(companyCode);
        var identifier = company.Result.Identifier;

        var jobPostsByCompany = await _jobPostService.GetByCompanyIdentifierAsync(identifier!.Value);
        Assert.NotNull(jobPostsByCompany);
        Assert.NotEmpty(jobPostsByCompany);

        var insertedJobPost = jobPostsByCompany.Find(jp => jp.Id == jobPostId);
        Assert.NotNull(insertedJobPost);
        Assert.NotNull(insertedJobPost.Title);
        Assert.Equal(insertedJobPost.Title, jobPostDto.Title);
        Assert.Equal(insertedJobPost.Description, jobPostDto.Description);
    }

    [Fact]
    public async Task ShouldSaveJobPostWhenRemoteWorkArrangementTestDataIsValid()
    {
        var workArrangementId = (long)WorkArrangement.Remote;
        var city = "New Jersey";
        var states = await GetStatesAsync();
        var state = states.Find(state => string.Equals(state.Name, "NEW YORK", StringComparison.OrdinalIgnoreCase));
        var stateId = state?.Id;
        var country = "USA";

        var jobPostDto = new JobPostDto()
        {
            Title = "JP" + DateTime.Now.Ticks,
            WorkArrangementId = workArrangementId,
            City = city,
            StateId = stateId,
            Country = country
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);

        jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);
        Assert.Equal(workArrangementId, jobPostDto.WorkArrangementId);
        Assert.Equal(city, jobPostDto.City);
        Assert.Equal(stateId, jobPostDto.StateId);
        Assert.Equal(country, jobPostDto.Country);
    }

    [Fact]
    public async Task ShouldGetCompanyCodeAndCompanyNameByCompanyIdentifier()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var companyCode = 1122334455;
        var companyId = await CreateCompany(companyCode);
        Assert.True(companyId > 0);
        _currentUserContext.CompanyId = companyId;

        var jobPostTitle = $"Title-{DateTime.Now.Ticks}";
        var jobPostDto = new JobPostDto
        {
            Title = jobPostTitle,
            Description = "Description",
            EmployeeTypeId = 4,
            EEOClassId = 12,
            ApplicationFormId = formId,
            PayGroupId = 17,
            PayMethodId = (int)PayMethod.Hourly,
            StartDate = DateOnly.FromDateTime(DateTime.Today),
            EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)),
            IsActive = true,
            IsSubmitted = true,
            WorkArrangementId = 27,
            WorksiteLocationId = null,
            LocationTypeId = null,
            CCEmailAddresses = "user1@company1.com",
            SalaryComments = "SalaryComment",
            Salary = 10000.00m,
            StartDateTime = DateTime.UtcNow
        };

        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.True(jobPostId > 0);

        var company = await _companyService.GetByCodeAsync(companyCode);
        Assert.NotNull(company);
        var identifier = company.Identifier;
        Assert.NotNull(identifier);

        var jobPostsByCompany = await _jobPostService.GetByCompanyIdentifierAsync(identifier.Value);

        Assert.NotNull(jobPostsByCompany);
        Assert.NotEmpty(jobPostsByCompany);

        var insertedJobPost = jobPostsByCompany.Find(jp => jp.Id == jobPostId);
        Assert.NotNull(insertedJobPost);
        Assert.Equal(jobPostDto.Title, insertedJobPost.Title);
        Assert.Equal(jobPostDto.Description, insertedJobPost.Description);
        Assert.Equal(company.DbaName, insertedJobPost.CompanyName);
        Assert.Equal(company.CompanyCode, insertedJobPost.CompanyCode);
    }

    [Fact]
    public async Task ShouldUpdateJobPostWhenRemoteWorkArrangementTestDataIsValid()
    {
        var workArrangementId = (long)WorkArrangement.Remote;
        var city = "New Jersey";
        var states = await GetStatesAsync();
        var state = states.Find(state => string.Equals(state.Name, "NEW YORK", StringComparison.OrdinalIgnoreCase));
        var stateId = state?.Id;
        var country = "USA";

        var jobPostDto = new JobPostDto()
        {
            Title = "JP" + DateTime.Now.Ticks,
            WorkArrangementId = workArrangementId,
            City = city,
            StateId = stateId,
            Country = country
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);

        city = "Charlotte";
        state = states.Find(state => string.Equals(state.Name, "NORTH CAROLINA", StringComparison.OrdinalIgnoreCase));
        stateId = state?.Id;
        country = "United States";

        jobPostDto.City = city;
        jobPostDto.StateId = stateId;
        jobPostDto.Country = country;

        await AssertUpdateJobPostAsync(jobPostDto);
        jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);

        Assert.Equal(workArrangementId, jobPostDto.WorkArrangementId);
        Assert.Equal(city, jobPostDto.City);
        Assert.Equal(stateId, jobPostDto.StateId);
        Assert.Equal(country, jobPostDto.Country);
    }

    [Fact]
    public async Task ShouldGetFormWithGivenActiveCustomFields()
    {
        var Options = new List<ApplicationFormFieldOptionDto> {
                         new() {Name = "Washington"},
                         new () {Name = "New York"} };

        var formFieldAttributeValues = new List<ApplicationFormFieldAttributeValueDto> { new() { AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = "100" } };
        var formFields = new List<ApplicationFormFieldDto>()
         {
             new() { Name = "First Name", DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true,IsSystemDefault = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
             new() { Name = "Middle Name", DisplayOrder = 2, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false,IsSystemDefault = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
             new() { Name = "Last Name", DisplayOrder = 3, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true,IsSystemDefault = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
             new() { Name = "Personal Email Address", DisplayOrder = 4, IsActive = true, IsAlwaysActiveAndRequired = true,IsSystemDefault = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
             new() { Name = "Home Telephone Number", DisplayOrder = 5, IsActive = true, IsAlwaysActiveAndRequired = false,IsSystemDefault = true, IsRequired = false, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.PhoneNumber },
             new() { Name = "State", DisplayOrder = 6, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true,IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.Dropdown, Options = Options },
             new() { Name = "Alternate Phone Number", DisplayOrder = 7, IsActive = false, IsAlwaysActiveAndRequired = false, IsRequired = false,IsSystemDefault = false,SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput,AttributeValues = formFieldAttributeValues },
             new() { Name = "Mobile Phone Number", DisplayOrder = 8, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true,IsSystemDefault = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.PhoneNumber },
             new() { Name = "Address Line 1", DisplayOrder = 9, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true,IsSystemDefault = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
             new() { Name = "Address Line 2", DisplayOrder = 10, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false,IsSystemDefault = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
             new() { Name = "Zip Code", DisplayOrder = 11, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, IsSystemDefault = true,SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
             new() { Name = "City", DisplayOrder = 12, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true,IsSystemDefault = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
         };

        var formDto = new ApplicationFormDto { Name = "form001" + DateTime.Now.Ticks, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id != 0);
        Assert.True(createdResponse.Id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = createdResponse.Id, Title = "JobPostTitle001" + DateTime.Now.Ticks, Description = "JobPost Description" };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostDTO = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(createdJobPostDTO.Id > 0);

        //var jobPost = _jobPostService.
        //var form = await _jobPostsController.GetActiveFieldsById(createdJobPostDTO.Id);
        //var appForm = Assert.IsType<OkObjectResult>(form.Result);
        //var formFromDB = Assert.IsType<ApplicationFormDto>(appForm.Value);
        //Assert.NotNull(formFromDB);
        //Assert.NotNull(formFromDB.CreatedOn);

        //var formFieldsFromDB = formFromDB.Fields;
        //Assert.NotNull(formFieldsFromDB);
        //foreach (var field in formFieldsFromDB)
        //{
        //    Assert.Contains(formFields, f => f.Name == field.Name);
        //    var customField = formFields.Find(f => f.Name == field.Name);
        //    Assert.NotNull(customField);
        //    Assert.True(customField.IsActive == field.IsActive);
        //    Assert.True(customField.IsActive != false);
        //    Assert.True(customField.TypeId == field.TypeId);
        //    Assert.True(customField.SectionId == field.SectionId);
        //    Assert.True(customField.IsAlwaysActiveAndRequired == field.IsAlwaysActiveAndRequired);
        //    Assert.True(customField.IsRequired == field.IsRequired);
        //}
    }

    [Fact]
    public async Task ShouldReturnsJobPostsListWithCategoryName()
    {
        var jobPostCategoryDTO = new JobPostCategoryDto { Name = $"Category003- {DateTime.Now.Ticks}", IsActive = true };

        var result = await _jobPostCategoriesController.Create(jobPostCategoryDTO);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);
        var categoryId = createdResponse.Id;

        var jobPostCategoryFromDB = await _jobPostCategoriesController.GetJobPostCategoryById(createdResponse.Id);
        Assert.NotNull(jobPostCategoryFromDB);
        Assert.NotNull(jobPostCategoryFromDB.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(jobPostCategoryFromDB.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostCategoryDto jobPostCategoryDB = (JobPostCategoryDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostCategoryDB);
        Assert.False(string.IsNullOrWhiteSpace(jobPostCategoryDTO.Name));
        Assert.True(jobPostCategoryDB.Name == jobPostCategoryDTO.Name);

        var formName = $"form003-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = formId, Title = "Title4000", IsActive = true, Description = "Descrption For the Given Job Post", IsSubmitted = true, CategoryId = categoryId, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdJobPostResponse.Id > 0);

        var jobPostResponseResult = await _jobPostsController.GetList(true);
        Assert.IsType<ActionResult<IEnumerable<JobPostListDto>>>(jobPostResponseResult);
        var okResult = Assert.IsType<OkObjectResult>(jobPostResponseResult.Result);
        var model = Assert.IsAssignableFrom<IEnumerable<JobPostListDto>>(okResult.Value);
        Assert.NotEmpty(model);
        var jobPostDb = model.FirstOrDefault(jobPost => jobPost.Id == createdJobPostResponse.Id);
        Assert.NotNull(jobPostDb);

        Assert.Contains(model, jobPost => jobPost.Title == "Title4000");
        Assert.Contains(model, jobPost => jobPost.IsActive);
        Assert.Contains(model, jobPost => jobPost.IsSubmitted);
        Assert.Equal(jobPostDb.WorksiteLocation, string.Empty);
        Assert.Equal(jobPostDb.JobPostCategory, jobPostCategoryDB.Name);
    }

    [Fact]
    public async Task ShouldReturnsJobPostsListWithInActiveCategory()
    {
        var jobPostCategoryDTO = new JobPostCategoryDto { Name = $"Category001- {DateTime.Now.Ticks}", IsActive = true };
        var result = await _jobPostCategoriesController.Create(jobPostCategoryDTO);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);
        var categoryId = createdResponse.Id;

        var jobPostCategoryFromDB = await _jobPostCategoriesController.GetJobPostCategoryById(createdResponse.Id);
        Assert.NotNull(jobPostCategoryFromDB);
        Assert.NotNull(jobPostCategoryFromDB.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(jobPostCategoryFromDB.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);
        JobPostCategoryDto jobPostCategoryDB = (JobPostCategoryDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostCategoryDB);
        Assert.False(string.IsNullOrWhiteSpace(jobPostCategoryDTO.Name));
        Assert.True(jobPostCategoryDB.Name == jobPostCategoryDTO.Name);

        var formDto = new ApplicationFormDto { Name = "form001" + DateTime.Now.Ticks };
        var formResult = await _formController.Create(formDto);
        var formInsertResult = Assert.IsType<OkObjectResult>(formResult.Result);
        var formCreatedResponse = Assert.IsType<CreatedResponse>(formInsertResult.Value);
        Assert.True(formCreatedResponse.Id != 0);
        Assert.True(formCreatedResponse.Id > 0);
        var formId = formCreatedResponse.Id;

        var jobPostDto = new JobPostDto { ApplicationFormId = formId, Title = "Title1000", IsActive = true, Description = "Descrption For the Given Job Post", IsSubmitted = true, CategoryId = categoryId, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdJobPostResponse.Id > 0);

        var jobPostResponseResult = await _jobPostsController.GetList(true);
        Assert.IsType<ActionResult<IEnumerable<JobPostListDto>>>(jobPostResponseResult);
        var okResult = Assert.IsType<OkObjectResult>(jobPostResponseResult.Result);
        var model = Assert.IsAssignableFrom<IEnumerable<JobPostListDto>>(okResult.Value);
        Assert.NotEmpty(model);
        var jobPostDb = model.FirstOrDefault(jobPost => jobPost.Id == createdJobPostResponse.Id);
        Assert.NotNull(jobPostDb);

        Assert.Contains(model, jobPost => jobPost.Title == "Title1000");
        Assert.Contains(model, jobPost => jobPost.IsActive);
        Assert.Contains(model, jobPost => jobPost.IsSubmitted);
        Assert.Equal(jobPostDb.WorksiteLocation, string.Empty);
        Assert.Equal(jobPostDb.JobPostCategory, jobPostCategoryDB.Name);

        var category = await _jobPostCategoryService.GetByIdAsync(categoryId);

        var jobPostCategory = new JobPostCategoryDto { Id = categoryId, IsActive = false,Version = category!.Version };
        var jobPostCategoryUpdateResult = await _jobPostCategoriesController.Update(jobPostCategory);

        var jobPostCategoryOkResult = Assert.IsType<OkResult>(jobPostCategoryUpdateResult);
        Assert.Equal(200, jobPostCategoryOkResult.StatusCode);

        var jobPostListResult = await _jobPostsController.GetList(true);
        Assert.IsType<ActionResult<IEnumerable<JobPostListDto>>>(jobPostListResult);
        var jobPostListOkResult = Assert.IsType<OkObjectResult>(jobPostListResult.Result);
        var jobList = Assert.IsAssignableFrom<IEnumerable<JobPostListDto>>(jobPostListOkResult.Value);
        Assert.NotNull(jobList);

        var jobPostafterUpdate = jobList.FirstOrDefault(jobPost => jobPost.Id == createdJobPostResponse.Id);
        Assert.NotNull(jobPostafterUpdate);

        Assert.Contains(jobList, jobPost => jobPost.Title == "Title1000");
        Assert.Contains(jobList, jobPost => jobPost.IsActive);
        Assert.Contains(jobList, jobPost => jobPost.IsSubmitted);
        Assert.Equal(jobPostafterUpdate.WorksiteLocation, string.Empty);
        Assert.Equal(jobPostafterUpdate.JobPostCategory, string.Empty);
    }

    [Fact]
    public async Task ShouldReturnsJobPostsListWithDeletedCategory()
    {
        var jobPostCategoryDTO = new JobPostCategoryDto { Name = $"Category2- {DateTime.Now.Ticks}", IsActive = true };
        var result = await _jobPostCategoriesController.Create(jobPostCategoryDTO);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        Assert.True(createdResponse.Id > 0);
        var categoryId = createdResponse.Id;

        var jobPostCategoryFromDB = await _jobPostCategoriesController.GetJobPostCategoryById(createdResponse.Id);
        Assert.NotNull(jobPostCategoryFromDB);
        Assert.NotNull(jobPostCategoryFromDB.Result);
        var jobPostCategoryResult = Assert.IsType<OkObjectResult>(jobPostCategoryFromDB.Result);
        var jobPostCategoryResultValue = jobPostCategoryResult.Value;
        Assert.NotNull(jobPostCategoryResultValue);

        JobPostCategoryDto jobPostCategoryDB = (JobPostCategoryDto)jobPostCategoryResultValue;
        Assert.NotNull(jobPostCategoryDB);
        Assert.False(string.IsNullOrWhiteSpace(jobPostCategoryDTO.Name));
        Assert.True(jobPostCategoryDB.Name == jobPostCategoryDTO.Name);

        var formName = $"form0-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = formId, Title = "Title3000", IsActive = true, Description = "Descrption For the Given Job Post", IsSubmitted = true, CategoryId = categoryId, StartDate = DateOnly.FromDateTime(DateTime.Now), StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdJobPostResponse.Id > 0);

        var jobPostResponseResult = await _jobPostsController.GetList(true);
        Assert.IsType<ActionResult<IEnumerable<JobPostListDto>>>(jobPostResponseResult);
        var okResult = Assert.IsType<OkObjectResult>(jobPostResponseResult.Result);
        var model = Assert.IsAssignableFrom<IEnumerable<JobPostListDto>>(okResult.Value);
        Assert.NotEmpty(model);
        var jobPostDb = model.FirstOrDefault(jobPost => jobPost.Id == createdJobPostResponse.Id);
        Assert.NotNull(jobPostDb);

        Assert.Contains(model, jobPost => jobPost.Title == "Title3000");
        Assert.Contains(model, jobPost => jobPost.IsActive);
        Assert.Contains(model, jobPost => jobPost.IsSubmitted);
        Assert.Equal(jobPostDb.WorksiteLocation, string.Empty);
        Assert.Equal(jobPostDb.JobPostCategory, jobPostCategoryDB.Name);

        var deletedCategory = await _jobPostCategoriesController.Delete(categoryId);
        Assert.NotNull(deletedCategory);
        var deletedResult = Assert.IsType<OkResult>(deletedCategory.Result);
        var affectedRecords = deletedResult;
        Assert.NotNull(affectedRecords);

        var jobPostListResult = await _jobPostsController.GetList(true);
        Assert.IsType<ActionResult<IEnumerable<JobPostListDto>>>(jobPostListResult);
        var jobPostListOkResult = Assert.IsType<OkObjectResult>(jobPostListResult.Result);
        var jobList = Assert.IsAssignableFrom<IEnumerable<JobPostListDto>>(jobPostListOkResult.Value);
        Assert.NotNull(jobList);

        var jobPostafterUpdate = jobList.FirstOrDefault(jobPost => jobPost.Id == createdJobPostResponse.Id);
        Assert.NotNull(jobPostafterUpdate);

        Assert.Contains(jobList, jobPost => jobPost.Title == "Title3000");
        Assert.Contains(jobList, jobPost => jobPost.IsActive);
        Assert.Contains(jobList, jobPost => jobPost.IsSubmitted);
        Assert.Equal(jobPostafterUpdate.WorksiteLocation, string.Empty);
        Assert.Equal(jobPostafterUpdate.JobPostCategory, string.Empty);
    }

    [Fact]
    public async Task ShouldSaveJobPostWhenCustomWorksiteLocationIsValid()
    {
        var workArrangementId = (long)WorkArrangement.Hybrid;
        var locationTypeId = (long)LocationType.CustomLocation;
        var location = "location1";
        var city = "New Jersey";
        var states = await GetStatesAsync();
        var state = states.Find(state => string.Equals(state.Name, "NEW YORK", StringComparison.OrdinalIgnoreCase));
        var stateId = state?.Id;

        var jobPostDto = new JobPostDto()
        {
            Title = "JP" + DateTime.Now.Ticks,
            WorkArrangementId = workArrangementId,
            LocationTypeId = locationTypeId,
            Location = location,
            City = city,
            StateId = stateId
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);

        jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);
        Assert.Equal(workArrangementId, jobPostDto.WorkArrangementId);
        Assert.Equal(locationTypeId, jobPostDto.LocationTypeId);
        Assert.Equal(location, jobPostDto.Location);
        Assert.Equal(city, jobPostDto.City);
        Assert.Equal(stateId, jobPostDto.StateId);
    }

    [Fact]
    public async Task ShouldUpdateJobPostWhenCustomWorksiteLocationIsValid()
    {
        var workArrangementId = (long)WorkArrangement.Hybrid;
        var locationTypeId = (long)LocationType.CustomLocation;
        var location = "location1";
        var city = "New Jersey";
        var states = await GetStatesAsync();
        var state = states.Find(state => string.Equals(state.Name, "NEW YORK", StringComparison.OrdinalIgnoreCase));
        var stateId = state?.Id;

        var jobPostDto = new JobPostDto()
        {
            Title = "JP" + DateTime.Now.Ticks,
            WorkArrangementId = workArrangementId,
            LocationTypeId = locationTypeId,
            Location = location,
            City = city,
            StateId = stateId
        };
        var jobPostId = await CreateJobPostDto(jobPostDto);
        jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);

        city = "Charlotte";
        state = states.Find(state => string.Equals(state.Name, "NORTH CAROLINA", StringComparison.OrdinalIgnoreCase));
        stateId = state?.Id;
        location = "location2";

        jobPostDto.Location = location;
        jobPostDto.City = city;
        jobPostDto.StateId = stateId;

        await AssertUpdateJobPostAsync(jobPostDto);
        jobPostDto = await AssertGetJobPostByIdAsync(jobPostId);

        Assert.Equal(workArrangementId, jobPostDto.WorkArrangementId);
        Assert.Equal(locationTypeId, jobPostDto.LocationTypeId);
        Assert.Equal(location, jobPostDto.Location);
        Assert.Equal(city, jobPostDto.City);
        Assert.Equal(stateId, jobPostDto.StateId);
    }

    [Fact]
    public async Task ShouldValidateWorkSiteLocationWhenRemote()
    {
        var applicationFormId = await CreateForm("Test Form" + DateTime.Now.Ticks);
        var workArrangementId = (long)WorkArrangement.Remote;
        var states = await GetStatesAsync();
        var expectedLocation = WorkArrangement.Remote.ToString();

        var jobPostsDto = new List<JobPostDto>
        {
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Descrption For the Given Job Post",EmployeeTypeId = 4, EEOClassId = 12, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), WorkArrangementId = workArrangementId, Location = "location1", City = "New Jersey", StateId = states.FirstOrDefault()?.Id, IsSubmitted = true  },
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Sample Descrption", WorkArrangementId = workArrangementId, Location = "location1", City = "New Jersey", StateId = states.FirstOrDefault()?.Id, IsSubmitted =false }
        };
        for (int i = 0; i < jobPostsDto.Count; i++)
        {
            var JobPost = await GetJobpostList(jobPostsDto[i]);

            Assert.Equal(expectedLocation, JobPost.WorksiteLocation);
        }
    }

    [Fact]
    public async Task ShouldValidateWorkSiteLocationWhenOnSiteCustom()
    {
        var applicationFormId = await CreateForm("Test Form" + DateTime.Now.Ticks);
        var workArrangementId = (long)WorkArrangement.Onsite;
        var states = await GetStatesAsync();
        var expectedLocation = "Location-Custom";

        var jobPostsDto = new List<JobPostDto>
        {
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Descrption For the Given Job Post",EmployeeTypeId = 4, EEOClassId = 12, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), WorkArrangementId = workArrangementId, Location = expectedLocation, City = "New Jersey", StateId = states.FirstOrDefault()?.Id, LocationTypeId = (long)LocationType.CustomLocation, IsSubmitted = true  },
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Sample Descrption", WorkArrangementId = workArrangementId, Location = expectedLocation, City = "New Jersey", StateId = states.FirstOrDefault()?.Id, LocationTypeId = (long)LocationType.CustomLocation, IsSubmitted =false }
        };
        for (int i = 0; i < jobPostsDto.Count; i++)
        {
            var JobPostList = await GetJobpostList(jobPostsDto[i]);

            Assert.Equal(expectedLocation, JobPostList.WorksiteLocation);
        }
    }

    [Fact]
    public async Task ShouldValidateWorkSiteLocationWhenOnSite()
    {
        var applicationFormId = await CreateForm("Test Form" + DateTime.Now.Ticks);
        var companyCode = 999999;
        var workSiteLocations = await GetWorkSiteLocation(companyCode);

        var workArrangementId = (long)WorkArrangement.Onsite;
        var expectedLocation = workSiteLocations.FirstOrDefault();

        var jobPostsDto = new List<JobPostDto>
        {
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Descrption For the Given Job Post",EmployeeTypeId = 4, EEOClassId = 12, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), WorkArrangementId = workArrangementId, LocationTypeId = (long)LocationType.WorksiteLocation, WorksiteLocationId = expectedLocation?.Id, IsSubmitted = true  },
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Sample Descrption", WorkArrangementId = workArrangementId, LocationTypeId = (long)LocationType.WorksiteLocation, WorksiteLocationId = expectedLocation?.Id, IsSubmitted =false }
        };

        for (int i = 0; i < jobPostsDto.Count; i++)
        {
            var JobPostList = await GetJobpostList(jobPostsDto[i]);

            Assert.Equal(expectedLocation?.Name, JobPostList.WorksiteLocation);
        }
    }

    [Fact]
    public async Task ShouldValidateWorkSiteLocationWhenHybridCustom()
    {
        var applicationFormId = await CreateForm("Test Form" + DateTime.Now.Ticks);
        var workArrangementId = (long)WorkArrangement.Hybrid;
        var states = await GetStatesAsync();
        var expectedLocation = "Location-Custom";

        var jobPostsDto = new List<JobPostDto>
        {
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Descrption For the Given Job Post",EmployeeTypeId = 4, EEOClassId = 12, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), WorkArrangementId = workArrangementId, Location = expectedLocation, City = "New Jersey", StateId = states.FirstOrDefault()?.Id, LocationTypeId = (long)LocationType.CustomLocation, IsSubmitted = true  },
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Sample Descrption", WorkArrangementId = workArrangementId, Location = expectedLocation, City = "New Jersey", StateId = states.FirstOrDefault()?.Id, LocationTypeId = (long)LocationType.CustomLocation, IsSubmitted =false }
        };
        for (int i = 0; i < jobPostsDto.Count; i++)
        {
            var JobPostList = await GetJobpostList(jobPostsDto[i]);

            Assert.Equal(expectedLocation, JobPostList.WorksiteLocation);
        }
    }

    [Fact]
    public async Task ShouldValidateWorkSiteLocationWhenHybrid()
    {
        var applicationFormId = await CreateForm("Test Form" + DateTime.Now.Ticks);
        var companyCode = 888888;
        var workSiteLocations = await GetWorkSiteLocation(companyCode);

        var workArrangementId = (long)WorkArrangement.Hybrid;
        var expectedLocation = workSiteLocations.FirstOrDefault();

        var jobPostsDto = new List<JobPostDto>
        {
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Descrption For the Given Job Post",EmployeeTypeId = 4, EEOClassId = 12, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), WorkArrangementId = workArrangementId, LocationTypeId = (long)LocationType.WorksiteLocation, WorksiteLocationId = expectedLocation?.Id, IsSubmitted = true  },
            new JobPostDto { ApplicationFormId = applicationFormId, Title = "JP" + DateTime.Now.Ticks, IsActive = true, Description = "Sample Descrption", WorkArrangementId = workArrangementId, LocationTypeId = (long)LocationType.WorksiteLocation, WorksiteLocationId = expectedLocation?.Id, IsSubmitted =false }
        };

        for (int i = 0; i < jobPostsDto.Count; i++)
        {
            var JobPostList = await GetJobpostList(jobPostsDto[i]);

            Assert.Equal(expectedLocation?.Name, JobPostList.WorksiteLocation);
        }
    }

    [Fact]
    public async Task ShouldGetInterviewersList()
    {
        var result = await _userController.GetInterviewers();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var interviewers = Assert.IsType<List<UserDto>>(actionResult.Value);
        Assert.NotNull(interviewers);
    }

    [Fact]
    public async Task ShouldFailSubmitJobpostWhenMinSalaryFormatIsNotCorrectRangeForHourlyPayMethod()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = 3454.4545m, MaxSalary = 53234.54m, Salary = null, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var validationException = await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _jobPostsController.Create(jobPostDto));
        Assert.Equal(JobPostValidation.JobPostInvalidMinSalaryFormat, validationException.Message);
    }

    [Fact]
    public async Task ShouldFailSubmitJobpostWhenMaxSalaryFormatIsNotCorrectRangeForHourlyPayMethod()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = 3454.45m, MaxSalary = 53234.544m, Salary = null, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var validationException = await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _jobPostsController.Create(jobPostDto));
        Assert.Equal(JobPostValidation.JobPostInvalidMaxSalaryFormat, validationException.Message);
    }

    [Fact]
    public async Task ShouldFailSubmitJobpostWhenSingleSalaryFormatIsNotCorrectForHourlyPayMethod()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = null, MaxSalary = null, Salary = 53234.5244m, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var validationException = await Assert.ThrowsAsync<BBSI.ATS.Common.Exceptions.ValidationException>(() => _jobPostsController.Create(jobPostDto));
        Assert.Equal(JobPostValidation.JobPostInvalidSalaryFormat, validationException.Message);
    }

    [Fact]
    public async Task ShouldSubmitJobPostForHourlyPayMethodForRange()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = 3454.45m, MaxSalary = 53234.54m, Salary = null, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var jobPostDB = await _jobPostService.GetByIdAsync(jobPost.Id);
        Assert.NotNull(jobPostDB);
        Assert.NotEmpty(jobPostDB.Title);
        Assert.Equal(jobPostDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDB.StartDate, jobPostDto.StartDate);
        Assert.Equal(jobPostDB.EndDate, jobPostDto.EndDate);
        Assert.Equal(jobPostDB.MinSalary, jobPostDto.MinSalary);
        Assert.Equal(jobPostDB.MaxSalary, jobPostDto.MaxSalary);
    }

    [Fact]
    public async Task ShouldSubmitJobPostForHourlyPayMethodForSingleSalary()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = null, MaxSalary = null, Salary = 8999.99m, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var jobPostDB = await _jobPostService.GetByIdAsync(jobPost.Id);
        Assert.NotNull(jobPostDB);
        Assert.NotEmpty(jobPostDB.Title);
        Assert.Equal(jobPostDB.Title, jobPostDto.Title);
        Assert.Equal(jobPostDB.Salary, jobPostDto.Salary);
    }

    [Fact]
    public async Task ShouldSubmitJobPostWithDriverPayMethodWithOnlyComments()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Weekly, PayMethodId = (long)PayMethod.Driver, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = null, MaxSalary = null, Salary = null, SalaryComments = "Please provide annual basis", StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var jobPostDB = await _jobPostService.GetByIdAsync(jobPost.Id);
        Assert.NotNull(jobPostDB);
        Assert.Equal(jobPostDB.SalaryComments, jobPostDto.SalaryComments);
    }

    [Fact]
    public async Task ShouldSubmitJobPostWithCommissionPayMethodWithSingleSalaryAndComments()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Weekly, PayMethodId = (long)PayMethod.Commission, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = null, MaxSalary = null, Salary = 10000.10m, SalaryComments = "Commission paymethod - Please provide annual basis", StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var jobPostDB = await _jobPostService.GetByIdAsync(jobPost.Id);
        Assert.NotNull(jobPostDB);
        Assert.Equal(jobPostDB.Salary, jobPostDto.Salary);
        Assert.Equal(jobPostDB.SalaryComments, jobPostDto.SalaryComments);
    }

    [Fact]
    public async Task ShouldUpdateJobPostForHourlyPayMethodForRange()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = 3454.45m, MaxSalary = 53234.54m, Salary = null, SalaryComments = null, StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var jobPostDB = await _jobPostService.GetByIdAsync(jobPost.Id);
        Assert.NotNull(jobPostDB);
        Assert.Equal(jobPostDB.MinSalary, jobPostDto.MinSalary);
        Assert.Equal(jobPostDB.MaxSalary, jobPostDto.MaxSalary);

        var salary = 20000m;
        jobPostDB.Salary = salary;
        jobPostDB.MinSalary = null;
        jobPostDB.MaxSalary = null;
        await _jobPostsController.Update(jobPostDB);

        var afterUpdateJobPostFromDBResult = await _jobPostsController.GetById(jobPost.Id);
        var afterUpdateJobPostOkResult = Assert.IsType<OkObjectResult>(afterUpdateJobPostFromDBResult.Result);
        var afterUpdateJobPostFromDB = Assert.IsType<JobPostDto>(afterUpdateJobPostOkResult.Value);
        Assert.NotNull(afterUpdateJobPostFromDB);
        Assert.NotNull(afterUpdateJobPostFromDB.Salary);
        Assert.True(afterUpdateJobPostFromDB.Salary == salary);
    }

    [Fact]
    public async Task ShouldUpdateJobPostWithCommissionPayMethodWithSingleSalaryAndComments()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Commission, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = 3454.45m, MaxSalary = null, Salary = 22000.54m, SalaryComments = "Commission paymethod - Please provide monthly basis", StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var jobPostDB = await _jobPostService.GetByIdAsync(jobPost.Id);
        Assert.NotNull(jobPostDB);
        Assert.Equal(jobPostDB.MinSalary, jobPostDto.MinSalary);
        Assert.Equal(jobPostDB.MaxSalary, jobPostDto.MaxSalary);

        var salary = 20000m;
        jobPostDB.Salary = salary;
        jobPostDB.MinSalary = null;
        jobPostDB.MaxSalary = null;
        await _jobPostsController.Update(jobPostDB);

        var afterUpdateJobPostFromDBResult = await _jobPostsController.GetById(jobPost.Id);
        var afterUpdateJobPostOkResult = Assert.IsType<OkObjectResult>(afterUpdateJobPostFromDBResult.Result);
        var afterUpdateJobPostFromDB = Assert.IsType<JobPostDto>(afterUpdateJobPostOkResult.Value);
        Assert.NotNull(afterUpdateJobPostFromDB);
        Assert.NotNull(afterUpdateJobPostFromDB.Salary);
        Assert.True(afterUpdateJobPostFromDB.Salary == salary);
    }

    [Fact]
    public async Task ShouldUpdateJobPostWithDriverPayMethodWithOnlyComments()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);
        //save a job post  and assert it
        var jobPostDto = new JobPostDto { Title = "Title" + DateTime.Now.Ticks, Description = "Salesforce Developer", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Driver, StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(2)), IsSubmitted = true, MinSalary = null, MaxSalary = null, Salary = null, SalaryComments = "Driver paymethod - Please provide annual basis", StartDateTime = DateTime.UtcNow.AddDays(1), EndDateTime = DateTime.UtcNow.AddDays(2) };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var jobPost = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(jobPost.Id > 0);

        var jobPostDB = await _jobPostService.GetByIdAsync(jobPost.Id);
        Assert.NotNull(jobPostDB);
        Assert.NotNull(jobPostDB.SalaryComments);
        Assert.Equal(jobPostDB.SalaryComments, jobPostDto.SalaryComments);

        jobPostDB.SalaryComments = "Driver paymethod, provide annual basis with 20% subsequent increments";
        await _jobPostsController.Update(jobPostDB);

        var afterUpdateJobPostFromDBResult = await _jobPostsController.GetById(jobPost.Id);
        var afterUpdateJobPostOkResult = Assert.IsType<OkObjectResult>(afterUpdateJobPostFromDBResult.Result);
        var afterUpdateJobPostFromDB = Assert.IsType<JobPostDto>(afterUpdateJobPostOkResult.Value);
        Assert.NotNull(afterUpdateJobPostFromDB);
        Assert.NotNull(afterUpdateJobPostFromDB.SalaryComments);
        Assert.Equal(afterUpdateJobPostFromDB.SalaryComments, jobPostDB.SalaryComments);
    }

    [Fact]
    public async Task ShouldFailGetJobPostWhenApplicationFormIsInActive()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateInActiveForm(formName);
        Assert.True(id > 0);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "Title22", IsActive = true, Description = "Descrption For the Given Job Post", CategoryId = 1, EEOClassId = 6, EmployeeTypeId = 1, PayGroupId = 17, PayMethodId = 24, StartDate = DateOnly.FromDateTime(DateTime.Now), IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);

        var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
        Assert.True(createdResponse.Id > 0);

        var getjobpost = await _jobPostsController.GetById(createdResponse.Id);
        Assert.NotNull(getjobpost);
        var jobResult = Assert.IsType<OkObjectResult>(getjobpost.Result);
        var jobPostResultValue = jobResult.Value;
        Assert.NotNull(jobPostResultValue);

        JobPostDto jobPostDtoDB = (JobPostDto)jobPostResultValue;
        Assert.NotNull(jobPostDtoDB);
        Assert.True(jobPostDtoDB.LinkId != null);
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.GetByLinkIdAsync((Guid)jobPostDtoDB.LinkId));
        Assert.Equal(InActiveApplicationForm, exception.Message);
    }

    [Fact]
    public async Task ShouldGetActiveJobPostsByLocation()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPosts = new List<JobPostDto>
            {
                new JobPostDto { ApplicationFormId = id, Title = "Title2000", IsActive = true, Description = "Descrption For the Given Job Post", WorkArrangementId = 29,LocationTypeId=31,City="Hyderabad",StateId=56,Location="Osi-Digital1",IsSubmitted =true, StartDate =  DateOnly.FromDateTime(DateTime.Now) ,StartDateTime=DateTime.UtcNow},
                new JobPostDto { ApplicationFormId = id, Title = "Title2001", IsActive = true, Description = "Sample Descrption",WorkArrangementId = 29,LocationTypeId=31,City="Hyderabad",StateId=56,Location="Osi-Digital2",IsSubmitted =true, StartDate =  DateOnly.FromDateTime(DateTime.Now),StartDateTime=DateTime.UtcNow  }
            };

        for (int i = 0; i < jobPosts.Count; i++)
        {
            var jobPost = jobPosts[i];
            var jobPostResult = await _jobPostsController.Create(jobPost);

            var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
            var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
            Assert.True(createdResponse.Id > 0);
        }
        var result = await _jobPostsController.GetActiveJobPostsByLocationAsync();
        Assert.IsType<ActionResult<List<NameCountPairDto>>>(result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsAssignableFrom<List<NameCountPairDto>>(okResult.Value);
        Assert.NotEmpty(model);
    }

    [Fact]
    public async Task ShouldCreateJobPostWithQuiz()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);

        var quizName = $"Quiz-{DateTime.Now.Ticks}";
        var isQuizActive = true;
        var quizId = await CreateApplicantQuiz(quizName, isQuizActive);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "JobPostTitle-" + DateTime.Now.Ticks, Description = "JobPost Description", ApplicantQuizId = quizId, IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostDto = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(createdJobPostDto.Id > 0);

        var jobPost = await _jobPostsController.GetById(createdJobPostDto.Id);
        var okResult = Assert.IsType<OkObjectResult>(jobPost.Result);
        var returnValue = Assert.IsType<JobPostDto>(okResult.Value);
        Assert.NotNull(returnValue);
        Assert.Equal(quizId, returnValue.ApplicantQuizId);
    }

    [Fact]
    public async Task ShouldFailCreateJobPostWithInactiveQuiz()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);

        var quizName = $"Quiz-{DateTime.Now.Ticks}";
        var isQuizActive = false;
        var quizId = await CreateApplicantQuiz(quizName, isQuizActive);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "JobPostTitle-" + DateTime.Now.Ticks, Description = "JobPost Description", ApplicantQuizId = quizId, IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Create(jobPostDto));
        Assert.Equal(ApplicantQuizValidation.InActiveApplicantQuiz, exception.Message);
    }

    [Fact]
    public async Task ShouldUpdateJobPostWithQuiz()
    {
        var jobPostDto = await AssertCreateJobPostForSubmit();
        Assert.True(jobPostDto.Id > 0);

        var jobPostFromDBResult = await _jobPostsController.GetById(jobPostDto.Id);
        var jobPostFromDBOkResult = Assert.IsType<OkObjectResult>(jobPostFromDBResult.Result);
        var jobPostFromDB = Assert.IsType<JobPostDto>(jobPostFromDBOkResult.Value);
        Assert.NotNull(jobPostFromDB);

        var quizName = $"Quiz-{DateTime.Now.Ticks}";
        var isQuizActive = true;
        var quizId = await CreateApplicantQuiz(quizName, isQuizActive);

        jobPostFromDB.ApplicantQuizId = quizId;
        jobPostFromDB.Id = jobPostDto.Id;
        await _jobPostsController.Update(jobPostFromDB);

        var afterUpdateJobPostFromDBResult = await _jobPostsController.GetById(jobPostDto.Id);
        var afterUpdateJobPostOkResult = Assert.IsType<OkObjectResult>(afterUpdateJobPostFromDBResult.Result);
        var afterUpdateJobPostFromDB = Assert.IsType<JobPostDto>(afterUpdateJobPostOkResult.Value);
        Assert.NotNull(afterUpdateJobPostFromDB);
        Assert.True(afterUpdateJobPostFromDB.ApplicantQuizId == quizId);
    }

    [Fact]
    public async Task ShouldFailUpdateJobPostWithInActiveQuiz()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);

        var jobPostDto = new JobPostDto { ApplicationFormId = id, Title = "JobPostTitle-" + DateTime.Now.Ticks, Description = "JobPost Description", IsSubmitted = true, StartDateTime = DateTime.UtcNow };
        var jobPostResult = await _jobPostsController.Create(jobPostDto);
        var jobPostOkResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
        var createdJobPostDto = Assert.IsType<CreatedResponse>(jobPostOkResult.Value);
        Assert.True(createdJobPostDto.Id > 0);

        var jobPostFromDBResult = await _jobPostsController.GetById(createdJobPostDto.Id);
        var jobPostFromDBOkResult = Assert.IsType<OkObjectResult>(jobPostFromDBResult.Result);
        var jobPostFromDB = Assert.IsType<JobPostDto>(jobPostFromDBOkResult.Value);
        Assert.NotNull(jobPostFromDB);

        var quizName = $"Quiz-{DateTime.Now.Ticks}";
        var isQuizActive = false;
        var quizId = await CreateApplicantQuiz(quizName, isQuizActive);

        jobPostFromDB.ApplicantQuizId = quizId;
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _jobPostsController.Update(jobPostFromDB));
        Assert.Equal(ApplicantQuizValidation.InActiveApplicantQuiz, exception.Message);
    }

    [Fact]
    public async Task ShouldGetActiveJobPostsCount()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var id = await CreateForm(formName);
        Assert.True(id > 0);

        var jobPosts = new List<JobPostDto>
            {
                new JobPostDto { ApplicationFormId = id, Title = "Title2000", IsActive = true, Description = "Descrption For the Given Job Post", WorkArrangementId = 29,LocationTypeId=31,City="Hyderabad",StateId=56,Location="Osi-Digital1",IsSubmitted =true, StartDateTime = DateTime.UtcNow  },
                new JobPostDto { ApplicationFormId = id, Title = "Title2001", IsActive = true, Description = "Sample Descrption",WorkArrangementId = 29,LocationTypeId=31,City="Hyderabad",StateId=56,Location="Osi-Digital2",IsSubmitted =true, StartDateTime = DateTime.UtcNow  }
            };

        for (int i = 0; i < jobPosts.Count; i++)
        {
            var jobPost = jobPosts[i];
            var jobPostResult = await _jobPostsController.Create(jobPost);

            var insertJobPostResult = Assert.IsType<OkObjectResult>(jobPostResult.Result);
            var createdResponse = Assert.IsType<CreatedResponse>(insertJobPostResult.Value);
            Assert.True(createdResponse.Id > 0);
        }
        var result = await _jobPostsController.GetActiveJobPostsCountAsync();
        var okResult = Assert.IsType<OkObjectResult>(result);
        var returnValue = okResult.Value as dynamic;

        Assert.NotNull(returnValue);
    }

    [Fact]
    public async Task ShouldGetActiveJobPostsForCompanyIdentifier()
    {
        var formName = $"form-{DateTime.Now.Ticks}";
        var formId = await CreateForm(formName);
        Assert.True(formId > 0);

        var companyCode = 111815;
        var companyId = await CreateCompany(companyCode);
        Assert.True(companyId > 0);
        _currentUserContext.CompanyId = companyId;

        var jobPostTitle = $"Title-{DateTime.Now.Ticks}";
        var jobPostDto = new JobPostDto { Title = jobPostTitle, Description = "Description", EmployeeTypeId = 4, EEOClassId = 12, ApplicationFormId = formId, PayGroupId = 17, PayMethodId = (long)PayMethod.Hourly, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), IsActive = true, IsSubmitted = true, WorkArrangementId = 27, WorksiteLocationId = null, LocationTypeId = null, CCEmailAddresses = "user1@company1.com", SalaryComments = "SalaryComment", Salary = 10000.00m, StartDateTime = DateTime.UtcNow };
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.True(jobPostId > 0);

        var company = _companyService.GetByCodeAsync(companyCode);
        var identifier = company.Result.Identifier;

        var result = await _jobPostsController.GetByCompanyIdentifierAsync(identifier!.Value);
        Assert.NotNull(result.Result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var jobPostsByCompany = Assert.IsType<List<CompanyJobPostsDto>>(okResult.Value);
        Assert.NotNull(jobPostsByCompany);

        var insertedJobPost = jobPostsByCompany.Find(jp => jp.Id == jobPostId);
        Assert.NotNull(insertedJobPost);
        Assert.NotNull(insertedJobPost.Title);
        Assert.Equal(insertedJobPost.Title, jobPostDto.Title);
        Assert.Equal(insertedJobPost.Description, jobPostDto.Description);
    }

    #region Private Methods

    private async Task<long> CreateCompanyJobBoard()
    {
        var jobBoards = await _companyJobBoardService.GetAllJobBoardsAsync();
        if (!jobBoards.Any(board => board.IsActive != false))
        {
            var companyJobBoardDto = new CompanyJobBoardDto
            {
                CompanyJobBoardId = (long)JobBoard.Indeed,
                EmailAddress = "user@gmail.com",
                IsActive = true
            };
            var jobBoardId = await _companyJobBoardService.AddAsync(companyJobBoardDto);
            Assert.True(jobBoardId > 0);
            return jobBoardId.Value;
        }
        return jobBoards.First().Id;
    }

    private async Task<long> CreateForm(string formName)
    {
        var Options = new List<ApplicationFormFieldOptionDto> {
                            new() {Name = "Washington"},
                            new () {Name = "New York"} };

        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "state", TypeId = (long)ApplicationFormFieldTypes.Dropdown, Options = Options } };
        var formDto = new ApplicationFormDto { Name = formName, Fields = formFields };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var applicationFormResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        return applicationFormResponse.Id;
    }

    private async Task<long> CreateInActiveForm(string formName)
    {
        var Options = new List<ApplicationFormFieldOptionDto> {
                            new() {Name = "Washington"},
                            new () {Name = "New York"} };

        var formFields = new List<ApplicationFormFieldDto> { new() { DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, IsSystemDefault = false, SectionId = (long)ApplicationFormSections.PersonalInformation, Name = "state", TypeId = (long)ApplicationFormFieldTypes.Dropdown, Options = Options } };
        var formDto = new ApplicationFormDto { Name = formName, Fields = formFields, IsActive = false };
        var result = await _formController.Create(formDto);
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var applicationFormResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        return applicationFormResponse.Id;
    }

    private async Task<JobPostDto> AssertCreateJobPostForSubmit()
    {
        var jobPostDto = new JobPostDto { Title = "jobPost1" + DateTime.Now.Ticks, IsSubmitted = false };
        long id = await CreateJobPostDto(jobPostDto);
        jobPostDto.Id = id;
        return jobPostDto;
    }

    private async Task<long> CreateJobPostDto(JobPostDto jobPostDto)
    {
        if (jobPostDto.IsSubmitted == true && jobPostDto.StartDateTime == null)
            jobPostDto.StartDateTime = DateTime.UtcNow;
        //Act
        var result = await _jobPostsController.Create(jobPostDto);

        //Assert
        var insertResult = Assert.IsType<OkObjectResult>(result.Result);
        var createdResponse = Assert.IsType<CreatedResponse>(insertResult.Value);
        return createdResponse.Id;
    }

    private async Task<JobPostDto> AssertGetJobPostByIdAsync(long id)
    {
        // Act
        var result = await _jobPostsController.GetById(id);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnValue = Assert.IsType<JobPostDto>(okResult.Value);
        Assert.True(returnValue.Id > 0);
        return returnValue;
    }

    private async Task AssertUpdateJobPostAsync(JobPostDto jobPostDto)
    {
        var result = await _jobPostsController.Update(jobPostDto);
        Assert.IsType<OkResult>(result);
    }

    private async Task<long> CreateCompany(int companyCode)
    {
        var companyDto = new CompanyDto
        {
            CompanyCode = companyCode,
            LegalName = $"Company Legal Name-{companyCode}",
            DbaName = $"Company DBA Name-{companyCode}",
            StatusCode = "A",
        };

        var createdCompanyId = await _companyService.SaveAsync(companyDto);
        Assert.True(createdCompanyId > 0);
        return createdCompanyId;
    }

    private List<WorksiteLocationDto> CreateWorksiteLocationDtoListObject()
    {
        return new List<WorksiteLocationDto>
                    {
                        new()
                        {
                            Code = "11118",
                            Addr1 = "Test Address 122",
                            Addr2 = "Test Address 222",
                            City = "TestCity",
                            State = "NY",
                            Country = "United States",
                            IsActive = true,
                            Name = "Test Location1",
                            ZipCode = "000101"
                        }
                    };
    }

    private async Task<List<NameIdPairDto>> GetStatesAsync()
    {
        var result = await _metadataController.GetStates();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var states = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);
        Assert.NotNull(states);
        return states;
    }

    private async Task<JobPostListDto> GetJobpostList(JobPostDto jobPostDto)
    {
        var jobPostId = await CreateJobPostDto(jobPostDto);
        Assert.True(jobPostId > 0);

        var jobPostListResult = await _jobPostsController.GetList(jobPostDto.IsSubmitted);
        Assert.IsType<ActionResult<IEnumerable<JobPostListDto>>>(jobPostListResult);
        var jobPostListOkResult = Assert.IsType<OkObjectResult>(jobPostListResult.Result);
        var jobList = Assert.IsAssignableFrom<IEnumerable<JobPostListDto>>(jobPostListOkResult.Value);
        Assert.NotNull(jobList);

        var JobPost = jobList.FirstOrDefault(jobPost => jobPost.Id == jobPostId);
        Assert.NotNull(JobPost);

        return JobPost;
    }

    private async Task<IEnumerable<WorksiteLocationDto>> GetWorkSiteLocation(int companyCode)
    {
        var companyId = await CreateCompany(companyCode);
        Assert.True(companyId > 0);

        var worksiteLocationsDto = CreateWorksiteLocationDtoListObject();
        await _companyService.SaveWorksiteLocationsAsync(companyCode, worksiteLocationsDto);
        var result = await _companyController.GetWorksiteLocationsByCompanyId(companyId);
        Assert.IsType<ActionResult<IEnumerable<WorksiteLocationDto>>>(result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var workSiteLocations = Assert.IsAssignableFrom<IEnumerable<WorksiteLocationDto>>(okResult.Value);
        Assert.NotNull(workSiteLocations);
        _currentUserContext.CompanyId = companyId;
        return workSiteLocations;
    }

    private async Task<List<UserDto>> GetHiringManagersAsync()
    {
        var result = await _userController.GetHiringManagers();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var hiringManagers = Assert.IsType<List<UserDto>>(actionResult.Value);
        Assert.NotNull(hiringManagers);
        return hiringManagers;
    }

    private async Task<long> CreateApplicantQuiz(string quizName, bool isActive)
    {
        var applicantQuiz = new ApplicantQuizDto
        {
            Name = quizName,
            MinimumPassingScore = 20,
            Description = "Description",
            IsActive = isActive,
            QuizQuestions =
            [
                new()
            {
                Question ="Test Question",
                TypeId = (long)QuestionType.MultipleChoice,
                Score = 21,
                IsActive = true,
                IsRequired = true,
                Answers =
                [
                    new()
                    {
                        Answer="test answer 1",
                        IsCorrect=true,
                    },
                    new()
                    {
                        Answer="test answer 2",
                        IsCorrect=false,
                    },
                    new()
                    {
                        Answer="test answer 3",
                        IsCorrect=false,
                    },
                ]
                }
            ]
        };

        var applicantQuizId = await _applicantQuizService.AddAsync(applicantQuiz);
        Assert.NotNull(applicantQuizId);
        Assert.True(applicantQuizId > 0);

        return applicantQuizId.Value;
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}