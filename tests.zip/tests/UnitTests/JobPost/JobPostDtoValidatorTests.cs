﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests
{
    public class JobPostDtoValidatorTests
    {
        private readonly JobPostDtoValidator _validator;

        public JobPostDtoValidatorTests()
        {
            _validator = new JobPostDtoValidator();
        }

        [Fact]
        public void ShouldFailDescriptionIsNullWhenSubmitted()
        {
            var jobPostDto = new JobPostDto { Title = "Title1", IsSubmitted = true };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.Description);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.DescriptionRequired);
        }

        [Fact]
        public void ShouldFailTitleIsNull()
        {
            var jobPostDto = new JobPostDto { Description = "Job Post Description" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.Title);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.TitleRequired);
        }

        [Fact]
        public void ShouldReturnErrorDescriptionIsEmptyWhenSubmitted()
        {
            var jobPostDto = new JobPostDto { Title = "Title1", Description = string.Empty, IsSubmitted = true };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.Description);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.DescriptionRequired);
        }

        [Fact]
        public void ShouldReturnErrorTitleIsEmpty()
        {
            var jobPostDto = new JobPostDto { Title = string.Empty, Description = "Job Post Description" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.Title);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.TitleRequired);
        }

        [Fact]
        public void ShouldReturnErrorTitleMaxLengthExceeded()
        {
            var jobPostDto = new JobPostDto { Title = "012345678901234567890123456789012345678901234567890123456789", Description = "Job Post Description" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.Title);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.TitleMaxLengthExceededMessage);
        }

        [Fact]
        public void ShouldSuccessValidDescription()
        {
            var jobPostDto = new JobPostDto { Description = "Job Post Description" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.Description);
        }

        [Fact]
        public void ShouldSuccessValidTitle()
        {
            var jobPostDto = new JobPostDto { Title = "Title1" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.Title);
        }

        [Fact]
        public void ShouldSuccessValidTitleAndDescription()
        {
            var jobPostDto = new JobPostDto { Title = "Title1", Description = "Job Post Description" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.Title);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.Description);
        }

        [Fact]
        public void ShouldSuccessValidEmail()
        {
            var jobPostDto = new JobPostDto { CCEmailAddresses = "user1@company1.com" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.CCEmailAddresses);
        }

        [Fact]
        public void ShouldSuccessValidEmails()
        {
            var jobPostDto = new JobPostDto { CCEmailAddresses = "user1@company1.com, user2@company1.com" };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.CCEmailAddresses);
        }

        //[Fact]
        //public void ShouldFailInValidEmail()
        //{
        //    var emailAddress = "user1company1.com";
        //    var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, CCEmailAddresses = emailAddress, Description = "AWS Architech", PayMethodId = 22, PayGroupId = 17, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)) };
        //    var result = _validator.TestValidate(jobPostDto);
        //    Assert.NotNull(result);
        //    Assert.IsType<TestValidationResult<JobPostDto>>(result);
        //    var validationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.CCEmailAddresses);
        //    Assert.True(validationResult.First().ErrorMessage == string.Format(JobPostValidation.EmailInvalid, emailAddress));
        //}

        [Fact]
        public void ShouldReturnErrorWhenPayGroupIdIsEmptyOnSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, PayMethodId = 26, IsSubmitted = true };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.PayGroupId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.PayGroupRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenPayMethodIdIsEmptyOnSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, PayGroupId = 17, IsSubmitted = true };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.PayMethodId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.PayMethodRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenWorksiteLocationIdIsEmptyForGivenLocationTypeOnSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, PayGroupId = 17, PayMethodId = 26, IsSubmitted = true, LocationTypeId = (long)LocationType.WorksiteLocation };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.WorksiteLocationId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.WorksiteLocationRequired);
        }

        [Fact]
        public void ShouldSuccessPayGroupIdIsEmptyWhenSaved()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, PayMethodId = 26, IsSubmitted = false };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.PayGroupId);
        }

        [Fact]
        public void ShouldSuccessPayMethodIdIsEmptyWhenSaved()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, PayGroupId = 17, IsSubmitted = false };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.PayMethodId);
        }

        [Fact]
        public void ShouldReturnErrorWhenStartIsEmptyOnSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Start date and end date checking", PayGroupId = 17, PayMethodId = 24, IsSubmitted = true };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.StartDateTime);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.StartDateRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenEndDateIsLessThanStartDateForSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Start date and end date checking", PayGroupId = 17, PayMethodId = 24, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)), StartDateTime = DateTime.UtcNow, EndDateTime = DateTime.Today.AddDays(-1) };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.EndDateTime);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.InvalidEndDate);
        }

        [Fact]
        public void ShouldSuccessWhenGiveValidStartDateAndEndDateForSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "AWS Architech", PayMethodId = 22, PayGroupId = 17, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)),StartDateTime=DateTime.UtcNow,EndDateTime=DateTime.UtcNow.AddDays(1) };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.StartDateTime);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.EndDateTime);
        }

        [Fact]
        public void ShouldReturnErrorWhenEmployeeTypeIdIsNullOrEmptyForSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Start date and end date checking", PayGroupId = 17, PayMethodId = 24, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)) };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.EmployeeTypeId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.EmployeeTypeRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenApplicationFormIdNullOrEmptyForSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Start date and end date checking", PayGroupId = 17, PayMethodId = 24, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)) };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.EmployeeTypeId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.EmployeeTypeRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenWorkArrangementIdIsEmptyForSubmit()
        {
            // Arrange
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = true,
                WorkArrangementId = null
            };

            // Act
            var result = _validator.TestValidate(jobPostDto);

            // Assert
            result.ShouldHaveValidationErrorFor(jobPost => jobPost.WorkArrangementId)
                  .WithErrorMessage(JobPostValidation.WorkArrangementRequired);
        }

        [Fact]
        public void ShouldNotReturnErrorWhenWorkArrangementIdIsNotEmptyForSubmit()
        {
            // Arrange
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = true,
                WorkArrangementId = 27
            };

            // Act
            var result = _validator.TestValidate(jobPostDto);

            // Assert
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.WorkArrangementId);
        }

        [Fact]
        public void ShouldNotReturnErrorWhenWorkArrangementIsEmptyForSave()
        {
            // Arrange
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = false,
                WorkArrangementId = null
            };

            // Act
            var result = _validator.TestValidate(jobPostDto);

            // Assert
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.WorkArrangementId);
        }

        [Fact]
        public void ShouldNotReturnErrorWhenRemoteWorkArrangementDataIsValid()
        {
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = true,
                WorkArrangementId = (long)WorkArrangement.Remote,
                City = "New York",
                Country = "United States"
            };

            var result = _validator.TestValidate(jobPostDto);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.City);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.Country);
        }

        [Fact]
        public void ShouldReturnErrorWhenRemoteWorkArrangementDataIsInValid()
        {
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = true,
                WorkArrangementId = (long)WorkArrangement.Remote,
                City = "012345678901234567890123456789012345678901234567890",
                Country = "012345678901234567890123456789012345678901234567890"
            };

            var result = _validator.TestValidate(jobPostDto);
            result.ShouldHaveValidationErrorFor(jobPost => jobPost.City).WithErrorMessage(JobPostValidation.CityMaxLengthExceededMessage);
            result.ShouldHaveValidationErrorFor(jobPost => jobPost.Country).WithErrorMessage(JobPostValidation.CountryMaxLengthExceededMessage);
        }

        [Fact]
        public void ShouldNotReturnErrorWhenCustomWorksiteLocationDataIsValid()
        {
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = true,
                WorkArrangementId = (long)WorkArrangement.Onsite,
                LocationTypeId = (long)LocationType.CustomLocation,
                Location = "location1",
                City = "New York",
                StateId = 63 //hardcoded, because DTO validator doesn't check if stateId is valid
            };

            var result = _validator.TestValidate(jobPostDto);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.Location);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.City);
            result.ShouldNotHaveValidationErrorFor(jobPost => jobPost.StateId);
        }

        [Fact]
        public void ShouldReturnErrorWhenCustomWorksiteLocationDataIsNullOREmpty()
        {
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = true,
                WorkArrangementId = (long)WorkArrangement.Onsite,
                LocationTypeId = (long)LocationType.CustomLocation,
                City = string.Empty,
                StateId = null
            };

            var result = _validator.TestValidate(jobPostDto);
            result.ShouldHaveValidationErrorFor(jobPost => jobPost.City).WithErrorMessage(JobPostValidation.CityRequired);
            result.ShouldHaveValidationErrorFor(jobPost => jobPost.StateId).WithErrorMessage(JobPostValidation.StateRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenCustomWorksiteLocationDataMaxLengthExceeded()
        {
            var jobPostDto = new JobPostDto
            {
                IsSubmitted = true,
                WorkArrangementId = (long)WorkArrangement.Onsite,
                LocationTypeId = (long)LocationType.CustomLocation,
                Location = "012345678901234567890123456789012345678901234567890",
                City = "012345678901234567890123456789012345678901234567890"
            };

            var result = _validator.TestValidate(jobPostDto);
            result.ShouldHaveValidationErrorFor(jobPost => jobPost.Location).WithErrorMessage(JobPostValidation.LocationMaxLengthExceededMessage);
            result.ShouldHaveValidationErrorFor(jobPost => jobPost.City).WithErrorMessage(JobPostValidation.CityMaxLengthExceededMessage);
        }

        [Fact]
        public void ShouldReturnErrorWhenSubmitMinSalaryLessThanZeroForSalaryRangeTypePayMethod()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Dynamic salary checking", PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Salary, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), MinSalary = -1, MaxSalary = 1000, Salary = null, SalaryComments = null };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.MinSalary);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.JobPostInvalidMinSalaryFormat);
        }

        [Fact]
        public void ShouldReturnErrorWhenSubmitMaxSalaryLessThanZeroForSalaryRangeTypeSalaryPayMethod()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Start date and end date checking", PayGroupId = 17, PayMethodId = 24, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), MinSalary = 1000, MaxSalary = -1, Salary = null, SalaryComments = null };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.MaxSalary);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.JobPostMaxSalaryRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenSubmitMaxSalaryLessThanMinSalaryForSalaryRangeTypeSalaryPayMethod()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Start date and end date checking", PayGroupId = 17, PayMethodId = 24, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), MinSalary = 1000, MaxSalary = -1, Salary = null, SalaryComments = null };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.MaxSalary);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.JobPostInvalidMaxSalary);
        }

        [Fact]
        public void ShouldReturnErrorWhenSubmitSingleSalaryLessThanZeroTypeSalaryPayMethod()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, Description = "Dynamic salary checking", PayGroupId = (long)PayGroup.Biweekly, PayMethodId = (long)PayMethod.Salary, IsSubmitted = true, StartDate = DateOnly.FromDateTime(DateTime.Today), EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(1)), MinSalary = null, MaxSalary = null, Salary = -1, SalaryComments = null };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.Salary);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.JobPostSalaryGreaterThanZero);
        }

        [Fact]
        public void ShouldReturnErrorWhenLocationTypeIsEmptyForGivenWorkArrangementOnSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, PayGroupId = 17, PayMethodId = 26, IsSubmitted = true, WorkArrangementId = (long)WorkArrangement.Onsite };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.LocationTypeId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.WorksiteLocationTypeRequired);
        }

        [Fact]
        public void ShouldReturnErrorWhenHiringManagerIsEmptyOnSubmit()
        {
            var jobPostDto = new JobPostDto { Title = "Title_" + DateTime.Now.Ticks, PayGroupId = 17, PayMethodId = 26, IsSubmitted = true, WorkArrangementId = (long)WorkArrangement.Remote };
            var result = _validator.TestValidate(jobPostDto);
            Assert.NotNull(result);
            Assert.IsType<TestValidationResult<JobPostDto>>(result);
            var testValidationResult = result.ShouldHaveValidationErrorFor(jobPost => jobPost.HiringManagerId);
            Assert.Contains(testValidationResult, result => result.ErrorMessage == JobPostValidation.HiringManagerRequired);
        }
    }
}