﻿using BBSI.ATS.Domain.Entities;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.Extensions.DependencyInjection;
using Moq;

namespace BBSI.ATS.UnitTests;

public class RolePrivilegeServiceTests : IDisposable
{
    private bool disposed = false;
    private readonly AtsDbContext _dbContext;
    private readonly Mock<IServiceScopeFactory> _mockScopeFactory;
    private readonly Mock<IServiceScope> _mockScope;
    private readonly Mock<IServiceProvider> _mockServiceProvider;
    private readonly RolePrivilegeService _rolePrivilegeService;

    public RolePrivilegeServiceTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();

        _mockScopeFactory = new Mock<IServiceScopeFactory>();
        _mockScope = new Mock<IServiceScope>();
        _mockServiceProvider = new Mock<IServiceProvider>();

        _mockScopeFactory.Setup(f => f.CreateScope()).Returns(_mockScope.Object);
        _mockScope.Setup(s => s.ServiceProvider).Returns(_mockServiceProvider.Object);
        _mockServiceProvider.Setup(p => p.GetService(typeof(AtsDbContext))).Returns(_dbContext);

        _rolePrivilegeService = new RolePrivilegeService(_mockScopeFactory.Object);
    }

    [Fact]
    public async Task ShouldReturnTrueWhenContainsRoleAndPrivilege()
    {
        var roles = new List<long> { 1, 2, 3 };
        var privilegeId = 1;
        _dbContext.RolePrivileges.Add(new RolePrivilege { RoleId = 1, PrivilegeId = privilegeId });
        await _dbContext.SaveChangesAsync();

        var result = await _rolePrivilegeService.HasRolePrivilegeAsync(roles, privilegeId);

        Assert.True(result);
    }

    [Fact]
    public async Task ShouldReturnFalseWhenRolePrivilegeNotContainsPrivilege()
    {
        var roles = new List<long> { 1, 2, 3 };
        var privilegeId = 999;

        var result = await _rolePrivilegeService.HasRolePrivilegeAsync(roles, privilegeId);

        Assert.False(result);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}
