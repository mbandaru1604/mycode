﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Configurations;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using static BBSI.ATS.Common.Constants;

namespace BBSI.ATS.UnitTests;

public class MetadataControllerTests : IDisposable
{
    private readonly MetaDataController _metaController;
    private readonly AtsDbContext _dbContext;
    private bool disposed = false;
    private readonly UsersController _userController;
    private readonly CurrentUserContext _currentUserContext;

    public MetadataControllerTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        var userContext = new CurrentUserContext() { UserId = 1, CompanyId = 1, RoleIds = [4, 1, 3] };
        var metadataRepository = new MetaDataRepository(_dbContext, userContext);
        var _repository = new AtsBaseRepository(_dbContext, new CurrentUserContext());
        var userRepository = new UserRepository(_dbContext, new CurrentUserContext());
        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        IMapper mapper = mappingConfig.CreateMapper();

        var metaDataService = new MetaDataService(metadataRepository, mapper);
        _metaController = new MetaDataController(metaDataService);
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        var unitOfWork = new UnitOfWork(_dbContext);
        var userService = new UserService(_repository, unitOfWork, userRepository, _currentUserContext);
        _userController = new UsersController(userService);
    }

    #region Get Application form default fields tests

    [Fact]
    public async Task ShouldReturnApplicationFormDefaultFields()
    {
        //Act
        var result = await _metaController.GetApplicationFormDefaultFields();

        //Assert
        var actionResult = Assert.IsType<ActionResult<IEnumerable<ApplicationFormDefaultFieldDto>>>(result).Result;
        Assert.IsType<OkObjectResult>(actionResult as OkObjectResult);
        var okResult = actionResult as OkObjectResult;
        Assert.NotNull(okResult);
        Assert.Equal(200, okResult.StatusCode);
    }

    [Fact]
    public async Task ShouldValidRequestReturnsDefaultFields()
    {
        // Act
        var result = await _metaController.GetApplicationFormDefaultFields();

        // Assert
        Assert.IsType<ActionResult<IEnumerable<ApplicationFormDefaultFieldDto>>>(result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsAssignableFrom<IEnumerable<ApplicationFormDefaultFieldDto>>(okResult.Value);

        var defaultFields = new List<ApplicationFormDefaultFieldDto>()
        {
            new() { Id = 1, Name = "First Name", DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 2, Name = "Middle Name", DisplayOrder = 2, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 3, Name = "Last Name", DisplayOrder = 3, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 4, Name = "Personal Email Address", DisplayOrder = 4, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.EmailAddress },
            new() { Id = 5, Name = "Home Telephone Number", DisplayOrder = 5, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.PhoneNumber },
            new() { Id = 6, Name = "Mobile Phone Number", DisplayOrder = 6, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.PhoneNumber },
            new() { Id = 7, Name = "Address Line 1", DisplayOrder = 7, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 8, Name = "Address Line 2", DisplayOrder = 8, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 9, Name = "Zip Code", DisplayOrder = 11, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 10, Name = "City", DisplayOrder = 9, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 11, Name = "State", DisplayOrder = 10, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.Dropdown, LookupTypeId = (long)LookupTypes.State },
            new() { Id = 12, Name = "Photo", DisplayOrder = 14, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.FileUpload },
            new() { Id = 13, Name = "Resume", DisplayOrder = 12, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.FileUpload },
            new() { Id = 14, Name = "Cover Letter", DisplayOrder = 13, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.FileUpload },
            new() { Id = 15, Name = "When are you available to start work?", DisplayOrder = 15, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.DatePicker },
            new() { Id = 16, Name = "Education Level", DisplayOrder = 16, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.Dropdown, LookupTypeId = (long)LookupTypes.EducationLevel },
            new() { Id = 17, Name = "School Major", DisplayOrder = 17, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 18, Name = "School Name", DisplayOrder = 18, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 19, Name = "Graduation Year", DisplayOrder = 19, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.DatePicker },
            new() { Id = 20, Name = "Notes", DisplayOrder = 20, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.ParagraphField },
            new() { Id = 21, Name = "Company Name", DisplayOrder = 21, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 22, Name = "Job Title", DisplayOrder = 22, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 23, Name = "Industry Type", DisplayOrder = 23, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 24, Name = "Start Date", DisplayOrder = 24, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.DatePicker },
            new() { Id = 25, Name = "End Date", DisplayOrder = 25, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.DatePicker }
        };

        foreach (var field in defaultFields)
        {
            Assert.Contains(model, f => f.Name == field.Name);
            var defaultField = model.FirstOrDefault(f => f.Name == field.Name);
            Assert.NotNull(defaultField);
            Assert.True(defaultField.IsActive == field.IsActive);
            Assert.True(defaultField.TypeId == field.TypeId);
            Assert.True(defaultField.SectionId == field.SectionId);
            Assert.True(defaultField.IsAlwaysActiveAndRequired == field.IsAlwaysActiveAndRequired);
            Assert.True(defaultField.IsRequired == field.IsRequired);
        }
    }

    #endregion Get Application form default fields tests

    #region Get Application form field types tests

    [Fact]
    public async Task ShouldReturnApplicationFormFieldTypes()
    {
        //Act
        var result = await _metaController.GetApplicationFormFieldTypes();

        //Assert
        var actionResult = Assert.IsType<ActionResult<IEnumerable<ApplicationFormFieldTypeDto>>>(result).Result;
        Assert.IsType<OkObjectResult>(actionResult as OkObjectResult);
        var okResult = actionResult as OkObjectResult;
        Assert.NotNull(okResult);
        Assert.Equal(200, okResult.StatusCode);
    }

    [Fact]
    public async Task ShouldReturnApplicationFormCustomFieldTypes()
    {
        //Act
        var result = await _metaController.GetApplicationFormCustomFieldTypes();

        //Assert
        var actionResult = Assert.IsType<ActionResult<IEnumerable<ApplicationFormFieldTypeDto>>>(result).Result;
        Assert.IsType<OkObjectResult>(actionResult as OkObjectResult);
        var okResult = actionResult as OkObjectResult;
        Assert.NotNull(okResult);
        Assert.Equal(200, okResult.StatusCode);
    }

    [Fact]
    public async Task ShouldValidRequestReturnsFieldTypes()
    {
        // Act
        var result = await _metaController.GetApplicationFormFieldTypes();

        // Assert
        Assert.IsType<ActionResult<IEnumerable<ApplicationFormFieldTypeDto>>>(result);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsAssignableFrom<IEnumerable<ApplicationFormFieldTypeDto>>(okResult.Value);

        var fieldTypes = new List<ApplicationFormFieldTypeDto>
        {
            new() { Id = 1, DisplayName = "Drop-down List", Name = "DropdownList" },
            new() { Id = 2, DisplayName = "File Upload", Name = "FileUpload" },
            new() { Id = 3, DisplayName = "Single Line Input", Name = "SingleLineInput" },
            new() { Id = 4, DisplayName = "Paragraph Field", Name = "ParagraphField" }
        };

        foreach (var type in fieldTypes)
        {
            Assert.Contains(model, f => f.Name == type.Name);
        }
    }

    #endregion Get Application form field types tests

    #region Get Pay Groups and Pay Methods tests

    [Fact]
    public async Task ShouldReturnGetPayGroups()
    {
        //Act
        var result = await _metaController.GetPayGroups();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var payGroupsFromDB = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(payGroupsFromDB);
        Assert.True(payGroupsFromDB.Count > 0);
    }

    [Fact]
    public async Task ShouldReturnGetPayMethods()
    {
        //Act
        var result = await _metaController.GetPayMethods();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var payMethodsFromDB = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(payMethodsFromDB);
        Assert.True(payMethodsFromDB.Count > 0);
    }

    #endregion Get Pay Groups and Pay Methods tests

    #region Get Employee Type and EEO Class tests

    [Fact]
    public async Task ShouldReturnEmployeeTypes()
    {
        //Act
        var result = await _metaController.GetEmployeeTypes();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var employeeTypesFromDB = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(employeeTypesFromDB);
        Assert.True(employeeTypesFromDB.Count > 0);
    }

    [Fact]
    public async Task ShouldReturnEEOClasses()
    {
        //Act
        var result = await _metaController.GetEEOClasses();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var eEOClassesFromDB = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(eEOClassesFromDB);
        Assert.True(eEOClassesFromDB.Count > 0);
    }

    #endregion Get Employee Type and EEO Class tests

    #region Get Work Arrangements tests

    [Fact]
    public async Task ShouldReturnWorkArrangements()
    {
        //Act
        var result = await _metaController.GetWorkArrangements();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var workArrangements = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(workArrangements);
        Assert.True(workArrangements.Count > 0);
        workArrangements.Should().BeEquivalentTo(LookupConstants.WorkArrangements);
    }

    #endregion Get Work Arrangements tests

    #region Get Location Types tests

    [Fact]
    public async Task ShouldReturnLocationTypes()
    {
        //Act
        var result = await _metaController.GetLocationTypes();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var locationTypes = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(locationTypes);
        Assert.True(locationTypes.Count > 0);
        locationTypes.Should().BeEquivalentTo(LookupConstants.LocationTypes);
    }

    #endregion Get Location Types tests

    [Fact]
    public async Task ShouldReturnAllMenuItems()
    {
        //Act
        var result = await _metaController.GetMenuItems();

        // Assert
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var menuItems = Assert.IsAssignableFrom<IEnumerable<MenuItemDto>>(actionResult.Value);
        Assert.Equal(200, actionResult.StatusCode);
        Assert.True(menuItems.Count() > 0);
    }

    [Fact]
    public async Task ShouldReturnJobBoardMenuItem()
    {
        //Act
        var result = await _metaController.GetMenuItems();

        //Assert
        var actonResult = Assert.IsType<OkObjectResult>(result.Result);
        var menuItems = Assert.IsAssignableFrom<IEnumerable<MenuItemDto>>(actonResult.Value);

        Assert.Contains(menuItems, menuItem => menuItem.Id == 9 && menuItem.Code == "Job Board Integration" && menuItem.DisplayOrder == 7);
    }

    [Fact]
    public async Task ShouldReturnApplicationFormSections()
    {
        //Act
        var result = await _metaController.GetApplicationFormSections();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var applicationFormSections = Assert.IsType<List<ApplicationFormSectionDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(applicationFormSections);
        Assert.True(applicationFormSections.Count > 0);
        Assert.Contains(applicationFormSections, section => section.Id == (long)ApplicationFormSections.PersonalInformation);
        Assert.Contains(applicationFormSections, section => section.Id == (long)ApplicationFormSections.Address);
        Assert.Contains(applicationFormSections, section => section.Id == (long)ApplicationFormSections.ProfessionalDetails);
        Assert.Contains(applicationFormSections, section => section.Id == (long)ApplicationFormSections.AdditionalDetails);
        Assert.Contains(applicationFormSections, section => section.Id == (long)ApplicationFormSections.EducationHistory);
        Assert.Contains(applicationFormSections, section => section.Id == (long)ApplicationFormSections.WorkHistory);
    }

    [Fact]
    public async Task ShouldReturnApplicationFormAttributes()
    {
        //Act
        var result = await _metaController.GetApplicationFormAttributes();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var applicationFormAttributes = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(applicationFormAttributes);
        Assert.True(applicationFormAttributes.Count > 0);
        Assert.Contains(applicationFormAttributes, attribute => attribute.Id == (long)ApplicationFormFieldAttributes.MaxLength);
        Assert.Contains(applicationFormAttributes, attribute => attribute.Id == (long)ApplicationFormFieldAttributes.MaxFileUploadSize);
        Assert.Contains(applicationFormAttributes, attribute => attribute.Id == (long)ApplicationFormFieldAttributes.TextValue);
        Assert.Contains(applicationFormAttributes, attribute => attribute.Id == (long)ApplicationFormFieldAttributes.Length);
        Assert.Contains(applicationFormAttributes, attribute => attribute.Id == (long)ApplicationFormFieldAttributes.AllowedFileFormats);
    }

    [Theory]
    [InlineData((long)LookupTypes.EmployeeType)]
    [InlineData((long)LookupTypes.EEOClass)]
    [InlineData((long)LookupTypes.PayGroup)]
    [InlineData((long)LookupTypes.PayMethod)]
    [InlineData((long)LookupTypes.WorkArrangement)]
    [InlineData((long)LookupTypes.LocationType)]
    [InlineData((long)LookupTypes.State)]
    [InlineData((long)LookupTypes.EducationLevel)]
    [InlineData((long)LookupTypes.SectionType)]
    public async Task ShouldReturnLookUpDataById(long id)
    {
        //Act
        var result = await _metaController.GetLookupData(id);
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var lookupData = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(lookupData);
        Assert.True(lookupData.Count > 0);
        switch (id)
        {
            case (long)LookupTypes.WorkArrangement:
                lookupData.Should().BeEquivalentTo(LookupConstants.WorkArrangements);
                break;

            case (long)LookupTypes.LocationType:
                lookupData.Should().BeEquivalentTo(LookupConstants.LocationTypes);
                break;
        }
    }

    [Fact]
    public async Task ShouldGetAllApplicationFormSections()
    {
        // Act
        var result = await _metaController.GetApplicationFormSections();

        // Assert
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var applicationFormSections = Assert.IsAssignableFrom<List<ApplicationFormSectionDto>>(actionResult.Value);
        Assert.Equal(200, actionResult.StatusCode);
        Assert.NotNull(applicationFormSections);
        Assert.True(applicationFormSections.Count > 0);

        applicationFormSections.Should().BeEquivalentTo(ApplicationFormSectionConfiguration.Sections, options => options.Excluding(property => property.Type)
                                                                                                                        .Excluding(property => property.IsCustomFieldSection));
    }

    [Fact]
    public async Task ShouldGetAllInterviewTypes()
    {
        // Act
        var result = await _metaController.GetLookupData((long)LookupTypes.InterviewType);

        // Assert
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var interviewTypes = Assert.IsAssignableFrom<List<NameIdPairDto>>(actionResult.Value);
        Assert.Equal(200, actionResult.StatusCode);
        Assert.NotNull(interviewTypes);
        Assert.True(interviewTypes.Count > 0);
        Assert.Contains(interviewTypes, interviewType => interviewType.Id == (long)InterviewType.Phone);
        Assert.Contains(interviewTypes, interviewType => interviewType.Id == (long)InterviewType.Video);
        Assert.Contains(interviewTypes, interviewType => interviewType.Id == (long)InterviewType.InPerson);
    }

    [Fact]
    public async Task ShouldGetAllJobApplicationStatuses()
    {
        //Act
        var result = await _metaController.GetJobApplicationStatuses();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var jobApplicationStatuses = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        //Assert
        Assert.NotNull(jobApplicationStatuses);
        Assert.True(jobApplicationStatuses.Count > 0);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.Applied);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.InterviewScheduled);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.NotSelected);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.OfferExtended);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.OfferAccepted);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.OfferDeclined);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.Onboarding);
        Assert.Contains(jobApplicationStatuses, status => status.Id == (long)JobApplicationStatuses.Hired);
    }

    [Fact]
    public async Task ShouldGetAllRoles()
    {
        // Arrange
        var expectedRoles = new List<NameIdPairDto>
        {
            new NameIdPairDto { Id = 1, Name = "Interviewer", Code = "INT" },
            new NameIdPairDto { Id = 3, Name = "SystemAdministrator", Code = "SYS" },
            new NameIdPairDto { Id = 4, Name = "HiringManager", Code = "HRM" }
        };

        var mockMetaDataService = new Mock<IMetaDataService>();
        mockMetaDataService.Setup(service => service.GetRolesAsync())
                           .ReturnsAsync(expectedRoles);

        var metaController = new MetaDataController(mockMetaDataService.Object);

        // Act
        var result = await metaController.GetRoles();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var roles = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);

        // Assert
        Assert.NotNull(roles);
        Assert.True(roles.Count > 0);
        Assert.Contains(roles, role => role.Id == 1 && role.Name == "Interviewer" && role.Code == "INT");
        Assert.Contains(roles, role => role.Id == 3 && role.Name == "SystemAdministrator" && role.Code == "SYS");
        Assert.Contains(roles, role => role.Id == 4 && role.Name == "HiringManager" && role.Code == "HRM");
    }

    [Fact]
    public async Task ShouldRetrieveAllRoles()
    {
        var result = await _metaController.GetRoles();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var roles = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);
        Assert.NotNull(roles);
        Assert.True(roles.Count > 0);
        Assert.Contains(roles, role => role.Name == "Hiring Manager" && role.Code == "Hiring Manager");
        Assert.Contains(roles, role => role.Name == "Interviewer" && role.Code == "Interviewer");
    }

    [Fact]
    public async Task ShouldGetPageDetailsForAuditLogs()
    {
        //Act
        var result = await _metaController.GetPageNames();

        // Assert
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var pages = Assert.IsAssignableFrom<IEnumerable<NameIdPairDto>>(actionResult.Value);
        Assert.Equal(200, actionResult.StatusCode);
        Assert.True(pages.Count() > 0);
    }

    [Fact]
    public async Task ShouldGetSectionDetailsForAuditLogs()
    {
        //Act
        var result = await _metaController.GetSectionNames();

        // Assert
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var sections = Assert.IsAssignableFrom<IEnumerable<NameIdPairDto>>(actionResult.Value);
        Assert.Equal(200, actionResult.StatusCode);
        Assert.True(sections.Count() > 0);
    }

    [Fact]
    public async Task ShouldGetUserEmailsList()
    {
        var result = await _userController.GetUserEmails();
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var users = Assert.IsType<List<NameIdPairDto>>(actionResult.Value);
        Assert.NotNull(users);
    }

    //[Fact]
    //public async Task ShouldGetUserProfile()
    //{
    //    var result = await _userController.GetUserProfileAsync();
    //    var actionResult = Assert.IsType<OkObjectResult>(result.Result);
    //    var user = Assert.IsType<UserProfileDto>(actionResult.Value);
    //    Assert.NotNull(user);
    //    Assert.Equal("John Doe", user.Name);
    //    Assert.Equal("johndoe@gmail.com", user.Email);
    //}

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}