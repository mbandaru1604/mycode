﻿using BBSI.ATS.Common.Helpers;

namespace BBSI.ATS.UnitTests
{
    public class UtilityHelperTests
    {
        [Fact]
        public void IsEmptyShouldReturnsTrueForDBNull()
        {
            // Arrange
            object value = DBNull.Value;

            // Act
            bool result = IsEmpty(value);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void IsEmptyShouldReturnsTrueForGuid()
        {
            // Arrange
            object value = new Guid();

            // Act
            bool result = IsEmpty(value);

            // Assert
            Assert.True(result);

            value = default(Guid);
            result = IsEmpty(value);
            Assert.True(result);
        }

        [Fact]
        public void IsEmptyShouldReturnsFalseForDateTime()
        {
            // Arrange
            object value = DateTime.Now;

            // Act
            bool result = IsEmpty(value);

            // Assert
            Assert.False(result);
        }

        [Theory]
        [InlineData(null, true)]
        [InlineData("", true)]
        [InlineData("   ", true)]
        [InlineData(new long[] { }, true)]
        [InlineData("Hello", false)]
        [InlineData(123, false)]
        [InlineData(new[] { 1, 2, 3 }, false)]
        public void IsEmptyShouldReturnsExpectedResult(object value, bool expectedResult)
        {
            // Act
            bool result = UtilityHelper.IsEmpty(value);

            // Assert
            Assert.Equal(expectedResult, result);
        }
    }
}