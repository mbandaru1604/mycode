﻿using BBSI.ATS.Common.Helpers;
using static BBSI.ATS.Common.Constants;

namespace BBSI.ATS.UnitTests
{
    public class DateUtilsTests
    {
        [Fact]
        public void DateTimeToEpochMillisShouldConvertsDateTimeToEpochMilliseconds()
        {
            // Arrange
            DateTime dateTime = new(2024, 5, 8, 12, 0, 0, DateTimeKind.Utc);
            long expectedEpochMillis = 1715169600000;

            // Act
            long epochMillis = DateUtils.DateTimeToEpochMillis(dateTime);

            // Assert
            Assert.Equal(expectedEpochMillis, epochMillis);
        }

        [Fact]
        public void GetCurrentPSTDateTimeShouldReturnCurrentDateTimeInPST()
        {
            // Arrange
            DateTime expectedDateTime = DateTime.UtcNow.AddHours(-7); // Pacific Standard Time (PST) offset is -7 hours

            // Act
            DateTime currentPSTDateTime = DateUtils.GetCurrentPSTDateTime();

            // Assert
            Assert.Equal(expectedDateTime.Date, currentPSTDateTime.Date);
            Assert.Equal(expectedDateTime.Hour, currentPSTDateTime.Hour);
            Assert.Equal(expectedDateTime.Minute, currentPSTDateTime.Minute);
        }

        [Fact]
        public void GetPSTDateTimeShouldConvertsToLocalTimeZoneDateTimeToPST()
        {
            // Arrange
            DateTime localDateTime = DateTime.Now;
            DateTime expectedPSTDateTime = TimeZoneInfo.ConvertTime(localDateTime, TimeZoneInfo.Local, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneConstants.PST_ZONE));

            // Act
            DateTime convertedPSTDateTime = DateUtils.GetPSTDateTime(localDateTime);

            // Assert
            Assert.Equal(expectedPSTDateTime, convertedPSTDateTime);
        }

        [Theory]
        [InlineData("2024-05-08", "2024-05-09", true)]
        [InlineData("2024-05-08", "2024-05-08", false)]
        public void IsFutureDateTimeShouldReturnExpectedResult(DateTime targetDateTime, DateTime dateTimeToTest, bool expectedResult)
        {
            // Act
            bool result = DateUtils.IsFutureDateTime(targetDateTime, dateTimeToTest);

            // Assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [InlineData("2024-05-08", "2024-05-07", true)]
        [InlineData("2024-05-08", "2024-05-08", false)]
        public void IsPastDateTimeShouldReturnExpectedResult(DateTime targetDateTime, DateTime dateTimeToTest, bool expectedResult)
        {
            // Act
            bool result = DateUtils.IsPastDateTime(targetDateTime, dateTimeToTest);

            // Assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [InlineData("2024-05-08", "2024-05-08", true)]
        [InlineData("2024-05-08", "2024-05-09", true)]
        [InlineData("2024-05-08", "2024-05-07", false)]
        public void IsSameOrFutureDayShouldReturnExpectedResult(DateTime targetDay, DateTime dateToTest, bool expectedResult)
        {
            // Act
            bool result = DateUtils.IsSameOrFutureDay(targetDay, dateToTest);

            // Assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [InlineData("2024-05-08", "2024-05-08", true)]
        [InlineData("2024-05-08", "2024-05-07", true)]
        [InlineData("2024-05-08", "2024-05-09", false)]
        public void IsSameOrPastDayShouldReturnExpectedResult(DateTime targetDay, DateTime dateToTest, bool expectedResult)
        {
            // Act
            bool result = DateUtils.IsSameOrPastDay(targetDay, dateToTest);

            // Assert
            Assert.Equal(expectedResult, result);
        }

        [Fact]
        public void ShouldFormatDateToGivenDatePattern()
        {
            // Arrange
            DateTime date = new(2024, 5, 8);
            string pattern = "yyyy-MM-dd";

            // Act
            string formattedDate = DateUtils.FormatTo(date, pattern);

            // Assert
            Assert.Equal("2024-05-08", formattedDate);
        }

        [Fact]
        public void ToEpochMillisShouldConvertsDateTimeToEpochMillisecondsUsingExtensionMethod()
        {
            // Arrange
            DateTime dateTime = new(2024, 5, 8, 12, 0, 0, DateTimeKind.Utc);
            long expectedEpochMillis = DateUtils.DateTimeToEpochMillis(dateTime);

            // Act
            long epochMillis = dateTime.ToEpochMillis();

            // Assert
            Assert.Equal(expectedEpochMillis, epochMillis);
        }

        [Fact]
        public void ToPSTDateTimeShouldConvertsDateTimeToPSTUsingExtensionMethod()
        {
            // Arrange
            DateTime dateTime = new(2024, 5, 8, 12, 0, 0);
            DateTime expectedPSTDateTime = DateUtils.GetPSTDateTime(dateTime);

            // Act
            DateTime convertedPSTDateTime = dateTime.ToPSTDateTime();

            // Assert
            Assert.Equal(expectedPSTDateTime, convertedPSTDateTime);
        }
    }
}