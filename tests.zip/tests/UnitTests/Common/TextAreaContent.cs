﻿namespace BBSI.ATS.UnitTests;

public class TextAreaContent
{
    public const string Stringwith500Chracters = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac urna id turpis facilisis scelerisque. Proin eu erat non est hendrerit interdum eu eu libero. Nunc id libero ac diam sodales maximus. Suspendisse potenti. Sed et eros magna. Integer non dapibus dolor. Fusce gravida arcu at libero molestie eleifend. Curabitur accumsan condimentum velit sit amet efficitur. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec et nibh magna. Suspendisse in lobortis sapien, non fringilla nisl. Morbi posuere orci nec ligula ullamcorper, nec sagittis nulla lobortis. Etiam auctor purus quis vestibulum ultrices. Nam non placerat ex. Mauris volutpat in arcu nec dignissim. Vivamus vehicula velit id tempus scelerisque.";
}
