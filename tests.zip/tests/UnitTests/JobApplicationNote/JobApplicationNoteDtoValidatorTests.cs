﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;

namespace BBSI.ATS.UnitTests;

public class JobApplicationNoteDtoValidatorTests
{
    private readonly JobApplicationNoteDtoValidatior _validator;

    public JobApplicationNoteDtoValidatorTests()
    {
        _validator = new JobApplicationNoteDtoValidatior();
    }

    [Fact]
    public void ShouldPasswhenRequriedFieldsEntered()
    {
        JobApplicationNoteDto jobApplicationNoteDto = new JobApplicationNoteDto()
        {
            JobApplicationId = 1,
            Note = "test Add Note",
        };

        var result = _validator.TestValidate(jobApplicationNoteDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationNoteDto>>(result);
        result.ShouldNotHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.JobApplicationId);
        result.ShouldNotHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.Note);
    }

    [Fact]
    public void ShouldFailwhenJobApplicationIdIsEmpty()
    {
        JobApplicationNoteDto jobApplicationNoteDto = new JobApplicationNoteDto()
        {
            JobApplicationId = null,
            Note = "test Add Note",
        };

        var result = _validator.TestValidate(jobApplicationNoteDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationNoteDto>>(result);
        result.ShouldHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.JobApplicationId);
        result.ShouldNotHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.Note);
    }

    [Fact]
    public void ShouldFailwhenNoteIsEmpty()
    {
        JobApplicationNoteDto jobApplicationNoteDto = new JobApplicationNoteDto()
        {
            JobApplicationId = 1,
            Note = "",
        };

        var result = _validator.TestValidate(jobApplicationNoteDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationNoteDto>>(result);
        result.ShouldNotHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.JobApplicationId);
        result.ShouldHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.Note);
    }

    [Fact]
    public void ShouldFailwhenNoteIsNull()
    {
        JobApplicationNoteDto jobApplicationNoteDto = new JobApplicationNoteDto()
        {
            JobApplicationId = 1,
            Note = null,
        };

        var result = _validator.TestValidate(jobApplicationNoteDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationNoteDto>>(result);
        result.ShouldNotHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.JobApplicationId);
        result.ShouldHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.Note);
    }

    [Fact]
    public void ShouldFailwhenNoteMaxLimitExceeds()
    {
        JobApplicationNoteDto jobApplicationNoteDto = new JobApplicationNoteDto()
        {
            JobApplicationId = 1,
            Note = TextAreaContent.Stringwith500Chracters
        };

        var result = _validator.TestValidate(jobApplicationNoteDto);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<JobApplicationNoteDto>>(result);
        result.ShouldNotHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.JobApplicationId);
        result.ShouldHaveValidationErrorFor(jobApplicationNote => jobApplicationNote.Note);
    }
}
