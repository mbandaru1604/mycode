﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Data.Repositories.Interfaces;
using BBSI.ATS.Infrastructure.Integrations.Concrete;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Xunit.Abstractions;
using static BBSI.ATS.Common.Constants;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class JobApplicationNoteControllerTests : IDisposable
{
    private readonly JobApplicationNotesController _jobApplicationNotesController;
    private readonly IApplicationFormService _applicationFormService;
    private readonly IJobPostService _jobPostService;
    private readonly AtsDbContext _dbContext;
    private readonly JobApplicationService _jobApplicationService;
    private readonly IApplicantInterviewService _applicantInterviewService;
    private readonly CurrentUserContext _currentUserContext;
    private readonly MetaDataService _metadataService;
    private readonly IMapper _mapper;
    private bool disposed = false;
    private readonly ITestOutputHelper _output;
    private readonly IJobApplicationRepository _jobApplicationRepository;
    private readonly IUserService _userService;

    public JobApplicationNoteControllerTests(ITestOutputHelper output)
    {
        _output = output;
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1, RoleIds = [4] };
        _jobApplicationRepository = new JobApplicationRepository(_dbContext, _currentUserContext);
        var applicationFormRepository = new ApplicationFormRepository(_dbContext, _currentUserContext);
        var JobPostRepository = new JobPostRepository(_dbContext, _currentUserContext);
        var metaDataRepository = new MetaDataRepository(_dbContext, _currentUserContext);
        var atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);
        var userRepository = new UserRepository(_dbContext, _currentUserContext);
        var jobApplicationNoteRepository = new JobApplicationNoteRepository(_dbContext, _currentUserContext);
        var applicantQuizRepository = new ApplicantQuizRepository(_dbContext, _currentUserContext);

        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        _mapper = mappingConfig.CreateMapper();
        var mockCosmosDbService = new Mock<ICosmosDbService>();

        _metadataService = new MetaDataService(metaDataRepository, _mapper);
        var formFieldComparer = new ApplicationFormFieldComparer();
        var applicationFormComparer = new ApplicationFormComparer(formFieldComparer);
        _applicationFormService = new ApplicationFormService(applicationFormRepository, _mapper, _currentUserContext, mockCosmosDbService.Object, applicationFormComparer);

        _userService = new UserService(atsBaseRepository, null, userRepository, _currentUserContext);
        var companyRepository = new CompanyRepository(_dbContext, _currentUserContext);
        var companyService = new CompanyService(companyRepository, _userService, null, _mapper, null);
        var appConfig = new AppConfig();
        _jobPostService = new JobPostService(JobPostRepository, _mapper, _applicationFormService, _currentUserContext,
                                            mockCosmosDbService.Object, applicantQuizRepository, companyService, appConfig);

        var blobServiceMock = new Mock<IBlobService>();

        var jobApplicationNoteService = new JobApplicationNoteService(atsBaseRepository, _mapper, _jobApplicationRepository,
                                        _currentUserContext, jobApplicationNoteRepository, _userService, mockCosmosDbService.Object);
        var mockLogger = new Mock<ILogger<JobApplicationService>>();
        var mockConfig = new Mock<IOptions<EmailTemplateConfig>>();
        var mockLoggerEmailClient = new Mock<ILogger<EmailClient>>();
        var emailConfig = new SendGridEmailConfig();
        emailConfig.ApiKey = "testkey";
        emailConfig.SenderEmail = "ats-no-reply@mybbsi.com";
        var emailClient = new EmailClient(emailConfig, mockLoggerEmailClient.Object);
        _jobApplicationService = new JobApplicationService(_jobApplicationRepository, _mapper, _applicationFormService, blobServiceMock.Object, null, jobApplicationNoteService, _metadataService, mockLogger.Object, emailClient, mockConfig.Object, null, null, _currentUserContext, _userService, mockCosmosDbService.Object, applicantQuizRepository);
        var applicantInterviewComparer = new ApplicantInterviewComparer();
        _applicantInterviewService = new ApplicantInterviewService(atsBaseRepository, _mapper, _jobApplicationRepository, null,
                                    _jobApplicationService, jobApplicationNoteService, emailClient, null,
                                    _currentUserContext, _userService, applicantInterviewComparer, _metadataService, mockCosmosDbService.Object);

        _jobApplicationNotesController = new JobApplicationNotesController(jobApplicationNoteService);
    }

    [Fact]
    public async Task ShouldGetAllNotesByApplicant()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(10).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.AddMinutes(100).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            EndDateTime = DateTime.Now.AddMinutes(123).ToString(ApplicantInterviewFields.InterviewDateTimeFormat),
            Interviewers =
            [
                 new()
                 {
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = "",
            EndTime = ""
        };
        var applicantInterviewId = await _applicantInterviewService.AddAsync(applicantInterviewDto);

        var NoteListResult = await _jobApplicationNotesController.GetAllNotesAsync(jobApplicationId);
        Assert.IsType<ActionResult<IEnumerable<JobApplicationNotesListDto>>>(NoteListResult);
        var okResult = Assert.IsType<OkObjectResult>(NoteListResult.Result);
        var Notes = Assert.IsAssignableFrom<IEnumerable<JobApplicationNotesListDto>>(okResult.Value);
        Assert.True(Notes.Count() > 0);
    }

    [Fact]
    public async Task UpdatedByShouldBeSystemForDynamicStatusChange()
    {
        var jobApplicationId = await CreateJobApplication();
        var NoteListResult = await _jobApplicationNotesController.GetAllNotesAsync(jobApplicationId);
        Assert.IsType<ActionResult<IEnumerable<JobApplicationNotesListDto>>>(NoteListResult);
        var okResult = Assert.IsType<OkObjectResult>(NoteListResult.Result);
        var Notes = Assert.IsAssignableFrom<IEnumerable<JobApplicationNotesListDto>>(okResult.Value);
        Assert.NotNull(Notes);
        Assert.NotNull(Notes?.First()?.UpdatedBy);
        Assert.Equal(JobApplicationNoteUser.System, Notes?.First()?.UpdatedBy);
    }

    //[Fact]
    //public async Task StatusShouldBeNotApplicableWhenCancelInterview()
    //{
    //    var jobApplicationId = await CreateJobApplication();
    //    var interviewId = await CreateApplicantInterview(jobApplicationId);

    //    var cancelDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = interviewId, Note = "Test cancel note", SendEmail = false, JobApplicationId = jobApplicationId };
    //    var cancelInterview = _applicantInterviewService.UpdateStatusAsync(cancelDto, (long)InterviewStatus.InterviewCancelled);

    //    var NoteListResult = await _jobApplicationNotesController.GetAllNotesAsync(jobApplicationId);
    //    Assert.IsType<ActionResult<IEnumerable<JobApplicationNotesListDto>>>(NoteListResult);
    //    var okResult = Assert.IsType<OkObjectResult>(NoteListResult.Result);
    //    var Notes = Assert.IsAssignableFrom<IEnumerable<JobApplicationNotesListDto>>(okResult.Value);
    //    Assert.NotNull(Notes);
    //    var ActualCancelNoteStatus = Notes.Where(x => x.Notes == cancelDto.Note).Select(x => x.Status).FirstOrDefault();
    //    Assert.Equal(JobApplicationNotesStatus.NotApplicable, ActualCancelNoteStatus);
    //}

    [Fact]
    public async Task ShouldAddNotesForApplicant()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantDetails = await _jobApplicationService.GetDetailsByIdAsync(jobApplicationId);

        var jobApplicantNoteDto = new JobApplicationNoteDto { IsManualUpdate = true, JobApplicationId = jobApplicationId, JobApplicationStatusId = applicantDetails?.StatusId, Note = " Test Add Notes" };

        var jobApplicationNote = await _jobApplicationNotesController.Create(jobApplicantNoteDto);
        var jobApplicationNoteResult = Assert.IsType<OkObjectResult>(jobApplicationNote);
        var jobApplicationNoteResultValue = Assert.IsType<CreatedResponse>(jobApplicationNoteResult.Value);
        Assert.NotNull(jobApplicationNoteResultValue);
    }

    [Fact]
    public async Task ShouldGetJobApplicationNotesbyId()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantDetails = await _jobApplicationService.GetDetailsByIdAsync(jobApplicationId);

        var jobApplicantNoteDto = new JobApplicationNoteDto { IsManualUpdate = true, JobApplicationId = jobApplicationId, JobApplicationStatusId = applicantDetails?.StatusId, Note = " Test Add Notes" };

        var jobApplicationNoteId = await _jobApplicationNotesController.Create(jobApplicantNoteDto);
        var jobApplicationNoteIdResult = Assert.IsType<OkObjectResult>(jobApplicationNoteId);
        var jobApplicationNoteIdResultValue = Assert.IsType<CreatedResponse>(jobApplicationNoteIdResult.Value);
        Assert.NotNull(jobApplicationNoteIdResultValue);

        var jobApplicationNote = await _jobApplicationNotesController.GetByIdAsync(jobApplicationNoteIdResultValue.Id);
        var jobApplicationNoteResult = Assert.IsType<OkObjectResult>(jobApplicationNote);
        Assert.NotNull(jobApplicationNoteResult.Value);
    }

    [Fact]
    public async Task ShouldUpdateNotesForApplicant()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantDetails = await _jobApplicationService.GetDetailsByIdAsync(jobApplicationId);

        var jobApplicantNoteDto = new JobApplicationNoteDto { IsManualUpdate = true, JobApplicationId = jobApplicationId, JobApplicationStatusId = applicantDetails?.StatusId, Note = " Test Add Notes" };

        var jobApplicationNoteId = await _jobApplicationNotesController.Create(jobApplicantNoteDto);
        var jobApplicationNoteIdResult = Assert.IsType<OkObjectResult>(jobApplicationNoteId);
        var jobApplicationNoteIdResultValue = Assert.IsType<CreatedResponse>(jobApplicationNoteIdResult.Value);
        Assert.NotNull(jobApplicationNoteIdResultValue);

        var jobApplicationNote = await _jobApplicationNotesController.GetByIdAsync(jobApplicationNoteIdResultValue.Id);
        var jobApplicationNoteResult = Assert.IsType<OkObjectResult>(jobApplicationNote);
        Assert.NotNull(jobApplicationNoteResult.Value);

        var jobApplicationNoteResultValue = (JobApplicationNoteDto)jobApplicationNoteResult.Value;
        jobApplicationNoteResultValue.Note = "update note testing";

        var updatejobApplicationNote = await _jobApplicationNotesController.UpdateAsync(jobApplicationNoteResultValue);
        var updatejobApplicationNoteResult = Assert.IsType<OkResult>(updatejobApplicationNote);
        Assert.NotNull(updatejobApplicationNoteResult);

        var updatedjobApplicationNote = await _jobApplicationNotesController.GetByIdAsync(jobApplicationNoteIdResultValue.Id);
        var updatedjobApplicationNoteResult = Assert.IsType<OkObjectResult>(updatedjobApplicationNote);
        Assert.NotNull(jobApplicationNoteResult.Value);
        var updatedjobApplicationNoteResultValue = (JobApplicationNoteDto)jobApplicationNoteResult.Value;

        Assert.Equal(jobApplicationNoteResultValue.Note, updatedjobApplicationNoteResultValue.Note);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInvalidJobApplication()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantDetails = await _jobApplicationService.GetDetailsByIdAsync(jobApplicationId);
        var jobApplicantNoteDto = new JobApplicationNoteDto { IsManualUpdate = true, JobApplicationId = long.MaxValue, JobApplicationStatusId = applicantDetails?.StatusId, Note = " Test Add Notes" };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _jobApplicationNotesController.Create(jobApplicantNoteDto));
        Assert.Equal(ApplicantInterviewValidation.InvalidJobApplicationId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForJobApplicationNoteNotFound()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _jobApplicationNotesController.GetByIdAsync(long.MaxValue));
        Assert.Equal(JobApplicationNoteValidation.JobApplicationNoteNotFound, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForInvalidJobApplicationNoteId()
    {
        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _jobApplicationNotesController.GetByIdAsync(0));
        Assert.Equal(InvalidRecordId, exception.Message);
    }

    //[Fact]
    //public async Task ShouldGetAllApplicantInterviewNotes()
    //{
    //    var jobApplicationId = await CreateJobApplication();

    //    var applicantInterviewDto = new ApplicantInterviewDto
    //    {
    //        Id = 0,
    //        JobApplicationId = jobApplicationId,
    //        InterviewTypeId = (long)InterviewType.Phone,
    //        InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(12).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
    //        StartDateTime = DateTime.Now.ToString("hh:mm tt"),
    //        EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
    //        Interviewers =
    //        [
    //             new()
    //             {
    //                 Id = 0,
    //                 InterviewerId =1,
    //             }
    //        ],
    //        MeetingLink = null,
    //        WorksiteLocationId = 1,
    //        LocationTypeId = (long)LocationType.WorksiteLocation,
    //        IsEmailSent = false,
    //    };
    //    var applicantInterviewId = await _applicantInterviewService.AddAsync(applicantInterviewDto);
    //    Assert.NotNull(applicantInterviewId);
    //    Assert.True(applicantInterviewId > 0);

    //    var applicantInterviewNotesDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, Note = "Test cancel note", SendEmail = false, JobApplicationId = jobApplicationId };

    //    var jobApplicationNoteId = await _applicantInterviewService.UpdateStatusAsync(applicantInterviewNotesDto, (long)InterviewStatus.InterviewCompleted);

    //    var applicantInterviewNotes = await _jobApplicationNotesController.GetInterviewNotesAsync(applicantInterviewId.GetValueOrDefault());
    //    Assert.IsType<ActionResult<IEnumerable<JobApplicationInterviewNotesListDto>>>(applicantInterviewNotes);
    //    var okResult = Assert.IsType<OkObjectResult>(applicantInterviewNotes.Result);
    //    var Notes = Assert.IsAssignableFrom<IEnumerable<JobApplicationInterviewNotesListDto>>(okResult.Value);
    //    Assert.True(Notes.Count() > 0);
    //}

    [Fact]
    public async Task ShouldFailApplicantInterviewNotesByInvalidId()
    {
        var jobApplicationId = await CreateJobApplication();
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(11).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                 new()
                 {
                     Id = 0,
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
            TimeZone = "PST",
            StartTime = "",
            EndTime = ""
        };
        var applicantInterviewId = await _applicantInterviewService.AddAsync(applicantInterviewDto);
        Assert.NotNull(applicantInterviewId);
        Assert.True(applicantInterviewId > 0);

        var applicantInterviewNotesDto = new ApplicantInterviewNotesDto { ApplicantInterviewId = applicantInterviewId, Note = "Test cancel note", SendEmail = false, JobApplicationId = jobApplicationId };

        var applicantInterviewNotes = await _jobApplicationNotesController.GetInterviewNotesAsync(long.MaxValue);
        Assert.IsType<ActionResult<IEnumerable<JobApplicationInterviewNotesListDto>>>(applicantInterviewNotes);
        var okResult = Assert.IsType<OkObjectResult>(applicantInterviewNotes.Result);
        var Notes = Assert.IsAssignableFrom<IEnumerable<JobApplicationInterviewNotesListDto>>(okResult.Value);
        Assert.True(Notes.Count() == 0);
    }

    [Fact]
    public async Task ShouldThrowExceptionJobApplicationIdInvalid()
    {
        var jobApplicationNoteDto = new JobApplicationNoteDto { ApplicantInterviewId = long.MaxValue, Note = "Test cancel note", JobApplicationId = long.MaxValue, Id = 0 };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _jobApplicationNotesController.UpdateAsync(jobApplicationNoteDto));
        Assert.Equal(InvalidRecordId, exception.Message);
    }

    [Fact]
    public async Task ShouldThrowExceptionForJobApplicationNotesNotFound()
    {
        var jobApplicationNoteDto = new JobApplicationNoteDto { ApplicantInterviewId = long.MaxValue, Note = "Test cancel note", JobApplicationId = long.MaxValue, Id = long.MaxValue };

        var exception = await Assert.ThrowsAsync<ValidationException>(async () => await _jobApplicationNotesController.UpdateAsync(jobApplicationNoteDto));
        Assert.Equal(JobApplicationNoteValidation.JobApplicationNoteNotFound, exception.Message);
    }

    #region Private Methods

    private async Task<long> CreateApplicationForm()
    {
        var formDTO = new ApplicationFormDto
        {
            Name = "form" + DateTime.Now.Ticks,
            Fields =
                [
                        new()
                        {
                            Name = "First Name",
                            DisplayOrder = 1,
                            IsSystemDefault = true,
                            DefaultFieldId = 1,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Middle Name",
                            DisplayOrder = 2,
                            IsSystemDefault = true,
                            DefaultFieldId = 2,
                            IsAlwaysActiveAndRequired = false,
                            IsActive = true,
                            IsRequired = false,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Last Name",
                            DisplayOrder = 3,
                            IsSystemDefault = true,
                            DefaultFieldId = 3,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 3,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "50"} }
                            }
                        },
                        new()
                        {
                            Name = "Personal Email Address",
                            DisplayOrder = 4,
                            IsSystemDefault = true,
                            DefaultFieldId = 4,
                            IsAlwaysActiveAndRequired = true,
                            IsActive = true,
                            IsRequired = true,
                            SectionId = 1,
                            TypeId = 8,
                            AttributeValues = new List<ApplicationFormFieldAttributeValueDto>
                            {
                                {new() {AttributeId = 1, AttributeValue = "100"} }
                            }
                        }
                ]
        };

        var formId = await _applicationFormService.AddAsync(formDTO);
        Assert.NotNull(formId);
        Assert.True(formId > 0);

        return formId.Value;
    }

    private async Task<long> CreateJobPost(long? formId)
    {
        var jobPostDto = new JobPostDto { Title = "jobPost1" + DateTime.Now.Ticks, IsSubmitted = false, ApplicationFormId = formId, HiringManagerId = _currentUserContext.UserId };
        //Act
        var jobPostId = await _jobPostService.AddAsync(jobPostDto);
        Assert.NotNull(jobPostId);
        Assert.True(jobPostId > 0);

        return jobPostId.Value;
    }

    private async Task<long> CreateJobApplication()
    {
        var formId = await CreateApplicationForm();
        var JobPostId = await CreateJobPost(formId);
        var form = await _applicationFormService.GetByIdAsync(formId);
        Assert.NotNull(form);

        var jobApplicationDto = new JobApplicationDto
        {
            JobPostId = JobPostId,
            FieldValues =
            [
                new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.FirstName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestFirstName",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.MiddleName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestMiddleName",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.LastName).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "TestLastname",
                    },
                    new()
                    {
                        FormFieldId = form.Fields.Where(a => a.DefaultFieldId == (long) ApplicationFormDefaultFields.PersonalEmailAddress).Select(a =>a.Id).FirstOrDefault(),
                        FormFieldValue = "test@email.com",
                    }
                ],
        };
        var jobApplicationId = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.NotNull(jobApplicationId);
        Assert.True(jobApplicationId > 0);
        return await CreateJobApplicationDto(jobApplicationDto);
    }

    private async Task<long> CreateJobApplicationDto(JobApplicationDto jobApplicationDto)
    {
        var jobApplicationId = await _jobApplicationService.AddAsync(jobApplicationDto);
        Assert.NotNull(jobApplicationId);
        Assert.True(jobApplicationId > 0);
        return jobApplicationId.Value;
    }

    private async Task<long> CreateApplicantInterview(long jobApplicationId)
    {
        var applicantInterviewDto = new ApplicantInterviewDto
        {
            Id = 0,
            JobApplicationId = jobApplicationId,
            InterviewTypeId = (long)InterviewType.Phone,
            InterviewDate = DateOnly.ParseExact(DateTime.Today.AddDays(10).ToString(ApplicantInterviewFields.DateFormat), ApplicantInterviewFields.DateFormat),
            StartDateTime = DateTime.Now.ToString("hh:mm tt"),
            EndDateTime = DateTime.Now.AddMinutes(30).ToString("hh:mm tt"),
            Interviewers =
            [
                 new()
                 {
                     Id = 0,
                     InterviewerId =1,
                 }
            ],
            MeetingLink = null,
            WorksiteLocationId = 1,
            LocationTypeId = (long)LocationType.WorksiteLocation,
            IsEmailSent = false,
        };
        var applicantInterviewId = await _applicantInterviewService.AddAsync(applicantInterviewDto);
        Assert.NotNull(applicantInterviewId);
        Assert.True(applicantInterviewId > 0);
        return applicantInterviewId.Value;
    }

    #endregion Private Methods

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}