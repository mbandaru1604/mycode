﻿using BBSI.ATS.API.Validators;
using BBSI.ATS.DTO;
using FluentValidation.TestHelper;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class CompanyJobBoardDtoValidatorTests
{
    private readonly CompanyJobBoardDtoValidator _validator;

    public CompanyJobBoardDtoValidatorTests()
    {
        _validator = new CompanyJobBoardDtoValidator();
    }

    [Fact]
    public void ShouldFailWhenCompanyJobBoardIdIsEmpty()
    {
        var companyJobBoard = new CompanyJobBoardDto
        {
            EmailAddress = "test@example.com",
            IsActive = true
        };

        var result = _validator.TestValidate(companyJobBoard);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<CompanyJobBoardDto>>(result);
        result.ShouldHaveValidationErrorFor(companyJobBoard => companyJobBoard.CompanyJobBoardId)
              .WithErrorMessage(CompanyJobBoardValidation.CompanyJobBoardRequired);
    }

    [Fact]
    public void ShouldFailWhenEmailAddressIsEmpty()
    {
        var companyJobBoard = new CompanyJobBoardDto
        {
            CompanyJobBoardId = 12345,
            EmailAddress = string.Empty
        };

        var result = _validator.TestValidate(companyJobBoard);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<CompanyJobBoardDto>>(result);
        result.ShouldHaveValidationErrorFor(companyJobBoard => companyJobBoard.EmailAddress);
    }

    [Fact]
    public void ShouldFailWhenEmailAddressIsInvalid()
    {
        var companyJobBoard = new CompanyJobBoardDto
        {
            CompanyJobBoardId = 12345,
            EmailAddress = "invalid-email"
        };

        var result = _validator.TestValidate(companyJobBoard);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<CompanyJobBoardDto>>(result);
        result.ShouldHaveValidationErrorFor(companyJobBoard => companyJobBoard.EmailAddress)
              .WithErrorMessage(CompanyJobBoardValidation.EmailInvalid);
    }

    [Fact]
    public void ShouldPassWhenAllRequiredFieldsAreValid()
    {
        var companyJobBoard = new CompanyJobBoardDto
        {
            CompanyJobBoardId = 12345,
            EmailAddress = "valid@example.com"
        };

        var result = _validator.TestValidate(companyJobBoard);
        Assert.NotNull(result);
        Assert.IsType<TestValidationResult<CompanyJobBoardDto>>(result);
        result.ShouldNotHaveValidationErrorFor(companyJobBoard => companyJobBoard.CompanyJobBoardId);
        result.ShouldNotHaveValidationErrorFor(companyJobBoard => companyJobBoard.EmailAddress);
    }
}
