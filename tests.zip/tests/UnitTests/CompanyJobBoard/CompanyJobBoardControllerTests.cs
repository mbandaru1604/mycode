﻿using AutoMapper;
using BBSI.ATS.API.Controllers;
using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Enums;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.Domain.Entities;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Data.Repositories.Interfaces;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Mappings;
using BBSI.ATS.UnitTests.Helpers;
using Microsoft.AspNetCore.Mvc;

using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.UnitTests;

public class CompanyJobBoardControllerTests : IDisposable
{
    private readonly CompanyJobBoardsController _companyJobBoardsController;
    private readonly AtsDbContext _dbContext;
    private readonly CompanyJobBoardService _companyJobBoardService;
    private readonly CurrentUserContext _currentUserContext;
    private readonly IAtsBaseRepository _atsBaseRepository;
    private bool disposed;

    public CompanyJobBoardControllerTests()
    {
        _dbContext = DBHelper.GetInMemoryDbContext();
        _currentUserContext = new CurrentUserContext { UserId = 1, CompanyId = 1 };
        _atsBaseRepository = new AtsBaseRepository(_dbContext, _currentUserContext);

        var mappingConfig = new MapperConfiguration(mc =>
        {
            mc.AddProfile(new MappingProfile());
        });
        IMapper mapper = mappingConfig.CreateMapper();

        _companyJobBoardService = new CompanyJobBoardService(_atsBaseRepository, mapper, _currentUserContext);
        _companyJobBoardsController = new CompanyJobBoardsController(_companyJobBoardService);
    }

    [Fact]
    public async Task ShouldThrowValidationExceptionWhenCompanyIsIntegratedWithJobBoard()
    {
        // Arrange
        var jobBoardDto = new CompanyJobBoardDto
        {
            CompanyJobBoardId = (long)JobBoard.Indeed,
            EmailAddress = "user@gmail.com",
            IsActive = true
        };

        await _companyJobBoardsController.Create(jobBoardDto);

        // Act 
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _companyJobBoardsController.Create(jobBoardDto));

        // Assert
        Assert.Equal(CompanyJobBoardValidation.CompanyAlreadyIntegratedWithJobBoard, exception.Message);
    }

    [Fact]
    public async Task ShouldGetCompanyJobBoardById()
    {
        // Arrange
        var jobBoardId = await CreateCompanyJobBoard();
        Assert.True(jobBoardId > 0);

        var result = await _companyJobBoardsController.GetCompanyJobBoardById(jobBoardId);
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var retrievedJobBoard = Assert.IsType<CompanyJobBoardDto>(okResult.Value);
        Assert.True(retrievedJobBoard.Id > 0);

        Assert.NotNull(retrievedJobBoard);
        Assert.Equal((long)JobBoard.Indeed, retrievedJobBoard.CompanyJobBoardId);
    }

    [Fact]
    public async Task ShouldGetActiveJobBoards()
    {
        // Arrange
        var jobBoardId = await CreateCompanyJobBoard();
        Assert.True(jobBoardId > 0);

        // Act
        var result = await _companyJobBoardsController.GetAllJobBoards();

        var jobBoardOkResult = Assert.IsType<OkObjectResult>(result.Result);
        var activeJobBoards = Assert.IsType<List<CompanyJobBoardListDto>>(jobBoardOkResult.Value);
        Assert.NotEmpty(activeJobBoards);

        // Assert
        var matchingJobBoard = activeJobBoards.Find(jb => jb.CompanyJobBoardId == (long)JobBoard.Indeed);

        Assert.NotNull(matchingJobBoard);
        Assert.Equal((long)JobBoard.Indeed, matchingJobBoard.CompanyJobBoardId);
    }

    [Fact]
    public async Task ShouldUpdateCompanyJobBoard()
    {
        // Arrange
        var jobBoardId = await CreateCompanyJobBoard();

        var companyJobBoard = await _companyJobBoardsController.GetCompanyJobBoardById(jobBoardId);
        var companyJobBoardResult = Assert.IsType<OkObjectResult>(companyJobBoard.Result);
        Assert.NotNull(companyJobBoardResult.Value);
        CompanyJobBoardDto companyJobBoardResultValue = (CompanyJobBoardDto)companyJobBoardResult.Value;
        Assert.NotNull(companyJobBoardResultValue);

        var updatedJobBoardDto = new CompanyJobBoardDto
        {
            Id = jobBoardId,
            EmailAddress = "updateduser@gmail.com",
            IsActive = false,
            Version= companyJobBoardResultValue.Version
        };

        var updateResult = await _companyJobBoardsController.Update(updatedJobBoardDto);
        Assert.IsType<OkResult>(updateResult);


        var getResult = await _companyJobBoardsController.GetCompanyJobBoardById(jobBoardId);
        var createOkResult = Assert.IsType<OkObjectResult>(getResult.Result);
        var retrievedJobBoard = Assert.IsType<CompanyJobBoardDto>(createOkResult.Value);

        // Assert
        Assert.NotNull(retrievedJobBoard);
        Assert.Equal(updatedJobBoardDto.EmailAddress, retrievedJobBoard.EmailAddress);
        Assert.Equal(updatedJobBoardDto.IsActive, retrievedJobBoard.IsActive);

        //reset the update status to active
        updatedJobBoardDto.IsActive = true;
        await _companyJobBoardsController.Update(updatedJobBoardDto);
    }

    [Fact]
    public async Task ShouldThrowExceptionWhenUpdatingWithInvalidId()
    {
        var jobBoardId = await CreateCompanyJobBoard();
        Assert.True(jobBoardId > 0);

        var invalidJobBoardDto = new CompanyJobBoardDto
        {
            Id = 0,
            EmailAddress = "invaliduser@gmail.com",
            IsActive = true
        };

        //Act
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _companyJobBoardsController.Update(invalidJobBoardDto));

        //Assert
        Assert.Equal("Invalid Id", exception.Message);
    }

    [Fact]
    public async Task ShouldThrowValidationExceptionWhenJobBoardNotFound()
    {
        //Arrange
        long invalidJobBoardId = 9999;

        // Act 
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _companyJobBoardsController.GetCompanyJobBoardById(invalidJobBoardId));

        //Assert
        Assert.Equal("Invalid Id", exception.Message);
    }

    [Fact]
    public async Task ShouldThrowValidationExceptionWhenUpdatingNonExistentJobBoard()
    {
        // Arrange
        var invalidJobBoardId = 9999;
        var jobBoardDto = new CompanyJobBoardDto
        {
            Id = invalidJobBoardId,
            EmailAddress = "nonexistent@gmail.com",
            IsActive = true
        };

        // Act 
        var exception = await Assert.ThrowsAsync<ValidationException>(() => _companyJobBoardsController.Update(jobBoardDto));

        // Assert
        Assert.Equal("Invalid Id", exception.Message);
    }

    #region Private Method

    private async Task<long> CreateCompanyJobBoard()
    {
        var jobBoards = await _companyJobBoardService.GetAllJobBoardsAsync();
        if (!jobBoards.Any())
        {
            var companyJobBoardDto = new CompanyJobBoardDto
            {
                CompanyJobBoardId = (long)JobBoard.Indeed,
                EmailAddress = "user@gmail.com",
                IsActive = true
            };
            var jobBoardResult = await _companyJobBoardsController.Create(companyJobBoardDto);

            var jobBoardOkResult = Assert.IsType<OkObjectResult>(jobBoardResult.Result);
            var createdJobBoardDTO = Assert.IsType<CreatedResponse>(jobBoardOkResult.Value);

            Assert.True(createdJobBoardDTO.Id > 0);
            return createdJobBoardDTO.Id;
        }
        return jobBoards.First().Id;
    }

    #endregion Private Method

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}
