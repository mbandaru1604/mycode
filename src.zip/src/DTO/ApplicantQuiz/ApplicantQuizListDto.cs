﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizListDto : BaseDto
{
    public string? Name { get; set; }
    public int? MinimumPassingScore { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTimeOffset? ModifiedOn { get; set; }
}