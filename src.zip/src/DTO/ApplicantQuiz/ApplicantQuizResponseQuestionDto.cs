﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizResponseQuestionDto : BaseDto
{
    public string? Question { get; set; }
    public List<ApplicantQuizResponseAnswerDto>? Answers { get; set; }
}