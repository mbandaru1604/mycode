﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizResultDto : BaseDto
{
    public long? QuizId { get; set; }
    public long? JobApplicationId { get; set; }
    public int? Score { get; set; }
    public bool? IsPassed { get; set; }
    public List<ApplicantQuizResultQADto>? QuizAnswers { get; set; }
}