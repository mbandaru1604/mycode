﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizAnswerDto : BaseDto
{
    public string? Answer { get; set; }
}