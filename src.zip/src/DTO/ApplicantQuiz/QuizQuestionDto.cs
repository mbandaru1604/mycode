﻿namespace BBSI.ATS.DTO;

public class QuizQuestionDto : BaseDto
{
    public required string Question { get; set; }
    public required long TypeId { get; set; }
    public required int Score { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; }
    public bool IsRequired { get; set; } = true;
    public List<QuizQuestionAnswerDto> Answers { get; set; } = [];
}
