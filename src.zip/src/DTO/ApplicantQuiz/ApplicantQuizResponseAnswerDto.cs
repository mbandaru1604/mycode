﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizResponseAnswerDto : BaseDto
{
    public string? Answer { get; set; }
    public bool? IsCorrectAnswer { get; set; }
    public bool? IsApplicantAnswer { get; set; }
}