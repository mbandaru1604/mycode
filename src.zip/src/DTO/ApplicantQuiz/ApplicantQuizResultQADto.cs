﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizResultQADto : BaseDto
{
    public long? QuestionId { get; set; }
    public long? AnswerId { get; set; }
    public bool? IsCorrect { get; set; }
    public long? ResultId { get; set; }
}