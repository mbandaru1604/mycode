﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizDto : BaseDto
{
    public string? Name { get; set; }
    public int? MinimumPassingScore { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public List<QuizQuestionDto> QuizQuestions { get; set; } = [];
}