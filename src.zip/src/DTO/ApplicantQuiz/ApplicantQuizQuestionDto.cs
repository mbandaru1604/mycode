﻿namespace BBSI.ATS.DTO;

public class ApplicantQuizQuestionDto : BaseDto
{
    public string? Question { get; set; }
    public long TypeId { get; set; }
    public bool IsRequired { get; set; } = true;
    public List<ApplicantQuizAnswerDto>? Answers { get; set; }
}