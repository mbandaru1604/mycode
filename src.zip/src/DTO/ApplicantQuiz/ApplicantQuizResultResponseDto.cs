namespace BBSI.ATS.DTO;

public class ApplicantQuizResultResponseDto : BaseDto
{
    public string? QuizName { get; set; }
    public string? Description { get; set; }
    public int? Score { get; set; }
    public bool? IsPassed { get; set; }
    public int? MinimumPassingScore { get; set; }
    public DateTimeOffset? DateCompleted { get; set; }
    public List<ApplicantQuizResponseQuestionDto>? QuizQuestions { get; set; }
}