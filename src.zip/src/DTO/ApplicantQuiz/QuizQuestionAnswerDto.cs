﻿namespace BBSI.ATS.DTO;

public class QuizQuestionAnswerDto : BaseDto
{
    public required string Answer { get; set; }
    public bool IsCorrect { get; set; }
    public bool IsDeleted { get; set; } = false;
}