﻿namespace BBSI.ATS.DTO
{
    public class InterviewCalendarOverviewDto
    {
        public long InterviewId { get; set; }
        public long? JobApplicationId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string ApplicantName => $"{LastName}, {FirstName}".Trim();
        public DateOnly? InterviewDate { get; set; }
        public string StartTime { get; set; } = string.Empty;
        public long? InterviewTypeId { get; set; }
        public string InterviewTypeName { get; set; } = string.Empty;
        public long? InterviewStatusId { get; set; } 
        public string InterviewStatusName { get; set; } = string.Empty;
    }
}
