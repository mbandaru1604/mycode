﻿namespace BBSI.ATS.DTO;

public class InterviewerInterviewsDto : BaseDto
{
    public IEnumerable<InterviewsListDto>? TodayInterviews { get; set; }
    public IEnumerable<InterviewsListDto>? UpcomingInterviews { get; set; }
}