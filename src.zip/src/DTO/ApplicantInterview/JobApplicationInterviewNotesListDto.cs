﻿namespace BBSI.ATS.DTO;

public class JobApplicationInterviewNotesListDto : BaseDto
{
    public string? Notes { get; set; }
    public string? UpdatedBy { get; set; }
    public long? CreatedBy { get; set; }
    public DateTimeOffset? ModifiedOn { get; set; }
    public int? Rating { get; set; }
}