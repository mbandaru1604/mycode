﻿namespace BBSI.ATS.DTO;

public class ApplicantInterviewerDto : BaseDto
{
    public long? InterviewerId { get; set; }
}
