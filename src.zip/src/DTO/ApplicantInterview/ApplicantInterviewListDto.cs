﻿namespace BBSI.ATS.DTO;

public class ApplicantInterviewListDto : BaseDto
{
    public string? InterviewType { get; set; }
    public DateOnly? InterviewDate { get; set; }
    public string? StartTime { get; set; }
    public string? EndTime { get; set; }
    public string? Status { get; set; }
    public List<string>? Interviewers { get; set; }
    public DateTimeOffset? CreatedOn { get; set; }
    public DateTimeOffset? ModifiedOn { get; set; }
}