﻿namespace BBSI.ATS.DTO;

public class ApplicantInterviewAuditDto : BaseDto
{
    public long? JobApplicationId { get; set; }
    public string? ApplicantName { get; set; }
    public string? InterviewType { get; set; }
    public DateOnly? InterviewDate { get; set; }
    public string? StartTime { get; set; }
    public string? EndTime { get; set; }
    public string? Status { get; set; }
    public string? MeetingLink { get; set; }
    public string? WorksiteLocation { get; set; }
    public string? LocationType { get; set; }
    public string? Location { get; set; }
    public string? Address1 { get; set; }
    public string? Address2 { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? ZipCode { get; set; }
    public string? TimeZone { get; set; }

}