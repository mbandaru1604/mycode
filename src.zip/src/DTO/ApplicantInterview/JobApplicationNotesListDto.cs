﻿namespace BBSI.ATS.DTO;

public class JobApplicationNotesListDto : BaseDto
{
    public string? Notes { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTimeOffset? ModifiedOn { get; set; }
    public string? Status { get; set; }
    public DateTimeOffset? CreatedOn { get; set; }
    public long? CreatedBy { get; set; }
    public bool IsManualUpdate { get; set; } = true;
}