﻿namespace BBSI.ATS.DTO;

public class InterviewsListDto
{
    public long? JobApplicationId { get; set; }
    public string? ApplicantName { get; set; }
    public DateOnly? InterviewDate { get; set; }
    public string? StartTime { get; set; }
    public string? EndTime { get; set; }
    public string? JobPostTitle { get; set; }
    public string? InterviewType { get; set; }
    public string? Status { get; set; }
}