﻿namespace BBSI.ATS.DTO
{
    public class EmailPreviewDto
    {
        public string? Template { get; set; }
    }
}