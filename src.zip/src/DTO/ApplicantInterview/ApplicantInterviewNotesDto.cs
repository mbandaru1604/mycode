﻿namespace BBSI.ATS.DTO;

public class ApplicantInterviewNotesDto : BaseDto
{
    public long? JobApplicationId { get; set; }
    public long? ApplicantInterviewId { get; set; }
    public string? Note { get; set; }
    public int? Rating { get; set; }
    public bool SendEmail { get; set; }
    public long? ApplicantInterviewStatusId { get; set; }
}