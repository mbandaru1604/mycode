﻿namespace BBSI.ATS.DTO;

public class ApplicantInterviewDto : BaseDto
{
    public long? JobApplicationId { get; set; }
    public long? InterviewTypeId { get; set; }
    public DateOnly? InterviewDate { get; set; }
    public string? StartTime { get; set; }
    public string? StartDateTime { get; set; }
    public string? EndTime { get; set; }
    public string? EndDateTime { get; set; }
    public List<ApplicantInterviewerDto>? Interviewers { get; set; }
    public long? StatusId { get; set; }
    public string? MeetingLink { get; set; }
    public long? WorksiteLocationId { get; set; }
    public long? LocationTypeId { get; set; }
    public string? Location { get; set; }
    public string? Address1 { get; set; }
    public string? Address2 { get; set; }
    public string? City { get; set; }
    public long? StateId { get; set; }
    public string? ZipCode { get; set; }
    public bool? IsEmailSent { get; set; }
    public bool SendEmail { get; set; } = false;
    public string? TimeZone { get; set; }
}