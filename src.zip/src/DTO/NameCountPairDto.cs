﻿namespace BBSI.ATS.DTO;

public class NameCountPairDto : NameIdPairDto
{
    public required int Count { get; set; }
}
