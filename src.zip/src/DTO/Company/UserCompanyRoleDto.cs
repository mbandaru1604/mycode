﻿namespace BBSI.ATS.DTO;

public class UserCompanyRoleDto
{
    public long? CompanyId { get; set; }
    public int? CompanyCode { get; set; }
    public string? UserType { get; set; }
    public string? RoleCode { get; set; }
    public string? RoleName { get; set; }
    public bool IsActive { get; set; } = true;
    public string? StartDate { get; set; }
    public string? EndDate { get; set; }
}