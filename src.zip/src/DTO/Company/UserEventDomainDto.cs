﻿namespace BBSI.ATS.DTO;

public class UserEventDomainDto
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public string? StartDate { get; set; }
    public string? EndDate { get; set; }
    public List<UserCompanyRoleDto>? Companies { get; set; }
}