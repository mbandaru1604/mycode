﻿namespace BBSI.ATS.DTO;

public class CompanyListDto
{
    public int? Code { get; set; }
    public string? Name { get; set; }
}
