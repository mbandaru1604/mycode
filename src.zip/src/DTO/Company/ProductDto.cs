﻿namespace BBSI.ATS.DTO;

public class ProductDto : BaseDto
{
    public string? Name { get; set; }
    public string? Start { get; set; }
    public string? End { get; set; }
    public bool IsUpdate { get; set; } = false;
    public CompanyDto? Company { get; set; }
}