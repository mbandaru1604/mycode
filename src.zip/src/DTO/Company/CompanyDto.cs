﻿namespace BBSI.ATS.DTO;

public class CompanyDto : BaseDto
{
    public int? CompanyCode { get; set; }
    public string? DbaName { get; set; }
    public string? LegalName { get; set; }
    public string? StatusCode { get; set; }
    public string? Start { get; set; }
    public string? End { get; set; }
    public Guid? Identifier { get; set; }
    public List<WorksiteLocationDto>? Locations { get; set; }
    public List<UserDto>? Users { get; set; }
}