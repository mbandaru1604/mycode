﻿namespace BBSI.ATS.DTO;

public class JobApplicationNotificationDto
{
    public string? ApplicantFirstName { get; set; }
    public string? ApplicantLastName { get; set; }
    public string? ApplicantEmail { get; set; }
    public string? MobilePhoneNumber { get; set; }
    public string? CompanyName { get; set; }
    public string? JobPostTitle { get; set; }
    public string? HiringManagerName { get; set; }
    public string? HiringManagerEmail { get; set; }
    public string? AppliedOn { get; set; }
    public string? WorksiteLocation { get; set; }
    public string? ApplicantDetailsUrl { get; set; }
    public string? Subject { get; set; }
    public string? CCEmailAddresses { get; set; }
    public string? OfferDeclineUrl { get; set; }
    public string? OfferAcceptUrl { get; set; }
    public string? TimeZone { get; set; }
    public bool OptOutNotification { get; set; } = false;
    public string? QuizName { get; set; }
    public string? QuizResult { get; set; }
    public int? MinPassingScore { get; set; }
    public int? QuizScore { get; set; }
    public DateTimeOffset? CreatedOn { get; set; }
}