﻿namespace BBSI.ATS.DTO;

public class InterviewNotificationDto
{
    public string? ApplicantFirstName { get; set; }
    public string? ApplicantLastName { get; set; }
    public string? ApplicantEmail { get; set; }
    public string? ApplicantPhone { get; set; }
    public string? InterviewDate { get; set; }
    public string? StartTime { get; set; }
    public string? EndTime { get; set; }
    public long? StatusId { get; set; }
    public string? MeetingLink { get; set; }
    public string? Location { get; set; }
    public string? Address1 { get; set; }
    public string? Address2 { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? ZipCode { get; set; }
    public string? CompanyName { get; set; }
    public string? JobPostTitle { get; set; }
    public DateTimeOffset? AppliedOn { get; set; }
    public string? WorksiteLocation { get; set; }
    public string? ApplicantDetailsUrl { get; set; }
    public string? Subject { get; set; }
    public string? CCEmailAddresses { get; set; }
    public string? TimeZone { get; set; }
    public string? InterviewType { get; set; }
    public string? Label { get; set; }
    public string? Content { get; set; }
    public int? Rating { get; set; }
    public string? Feedback { get; set; }
    public List<UserDto>? Users { get; set; }
    public string? FeedbackSubmittedBy { get; set; }
    public string? InterviewerNames { get; set; }
    public string? HiringManagerName { get; set; }
}