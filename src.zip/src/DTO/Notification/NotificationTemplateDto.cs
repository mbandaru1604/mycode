﻿namespace BBSI.ATS.DTO;

public class NotificationTemplateDto
{
    public long? JobApplicationStatusId { get; set; }
    public long? ReceiverTypeId { get; set; }
    public string? EmailTemplateId { get; set; }
    public string? EmailTemplateFileName { get; set; }
}