﻿namespace BBSI.ATS.DTO;

public class NameIdPairDto
{
    public long Id { get; set; }
    public string? Code { get; set; }
    public string? Name { get; set; }
}