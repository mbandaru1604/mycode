﻿namespace BBSI.ATS.DTO;

public class ApplicationFormSectionDto : BaseDto
{
    public string? Name { get; set; }
    public int? DisplayOrder { get; set; }
    public long? TypeId { get; set; }
    public string? Type { get; set; }
    public bool IsCustomFieldSection { get; set; }

}