﻿namespace BBSI.ATS.DTO;

public class JobPostDto : BaseDto
{
    public long? ApplicationFormId { get; set; }
    public long? CategoryId { get; set; }
    public string? CCEmailAddresses { get; set; }
    public string Description { get; set; } = string.Empty;
    public long? EEOClassId { get; set; }
    public long? EmployeeTypeId { get; set; }
    public DateOnly? EndDate { get; set; }
    public string? JobCode { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsSubmitted { get; set; }
    public long? PayGroupId { get; set; }
    public long? PayMethodId { get; set; }
    public long? WorkArrangementId { get; set; }
    public DateOnly? StartDate { get; set; }
    public string Title { get; set; } = string.Empty;
    public Guid? LinkId { get; set; }
    public long? LocationTypeId { get; set; }
    public long? WorksiteLocationId { get; set; }
    public string? City { get; set; }
    public long? StateId { get; set; }
    public string? Country { get; set; }
    public string? Location { get; set; }
    public decimal? MinSalary { get; set; }
    public decimal? MaxSalary { get; set; }
    public decimal? Salary { get; set; }
    public string? SalaryComments { get; set; }
    public long? HiringManagerId { get; set; }
    public bool OptOutNotification { get; set; } = false;
    public long? ApplicantQuizId { get; set; }
    public string? DerivedLocation { get; set; }
    public DateOnly? SubmittedDate { get; set; }
    public DateTimeOffset? StartDateTime { get; set; }
    public DateTimeOffset? EndDateTime { get; set; }
}