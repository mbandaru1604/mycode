﻿namespace BBSI.ATS.DTO;

public class CompanyJobPostsForIndeedDto : BaseDto
{
    public required string Title { get; set; }
    public DateOnly? StartDate { get; set; }
    public required string FormattedStartDate { get; set; }
    public required string LinkId { get; set; }
    public required string Url { get; set; }
    public required string CompanyDbaName { get; set; }
    public required string City { get; set; }
    public required string State { get; set; }
    public required string Country { get; set; }
    public required string ZipCode { get; set; }
    public required string StreetAddress { get; set; }
    public required string CompanyEmail { get; set; }
    public required string Description { get; set; }
    public decimal? Salary { get; set; }
    public decimal? MinSalary { get; set; }
    public decimal? MaxSalary { get; set; }
    public long? PayMethodId { get; set; }
    public long? PayGroupId { get; set; }
    public required string EmployeeType { get; set; }
    public required string Category { get; set; }
    public DateOnly? EndDate { get; set; }
    public required string FormattedEndDate { get; set; }
    public required string WorkArrangement { get; set; }
    public DateTimeOffset? ModifiedOn { get; set; }
    public required string FormattedModifiedOn { get; set; }
}
