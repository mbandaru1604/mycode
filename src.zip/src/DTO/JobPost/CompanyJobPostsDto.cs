﻿namespace BBSI.ATS.DTO;

public class CompanyJobPostsDto : BaseDto
{
    public string? EmployeeType { get; set; }
    public WorksiteLocationDto? WorkSiteLocation { get; set; }
    public string? Description { get; set; }
    public string? Title { get; set; }
    public string? PayMethod { get; set; }
    public decimal? MinSalary { get; set; }
    public decimal? MaxSalary { get; set; }
    public decimal? Salary { get; set; }
    public string? SalaryComments { get; set; }
    public string? EEOClass { get; set; }
    public string? PayGroup { get; set; }
    public string? PostedOn { get; set; }
    public DateTimeOffset? StartDateTime { get; set; }
    public string? WorkArrangement { get; set; }
    public DateTimeOffset? EndDateTime { get; set; }
    public int? ActiveDaysAgo
    {
        get
        {
            if (StartDateTime.HasValue)
            {
                return (DateTime.UtcNow - StartDateTime.Value.DateTime).Days;
            }
            return null;
        }
    }
    public string? CompanyName { get; set; }
    public int? CompanyCode { get; set; }
    public Guid? LinkId { get; set; }
}