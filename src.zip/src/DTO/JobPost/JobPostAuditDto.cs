﻿namespace BBSI.ATS.DTO
{
    public class JobPostAuditDto
    {
        public long Id { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public DateOnly? StartDate { get; set; }
        public DateOnly? EndDate { get; set; }
        public string? PayGroup { get; set; }
        public string? PayMethod { get; set; }
        public string? EmployeeType { get; set; }
        public string? EEOClass { get; set; }
        public string? City { get; set; }
        public string? Location { get; set; }
        public string? State { get; set; }
        public string? Country { get; set; }
        public string? StateCode { get; set; }
        public string? LocationType { get; set; }
        public long? WorksiteLocationId { get; set; }
        public string? WorksiteLocationName { get; set; }
        public string? WorksiteLocationCity { get; set; }
        public string? WorksiteLocationState { get; set; }
        public decimal? MinSalary { get; set; }
        public decimal? MaxSalary { get; set; }
        public decimal? Salary { get; set; }
        public string? SalaryComments { get; set; }
        public string? WorkArrangement { get; set; }
        public string? CCEmailAddresses { get; set; }
        public string? OptOutNotification { get; set; }
        public string? ApplicationForm { get; set; }
        public string? Category { get; set; }
        public string? Status { get; set; }
        public string? IsSubmitted { get; set; }
        public string? HiringManager { get; set; }
        public string? Quiz { get; set; }
        public DateTimeOffset? StartDateTime { get; set; }
        public DateTimeOffset? EndDateTime { get; set; }

    }
}