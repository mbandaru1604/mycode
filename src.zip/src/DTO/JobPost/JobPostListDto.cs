﻿namespace BBSI.ATS.DTO;

public class JobPostListDto : BaseDto
{
    public DateTimeOffset? CreatedOn { get; set; }
    public string? EmployeeType { get; set; }
    public DateOnly? EndDate { get; set; }
    public string? HiringManager { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsSubmitted { get; set; } = false;
    public string? JobPostCategory { get; set; }
    public int NumberOfCandidatesApplied { get; set; } = 0;
    public DateTimeOffset? ModifiedOn { get; set; }
    public DateOnly? StartDate { get; set; }
    public string? Title { get; set; }
    public string? WorksiteLocation { get; set; }
    public Guid? LinkId { get; set; }
    public DateTimeOffset? StartDateTime { get; set; }
    public DateTimeOffset? EndDateTime { get; set; }
}