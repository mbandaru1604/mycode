﻿using BBSI.ATS.DTO.Interfaces;
using Newtonsoft.Json;

namespace BBSI.ATS.DTO
{
    public abstract class BaseDto : IBaseDto
    {
        [JsonProperty(Order = -2)]
        public long Id { get; set; }
        public byte[]? Version { get; set; }
    }
}