﻿namespace BBSI.ATS.DTO;

public class MenuItemDto : BaseDto
{
    public string? Label { get; set; }
    public string? Code { get; set; }
    public string? Url { get; set; }
    public string? Icon { get; set; }
    public int? DisplayOrder { get; set; }
    public bool IsVisible { get; set; }
}