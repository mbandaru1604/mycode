﻿using Newtonsoft.Json;

namespace BBSI.ATS.DTO;

public class PortalUserDetailsDto
{
    public bool IsValidToken { get; set; } = false;
    public Principal? Principal { get; set; }
}
public class Principal
{
    public string? Email { get; set; }

    [JsonProperty("client_code")]
    public string? ClientCode { get; set; }
}
