﻿namespace BBSI.ATS.DTO;

public class LoginRequestDto
{
    public string? Token { get; set; }
}
