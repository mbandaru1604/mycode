﻿namespace BBSI.ATS.DTO;

public class TokenDto
{
    public string? Token { get; set; }
}
