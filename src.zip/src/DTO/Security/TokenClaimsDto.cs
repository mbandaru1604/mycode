﻿namespace BBSI.ATS.DTO;

public class TokenClaimsDto
{
    public long? UserId { get; set; }
    public string? TokenId { get; set; }
    public string? UserEmail { get; set; }
    public long? CompanyId { get; set; }
    public int? CompanyCode { get; set; }
    public string? CompanyName { get; set; }
    public List<NameIdPairDto> Roles { get; set; } = [];
}
