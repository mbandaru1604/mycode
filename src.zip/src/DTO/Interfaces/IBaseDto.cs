﻿namespace BBSI.ATS.DTO.Interfaces;

public interface IBaseDto
{
    long Id { get; set; }
}