﻿namespace BBSI.ATS.DTO;

public class ProductEnabledAckPayloadDto
{
    public int? CompanyCode { get; set; }
    public bool? Enabled { get; set; }
}