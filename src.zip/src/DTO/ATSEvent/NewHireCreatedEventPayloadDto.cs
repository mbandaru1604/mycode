﻿namespace BBSI.ATS.DTO.ATSEvent;

public class NewHireCreatedEventPayloadDto : BaseDto
{
    public int? CompanyCode { get; set; }
    public Guid? CorrelationId { get; set; }
    public string? EmployeeId { get; set; }
    public string? Status { get; set; }
}