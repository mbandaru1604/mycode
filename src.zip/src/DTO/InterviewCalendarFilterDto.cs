﻿
namespace BBSI.ATS.DTO
{
    public class InterviewCalendarFilterDto
    {
        public DateOnly FromDate { get; set; }
        public DateOnly ToDate { get; set; }
        public List<long>? FilterStatuses { get; set; }

    }
}
