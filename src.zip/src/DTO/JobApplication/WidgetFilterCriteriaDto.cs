﻿namespace BBSI.ATS.DTO;

public class WidgetFilterCriteriaDto
{
    public List<string>? Locations { get; set; }
    public List<long>? JobCategoryIds { get; set; }
    public List<long>? JobPostIds { get; set; }
    public DateOnly? FromDate { get; set; }
    public DateOnly? ToDate { get; set; }
}