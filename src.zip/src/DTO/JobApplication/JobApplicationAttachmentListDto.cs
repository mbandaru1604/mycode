﻿namespace BBSI.ATS.DTO
{
    public class JobApplicationAttachmentListDto : BaseDto
    {
        public string? Name { get; set; }
        public string? Type { get; set; }
        public bool IsApplicantUploaded { get; set; }
        public DateTimeOffset? CreatedOn { get; set; }
        public long? CreatedBy { get; set; }
    }
}