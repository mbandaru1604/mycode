﻿namespace BBSI.ATS.DTO;

public class JobApplicationDetailsDto : BaseDto
{
    public string? JobPostTitle { get; set; }
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? LastName { get; set; }
    public string? PersonalEmailAddress { get; set; }
    public long? StatusId { get; set; }
    public List<JobApplicationFormFieldDetailsDto>? FormFieldValues { get; set; }
    public List<JobApplicationFormFieldDetailsDto>? FieldSetFormFieldValues { get; set; } = [];
}