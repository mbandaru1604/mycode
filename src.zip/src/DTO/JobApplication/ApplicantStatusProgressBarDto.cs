﻿namespace BBSI.ATS.DTO;

public class ApplicantStatusProgressBarDto
{
    public int? DisplayOrder { get; set; }
    public long? StatusId { get; set; }
    public string? Status { get; set; }
}