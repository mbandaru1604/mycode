﻿namespace BBSI.ATS.DTO;

public class NewHireInitiatedEventDto
{
    public int? CompanyCode { get; set; }
    public string? CorrelationId { get; set; }
    public string? NewHireType { get; set; }
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? LastName { get; set; }
    public string? MobilePhone { get; set; }
    public string? WorksiteLocation { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? ZipCode { get; set; }
    public string? PersonalEmail { get; set; }
    public string? EmploymentType { get; set; }
    public string? PreferredLanguage { get; set; }
    public string? PayMethod { get; set; }
    public decimal? PayRate { get; set; }
    public string? PayRateType { get; set; }
}