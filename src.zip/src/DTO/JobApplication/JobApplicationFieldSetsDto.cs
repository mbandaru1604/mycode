﻿namespace BBSI.ATS.DTO
{
    public class JobApplicationFieldSetsDto : BaseDto
    {
        public List<JobApplicationFieldDto>? Fields { get; set; }
    }
}