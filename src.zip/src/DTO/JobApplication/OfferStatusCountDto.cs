﻿namespace BBSI.ATS.DTO;

public class OfferStatusCountDto
{
    public int OffersAccepted { get; set; }
    public int OffersDeclined { get; set; }
    public int OffersExtended { get; set; }
}

public class OfferStatusCountResult
{
    public long ToStatusId { get; set; }
    public int Count { get; set; }
}