﻿namespace BBSI.ATS.DTO;

public class JobApplicationListDto
{
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? LastName { get; set; }
    public string? JobPostTitle { get; set; }
    public string? WorksiteLocation { get; set; }
    public string? Status { get; set; }
    public DateTimeOffset? DateApplied { get; set; }
    public long? JobApplicationId { get; set; }
}