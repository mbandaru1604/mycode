﻿namespace BBSI.ATS.DTO
{
    public class JobApplicationFieldSetDto : BaseDto
    {
        public List<JobApplicationFieldValueDto>? FieldValues { get; set; }
    }
}