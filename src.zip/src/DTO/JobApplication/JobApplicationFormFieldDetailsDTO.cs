﻿namespace BBSI.ATS.DTO;

public class JobApplicationFormFieldDetailsDto : BaseDto
{
    public long? FormFieldId { get; set; }
    public string? FormFieldName { get; set; }
    public string? FormFieldValue { get; set; }
    public int? DisplayOrder { get; set; }
    public long? SectionId { get; set; }
    public string? SectionName { get; set; }
    public long? FieldSetId { get; set; }
    public long? DefaultFieldId { get; set; }
    public long? TypeId { get; set; }
    public bool? IsSystemDefault { get; set; }
}