﻿namespace BBSI.ATS.DTO;

public class JobApplicationFieldValueDto : BaseDto
{
    public long? FormFieldId { get; set; }
    public string? FormFieldValue { get; set; }
    public string? FileName { get; set; }
    public long? JobApplicationId { get; set; }
}