﻿namespace BBSI.ATS.DTO;

public class JobApplicationDownloadDto : BaseDto
{
    public string? JobPostTitle { get; set; }
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? LastName { get; set; }
    public string? PersonalEmailAddress { get; set; }

    public string? DownloadFileName
    {
        get { return $"{FirstName} {LastName}_{JobPostTitle}"; }
    }

    public string? ApplicantName => $"{FirstName} {LastName}";

    public string ShortName => $"{FirstName?.Substring(0, 1)}{LastName?.Substring(0, 1)}";

    public List<JobApplicationFieldSectionDto>? FieldSections { get; set; }
    public List<JobApplicationFieldSetSectionDto>? FieldSetSections { get; set; }
}