﻿namespace BBSI.ATS.DTO.JobApplication
{
	public class JobApplicationOfferTokenDto
	{
		public long? JobApplicationId { get; set; }
		public string? Token { get; set; }
		public bool? IsUsed { get; set; }
		public string? Status { get; set; }
	}
}