﻿namespace BBSI.ATS.DTO;

public class JobApplicationFieldSectionDto : BaseDto
{
    public string? Name { get; set; }
    public List<JobApplicationFieldDto>? Fields { get; set; }
}