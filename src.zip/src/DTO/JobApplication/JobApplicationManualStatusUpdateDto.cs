﻿namespace BBSI.ATS.DTO
{
    public class JobApplicationManualStatusUpdateDto
    {
        public long? JobApplicationId { get; set; }
        public long? StatusId { get; set; }
        public bool SendEmail { get; set; } = false;
        public string? Note { get; set; }
        public long? NewHireTypeId { get; set; }
        public byte[]? Version { get; set; }
    }
}