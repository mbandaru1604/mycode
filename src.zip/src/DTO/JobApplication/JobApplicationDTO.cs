﻿namespace BBSI.ATS.DTO;

public class JobApplicationDto : BaseDto
{
    public string? ApplicantName { get; set; }
    public long? JobPostId { get; set; }
    public DateTimeOffset? FormModifiedOn { get; set; }
    public long? StatusId { get; set; }
    public string? timeZone { get; set; }
    public string? timeZoneDescription { get; set; }
    public List<JobApplicationFieldValueDto>? FieldValues { get; set; }
    public List<JobApplicationFieldSetDto>? FieldSets { get; set; } = [];
    public JobApplicationAttachmentDto? Attachment { get; set; }
    public ApplicantQuizResultDto? ApplicantQuizResult { get; set; }
}