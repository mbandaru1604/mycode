﻿namespace BBSI.ATS.DTO;

public class JobApplicationFieldSetSectionDto : BaseDto
{
    public string? Name { get; set; }

    public List<JobApplicationFieldSetsDto>? FieldSets { get; set; }
}