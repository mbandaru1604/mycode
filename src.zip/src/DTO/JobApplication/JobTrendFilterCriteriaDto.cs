﻿
namespace BBSI.ATS.DTO
{
    public class JobTrendFilterCriteriaDto
    {
        public List<string>? Locations { get; set; }
        public List<long>? JobCategoryIds { get; set; }
        public List<long>? JobPostIds { get; set; }
    }
}
