﻿namespace BBSI.ATS.DTO
{
    public class JobApplicationFieldDto : BaseDto
    {
        public string? Name { get; set; }
        public string? Value { get; set; }
        public int? DisplayOrder { get; set; }
    }
}