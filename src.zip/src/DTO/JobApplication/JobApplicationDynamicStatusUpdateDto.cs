﻿namespace BBSI.ATS.DTO
{
    public class JobApplicationDynamicStatusUpdateDto
    {
        public long? JobApplicationId { get; set; }
        public long? TriggerId { get; set; }
    }
}