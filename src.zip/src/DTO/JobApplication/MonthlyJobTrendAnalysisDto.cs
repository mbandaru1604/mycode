﻿namespace BBSI.ATS.DTO
{
    public class MonthlyJobTrendAnalysisDto
    {
        public int? Year { get; set; }
        public string? Month { get; set; }
        public int? JobsPosted { get; set; }
        public int? Applied { get; set; }
        public int? OffersExtended { get; set; }
        public int? Hired { get; set; }
    }

    public class ApplicationStatusResult
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public long ToStatusId { get; set; }
        public int Count { get; set; }
    }
}