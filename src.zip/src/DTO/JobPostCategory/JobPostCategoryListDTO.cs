﻿namespace BBSI.ATS.DTO;

public class JobPostCategoryListDto : JobPostCategoryDto
{
    public DateTimeOffset? CreatedOn { get; set; }
    public DateTimeOffset? ModifiedOn { get; set; }
}
