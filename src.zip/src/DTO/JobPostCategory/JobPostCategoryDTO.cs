﻿namespace BBSI.ATS.DTO;

public class JobPostCategoryDto : BaseDto
{
    public bool IsActive { get; set; }
    public string? Name { get; set; }
}