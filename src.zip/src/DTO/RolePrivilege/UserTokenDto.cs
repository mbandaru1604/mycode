﻿namespace BBSI.ATS.DTO;

public class UserTokenDto
{
    public long UserId { get; set; }
    public long CompanyId { get; set; }
}