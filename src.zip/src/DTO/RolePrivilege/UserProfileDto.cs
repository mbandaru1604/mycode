﻿namespace BBSI.ATS.DTO.RolePrivilege;

public class UserProfileDto
{
    public string? Name { get; set; }
    public string? Email { get; set; }
    public List<string>? CurrentContextPrivileges { get; set; }
    public IEnumerable<CompanyListDto>? Companies { get; set; }
}
