﻿namespace BBSI.ATS.DTO;

public class UserDetailsDto : BaseDto
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public long? RoleId { get; set; }
    public string? UserName { get; set; }
}