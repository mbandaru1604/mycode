﻿namespace BBSI.ATS.DTO;

public class RazorDto : BaseDto
{
    public string? Name { get; set; }
    public int Age { get; set; }
    public string? Email { get; set; }
}