﻿namespace BBSI.ATS.DTO;

public class CompanyJobBoardDto : BaseDto
{
    public long? CompanyJobBoardId { get; set; }
    public string? EmailAddress { get; set; }
    public bool IsActive { get; set; } = true;
}

