﻿namespace BBSI.ATS.DTO;

public class CompanyJobBoardListDto : BaseDto
{
    public long? CompanyJobBoardId { get; set; }
    public string? CompanyJobBoardName { get; set; }
    public bool? IsActive { get; set; }
    public string? CreatedOn { get; set; }
    public string? ModifiedOn { get; set; }
    public Guid? CompanyIdentifier { get; set; }
}


