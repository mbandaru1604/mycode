﻿namespace BBSI.ATS.DTO;

public class ApplicationFormFieldAttributeDto : BaseDto
{
    public string? Name { get; set; }
}