﻿namespace BBSI.ATS.DTO;

public class ApplicationFormFieldAttributeValueDto : BaseDto
{
    public long? AttributeId { get; set; }
    public string? AttributeName { get; set; }
    public string? AttributeValue { get; set; }
}