﻿namespace BBSI.ATS.DTO;

public class ApplicationFormDefaultFieldDto : BaseDto
{
    public int? DisplayOrder { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsAlwaysActiveAndRequired { get; set; }
    public bool? IsRequired { get; set; }
    public long? SectionId { get; set; }
    public string? Name { get; set; }
    public long? TypeId { get; set; }
    public long? LookupTypeId { get; set; }
    public List<DefaultFieldAttributeValueDto>? AttributeValues { get; set; }
}