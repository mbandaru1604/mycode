﻿namespace BBSI.ATS.DTO;

public class ApplicationFormFieldOptionDto : BaseDto
{
    public string? Name { get; set; }
}