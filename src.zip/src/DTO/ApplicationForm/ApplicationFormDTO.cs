﻿namespace BBSI.ATS.DTO;

public class ApplicationFormDto : BaseDto
{
    public string? Name { get; set; }
    public string? JobPostTitle { get; set; } //added to get job post title for the applicant page
    public bool? IsActive { get; set; } = true;
    public bool? IncludeEducationHistory { get; set; }
    public bool? IncludeWorkHistory { get; set; }
    public DateTimeOffset? CreatedOn { get; set; }
    public DateTimeOffset? ModifiedOn { get; set; }
    public List<ApplicationFormFieldDto>? Fields { get; set; } = [];

    public string IsActiveAuditValue => Id > 0 ? (IsActive.GetValueOrDefault() ? "Active" : "InActive") : string.Empty;

    public string IncludeEducationHistoryAuditValue => Id > 0 ?
                                                       (IncludeEducationHistory.GetValueOrDefault() ? "Include Education History" : "Exclude Education History")
                                                        : string.Empty;

    public string IncludeWorkHistoryAuditValue => Id > 0 ?
                                                       (IncludeWorkHistory.GetValueOrDefault() ? "Include Work History" : "Exclude Work History")
                                                        : string.Empty;
}