﻿namespace BBSI.ATS.DTO;

public class ApplicationFormFieldTypeDto : BaseDto
{
    public string? DisplayName { get; set; }
    public string? Name { get; set; }
    public bool IsCustomFieldType { get; set; }
    public List<ApplicationFormFieldAttributeDto>? Attributes { get; set; }
}