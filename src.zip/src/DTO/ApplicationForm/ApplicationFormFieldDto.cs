﻿namespace BBSI.ATS.DTO;

public class ApplicationFormFieldDto : BaseDto
{
    public long? DefaultFieldId { get; set; }
    public int? DisplayOrder { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsAlwaysActiveAndRequired { get; set; }
    public bool? IsRequired { get; set; }
    public bool? IsSystemDefault { get; set; }
    public long? SectionId { get; set; }
    public string? SectionName { get; set; }
    public string? Name { get; set; }
    public long? TypeId { get; set; }
    public long? LookupTypeId { get; set; }

    public List<ApplicationFormFieldOptionDto>? Options { get; set; } = [];
    public List<ApplicationFormFieldAttributeValueDto>? AttributeValues { get; set; } = [];

    public string IsActiveAuditValue => Id > 0 ? (IsActive.GetValueOrDefault() ? "Active" : "InActive") : string.Empty;

    public string IsRequiredAuditValue => Id > 0 ? (IsRequired.GetValueOrDefault() ? "Mandatory" : "Optional") : string.Empty;
}