﻿namespace BBSI.ATS.DTO;

public class ApplicationFormListDto : BaseDto
{
    public string? Name { get; set; }
    public bool? IsActive { get; set; }
    public DateTimeOffset? CreatedOn { get; set; }
    public DateTimeOffset? ModifiedOn { get; set; }
    public int OpenPositions { get; set; } = 0;
}