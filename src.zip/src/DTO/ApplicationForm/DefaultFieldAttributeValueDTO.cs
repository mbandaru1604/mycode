﻿namespace BBSI.ATS.DTO;

public class DefaultFieldAttributeValueDto : BaseDto
{
    public long? AttributeId { get; set; }
    public string? AttributeValue { get; set; }
}