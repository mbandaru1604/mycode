﻿namespace BBSI.ATS.DTO;

public class AuditLogRequestDto
{
    public int? PageNumber { get; set; }
    public int? PageSize { get; set; }
    public string? SearchTerm { get; set; }
    public string? SortByField { get; set; }
    public bool IsAscendingOrder { get; set; } = true;
    public List<string>? Pages { get; set; }
    public List<string>? Sections { get; set; }
    public List<string>? ModifiedByUsers { get; set; }
    public DateOnly? FromDate { get; set; }
    public DateOnly? ToDate { get; set; }
}