﻿namespace BBSI.ATS.DTO.AuditLog;

public class AuditLogItemDto
{
    public string? Identifier { get; set; }
    public string? PageName { get; set; }
    public List<AuditLogItemFieldDto> Fields { get; set; } = [];
}