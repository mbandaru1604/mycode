﻿using Newtonsoft.Json;

namespace BBSI.ATS.DTO;

public class AuditLogListDto
{
    [JsonProperty("id")]
    public string? Id { get; set; }

    [JsonProperty("eventDateTime")]
    public DateTimeOffset? EventDateTime { get; set; }

    [JsonProperty("pstEventDateTime")]
    public string? PSTEventDateTime { get; set; }

    [JsonProperty("identifier")]
    public string? Identifier { get; set; }

    [JsonProperty("userName")]
    public string? ModifiedByUserEmail { get; set; }

    [JsonProperty("page")]
    public string? Page { get; set; }

    [JsonProperty("section")]
    public string? Section { get; set; }

    [JsonProperty("fieldName")]
    public string? FieldChanged { get; set; }

    [JsonProperty("beforeValue")]
    public string? BeforeValue { get; set; }

    [JsonProperty("afterValue")]
    public string? AfterValue { get; set; }
}

public class PaginatedAuditLogDto
{
    public int TotalCount { get; set; }
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int TotalPages { get; set; }
    public IEnumerable<AuditLogListDto> AuditLogs { get; set; } = [];
}