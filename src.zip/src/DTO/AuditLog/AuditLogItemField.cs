﻿using Newtonsoft.Json;

namespace BBSI.ATS.DTO;

public class AuditLogItemField
{
    [JsonProperty("section")]
    public string? Section { get; set; }

    [JsonProperty("sectionId")]
    public long? SectionId { get; set; }

    [JsonProperty("fieldName")]
    public string? FieldName { get; set; }

    [JsonProperty("beforeValue")]
    public string? BeforeValue { get; set; }

    [JsonProperty("afterValue")]
    public string? AfterValue { get; set; }
}