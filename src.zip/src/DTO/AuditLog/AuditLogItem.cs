﻿using Newtonsoft.Json;

namespace BBSI.ATS.DTO;

public class AuditLogItem
{
    [JsonProperty("id")]
    public Guid? Id { get; set; }

    [JsonProperty("pKey")]
    public string? PartitionKey { get; set; }

    [JsonProperty("clientCode")]
    public int? CompanyCode { get; set; }

    [JsonProperty("eventDateTime")]
    public DateTimeOffset? EventDateTime { get; set; }

    [JsonProperty("userName")]
    public string? ModifiedByUserEmail { get; set; }

    [JsonProperty("identifier")]
    public string? Identifier { get; set; }

    [JsonProperty("identifierId")]
    public long? IdentifierId { get; set; }

    [JsonProperty("page")]
    public string? Page { get; set; }

    [JsonProperty("pageId")]
    public long? PageId { get; set; }

    [JsonProperty("fields")]
    public List<AuditLogItemField>? Fields { get; set; } = [];
}