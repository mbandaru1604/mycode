﻿using Newtonsoft.Json;

namespace BBSI.ATS.DTO.AuditLog;

public class AuditLogItemFieldDto
{
    public string? SectionName { get; set; }
    public string? FieldName { get; set; }
    public string? BeforeValue { get; set; }
    public string? AfterValue { get; set; }
}