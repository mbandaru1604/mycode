﻿namespace BBSI.ATS.Domain.Common;

public class BaseEntity : IEntity
{
    public long Id { get; set; }
}