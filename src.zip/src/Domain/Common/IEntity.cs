﻿namespace BBSI.ATS.Domain.Common;

public interface IEntity
{
    long Id { get; set; }
}