﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicantInterviewer : AuditEntity
{
    public long ApplicantInterviewId { get; set; }
    public long? InterviewerId { get; set; }
    public User? Interviewer { get; set; }
    public ApplicantInterview ApplicantInterview { get; set; }
}
