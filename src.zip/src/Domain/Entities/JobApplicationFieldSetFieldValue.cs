﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class JobApplicationFieldSetFieldValue : AuditEntity
    {
        public long? FormFieldId { get; set; }
        public string? FormFieldValue { get; set; }
        public long? FormFieldSetId { get; set; }
        public JobApplicationFieldSet? FormFieldSet { get; set; }
        public ApplicationFormField? FormField { get; set; }
    }
}