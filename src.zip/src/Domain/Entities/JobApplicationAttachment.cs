﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class JobApplicationAttachment : AuditEntity
{
    public string Name { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public long TypeId { get; set; }
    public long? JobApplicationId { get; set; }
    public LookupData? Type { get; set; }
    public JobApplication? JobApplication { get; set; }
}