﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationFormFieldOption : AuditEntity
{
    public string? Name { get; set; }
    public long? FormFieldId { get; set; }
    public bool IsDeleted { get; set; } = false;
    public ApplicationFormField? FormField { get; set; }
}