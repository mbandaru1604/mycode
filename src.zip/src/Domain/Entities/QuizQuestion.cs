﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class QuizQuestion : AuditEntity
{
    public required string Question { get; set; }
    public required long TypeId { get; set; }
    public required int Score { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsRequired { get; set; } = true;
    public long? ApplicantQuizId { get; set; }
    public bool IsDeleted { get; set; } = false;
    public ApplicantQuiz ApplicantQuiz { get; set; }
    public LookupData? Type { get; set; }
    public List<QuizQuestionAnswer> Answers { get; set; } = [];
}