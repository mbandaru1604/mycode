﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
	public class JobApplicationOfferToken : AuditEntity
	{
		public long? JobApplicationId { get; set; }
		public string? Token { get; set; }
		public bool? IsUsed { get; set; }
		public string? Status { get; set; }
		public JobApplication? JobApplication { get; set; }
	}
}