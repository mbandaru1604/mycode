﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class JobApplicationFieldValue : AuditEntity
    {
        public long? FormFieldId { get; set; }
        public string? FormFieldValue { get; set; }
        public long? JobApplicationId { get; set; }
        public ApplicationFormField? ApplicationFormField { get; set; }
        public JobApplication? JobApplication { get; set; }
    }
}