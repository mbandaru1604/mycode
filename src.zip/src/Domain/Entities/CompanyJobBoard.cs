﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class CompanyJobBoard : AuditEntity
{
    public long? CompanyJobBoardId { get; set; }
    public string? EmailAddress { get; set; }
    public bool IsActive { get; set; } = true;
    public long? CompanyId { get; set; }
    public Company? Company { get; set; }
    public LookupData? JobBoard { get; set; }
}