﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class NotificationTemplate : BaseEntity
    {
        public long? JobApplicationStatusId { get; set; }
        public long? ApplicantInterviewStatusId { get; set; }
        public long? TypeId { get; set; }
        public string? MatchingSendGridEmailTemplateId { get; set; }
        public string? EmailTemplateName { get; set; }
        public LookupData? ReceiverType { get; set; }
        public JobApplicationStatus? JobApplicationStatus { get; set; }
        public LookupData? ApplicantInterviewStatus { get; set; }
    }
}