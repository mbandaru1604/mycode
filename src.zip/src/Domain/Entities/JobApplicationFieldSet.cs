﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class JobApplicationFieldSet : AuditEntity
    {
        public long? JobApplicationId { get; set; }
        public JobApplication? JobApplication { get; set; }
        public List<JobApplicationFieldSetFieldValue>? FieldValues { get; set; }
    }
}