﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class CompanyJobCodeSequence : AuditEntity
{
    public long CompanyId { get; set; }
    public int SequenceNumber { get; set; }
    public Company? Company { get; set; }
}