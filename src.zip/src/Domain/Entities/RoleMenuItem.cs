﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class RoleMenuItem : BaseEntity
{
    public long? RoleId { get; set; }
    public long? MenuItemId { get; set; }
    public Role? Role { get; set; }
    public MenuItem? MenuItem { get; set; }
}
