﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class JobApplicationStatusTransition : BaseEntity
    {
        public long? FromStatusId { get; set; }
        public long? TriggerId { get; set; }
        public long? ToStatusId { get; set; }
        public string? Note { get; set; }
        public JobApplicationStatus? FromStatus { get; set; }
        public LookupData? Trigger { get; set; }
        public JobApplicationStatus? ToStatus { get; set; }
    }
}