﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class Company : AuditEntity
{
    public int? Code { get; set; }
    public string? DbaName { get; set; }
    public string? LegalName { get; set; }
    public string? StatusCode { get; set; }
    public DateOnly? Start { get; set; }
    public DateOnly? End { get; set; }
    public Guid? Identifier { get; set; }
    public List<WorksiteLocation>? WorksiteLocations { get; set; }
}