﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class JobApplication : AuditEntity
    {
        public long? CompanyId { get; set; }
        public string? ApplicantName { get; set; }
        public long? JobPostId { get; set; }
        public JobPost? JobPost { get; set; }
        public long? StatusId { get; set; }
        public Guid? CorrelationId { get; set; }
        public string? EmployeeId { get; set; }
        public long? NewHireTypeId { get; set; }
        public List<JobApplicationFieldValue>? FieldValues { get; set; }
        public List<JobApplicationFieldSet>? FieldSets { get; set; }
        public JobApplicationStatus? Status { get; set; }
        public List<JobApplicationAttachment>? Attachments { get; set; }
        public LookupData? NewHireType { get; set; }
        public ApplicantQuizResult? ApplicantQuizResult { get; set; }
        public Company? Company { get; set; }
    }
}