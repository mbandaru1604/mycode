﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicantQuizResult : AuditEntity
{
    public long? JobApplicationId { get; set; }
    public long? QuizId { get; set; }
    public int? Score { get; set; }
    public bool? IsPassed { get; set; }
    public ApplicantQuiz? Quiz { get; set; }
    public JobApplication? JobApplication { get; set; }
    public IList<ApplicantQuizResultQA>? QuizAnswers { get; set; }
}