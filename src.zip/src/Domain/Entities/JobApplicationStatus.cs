﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class JobApplicationStatus : BaseEntity
{
    public string? Name { get; set; }
    public int? DisplayOrder { get; set; }
}