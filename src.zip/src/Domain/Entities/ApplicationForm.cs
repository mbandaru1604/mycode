﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationForm : AuditEntity
{
    public string? Name { get; set; }
    public bool? IsActive { get; set; }
    public bool? IncludeEducationHistory { get; set; }
    public bool? IncludeWorkHistory { get; set; }
    public List<ApplicationFormField> Fields { get; set; } = [];
    public Company? Company { get; set; }
    public long? CompanyId { get; set; }
    public List<JobPost>? JobPosts { get; set; }
}