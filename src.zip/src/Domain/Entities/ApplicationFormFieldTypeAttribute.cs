﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationFormFieldTypeAttribute : BaseEntity
{
    public long? FieldTypeId { get; set; }
    public long? FieldAttributeId { get; set; }
    public ApplicationFormFieldType? FieldType { get; set; }
    public ApplicationFormFieldAttribute? FieldAttribute { get; set; }
}