﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicantQuiz : AuditEntity
{
    public string? Name { get; set; }
    public int? MinimumPassingScore { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public long? CompanyId { get; set; }
    public Company? Company { get; set; }
    public List<QuizQuestion>? QuizQuestions { get; set; }
}