﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class ApplicantQuizResultQA : AuditEntity
    {
        public long? QuestionId { get; set; }
        public long? AnswerId { get; set; }
        public bool IsCorrect { get; set; }
        public long? ResultId { get; set; }
        public ApplicantQuizResult? ApplicantQuizResult { get; set; }
        public QuizQuestion? QuizQuestion { get; set; }
        public QuizQuestionAnswer? QuizQuestionAnswer { get; set; }
    }
}