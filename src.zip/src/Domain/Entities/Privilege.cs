﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class Privilege : BaseEntity
{
    public string? Name { get; set; }
    public string? DisplayName { get; set; }
    public string? Feature { get; set; }
    public string? SubFeature { get; set; }
    public bool IsActive { get; set; } = true;
}