﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class ApplicationFormFieldAttributeValue : AuditEntity
    {
        public long? AttributeId { get; set; }
        public ApplicationFormFieldAttribute? Attribute { get; set; }
        public string? AttributeValue { get; set; }
        public long? FormFieldId { get; set; }
        public bool IsDeleted { get; set; } = false;
        public ApplicationFormField? FormField { get; set; }
    }
}