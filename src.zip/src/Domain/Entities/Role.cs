﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class Role : BaseEntity
{
    public string? Code { get; set; }
    public string? Name { get; set; }
}