﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class QuizQuestionAnswer : AuditEntity
{
    public required string Answer { get; set; }
    public bool IsCorrect { get; set; }
    public long? QuizQuestionId { get; set; }
    public bool IsDeleted { get; set; } = false;
    public QuizQuestion? QuizQuestion { get; set; }
}