﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class JobPostCategory : AuditEntity
{
    public long? CompanyId { get; set; }
    public bool IsActive { get; set; }
    public bool IsDeleted { get; set; }
    public string? Name { get; set; }
    public Company? Company { get; set; }
}