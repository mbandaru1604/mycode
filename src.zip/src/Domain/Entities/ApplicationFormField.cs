﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationFormField : AuditEntity
{
    public string? Name { get; set; }
    public long? TypeId { get; set; }
    public ApplicationFormFieldType? Type { get; set; }
    public long? SectionId { get; set; }
    public ApplicationFormSection? Section { get; set; }
    public long? ApplicationFormId { get; set; }
    public ApplicationForm? ApplicationForm { get; set; }
    public long? DefaultFieldId { get; set; }
    public ApplicationFormDefaultField? DefaultField { get; set; }
    public Company? Company { get; set; }
    public long? CompanyId { get; set; }
    public int? DisplayOrder { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsAlwaysActiveAndRequired { get; set; }
    public bool? IsRequired { get; set; }
    public bool? IsSystemDefault { get; set; }
    public long? LookupTypeId { get; set; }
    public LookupType? LookupType { get; set; }
    public bool IsDeleted { get; set; } = false;
    public List<ApplicationFormFieldAttributeValue> AttributeValues { get; set; } = [];
    public List<ApplicationFormFieldOption> Options { get; set; } = [];
}