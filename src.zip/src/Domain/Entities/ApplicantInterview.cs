﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicantInterview : AuditEntity
{
    public long? CompanyId { get; set; }
    public long? JobApplicationId { get; set; }
    public long? InterviewTypeId { get; set; }
    public DateOnly? InterviewDate { get; set; }
    public DateTime? StartDateTime { get; set; }
    public DateTime? EndDateTime { get; set; }
    public long? StatusId { get; set; }
    public string? MeetingLink { get; set; }
    public long? WorksiteLocationId { get; set; }
    public long? LocationTypeId { get; set; }
    public string? Location { get; set; }
    public string? Address1 { get; set; }
    public string? Address2 { get; set; }
    public string? City { get; set; }
    public long? StateId { get; set; }
    public string? ZipCode { get; set; }
    public bool? IsEmailSent { get; set; }
    public string? TimeZone { get; set; }
    public string? StartTime { get; set; }
    public string? EndTime { get; set; }
    public JobApplication? JobApplication { get; set; }
    public LookupData? InterviewType { get; set; }
    public LookupData? Status { get; set; }
    public WorksiteLocation? WorksiteLocation { get; set; }
    public LookupData? LocationType { get; set; }
    public LookupData? State { get; set; }
    public List<ApplicantInterviewer>? Interviewers { get; set; }
    public Company? Company { get; set; }
}