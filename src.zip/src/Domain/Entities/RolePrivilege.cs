﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class RolePrivilege : BaseEntity
{
    public long? RoleId { get; set; }
    public long? PrivilegeId { get; set; }
    public Role? Role { get; set; }
    public Privilege? Privilege { get; set; }
}