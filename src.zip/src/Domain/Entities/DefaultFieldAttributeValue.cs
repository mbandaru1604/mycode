﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class DefaultFieldAttributeValue : BaseEntity
    {
        public long? AttributeId { get; set; }
        public ApplicationFormFieldAttribute? Attribute { get; set; }
        public string? AttributeValue { get; set; }
        public long? DefaultFieldId { get; set; }
        public ApplicationFormDefaultField? DefaultField { get; set; }
    }
}