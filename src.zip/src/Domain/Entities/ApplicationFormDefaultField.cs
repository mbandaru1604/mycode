﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationFormDefaultField : BaseEntity
{
    public string? Name { get; set; }
    public int? DisplayOrder { get; set; }
    public bool? IsActive { get; set; }
    public bool? IsRequired { get; set; }
    public bool? IsAlwaysActiveAndRequired { get; set; }
    public long? SectionId { get; set; }
    public long? TypeId { get; set; }
    public long? LookupTypeId { get; set; }
    public ApplicationFormSection? Section { get; set; }
    public ApplicationFormFieldType? Type { get; set; }
    public LookupType? LookupType { get; set; }
    public List<DefaultFieldAttributeValue> AttributeValues { get; set; } = [];
}