﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class JobApplicationStatusHistory : AuditEntity
    {
        public long? JobApplicationId { get; set; }
        public long? FromStatusId { get; set; }
        public long? ToStatusId { get; set; }
        public bool IsManualUpdate { get; set; } = false;
        public bool IsEmailSent { get; set; }
        public JobApplication? JobApplication { get; set; }
        public JobApplicationStatus? FromStatus { get; set; }
        public JobApplicationStatus? ToStatus { get; set; }
    }
}