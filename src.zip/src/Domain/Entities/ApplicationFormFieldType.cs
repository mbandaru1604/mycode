﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationFormFieldType : BaseEntity
{
    public string? DisplayName { get; set; }
    public string? Name { get; set; }
    public bool IsCustomFieldType { get; set; }
    public List<ApplicationFormFieldAttribute>? Attributes { get; set; }
    public List<ApplicationFormFieldTypeAttribute>? FieldTypeAttributes { get; set; }
}