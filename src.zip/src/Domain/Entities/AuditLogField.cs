﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class AuditLogField : BaseEntity
{
    public string? Name { get; set; } 

}