﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationFormFieldAttribute : BaseEntity
{
    public string? Name { get; set; }
    public bool IsActive { get; set; } = true;
    public List<ApplicationFormFieldType>? FieldTypes { get; set; }
    public List<ApplicationFormFieldTypeAttribute>? FieldTypeAttributes { get; set; }
}