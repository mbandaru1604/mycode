﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class UserCompanyRole : AuditEntity
{
    public long? UserId { get; set; }
    public string? UserType { get; set; }
    public long? CompanyId { get; set; }
    public long? RoleId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public User? User { get; set; }
    public Company? Company { get; set; }
    public Role? Role { get; set; }
}