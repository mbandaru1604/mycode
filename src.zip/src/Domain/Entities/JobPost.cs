﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class JobPost : AuditEntity
{
    public string? Title { get; set; }
    public string? Description { get; set; }
    public bool? IsActive { get; set; }
    public string? CCEmailAddresses { get; set; }
    public bool? IsSubmitted { get; set; }
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public long? CategoryId { get; set; }
    public long? CompanyId { get; set; }
    public string? JobCode { get; set; }
    public long? ApplicationFormId { get; set; }
    public long? EEOClassId { get; set; }
    public long? EmployeeTypeId { get; set; }
    public long? PayMethodId { get; set; }
    public long? PayGroupId { get; set; }
    public long? WorkArrangementId { get; set; }
    public long? LocationTypeId { get; set; }
    public string? City { get; set; }
    public long? StateId { get; set; }
    public string? Country { get; set; }
    public string? Location { get; set; }
    public Company? Company { get; set; }
    public JobPostCategory? Category { get; set; }
    public LookupData? EEOClass { get; set; }
    public LookupData? PayGroup { get; set; }
    public LookupData? PayMethod { get; set; }
    public LookupData? EmployeeType { get; set; }
    public LookupData? WorkArrangement { get; set; }
    public LookupData? LocationType { get; set; }
    public LookupData? State { get; set; }
    public ApplicationForm? ApplicationForm { get; set; }
    public Guid? LinkId { get; set; }
    public WorksiteLocation? WorksiteLocation { get; set; }
    public long? WorksiteLocationId { get; set; }
    public decimal? MinSalary { get; set; }
    public decimal? MaxSalary { get; set; }
    public decimal? Salary { get; set; }
    public string? SalaryComments { get; set; }
    public long? HiringManagerId { get; set; }
    public User? HiringManager { get; set; }
    public bool OptOutNotification { get; set; } = false;
    public long? ApplicantQuizId { get; set; }
    public ApplicantQuiz? ApplicantQuiz { get; set; }
    public string? DerivedLocation { get; set; }
    public DateOnly? SubmittedDate { get; set; }
    public DateTimeOffset? StartDateTime{ get; set;}
    public DateTimeOffset? EndDateTime { get; set; }
}