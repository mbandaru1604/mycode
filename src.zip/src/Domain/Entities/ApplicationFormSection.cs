﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class ApplicationFormSection : BaseEntity
{
    public string? Name { get; set; }
    public int? DisplayOrder { get; set; }
    public long? TypeId { get; set; }
    public bool IsCustomFieldSection { get; set; }
    public LookupData? Type { get; set; }
}