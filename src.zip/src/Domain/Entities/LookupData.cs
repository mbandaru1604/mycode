﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities
{
    public class LookupData : BaseEntity
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public long? TypeId { get; set; }
        public LookupType? Type { get; set; }
        public int? DisplayOrder { get; set; }
        public bool IsActive { get; set; } = true;
    }
}