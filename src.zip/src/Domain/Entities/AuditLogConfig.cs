﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class AuditLogConfig : BaseEntity
{
    public long? PageId { get; set; }
    public long? SectionId { get; set; }
    public long? FieldId { get; set; }

    public LookupData? Page { get; set; }
    public LookupData? Section { get; set; }
    public AuditLogField? Field { get; set; }
}