﻿using BBSI.ATS.Domain.Common;

namespace BBSI.ATS.Domain.Entities;

public class JobApplicationNote : AuditEntity
{
    public long? CompanyId { get; set; }
    public long? JobApplicationId { get; set; }
    public long? ApplicantInterviewId { get; set; }
    public long? JobApplicationStatusId { get; set; }
    public long? ApplicantInterviewStatusId { get; set; }
    public string? Note { get; set; }
    public int? Rating { get; set; }
    public bool IsManualUpdate { get; set; } = true;
    public JobApplication? JobApplication { get; set; }
    public ApplicantInterview? ApplicantInterview { get; set; }
    public JobApplicationStatus? JobApplicationStatus { get; set; }
    public LookupData? ApplicantInterviewStatus { get; set; }
    public Company? Company { get; set; }
}