﻿using BBSI.ATS.Common;

namespace BBSI.ATS.Infrastructure.Data.Extensions;

public static class DbContextExtensions
{
    public static IQueryable<TEntity> Paginate<TEntity>(this IQueryable<TEntity> source, Pagination? pagination)
    {
        if (pagination == null) return source;

        return source
        .Skip((pagination.PageNumber - 1) * pagination.PageSize)
        .Take(pagination.PageSize);
    }

    public static IOrderedEnumerable<TEntity> OrderBy<TEntity, TKey>(this IEnumerable<TEntity> source, Func<TEntity, TKey> keySelector, bool isAscendingOrder)
    {
        return isAscendingOrder ? source.OrderBy(keySelector) : source.OrderByDescending(keySelector);
    }
}