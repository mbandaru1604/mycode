﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddedStatecodes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Code",
                table: "LookupData",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 1,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 2,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 3,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 4,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 5,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 6,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 7,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 8,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 9,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 10,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 11,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 12,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 13,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 14,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 15,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 16,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 17,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 18,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 19,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 20,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 21,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 22,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 23,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 24,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 25,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 26,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 27,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 28,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 29,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 30,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 31,
                column: "Code",
                value: null);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 32,
                column: "Code",
                value: "AL");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 33,
                column: "Code",
                value: "AK");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 34,
                column: "Code",
                value: "AZ");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 35,
                column: "Code",
                value: "AR");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 36,
                column: "Code",
                value: "CA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 37,
                column: "Code",
                value: "CO");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 38,
                column: "Code",
                value: "CT");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 39,
                column: "Code",
                value: "DE");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 40,
                columns: new[] { "Code", "Name" },
                values: new object[] { "DC", "DISTRICT OF COLUMBIA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 41,
                columns: new[] { "Code", "Name" },
                values: new object[] { "FL", "FLORIDA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 42,
                columns: new[] { "Code", "Name" },
                values: new object[] { "GA", "GEORGIA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 43,
                columns: new[] { "Code", "Name" },
                values: new object[] { "HI", "HAWAII" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 44,
                columns: new[] { "Code", "Name" },
                values: new object[] { "ID", "IDAHO" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 45,
                columns: new[] { "Code", "DisplayOrder", "Name" },
                values: new object[] { "IL", 45, "ILLINOIS" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 46,
                columns: new[] { "Code", "Name" },
                values: new object[] { "IN", "INDIANA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 47,
                columns: new[] { "Code", "Name" },
                values: new object[] { "IA", "IOWA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 48,
                columns: new[] { "Code", "Name" },
                values: new object[] { "KS", "KANSAS" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 49,
                columns: new[] { "Code", "Name" },
                values: new object[] { "KY", "KENTUCKY" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 50,
                columns: new[] { "Code", "Name" },
                values: new object[] { "LA", "LOUISIANA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 51,
                columns: new[] { "Code", "Name" },
                values: new object[] { "ME", "MAINE" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 52,
                columns: new[] { "Code", "Name" },
                values: new object[] { "MD", "MARYLAND" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 53,
                columns: new[] { "Code", "Name" },
                values: new object[] { "MA", "MASSACHUSETTS" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 54,
                columns: new[] { "Code", "Name" },
                values: new object[] { "MI", "MICHIGAN" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 55,
                columns: new[] { "Code", "Name" },
                values: new object[] { "MN", "MINNESOTA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 56,
                columns: new[] { "Code", "Name" },
                values: new object[] { "MS", "MISSISSIPPI" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 57,
                columns: new[] { "Code", "Name" },
                values: new object[] { "MO", "MISSOURI" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 58,
                columns: new[] { "Code", "Name" },
                values: new object[] { "MT", "MONTANA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 59,
                columns: new[] { "Code", "Name" },
                values: new object[] { "NE", "NEBRASKA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 60,
                columns: new[] { "Code", "Name" },
                values: new object[] { "NV", "NEVADA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 61,
                columns: new[] { "Code", "Name" },
                values: new object[] { "NH", "NEW HAMPSHIRE" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 62,
                columns: new[] { "Code", "Name" },
                values: new object[] { "NJ", "NEW JERSEY" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 63,
                columns: new[] { "Code", "Name" },
                values: new object[] { "NM", "NEW MEXICO" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 64,
                columns: new[] { "Code", "Name" },
                values: new object[] { "NY", "NEW YORK" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 65,
                columns: new[] { "Code", "Name" },
                values: new object[] { "NC", "NORTH CAROLINA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 66,
                columns: new[] { "Code", "Name" },
                values: new object[] { "ND", "NORTH DAKOTA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 67,
                columns: new[] { "Code", "Name" },
                values: new object[] { "OH", "OHIO" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 68,
                columns: new[] { "Code", "Name" },
                values: new object[] { "OK", "OKLAHOMA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 69,
                columns: new[] { "Code", "Name" },
                values: new object[] { "OR", "OREGON" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 70,
                columns: new[] { "Code", "Name" },
                values: new object[] { "PA", "PENNSYLVANIA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 71,
                columns: new[] { "Code", "Name" },
                values: new object[] { "PR", "PUERTO RICO" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 72,
                columns: new[] { "Code", "Name" },
                values: new object[] { "RI", "RHODE ISLAND" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 73,
                columns: new[] { "Code", "Name" },
                values: new object[] { "SC", "SOUTH CAROLINA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 74,
                columns: new[] { "Code", "Name" },
                values: new object[] { "SD", "SOUTH DAKOTA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 75,
                columns: new[] { "Code", "Name" },
                values: new object[] { "TN", "TENNESSEE" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 76,
                columns: new[] { "Code", "Name" },
                values: new object[] { "TX", "TEXAS" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 77,
                columns: new[] { "Code", "Name" },
                values: new object[] { "UT", "UTAH" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 78,
                columns: new[] { "Code", "Name" },
                values: new object[] { "VT", "VERMONT" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 79,
                columns: new[] { "Code", "Name" },
                values: new object[] { "VA", "VIRGINIA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 80,
                columns: new[] { "Code", "Name" },
                values: new object[] { "WA", "WASHINGTON" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 81,
                columns: new[] { "Code", "Name" },
                values: new object[] { "WV", "WEST VIRGINIA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 82,
                columns: new[] { "Code", "Name" },
                values: new object[] { "WI", "WISCONSIN" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 83,
                columns: new[] { "Code", "Name" },
                values: new object[] { "WY", "WYOMING" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Code",
                table: "LookupData");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 40,
                column: "Name",
                value: "FLORIDA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 41,
                column: "Name",
                value: "GEORGIA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 42,
                column: "Name",
                value: "HAWAII");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 43,
                column: "Name",
                value: "IDAHO");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 44,
                column: "Name",
                value: "ILLINOIS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 45,
                columns: new[] { "DisplayOrder", "Name" },
                values: new object[] { 46, "INDIANA" });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 46,
                column: "Name",
                value: "IOWA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 47,
                column: "Name",
                value: "KANSAS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 48,
                column: "Name",
                value: "KENTUCKY");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 49,
                column: "Name",
                value: "LOUISIANA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 50,
                column: "Name",
                value: "MAINE");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 51,
                column: "Name",
                value: "MARYLAND");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 52,
                column: "Name",
                value: "MASSACHUSETTS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 53,
                column: "Name",
                value: "MICHIGAN");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 54,
                column: "Name",
                value: "MINNESOTA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 55,
                column: "Name",
                value: "MISSISSIPPI");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 56,
                column: "Name",
                value: "MISSOURI");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 57,
                column: "Name",
                value: "MONTANA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 58,
                column: "Name",
                value: "NEBRASKA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 59,
                column: "Name",
                value: "NEVADA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 60,
                column: "Name",
                value: "NEW HAMPSHIRE");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 61,
                column: "Name",
                value: "NEW JERSEY");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 62,
                column: "Name",
                value: "NEW MEXICO");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 63,
                column: "Name",
                value: "NEW YORK");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 64,
                column: "Name",
                value: "NORTH CAROLINA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 65,
                column: "Name",
                value: "NORTH DAKOTA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 66,
                column: "Name",
                value: "OHIO");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 67,
                column: "Name",
                value: "OKLAHOMA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 68,
                column: "Name",
                value: "OREGON");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 69,
                column: "Name",
                value: "PENNSYLVANIA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 70,
                column: "Name",
                value: "RHODE ISLAND");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 71,
                column: "Name",
                value: "SOUTH CAROLINA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 72,
                column: "Name",
                value: "SOUTH DAKOTA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 73,
                column: "Name",
                value: "TENNESSEE");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 74,
                column: "Name",
                value: "TEXAS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 75,
                column: "Name",
                value: "UTAH");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 76,
                column: "Name",
                value: "VERMONT");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 77,
                column: "Name",
                value: "VIRGINIA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 78,
                column: "Name",
                value: "WASHINGTON");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 79,
                column: "Name",
                value: "WEST VIRGINIA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 80,
                column: "Name",
                value: "WISCONSIN");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 81,
                column: "Name",
                value: "WYOMING");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 82,
                column: "Name",
                value: "DISTRICT OF COLUMBIA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 83,
                column: "Name",
                value: "PUERTO RICO");
        }
    }
}
