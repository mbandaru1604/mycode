﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddWorkArrangement : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "WorkArrangementId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 5, "Work Arrangement" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Name", "TypeId" },
                values: new object[,]
                {
                    { 27, "Remote", 5 },
                    { 28, "Hybrid", 5 },
                    { 29, "Onsite", 5 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_WorkArrangementId",
                table: "JobPost",
                column: "WorkArrangementId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_LookupData_WorkArrangementId",
                table: "JobPost",
                column: "WorkArrangementId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_LookupData_WorkArrangementId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_WorkArrangementId",
                table: "JobPost");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 27);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 28);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 29);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DropColumn(
                name: "WorkArrangementId",
                table: "JobPost");
        }
    }
}
