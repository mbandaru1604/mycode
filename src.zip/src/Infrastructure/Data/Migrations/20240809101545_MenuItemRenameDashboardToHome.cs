﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class MenuItemRenameDashboardToHome : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                           table: "MenuItem",
                           keyColumn: "Id",
                           keyValue: 1,
                           column: "Label",
                           value: "Home");

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 1,
                column: "Icon",
                value: "icon-home-light");

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
               table: "MenuItem",
               keyColumn: "Id",
               keyValue: 1,
               column: "Label",
               value: "Dashboard");

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 1,
                column: "Icon",
                value: "icon-dashboard-light");           
        }
    }
}
