﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class LocationTypeToJobPost : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 6, "Location Type" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Name", "TypeId" },
                values: new object[,]
                {
                    { 30, "Worksite Location", 6 },
                    { 31, "Custom Location", 6 }
                });

            migrationBuilder.AddColumn<int>(
                name: "LocationTypeId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_LocationTypeId",
                table: "JobPost",
                column: "LocationTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_LookupData_LocationTypeId",
                table: "JobPost",
                column: "LocationTypeId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_LookupData_LocationTypeId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_LocationTypeId",
                table: "JobPost");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 30);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 31);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DropColumn(
                name: "LocationTypeId",
                table: "JobPost");
        }
    }
}
