﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobPostUpdateSchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<bool>(
                name: "IsActive",
                table: "JobPost",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldDefaultValue: true);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "JobPost",
                type: "nvarchar(max)",
                maxLength: -1,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(4000)",
                oldMaxLength: 4000);

            migrationBuilder.AddColumn<string>(
                name: "CCEmailAddresses",
                table: "JobPost",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CategoryId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "EEOClassId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "EmployeeTypeId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateOnly>(
                name: "EndDate",
                table: "JobPost",
                type: "date",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsSubmitted",
                table: "JobPost",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "PayGroupId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "PayMethodId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateOnly>(
                name: "StartDate",
                table: "JobPost",
                type: "date",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "LookupType",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LookupType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "LookupData",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    TypeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LookupData", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LookupData_LookupType_TypeId",
                        column: x => x.TypeId,
                        principalTable: "LookupType",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Employee Type" },
                    { 2, "EEO Class" },
                    { 3, "Pay Group" },
                    { 4, "Pay Method" }
                });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Name", "TypeId" },
                values: new object[,]
                {
                    { 1, "Full Time", 1 },
                    { 2, "Part Time", 1 },
                    { 3, "Part Time Eligible for Benefits", 1 },
                    { 4, "Seasonal", 1 },
                    { 5, "Variable", 1 },
                    { 6, "Executive/ Senior Level Officials/ Managers", 2 },
                    { 7, "First/ Mid Level Officials/ Managers", 2 },
                    { 8, "Part Time Eligible for Benefits", 2 },
                    { 9, "Professionals", 2 },
                    { 10, "Technicians", 2 },
                    { 11, "Sales Workers", 2 },
                    { 12, "Administrative Support Workers", 2 },
                    { 13, "Craft or Skilled Workers", 2 },
                    { 14, "Operatives or Semi-Skilled Workers", 2 },
                    { 15, "Laborers or Helpers", 2 },
                    { 16, "Service Workers", 2 },
                    { 17, "Annually", 3 },
                    { 18, "Bi-weekly", 3 },
                    { 19, "Monthly", 3 },
                    { 20, "Quarterly", 3 },
                    { 21, "Semi-Monthly", 3 },
                    { 22, "Weekly", 3 },
                    { 23, "Daily", 3 },
                    { 24, "Hourly", 4 },
                    { 25, "Salary", 4 },
                    { 26, "Commission", 4 },
                    { 27, "Driver", 4 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_CategoryId",
                table: "JobPost",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_EEOClassId",
                table: "JobPost",
                column: "EEOClassId");

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_EmployeeTypeId",
                table: "JobPost",
                column: "EmployeeTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_PayGroupId",
                table: "JobPost",
                column: "PayGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_PayMethodId",
                table: "JobPost",
                column: "PayMethodId");

            migrationBuilder.CreateIndex(
                name: "IX_LookupData_TypeId",
                table: "LookupData",
                column: "TypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_JobPostCategory_CategoryId",
                table: "JobPost",
                column: "CategoryId",
                principalTable: "JobPostCategory",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_LookupData_EEOClassId",
                table: "JobPost",
                column: "EEOClassId",
                principalTable: "LookupData",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_LookupData_EmployeeTypeId",
                table: "JobPost",
                column: "EmployeeTypeId",
                principalTable: "LookupData",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_LookupData_PayGroupId",
                table: "JobPost",
                column: "PayGroupId",
                principalTable: "LookupData",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_LookupData_PayMethodId",
                table: "JobPost",
                column: "PayMethodId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_JobPostCategory_CategoryId",
                table: "JobPost");

            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_LookupData_EEOClassId",
                table: "JobPost");

            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_LookupData_EmployeeTypeId",
                table: "JobPost");

            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_LookupData_PayGroupId",
                table: "JobPost");

            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_LookupData_PayMethodId",
                table: "JobPost");

            migrationBuilder.DropTable(
                name: "LookupData");

            migrationBuilder.DropTable(
                name: "LookupType");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_CategoryId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_EEOClassId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_EmployeeTypeId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_PayGroupId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_PayMethodId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "CCEmailAddresses",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "CategoryId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "EEOClassId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "EmployeeTypeId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "EndDate",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "IsSubmitted",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "PayGroupId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "PayMethodId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "StartDate",
                table: "JobPost");

            migrationBuilder.AlterColumn<bool>(
                name: "IsActive",
                table: "JobPost",
                type: "bit",
                nullable: false,
                defaultValue: true,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldDefaultValue: false);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "JobPost",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldMaxLength: -1);
        }
    }
}
