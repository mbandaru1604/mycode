﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class RemoveWrongEntryInEEOClass : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 27);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 8,
                column: "Name",
                value: "Professionals");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 9,
                column: "Name",
                value: "Technicians");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 10,
                column: "Name",
                value: "Sales Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 11,
                column: "Name",
                value: "Administrative Support Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 12,
                column: "Name",
                value: "Craft or Skilled Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 13,
                column: "Name",
                value: "Operatives or Semi-Skilled Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 14,
                column: "Name",
                value: "Laborers or Helpers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 15,
                column: "Name",
                value: "Service Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 16,
                columns: new[] { "Name", "TypeId" },
                values: new object[] { "Annually", 3 });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 17,
                column: "Name",
                value: "Bi-weekly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 18,
                column: "Name",
                value: "Monthly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 19,
                column: "Name",
                value: "Quarterly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 20,
                column: "Name",
                value: "Semi-Monthly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 21,
                column: "Name",
                value: "Weekly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 22,
                column: "Name",
                value: "Daily");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 23,
                columns: new[] { "Name", "TypeId" },
                values: new object[] { "Hourly", 4 });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 24,
                column: "Name",
                value: "Salary");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 25,
                column: "Name",
                value: "Commission");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 26,
                column: "Name",
                value: "Driver");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 8,
                column: "Name",
                value: "Part Time Eligible for Benefits");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 9,
                column: "Name",
                value: "Professionals");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 10,
                column: "Name",
                value: "Technicians");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 11,
                column: "Name",
                value: "Sales Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 12,
                column: "Name",
                value: "Administrative Support Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 13,
                column: "Name",
                value: "Craft or Skilled Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 14,
                column: "Name",
                value: "Operatives or Semi-Skilled Workers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 15,
                column: "Name",
                value: "Laborers or Helpers");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 16,
                columns: new[] { "Name", "TypeId" },
                values: new object[] { "Service Workers", 2 });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 17,
                column: "Name",
                value: "Annually");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 18,
                column: "Name",
                value: "Bi-weekly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 19,
                column: "Name",
                value: "Monthly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 20,
                column: "Name",
                value: "Quarterly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 21,
                column: "Name",
                value: "Semi-Monthly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 22,
                column: "Name",
                value: "Weekly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 23,
                columns: new[] { "Name", "TypeId" },
                values: new object[] { "Daily", 3 });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 24,
                column: "Name",
                value: "Hourly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 25,
                column: "Name",
                value: "Salary");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 26,
                column: "Name",
                value: "Commission");

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Name", "TypeId" },
                values: new object[] { 27, "Driver", 4 });
        }
    }
}
