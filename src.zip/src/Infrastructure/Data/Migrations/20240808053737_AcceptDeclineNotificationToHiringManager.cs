﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AcceptDeclineNotificationToHiringManager : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 158, null, 8, true, "Applicant Offer Accepted Notification To Hiring Manager", 15 },
                    { 159, null, 9, true, "Applicant Offer Declined Notification To Hiring Manager", 15 }
                });

            migrationBuilder.InsertData(
                table: "NotificationTemplate",
                columns: new[] { "Id", "ApplicantInterviewStatusId", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "TypeId" },
                values: new object[,]
                {
                    { 10, null, null, null, "ats-applicants-offeracceptednotification-hiringmanager", 5, "d-79833af620df4f9e90a53843f4dc5258", null, null, 158 },
                    { 11, null, null, null, "ats-applicant-offerdeclinednotification-hiringmanager", 6, "d-73fa8d40523b4063ad011f38b14a3cd1", null, null, 159 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 158);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 159);
        }
    }
}
