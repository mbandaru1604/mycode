﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddEditListApplicationForm : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ApplicationFormFieldAttribute",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormFieldAttribute", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ApplicationFormFieldType",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DisplayName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormFieldType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ApplicationFormSection",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormSection", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Company",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Company", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ApplicationFormFieldTypeAttribute",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FieldTypeId = table.Column<int>(type: "int", nullable: false),
                    FieldAttributeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormFieldTypeAttribute", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicationFormFieldTypeAttribute_ApplicationFormFieldAttribute_FieldAttributeId",
                        column: x => x.FieldAttributeId,
                        principalTable: "ApplicationFormFieldAttribute",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicationFormFieldTypeAttribute_ApplicationFormFieldType_FieldTypeId",
                        column: x => x.FieldTypeId,
                        principalTable: "ApplicationFormFieldType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ApplicationFormDefaultField",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DisplayOrder = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsRequired = table.Column<bool>(type: "bit", nullable: false),
                    IsAlwaysActiveAndRequired = table.Column<bool>(type: "bit", nullable: false),
                    SectionId = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    TypeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormDefaultField", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicationFormDefaultField_ApplicationFormFieldType_TypeId",
                        column: x => x.TypeId,
                        principalTable: "ApplicationFormFieldType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicationFormDefaultField_ApplicationFormSection_SectionId",
                        column: x => x.SectionId,
                        principalTable: "ApplicationFormSection",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ApplicationForm",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(56)", maxLength: 56, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    DisplayEEOSurvey = table.Column<bool>(type: "bit", nullable: true),
                    DisplayEducation = table.Column<bool>(type: "bit", nullable: true),
                    DisplayPreviousEmployers = table.Column<bool>(type: "bit", nullable: true),
                    CompanyId = table.Column<int>(type: "int", nullable: true),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationForm", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicationForm_Company_CompanyId",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "ApplicationFormField",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    TypeId = table.Column<int>(type: "int", nullable: false),
                    SectionId = table.Column<int>(type: "int", nullable: false),
                    ApplicationFormId = table.Column<int>(type: "int", nullable: false),
                    DefaultFieldId = table.Column<int>(type: "int", nullable: true),
                    CompanyId = table.Column<int>(type: "int", nullable: true),
                    DisplayOrder = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsAlwaysActiveAndRequired = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    IsRequired = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    IsSystemDefault = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormField", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicationFormField_ApplicationFormDefaultField_DefaultFieldId",
                        column: x => x.DefaultFieldId,
                        principalTable: "ApplicationFormDefaultField",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ApplicationFormField_ApplicationFormFieldType_TypeId",
                        column: x => x.TypeId,
                        principalTable: "ApplicationFormFieldType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicationFormField_ApplicationFormSection_SectionId",
                        column: x => x.SectionId,
                        principalTable: "ApplicationFormSection",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicationFormField_ApplicationForm_ApplicationFormId",
                        column: x => x.ApplicationFormId,
                        principalTable: "ApplicationForm",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicationFormField_Company_CompanyId",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "ApplicationFormFieldAttributeValue",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AttributeId = table.Column<int>(type: "int", nullable: false),
                    AttributeValue = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FormFieldId = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormFieldAttributeValue", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicationFormFieldAttributeValue_ApplicationFormFieldAttribute_AttributeId",
                        column: x => x.AttributeId,
                        principalTable: "ApplicationFormFieldAttribute",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicationFormFieldAttributeValue_ApplicationFormField_FormFieldId",
                        column: x => x.FormFieldId,
                        principalTable: "ApplicationFormField",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ApplicationFormFieldOption",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    FormFieldId = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationFormFieldOption", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicationFormFieldOption_ApplicationFormField_FormFieldId",
                        column: x => x.FormFieldId,
                        principalTable: "ApplicationFormField",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "ApplicationFormFieldAttribute",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Max Length" },
                    { 2, "Max File Upload Size" },
                    { 3, "Text Value" }
                });

            migrationBuilder.InsertData(
                table: "ApplicationFormFieldType",
                columns: new[] { "Id", "DisplayName", "Name" },
                values: new object[,]
                {
                    { 1, "Drop-down list", "DropdownList" },
                    { 2, "File Upload", "FileUpload" },
                    { 3, "Text Box", "TextBox" },
                    { 4, "Text Area", "TextArea" },
                    { 5, "Body Text", "BodyText" }
                });

            migrationBuilder.InsertData(
                table: "ApplicationFormSection",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Personal Details" },
                    { 2, "Addresses" },
                    { 3, "Professional Details" },
                    { 4, "Others" }
                });

      

            migrationBuilder.InsertData(
                table: "ApplicationFormDefaultField",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "IsAlwaysActiveAndRequired", "IsRequired", "Name", "SectionId", "TypeId" },
                values: new object[,]
                {
                    { 1, 1, true, true, true, "First Name", 1, 3 },
                    { 2, 2, true, false, false, "Middle Name", 1, 3 },
                    { 3, 3, true, true, true, "Last Name", 1, 3 },
                    { 4, 4, true, true, true, "Email", 1, 3 },
                    { 5, 5, true, false, false, "Home Phone", 1, 3 },
                    { 6, 6, true, true, true, "Mobile", 1, 3 },
                    { 7, 7, true, false, true, "Address Line 1", 2, 3 },
                    { 8, 8, true, false, false, "Address Line 2", 2, 3 },
                    { 9, 9, true, false, true, "Zip Code", 2, 3 },
                    { 10, 10, true, true, true, "Country", 2, 1 },
                    { 11, 11, true, false, true, "City", 2, 3 },
                    { 12, 12, true, true, true, "State", 2, 3 },
                    { 13, 13, true, false, false, "Photo Upload", 3, 2 },
                    { 14, 14, true, true, true, "Resume Upload", 3, 2 },
                    { 15, 15, true, false, false, "Cover Letter", 3, 2 },
                    { 16, 16, true, false, false, "When are you available to start work?", 3, 3 }
                });

            migrationBuilder.InsertData(
                table: "ApplicationFormFieldTypeAttribute",
                columns: new[] { "Id", "FieldAttributeId", "FieldTypeId" },
                values: new object[,]
                {
                    { 1, 1, 3 },
                    { 2, 1, 4 },
                    { 3, 3, 5 },
                    { 4, 2, 2 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationForm_CompanyId",
                table: "ApplicationForm",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormDefaultField_SectionId",
                table: "ApplicationFormDefaultField",
                column: "SectionId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormDefaultField_TypeId",
                table: "ApplicationFormDefaultField",
                column: "TypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormField_ApplicationFormId",
                table: "ApplicationFormField",
                column: "ApplicationFormId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormField_CompanyId",
                table: "ApplicationFormField",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormField_DefaultFieldId",
                table: "ApplicationFormField",
                column: "DefaultFieldId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormField_SectionId",
                table: "ApplicationFormField",
                column: "SectionId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormField_TypeId",
                table: "ApplicationFormField",
                column: "TypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormFieldAttributeValue_AttributeId",
                table: "ApplicationFormFieldAttributeValue",
                column: "AttributeId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormFieldAttributeValue_FormFieldId",
                table: "ApplicationFormFieldAttributeValue",
                column: "FormFieldId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormFieldOption_FormFieldId",
                table: "ApplicationFormFieldOption",
                column: "FormFieldId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormFieldTypeAttribute_FieldAttributeId",
                table: "ApplicationFormFieldTypeAttribute",
                column: "FieldAttributeId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormFieldTypeAttribute_FieldTypeId",
                table: "ApplicationFormFieldTypeAttribute",
                column: "FieldTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ApplicationFormFieldAttributeValue");

            migrationBuilder.DropTable(
                name: "ApplicationFormFieldOption");

            migrationBuilder.DropTable(
                name: "ApplicationFormFieldTypeAttribute");

            migrationBuilder.DropTable(
                name: "ApplicationFormField");

            migrationBuilder.DropTable(
                name: "ApplicationFormFieldAttribute");

            migrationBuilder.DropTable(
                name: "ApplicationFormDefaultField");

            migrationBuilder.DropTable(
                name: "ApplicationForm");

            migrationBuilder.DropTable(
                name: "ApplicationFormFieldType");

            migrationBuilder.DropTable(
                name: "ApplicationFormSection");

            migrationBuilder.DropTable(
                name: "Company");
        }
    }
}
