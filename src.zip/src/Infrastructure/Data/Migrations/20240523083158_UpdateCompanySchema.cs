﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdateCompanySchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Company",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DropColumn(
                name: "Name",
                table: "Company");

            migrationBuilder.AlterColumn<int>(
                name: "Code",
                table: "Company",
                type: "int",
                maxLength: 6,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AddColumn<string>(
                name: "DbaName",
                table: "Company",
                type: "nvarchar(157)",
                maxLength: 157,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "LegalName",
                table: "Company",
                type: "nvarchar(114)",
                maxLength: 114,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "StatusCode",
                table: "Company",
                type: "nvarchar(114)",
                maxLength: 114,
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DbaName",
                table: "Company");

            migrationBuilder.DropColumn(
                name: "LegalName",
                table: "Company");

            migrationBuilder.DropColumn(
                name: "StatusCode",
                table: "Company");

            migrationBuilder.AlterColumn<string>(
                name: "Code",
                table: "Company",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldMaxLength: 6);

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "Company",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                defaultValue: "");
        }
    }
}