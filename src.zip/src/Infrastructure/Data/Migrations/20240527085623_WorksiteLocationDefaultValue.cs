﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class WorksiteLocationDefaultValue : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Company",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.AlterColumn<string>(
                name: "Country",
                table: "WorksiteLocation",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                defaultValue: "United States",
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true,
                oldDefaultValue: "USA");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Country",
                table: "WorksiteLocation",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                defaultValue: "USA",
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50,
                oldNullable: true,
                oldDefaultValue: "United States");

            migrationBuilder.InsertData(
                table: "Company",
                columns: new[] { "Id", "Code", "CreatedBy", "CreatedOn", "DbaName", "LegalName", "ModifiedBy", "ModifiedOn", "StatusCode" },
                values: new object[] { 1, 111111, null, null, "DBA1", "Legal1", null, null, "A" });
        }
    }
}
