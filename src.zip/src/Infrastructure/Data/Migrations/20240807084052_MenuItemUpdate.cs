﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class MenuItemUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Dashboard", "icon-dashboard-light", "Home", "/dashboard" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Applicant List", "icon-applicant-list", "Applicant List", "/applicantlist" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Application Forms", "icon-application-from-settings-light", "Application Forms", "/application-form" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Categories", "icon-job-category-light", "Job Categories", "/job-category" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Applicant Quiz", "icon-quiz-light", "Applicant Quizzes", "/quiz" });

            migrationBuilder.InsertData(
                table: "MenuItem",
                columns: new[] { "Id", "Code", "DisplayOrder", "Icon", "IsVisible", "Label", "Url" },
                values: new object[,]
                {
                    { 6, "Job Posts", 6, "icon-manage-jobs-light", true, "Job Posts", "/manage-job" },
                    { 7, "Audit Log", 7, "icon-audit-log-light", true, "Audit Log", "/audit-log" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Application Forms", "icon-application-from-settings-light", "Application Forms", "/application-form" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Categories", "icon-job-category-light", "Job Categories", "/job-category" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Job Posts", "icon-manage-jobs-light", "Job Posts", "/manage-job" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Applicant Reports", "icon-application-reports-light", "Applicant List", "/application-report" });

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "Code", "Icon", "Label", "Url" },
                values: new object[] { "Audit Log", "icon-audit-log-light", "Audit Log", "/audit-log" });
        }
    }
}
