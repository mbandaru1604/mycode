﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobApplicationStatus : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "StatusId",
                table: "JobApplication",
                type: "int",
                nullable: true);

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 12, "JobApplication Status" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 100, null, 1, true, "Applied", 12 },
                    { 101, null, 2, true, "Interview Scheduled", 12 },
                    { 102, null, 3, true, "Interview No Show", 12 },
                    { 103, null, 4, true, "Interview Canceled", 12 },
                    { 104, null, 5, true, "Interview Completed", 12 },
                    { 105, null, 6, true, "Not Selected", 12 },
                    { 106, null, 7, true, "Offer Extended", 12 },
                    { 107, null, 8, true, "Offer Accepted", 12 },
                    { 108, null, 9, true, "Offer Declined", 12 },
                    { 109, null, 10, true, "Onboarding", 12 },
                    { 110, null, 11, true, "Hired", 12 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobApplication_StatusId",
                table: "JobApplication",
                column: "StatusId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplication_LookupData_StatusId",
                table: "JobApplication",
                column: "StatusId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobApplication_LookupData_StatusId",
                table: "JobApplication");

            migrationBuilder.DropIndex(
                name: "IX_JobApplication_StatusId",
                table: "JobApplication");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 100);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 101);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 102);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 103);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 104);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 105);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 106);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 107);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 108);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 109);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 110);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DropColumn(
                name: "StatusId",
                table: "JobApplication");
        }
    }
}
