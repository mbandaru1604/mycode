﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobPostCategoryListUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDelete",
                table: "JobPostCategory");

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "JobPostCategory",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "JobPostCategory");

            migrationBuilder.AddColumn<bool>(
                name: "IsDelete",
                table: "JobPostCategory",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }
    }
}
