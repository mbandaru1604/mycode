﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AttachmentLookupTyp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 13,
                column: "Name",
                value: "JobApplication Attachment Type");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 13,
                column: "Name",
                value: "JobApplication Attachment");
        }
    }
}
