﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class RemoteWorkArrangement : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "City",
                table: "JobPost",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Country",
                table: "JobPost",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StateId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 7, "State" }
                });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Name", "TypeId" },
                values: new object[,]
                {
                    { 32, "Arizona", 7 },
                    { 33, "California", 7 },
                    { 34, "Colorado", 7 },
                    { 35, "Delaware", 7 },
                    { 36, "Idaho", 7 },
                    { 37, "Illinois", 7 },
                    { 38, "Kentucky", 7 },
                    { 39, "Louisiana", 7 },
                    { 40, "Maryland", 7 },
                    { 41, "Massachusetts", 7 },
                    { 42, "Minnesota", 7 },
                    { 43, "Missouri", 7 },
                    { 44, "Nevada", 7 },
                    { 45, "New York", 7 },
                    { 46, "North Carolina", 7 },
                    { 47, "Ohio", 7 },
                    { 48, "Oklahoma", 7 },
                    { 49, "Oregon", 7 },
                    { 50, "Pennsylvania", 7 },
                    { 51, "Tennessee", 7 },
                    { 52, "Texas", 7 },
                    { 53, "Utah", 7 },
                    { 54, "Washington", 7 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_StateId",
                table: "JobPost",
                column: "StateId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_LookupData_StateId",
                table: "JobPost",
                column: "StateId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_LookupData_StateId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_StateId",
                table: "JobPost");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 32);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 33);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 34);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 35);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 36);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 37);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 38);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 39);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 40);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 41);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 42);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 43);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 44);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 45);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 48);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 49);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 50);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 51);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 52);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 53);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 54);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DropColumn(
                name: "City",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "Country",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "StateId",
                table: "JobPost");
        }
    }
}
