﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class RolePrivilageConfigurationUpdated : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RolePrivilege_Privilege_PrivilegeId1",
                table: "RolePrivilege");

            migrationBuilder.DropIndex(
                name: "IX_RolePrivilege_PrivilegeId1",
                table: "RolePrivilege");

            migrationBuilder.DropColumn(
                name: "PrivilegeId1",
                table: "RolePrivilege");

            migrationBuilder.DropColumn(
                name: "CreatedBy",
                table: "Privilege");

            migrationBuilder.DropColumn(
                name: "CreatedOn",
                table: "Privilege");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                table: "Privilege");

            migrationBuilder.DropColumn(
                name: "ModifiedOn",
                table: "Privilege");

            migrationBuilder.DropColumn(
                name: "Version",
                table: "Privilege");

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Feature", "SubFeature" },
                values: new object[] { "ApplicationForms", "ApplicationForms" });

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Feature", "SubFeature" },
                values: new object[] { "ApplicationForms", "ApplicationForms" });

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Feature", "SubFeature" },
                values: new object[] { "ApplicationForms", "ApplicationForms" });

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "Feature", "Name", "SubFeature" },
                values: new object[] { "ApplicationForms", "ApplicationFormFilters", "ApplicationForms" });

            migrationBuilder.InsertData(
                table: "Privilege",
                columns: new[] { "Id", "DisplayName", "Feature", "IsActive", "Name", "SubFeature" },
                values: new object[,]
                {
                    { 5, "Job Category List Page", "JobCategories", true, "JobCategoryListPage", "JobCategories" },
                    { 6, "Add Category", "JobCategories", true, "AddCategory", "JobCategories" },
                    { 7, "Edit Category", "JobCategories", true, "EditCategory", "JobCategories" },
                    { 8, "Delete Category", "JobCategories", true, "DeleteCategory", "JobCategories" },
                    { 9, "Filters", "JobCategories", true, "JobCategoryFilters", "JobCategories" },
                    { 10, "Job Posts List Page", "Job Posts", true, "JobPostsListPage", "JobPosts" },
                    { 11, "Add Job Post", "JobPosts", true, "AddJobPost", "JobPosts" },
                    { 12, "Edit Job Post", "JobPosts", true, "EditJobPost", "JobPosts" },
                    { 13, "Copy to Clipboard", "JobPosts", true, "CopyToClipboard", "JobPosts" },
                    { 14, "Job Post Preview", "JobPosts", true, "JobPostPreview", "JobPosts" },
                    { 15, "Filters", "JobPosts", true, "JobPostFilters", "JobPosts" },
                    { 16, "Publish Jobs to Indeed", "JobPosts", true, "PublishJobsToIndeed", "JobPosts" },
                    { 17, "View All Job Posts", "ApplyForJobPosts", true, "ViewAllJobPosts", "ApplyForJobPosts" },
                    { 18, "Apply for Job Posts", "ApplyForJobPosts", true, "ApplyForJobPosts", "ApplyForJobPosts" },
                    { 19, "Filters", "ApplyForJobPosts", true, "ApplyForJobPostsFilters", "ApplyForJobPosts" },
                    { 20, "Applicant Details List Page", "ApplicantDetails", true, "ApplicantDetailsListPage", "ApplicantDetailsListPage" },
                    { 21, "Filters", "ApplicantDetails", true, "ApplicantDetailsFilters", "ApplicantDetailsListPage" },
                    { 22, "Completed Application", "ApplicantDetails", true, "CompletedApplication", "ApplicationTab" },
                    { 23, "Ability to Download Application", "ApplicantDetails", true, "AbilityToDownloadApplication", "ApplicationTab" },
                    { 24, "Ability to Purge Applicant Data", "ApplicantDetails", true, "AbilityToPurgeApplicantData", "ApplicationTab" },
                    { 25, "Interviews List Page", "ApplicantDetails", true, "InterviewsListPage", "InterviewTab" },
                    { 26, "Schedule Interview", "ApplicantDetails", true, "ScheduleInterview", "InterviewTab" },
                    { 27, "Edit Scheduled Interview", "ApplicantDetails", true, "EditScheduledInterview", "InterviewTab" },
                    { 28, "Cancel Scheduled Interview", "ApplicantDetails", true, "CancelScheduledInterview", "InterviewTab" },
                    { 29, "Mark Interview as No-Show", "ApplicantDetails", true, "MarkInterviewAsNoShow", "InterviewTab" },
                    { 30, "Interview Notes Feedback", "ApplicantDetails", true, "InterviewNotesFeedback", "InterviewTab" },
                    { 31, "Edit Interview Notes", "ApplicantDetails", true, "InterviewEditNotes", "InterviewTab" },
                    { 32, "Notes List Page", "ApplicantDetails", true, "NotesListPage", "NotesTab" },
                    { 33, "View Notes", "ApplicantDetails", true, "ViewNotes", "NotesTab" },
                    { 34, "Add Notes", "ApplicantDetails", true, "AddNotes", "NotesTab" },
                    { 35, "Edit Notes", "ApplicantDetails", true, "EditNotes", "NotesTab" },
                    { 36, "Attachments List Page", "ApplicantDetails", true, "AttachmentsListPage", "AttachmentsTab" },
                    { 37, "Add Attachments", "ApplicantDetails", true, "AddAttachments", "AttachmentsTab" },
                    { 38, "Delete Attachments", "ApplicantDetails", true, "DeleteAttachments", "AttachmentsTab" },
                    { 39, "View Attachments", "ApplicantDetails", true, "ViewAttachments", "AttachmentsTab" },
                    { 40, "Edit Attachments", "ApplicantDetails", true, "EditAttachments", "AttachmentsTab" },
                    { 41, "Manual Change Status", "StatusChangesNotifications", true, "ManualChangeStatus", "StatusChangesNotifications" },
                    { 42, "View Audit Log", "AuditLog", true, "ViewAuditLog", "AuditLog" },
                    { 43, "Export to CSV", "AuditLog", true, "ExportToCSV", "AuditLog" },
                    { 44, "Auto Log Off ATS", "Global", true, "AutoLogOffATS", "AuditLog" },
                    { 45, "Unique URL on Job Board for Each Company", "Global", true, "UniqueURLOnJobBoardForEachCompany", "Global" },
                    { 46, "Client Name and ID Added to Top of ATS Screens", "Global", true, "ClientNameAndIDAddedToTopOfATSScreens", "Global" },
                    { 47, "ATS Menu", "Global", true, "ATSMenu", "Global" },
                    { 48, "Ability to Switch Companies", "Global", true, "AbilityToSwitchCompanies", "Global" },
                    { 49, "Ability to Move Back to Portal from ATS", "Global", true, "AbilityToMoveBackToPortalFromATS", "Global" },
                    { 50, "Scheduled Interview Calendar", "Dashboard", true, "ScheduledInterviewCalendar", "Dashboard" },
                    { 51, "Pipeline Overview", "Dashboard", true, "PipelineOverview", "Dashboard" },
                    { 52, "Metrics Summary", "Dashboard", true, "MetricsSummary", "Dashboard" },
                    { 53, "Monthly Job Trend", "Dashboard", true, "MonthlyJobTrend", "Dashboard" }
                });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 4,
                column: "RoleId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 5, 3 });

            migrationBuilder.InsertData(
                table: "RolePrivilege",
                columns: new[] { "Id", "CreatedBy", "CreatedOn", "ModifiedBy", "ModifiedOn", "PrivilegeId", "RoleId" },
                values: new object[,]
                {
                    { 53, null, null, null, null, 1, 1 },
                    { 54, null, null, null, null, 2, 1 },
                    { 55, null, null, null, null, 3, 1 },
                    { 56, null, null, null, null, 4, 1 },
                    { 104, null, null, null, null, 1, 4 },
                    { 105, null, null, null, null, 2, 4 },
                    { 106, null, null, null, null, 3, 4 },
                    { 107, null, null, null, null, 4, 4 },
                    { 6, null, null, null, null, 6, 3 },
                    { 7, null, null, null, null, 7, 3 },
                    { 8, null, null, null, null, 8, 3 },
                    { 9, null, null, null, null, 9, 3 },
                    { 10, null, null, null, null, 10, 3 },
                    { 11, null, null, null, null, 11, 3 },
                    { 12, null, null, null, null, 12, 3 },
                    { 13, null, null, null, null, 13, 3 },
                    { 14, null, null, null, null, 14, 3 },
                    { 15, null, null, null, null, 15, 3 },
                    { 16, null, null, null, null, 16, 3 },
                    { 17, null, null, null, null, 17, 3 },
                    { 18, null, null, null, null, 18, 3 },
                    { 19, null, null, null, null, 19, 3 },
                    { 20, null, null, null, null, 20, 3 },
                    { 21, null, null, null, null, 21, 3 },
                    { 22, null, null, null, null, 22, 3 },
                    { 23, null, null, null, null, 23, 3 },
                    { 24, null, null, null, null, 24, 3 },
                    { 25, null, null, null, null, 25, 3 },
                    { 26, null, null, null, null, 26, 3 },
                    { 27, null, null, null, null, 27, 3 },
                    { 28, null, null, null, null, 28, 3 },
                    { 29, null, null, null, null, 29, 3 },
                    { 30, null, null, null, null, 30, 3 },
                    { 31, null, null, null, null, 31, 3 },
                    { 32, null, null, null, null, 32, 3 },
                    { 33, null, null, null, null, 33, 3 },
                    { 34, null, null, null, null, 34, 3 },
                    { 35, null, null, null, null, 35, 3 },
                    { 36, null, null, null, null, 36, 3 },
                    { 37, null, null, null, null, 37, 3 },
                    { 38, null, null, null, null, 38, 3 },
                    { 39, null, null, null, null, 39, 3 },
                    { 40, null, null, null, null, 40, 3 },
                    { 41, null, null, null, null, 41, 3 },
                    { 42, null, null, null, null, 42, 3 },
                    { 43, null, null, null, null, 43, 3 },
                    { 44, null, null, null, null, 45, 3 },
                    { 45, null, null, null, null, 46, 3 },
                    { 46, null, null, null, null, 47, 3 },
                    { 47, null, null, null, null, 48, 3 },
                    { 48, null, null, null, null, 49, 3 },
                    { 49, null, null, null, null, 50, 3 },
                    { 50, null, null, null, null, 51, 3 },
                    { 51, null, null, null, null, 52, 3 },
                    { 52, null, null, null, null, 53, 3 },
                    { 57, null, null, null, null, 5, 1 },
                    { 58, null, null, null, null, 6, 1 },
                    { 59, null, null, null, null, 7, 1 },
                    { 60, null, null, null, null, 8, 1 },
                    { 61, null, null, null, null, 9, 1 },
                    { 62, null, null, null, null, 10, 1 },
                    { 63, null, null, null, null, 11, 1 },
                    { 64, null, null, null, null, 12, 1 },
                    { 65, null, null, null, null, 13, 1 },
                    { 66, null, null, null, null, 14, 1 },
                    { 67, null, null, null, null, 15, 1 },
                    { 68, null, null, null, null, 16, 1 },
                    { 69, null, null, null, null, 17, 1 },
                    { 70, null, null, null, null, 18, 1 },
                    { 71, null, null, null, null, 19, 1 },
                    { 72, null, null, null, null, 20, 1 },
                    { 73, null, null, null, null, 21, 1 },
                    { 74, null, null, null, null, 22, 1 },
                    { 75, null, null, null, null, 23, 1 },
                    { 76, null, null, null, null, 25, 1 },
                    { 77, null, null, null, null, 26, 1 },
                    { 78, null, null, null, null, 27, 1 },
                    { 79, null, null, null, null, 28, 1 },
                    { 80, null, null, null, null, 29, 1 },
                    { 81, null, null, null, null, 30, 1 },
                    { 82, null, null, null, null, 31, 1 },
                    { 83, null, null, null, null, 32, 1 },
                    { 84, null, null, null, null, 33, 1 },
                    { 85, null, null, null, null, 34, 1 },
                    { 86, null, null, null, null, 35, 1 },
                    { 87, null, null, null, null, 36, 1 },
                    { 88, null, null, null, null, 37, 1 },
                    { 89, null, null, null, null, 38, 1 },
                    { 90, null, null, null, null, 39, 1 },
                    { 91, null, null, null, null, 40, 1 },
                    { 92, null, null, null, null, 41, 1 },
                    { 93, null, null, null, null, 42, 1 },
                    { 94, null, null, null, null, 43, 1 },
                    { 95, null, null, null, null, 45, 1 },
                    { 96, null, null, null, null, 46, 1 },
                    { 97, null, null, null, null, 47, 1 },
                    { 98, null, null, null, null, 48, 1 },
                    { 99, null, null, null, null, 49, 1 },
                    { 100, null, null, null, null, 50, 1 },
                    { 101, null, null, null, null, 51, 1 },
                    { 102, null, null, null, null, 52, 1 },
                    { 103, null, null, null, null, 53, 1 },
                    { 108, null, null, null, null, 5, 4 },
                    { 109, null, null, null, null, 6, 4 },
                    { 110, null, null, null, null, 7, 4 },
                    { 111, null, null, null, null, 8, 4 },
                    { 112, null, null, null, null, 9, 4 },
                    { 113, null, null, null, null, 10, 4 },
                    { 114, null, null, null, null, 11, 4 },
                    { 115, null, null, null, null, 12, 4 },
                    { 116, null, null, null, null, 13, 4 },
                    { 117, null, null, null, null, 14, 4 },
                    { 118, null, null, null, null, 15, 4 },
                    { 119, null, null, null, null, 16, 4 },
                    { 120, null, null, null, null, 17, 4 },
                    { 121, null, null, null, null, 18, 4 },
                    { 122, null, null, null, null, 19, 4 },
                    { 123, null, null, null, null, 20, 4 },
                    { 124, null, null, null, null, 21, 4 },
                    { 125, null, null, null, null, 22, 4 },
                    { 126, null, null, null, null, 23, 4 },
                    { 127, null, null, null, null, 25, 4 },
                    { 128, null, null, null, null, 26, 4 },
                    { 129, null, null, null, null, 27, 4 },
                    { 130, null, null, null, null, 28, 4 },
                    { 131, null, null, null, null, 29, 4 },
                    { 132, null, null, null, null, 30, 4 },
                    { 133, null, null, null, null, 31, 4 },
                    { 134, null, null, null, null, 32, 4 },
                    { 135, null, null, null, null, 33, 4 },
                    { 136, null, null, null, null, 34, 4 },
                    { 137, null, null, null, null, 35, 4 },
                    { 138, null, null, null, null, 36, 4 },
                    { 139, null, null, null, null, 37, 4 },
                    { 140, null, null, null, null, 38, 4 },
                    { 141, null, null, null, null, 39, 4 },
                    { 142, null, null, null, null, 40, 4 },
                    { 143, null, null, null, null, 41, 4 },
                    { 144, null, null, null, null, 42, 4 },
                    { 145, null, null, null, null, 43, 4 },
                    { 146, null, null, null, null, 45, 4 },
                    { 147, null, null, null, null, 46, 4 },
                    { 148, null, null, null, null, 47, 4 },
                    { 149, null, null, null, null, 48, 4 },
                    { 150, null, null, null, null, 49, 4 },
                    { 151, null, null, null, null, 50, 4 },
                    { 152, null, null, null, null, 51, 4 },
                    { 153, null, null, null, null, 52, 4 },
                    { 154, null, null, null, null, 53, 4 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 44);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 25);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 27);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 28);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 29);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 30);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 31);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 32);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 33);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 34);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 35);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 36);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 37);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 38);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 39);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 40);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 41);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 42);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 43);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 44);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 45);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 48);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 49);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 50);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 51);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 52);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 53);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 54);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 55);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 56);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 57);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 58);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 59);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 60);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 61);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 62);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 63);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 64);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 65);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 66);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 67);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 68);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 69);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 70);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 71);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 72);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 73);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 74);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 75);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 76);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 77);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 78);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 79);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 80);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 81);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 82);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 83);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 84);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 85);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 86);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 87);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 88);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 89);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 90);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 91);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 92);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 93);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 94);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 95);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 96);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 97);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 98);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 99);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 100);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 101);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 102);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 103);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 104);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 105);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 106);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 107);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 108);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 109);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 110);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 111);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 112);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 113);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 114);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 115);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 116);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 117);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 118);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 119);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 120);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 121);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 122);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 123);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 124);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 125);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 126);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 127);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 128);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 129);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 130);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 131);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 132);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 133);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 134);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 135);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 136);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 137);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 138);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 139);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 140);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 141);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 142);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 143);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 144);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 145);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 146);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 147);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 148);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 149);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 150);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 151);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 152);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 153);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 154);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 25);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 27);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 28);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 29);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 30);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 31);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 32);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 33);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 34);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 35);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 36);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 37);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 38);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 39);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 40);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 41);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 42);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 43);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 45);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 48);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 49);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 50);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 51);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 52);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 53);

            migrationBuilder.AddColumn<int>(
                name: "PrivilegeId1",
                table: "RolePrivilege",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CreatedBy",
                table: "Privilege",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "CreatedOn",
                table: "Privilege",
                type: "datetimeoffset",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ModifiedBy",
                table: "Privilege",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "ModifiedOn",
                table: "Privilege",
                type: "datetimeoffset",
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "Version",
                table: "Privilege",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedBy", "CreatedOn", "Feature", "ModifiedBy", "ModifiedOn", "SubFeature" },
                values: new object[] { null, null, "Application Forms", null, null, "Application Forms" });

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedBy", "CreatedOn", "Feature", "ModifiedBy", "ModifiedOn", "SubFeature" },
                values: new object[] { null, null, "Application Forms", null, null, "Application Forms" });

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedBy", "CreatedOn", "Feature", "ModifiedBy", "ModifiedOn", "SubFeature" },
                values: new object[] { null, null, "Application Forms", null, null, "Application Forms" });

            migrationBuilder.UpdateData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedBy", "CreatedOn", "Feature", "ModifiedBy", "ModifiedOn", "Name", "SubFeature" },
                values: new object[] { null, null, "Application Forms", null, null, "Filters", "Application Forms" });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 1,
                column: "PrivilegeId1",
                value: null);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 2,
                column: "PrivilegeId1",
                value: null);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 3,
                column: "PrivilegeId1",
                value: null);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "PrivilegeId1", "RoleId" },
                values: new object[] { null, 1 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "PrivilegeId", "PrivilegeId1", "RoleId" },
                values: new object[] { 2, null, 2 });

            migrationBuilder.CreateIndex(
                name: "IX_RolePrivilege_PrivilegeId1",
                table: "RolePrivilege",
                column: "PrivilegeId1");

            migrationBuilder.AddForeignKey(
                name: "FK_RolePrivilege_Privilege_PrivilegeId1",
                table: "RolePrivilege",
                column: "PrivilegeId1",
                principalTable: "Privilege",
                principalColumn: "Id");
        }
    }
}
