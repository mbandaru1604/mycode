﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class ActivateInactiveAField : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "DisplayOrder", "Name" },
                values: new object[] { 10, "State" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "DisplayOrder", "IsAlwaysActiveAndRequired", "IsRequired", "Name", "SectionId", "TypeId" },
                values: new object[] { 12, false, false, "Photo", 3, 2 });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 13,
                column: "Name",
                value: "Resume");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "IsAlwaysActiveAndRequired", "IsRequired", "Name" },
                values: new object[] { false, false, "Cover Letter" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 15,
                columns: new[] { "Name", "TypeId" },
                values: new object[] { "When are you available to start work?", 6 });

            migrationBuilder.InsertData(
                table: "ApplicationFormDefaultField",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "IsAlwaysActiveAndRequired", "IsRequired", "Name", "SectionId", "TypeId" },
                values: new object[] { 10, 9, true, true, true, "City", 2, 3 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "DisplayOrder", "Name" },
                values: new object[] { 9, "City" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "DisplayOrder", "IsAlwaysActiveAndRequired", "IsRequired", "Name", "SectionId", "TypeId" },
                values: new object[] { 10, true, true, "State", 2, 3 });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 13,
                column: "Name",
                value: "Photo");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "IsAlwaysActiveAndRequired", "IsRequired", "Name" },
                values: new object[] { true, true, "Resume" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 15,
                columns: new[] { "Name", "TypeId" },
                values: new object[] { "Cover Letter", 2 });

            migrationBuilder.InsertData(
                table: "ApplicationFormDefaultField",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "IsAlwaysActiveAndRequired", "IsRequired", "Name", "SectionId", "TypeId" },
                values: new object[] { 16, 16, true, false, false, "When are you available to start work?", 3, 6 });
        }
    }
}
