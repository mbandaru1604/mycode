﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobApplicationStatusTransition : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "JobApplicationStatusHistory",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobApplicationId = table.Column<int>(type: "int", nullable: false),
                    FromStatusId = table.Column<int>(type: "int", nullable: true),
                    ToStatusId = table.Column<int>(type: "int", nullable: false),
                    IsManualUpdate = table.Column<bool>(type: "bit", nullable: false),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobApplicationStatusHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_JobApplicationStatusHistory_JobApplicationStatus_FromStatusId",
                        column: x => x.FromStatusId,
                        principalTable: "JobApplicationStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_JobApplicationStatusHistory_JobApplicationStatus_ToStatusId",
                        column: x => x.ToStatusId,
                        principalTable: "JobApplicationStatus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_JobApplicationStatusHistory_JobApplication_JobApplicationId",
                        column: x => x.JobApplicationId,
                        principalTable: "JobApplication",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "JobApplicationStatusTransition",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FromStatusId = table.Column<int>(type: "int", nullable: true),
                    TriggerId = table.Column<int>(type: "int", nullable: false),
                    ToStatusId = table.Column<int>(type: "int", nullable: false),
                    Note = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobApplicationStatusTransition", x => x.Id);
                    table.ForeignKey(
                        name: "FK_JobApplicationStatusTransition_JobApplicationStatus_FromStatusId",
                        column: x => x.FromStatusId,
                        principalTable: "JobApplicationStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_JobApplicationStatusTransition_JobApplicationStatus_ToStatusId",
                        column: x => x.ToStatusId,
                        principalTable: "JobApplicationStatus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_JobApplicationStatusTransition_LookupData_TriggerId",
                        column: x => x.TriggerId,
                        principalTable: "LookupData",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 13, "JobApplication Status Transition Trigger" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 104, null, 1, true, "Initial Application Status", 13 },
                    { 105, null, 2, true, "Interview Scheduling", 13 },
                    { 106, null, 3, true, "Offer Acceptance", 13 },
                    { 107, null, 4, true, "Offer Decline", 13 },
                    { 108, null, 5, true, "Successful Hire Event", 13 }
                });

            migrationBuilder.InsertData(
                table: "JobApplicationStatusTransition",
                columns: new[] { "Id", "FromStatusId", "Note", "ToStatusId", "TriggerId" },
                values: new object[,]
                {
                    { 1, null, "The status has been changed to 'Applied'", 1, 104 },
                    { 2, 1, "The status has been changed to 'Interview Scheduled' from 'Applied'", 2, 105 },
                    { 3, 4, "The status has been changed to 'Offer Accepted' from 'Offer Extended'", 5, 106 },
                    { 4, 4, "The status has been changed to Offer Declined' from 'Offer Extended'", 6, 107 },
                    { 5, 7, "The status has been changed to 'Hired' from 'Onboarding'", 8, 108 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationStatusHistory_FromStatusId",
                table: "JobApplicationStatusHistory",
                column: "FromStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationStatusHistory_JobApplicationId",
                table: "JobApplicationStatusHistory",
                column: "JobApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationStatusHistory_ToStatusId",
                table: "JobApplicationStatusHistory",
                column: "ToStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationStatusTransition_FromStatusId",
                table: "JobApplicationStatusTransition",
                column: "FromStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationStatusTransition_ToStatusId",
                table: "JobApplicationStatusTransition",
                column: "ToStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationStatusTransition_TriggerId",
                table: "JobApplicationStatusTransition",
                column: "TriggerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "JobApplicationStatusHistory");

            migrationBuilder.DropTable(
                name: "JobApplicationStatusTransition");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 104);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 105);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 106);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 107);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 108);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 13);
        }
    }
}
