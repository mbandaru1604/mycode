﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
	/// <inheritdoc />
	public partial class OfferExtendedEmail : Migration
	{
		/// <inheritdoc />
		protected override void Up(MigrationBuilder migrationBuilder)
		{
			migrationBuilder.CreateTable(
	  name: "JobApplicationOfferToken",
	  columns: table => new
	  {
		  Id = table.Column<int>(type: "int", nullable: false)
			  .Annotation("SqlServer:Identity", "1, 1"),
		  JobApplicationId = table.Column<int>(type: "int", nullable: true),
		  Token = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
		  IsUsed = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
		  Status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
		  CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
		  CreatedBy = table.Column<int>(type: "int", nullable: true),
		  ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
		  ModifiedBy = table.Column<int>(type: "int", nullable: true),
		  Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
	  },
	  constraints: table =>
	  {
		  table.PrimaryKey("PK_JobApplicationOfferToken", x => x.Id);
		  table.ForeignKey(
			  name: "FK_JobApplicationOfferToken_JobApplication_JobApplicationId",
			  column: x => x.JobApplicationId,
			  principalTable: "JobApplication",
			  principalColumn: "Id");
	  });

			migrationBuilder.InsertData(
				table: "LookupData",
				columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
				values: new object[] { 115, null, 3, true, "Offer Extended Email Notification", 15 });

			migrationBuilder.InsertData(
				table: "NotificationTemplate",
				columns: new[] { "Id", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "ReceiverTypeId" },
				values: new object[] { 6, null, null, "ats-offerextended-applicant", 4, "d-9f8a365f214d4d33a958cf50667fb8af", null, null, 115 });

			migrationBuilder.CreateIndex(
				name: "IX_JobApplicationOfferToken_JobApplicationId",
				table: "JobApplicationOfferToken",
				column: "JobApplicationId");
		}

		/// <inheritdoc />
		protected override void Down(MigrationBuilder migrationBuilder)
		{
			migrationBuilder.DropTable(
				name: "JobApplicationOfferToken");

			migrationBuilder.DeleteData(
				table: "NotificationTemplate",
				keyColumn: "Id",
				keyValue: 6);

			migrationBuilder.DeleteData(
				table: "LookupData",
				keyColumn: "Id",
				keyValue: 115);
		}
	}
}