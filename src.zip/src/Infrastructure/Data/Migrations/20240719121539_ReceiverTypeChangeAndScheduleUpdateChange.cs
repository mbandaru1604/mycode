﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class ReceiverTypeChangeAndScheduleUpdateChange : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_NotificationTemplate_LookupData_ReceiverTypeId",
                table: "NotificationTemplate");

            migrationBuilder.RenameColumn(
                name: "ReceiverTypeId",
                table: "NotificationTemplate",
                newName: "TypeId");

            migrationBuilder.RenameIndex(
                name: "IX_NotificationTemplate_ReceiverTypeId",
                table: "NotificationTemplate",
                newName: "IX_NotificationTemplate_TypeId");

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[] { 118, null, 4, true, "Interview Schedule Update", 15 });

            migrationBuilder.InsertData(
                table: "NotificationTemplate",
                columns: new[] { "Id", "ApplicantInterviewStatusId", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "TypeId" },
                values: new object[] { 9, null, null, null, "ats-interviewupdated-applicant", 2, "d-9a31117d846849fc8098391c8cc9516d", null, null, 118 });

            migrationBuilder.AddForeignKey(
                name: "FK_NotificationTemplate_LookupData_TypeId",
                table: "NotificationTemplate",
                column: "TypeId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_NotificationTemplate_LookupData_TypeId",
                table: "NotificationTemplate");

            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 118);

            migrationBuilder.RenameColumn(
                name: "TypeId",
                table: "NotificationTemplate",
                newName: "ReceiverTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_NotificationTemplate_TypeId",
                table: "NotificationTemplate",
                newName: "IX_NotificationTemplate_ReceiverTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_NotificationTemplate_LookupData_ReceiverTypeId",
                table: "NotificationTemplate",
                column: "ReceiverTypeId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }
    }
}
