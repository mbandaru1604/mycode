﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddApplicantNameToJobApplication : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ApplicantName",
                table: "JobApplication",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApplicantName",
                table: "JobApplication");
        }
    }
}
