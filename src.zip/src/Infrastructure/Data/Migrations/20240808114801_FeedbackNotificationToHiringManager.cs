﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class FeedbackNotificationToHiringManager : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[] { 160, null, 10, true, "Interviwer feedback Notification To Hiring Manager", 15 });

            migrationBuilder.InsertData(
                table: "NotificationTemplate",
                columns: new[] { "Id", "ApplicantInterviewStatusId", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "TypeId" },
                values: new object[] { 12, null, null, null, "ats-interviewfeedbacknotificaiton-hiringmanager", 2, "d-c9e13004449e414da1cd83f28626845c", null, null, 160 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 160);
        }
    }
}
