﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobPostWorksiteLocationAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "WorksiteLocationId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_WorksiteLocationId",
                table: "JobPost",
                column: "WorksiteLocationId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_WorksiteLocation_WorksiteLocationId",
                table: "JobPost",
                column: "WorksiteLocationId",
                principalTable: "WorksiteLocation",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_WorksiteLocation_WorksiteLocationId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_WorksiteLocationId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "WorksiteLocationId",
                table: "JobPost");
        }
    }
}
