﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedNotificationTemplateConfiguration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ApplicantInterviewStatusId",
                table: "NotificationTemplate",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 99,
                column: "Name",
                value: "Interview Cancelled");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 115,
                column: "DisplayOrder",
                value: 4);

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 116, null, 5, true, "Not Selected", 15 },
                    { 117, null, 6, true, "Interview Cancelled", 15 }
                });

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 1,
                column: "ApplicantInterviewStatusId",
                value: null);

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 2,
                column: "ApplicantInterviewStatusId",
                value: null);

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 3,
                column: "ApplicantInterviewStatusId",
                value: null);

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 4,
                column: "ApplicantInterviewStatusId",
                value: null);

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 5,
                column: "ApplicantInterviewStatusId",
                value: null);

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 6,
                column: "ApplicantInterviewStatusId",
                value: null);

            migrationBuilder.InsertData(
                table: "NotificationTemplate",
                columns: new[] { "Id", "ApplicantInterviewStatusId", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "ReceiverTypeId" },
                values: new object[,]
                {
                    { 7, null, null, null, "ats-applicantnotselected", 2, "d-8d871423c4fc41cfad2770900f20bff1", null, null, 116 },
                    { 8, 99, null, null, "ats-interviewcancellednotification-applicant", null, "d-54a647ac712041eaa2a9c262310bdd23", null, null, 117 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_NotificationTemplate_ApplicantInterviewStatusId",
                table: "NotificationTemplate",
                column: "ApplicantInterviewStatusId");

            migrationBuilder.AddForeignKey(
                name: "FK_NotificationTemplate_LookupData_ApplicantInterviewStatusId",
                table: "NotificationTemplate",
                column: "ApplicantInterviewStatusId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_NotificationTemplate_LookupData_ApplicantInterviewStatusId",
                table: "NotificationTemplate");

            migrationBuilder.DropIndex(
                name: "IX_NotificationTemplate_ApplicantInterviewStatusId",
                table: "NotificationTemplate");

            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 116);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 117);

            migrationBuilder.DropColumn(
                name: "ApplicantInterviewStatusId",
                table: "NotificationTemplate");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 99,
                column: "Name",
                value: "Interview Canceled");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 115,
                column: "DisplayOrder",
                value: 3);
        }
    }
}
