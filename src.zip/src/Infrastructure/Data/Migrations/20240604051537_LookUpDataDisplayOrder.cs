﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class LookUpDataDisplayOrder : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DisplayOrder",
                table: "LookupData",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 1,
                column: "DisplayOrder",
                value: 1);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 2,
                column: "DisplayOrder",
                value: 2);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 3,
                column: "DisplayOrder",
                value: 3);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 4,
                column: "DisplayOrder",
                value: 4);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 5,
                column: "DisplayOrder",
                value: 5);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 6,
                column: "DisplayOrder",
                value: 6);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 7,
                column: "DisplayOrder",
                value: 7);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 8,
                column: "DisplayOrder",
                value: 8);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 9,
                column: "DisplayOrder",
                value: 9);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 10,
                column: "DisplayOrder",
                value: 10);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 11,
                column: "DisplayOrder",
                value: 11);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 12,
                column: "DisplayOrder",
                value: 12);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 13,
                column: "DisplayOrder",
                value: 13);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 14,
                column: "DisplayOrder",
                value: 14);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 15,
                column: "DisplayOrder",
                value: 15);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 16,
                column: "DisplayOrder",
                value: 16);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 17,
                column: "DisplayOrder",
                value: 17);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 18,
                column: "DisplayOrder",
                value: 18);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 19,
                column: "DisplayOrder",
                value: 19);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 20,
                column: "DisplayOrder",
                value: 20);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 21,
                column: "DisplayOrder",
                value: 21);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 22,
                column: "DisplayOrder",
                value: 22);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 23,
                column: "DisplayOrder",
                value: 23);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 24,
                column: "DisplayOrder",
                value: 24);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 25,
                column: "DisplayOrder",
                value: 25);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 26,
                column: "DisplayOrder",
                value: 26);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 27,
                column: "DisplayOrder",
                value: 27);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 28,
                column: "DisplayOrder",
                value: 28);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 29,
                column: "DisplayOrder",
                value: 29);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 30,
                column: "DisplayOrder",
                value: 30);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 31,
                column: "DisplayOrder",
                value: 31);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DisplayOrder",
                table: "LookupData");
        }
    }
}
