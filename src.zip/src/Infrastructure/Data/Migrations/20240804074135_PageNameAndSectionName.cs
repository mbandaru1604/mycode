﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class PageNameAndSectionName : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 154);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 155);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 156);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 157);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 158);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 159);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 160);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 143,
                column: "Name",
                value: "Add Form");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 144,
                column: "Name",
                value: "Edit Form");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 145,
                column: "Name",
                value: "Job Categories");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 146,
                column: "Name",
                value: "Job Posts");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 147,
                column: "Name",
                value: "Add New Field");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 148,
                column: "Name",
                value: "Add Category");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 149,
                column: "Name",
                value: "Edit Category");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 152,
                column: "Name",
                value: "Edit Job Post");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 153,
                column: "Name",
                value: "In-Progress");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 143,
                column: "Name",
                value: "Add Form/Edit Form");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 144,
                column: "Name",
                value: "Job Categories");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 145,
                column: "Name",
                value: "Job Posts");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 146,
                column: "Name",
                value: "Applicant Details");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 147,
                column: "Name",
                value: "General");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 148,
                column: "Name",
                value: "Add New Field");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 149,
                column: "Name",
                value: "Add Category");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 152,
                column: "Name",
                value: "In-Progress");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 153,
                column: "Name",
                value: "Application");

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 154, null, 8, true, "Interviews", 23 },
                    { 155, null, 9, true, "Attachments", 23 },
                    { 156, null, 10, true, "Notes", 23 },
                    { 157, null, 11, true, "Applicant Details", 23 },
                    { 158, null, 12, true, "Edit Job Post", 23 },
                    { 159, null, 13, true, "Edit Category", 23 },
                    { 160, null, 14, true, "Delete Job Post", 23 }
                });
        }
    }
}
