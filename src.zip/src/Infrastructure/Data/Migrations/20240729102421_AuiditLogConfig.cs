﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AuiditLogConfig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AuditLogField",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLogField", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AuditLogConfig",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PageId = table.Column<int>(type: "int", nullable: false),
                    SectionId = table.Column<int>(type: "int", nullable: false),
                    FieldId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLogConfig", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AuditLogConfig_AuditLogField_FieldId",
                        column: x => x.FieldId,
                        principalTable: "AuditLogField",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_AuditLogConfig_LookupData_PageId",
                        column: x => x.PageId,
                        principalTable: "LookupData",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_AuditLogConfig_LookupData_SectionId",
                        column: x => x.SectionId,
                        principalTable: "LookupData",
                        principalColumn: "Id");
                }); 

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                { 
                    { 22, "Page Name" },
                    { 23, "Section Name" }
                }); 

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                { 
                    { 142, null, 1, true, "Application Forms", 22 },
                    { 143, null, 2, true, "Add Form/Edit Form", 22 },
                    { 144, null, 3, true, "Job Categories", 22 },
                    { 145, null, 4, true, "Job Posts", 22 },
                    { 146, null, 5, true, "Applicant Details", 22 },
                    { 147, null, 1, true, "General", 23 },
                    { 148, null, 2, true, "Add New Field", 23 },
                    { 149, null, 3, true, "Add/Edit Category", 23 },
                    { 150, null, 4, true, "Submitted Jobs", 23 },
                    { 151, null, 5, true, "Add/Edit Job Post", 23 },
                    { 152, null, 6, true, "In-Progress", 23 },
                    { 153, null, 7, true, "Application", 23 },
                    { 154, null, 8, true, "Interviews", 23 },
                    { 155, null, 9, true, "Attachments", 23 },
                    { 156, null, 10, true, "Notes", 23 },
                    { 157, null, 11, true, "Applicant Details ", 23 }
                });  

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogConfig_FieldId",
                table: "AuditLogConfig",
                column: "FieldId");

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogConfig_PageId",
                table: "AuditLogConfig",
                column: "PageId");

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogConfig_SectionId",
                table: "AuditLogConfig",
                column: "SectionId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AuditLogConfig");

            migrationBuilder.DropTable(
                name: "AuditLogField");   

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 142);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 143);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 144);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 145);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 146);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 147);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 148);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 149);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 150);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 151);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 152);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 153);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 154);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 155);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 156);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 157); 

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 23); 
        }
    }
}
