﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedRolePrivilegeConfiguration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Privilege",
                columns: new[] { "Id", "DisplayName", "Feature", "IsActive", "Name", "SubFeature" },
                values: new object[,]
                {
                    { 54, "Email Notification Preview", "StatusChangesNotifications", true, "EmailNotificationPreview", "Notification" },
                    { 55, "Application Submitted Email to Hiring Manager Option to Send", "StatusChangesNotifications", true, "ApplicationSubmittedEmailtoHiringManagerOptiontoSend", "Notification" },
                    { 56, "Interview Scheduled Applicant Email Notification Option to Send", "StatusChangesNotifications", true, "InterviewScheduledApplicantEmailNotificationOptiontoSend", "Notification" },
                    { 57, "Interview Updated Email Notification Option to Send", "StatusChangesNotifications", true, "InterviewUpdatedEmailNotificationOptiontoSend", "Notification" },
                    { 58, "Interview Cancelled Email Notification Option to Send", "StatusChangesNotifications", true, "InterviewCancelledEmailNotificationOptiontoSend", "Notification" },
                    { 59, "Not Selected Email Notification Option to Send", "StatusChangesNotifications", true, "NotSelectedEmailNotificationOptiontoSend", "Notification" },
                    { 60, "Offer Extended Email Notification Option to Send", "StatusChangesNotifications", true, "OfferExtendedEmailNotificationOptiontoSend", "Notification" }
                });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 104,
                column: "PrivilegeId",
                value: 17);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 105,
                column: "PrivilegeId",
                value: 18);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 106,
                column: "PrivilegeId",
                value: 19);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 107,
                column: "PrivilegeId",
                value: 20);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 108,
                column: "PrivilegeId",
                value: 21);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 109,
                column: "PrivilegeId",
                value: 22);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 110,
                column: "PrivilegeId",
                value: 23);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 111,
                column: "PrivilegeId",
                value: 25);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 112,
                column: "PrivilegeId",
                value: 26);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 113,
                column: "PrivilegeId",
                value: 27);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 114,
                column: "PrivilegeId",
                value: 28);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 115,
                column: "PrivilegeId",
                value: 29);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 116,
                column: "PrivilegeId",
                value: 30);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 117,
                column: "PrivilegeId",
                value: 31);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 118,
                column: "PrivilegeId",
                value: 32);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 119,
                column: "PrivilegeId",
                value: 33);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 120,
                column: "PrivilegeId",
                value: 34);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 121,
                column: "PrivilegeId",
                value: 35);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 122,
                column: "PrivilegeId",
                value: 36);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 123,
                column: "PrivilegeId",
                value: 37);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 124,
                column: "PrivilegeId",
                value: 38);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 125,
                column: "PrivilegeId",
                value: 39);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 126,
                column: "PrivilegeId",
                value: 40);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 127,
                column: "PrivilegeId",
                value: 42);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 128,
                column: "PrivilegeId",
                value: 43);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 129,
                column: "PrivilegeId",
                value: 45);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 130,
                column: "PrivilegeId",
                value: 46);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 131,
                column: "PrivilegeId",
                value: 47);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 132,
                column: "PrivilegeId",
                value: 48);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 133,
                column: "PrivilegeId",
                value: 49);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 134,
                column: "PrivilegeId",
                value: 50);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 135,
                column: "PrivilegeId",
                value: 51);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 136,
                column: "PrivilegeId",
                value: 52);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 137,
                column: "PrivilegeId",
                value: 53);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 138,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 54, 3 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 139,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 54, 1 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 140,
                column: "PrivilegeId",
                value: 54);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 141,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 55, 3 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 142,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 55, 1 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 143,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 56, 3 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 144,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 56, 1 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 145,
                column: "PrivilegeId",
                value: 56);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 146,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 57, 3 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 147,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 57, 1 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 148,
                column: "PrivilegeId",
                value: 57);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 149,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 58, 3 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 150,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 58, 1 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 151,
                column: "PrivilegeId",
                value: 58);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 152,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 59, 3 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 153,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 59, 1 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 154,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 60, 3 });

            migrationBuilder.InsertData(
                table: "RolePrivilege",
                columns: new[] { "Id", "CreatedBy", "CreatedOn", "ModifiedBy", "ModifiedOn", "PrivilegeId", "RoleId" },
                values: new object[] { 155, null, null, null, null, 60, 1 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 54);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 55);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 56);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 57);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 58);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 59);

            migrationBuilder.DeleteData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 155);

            migrationBuilder.DeleteData(
                table: "Privilege",
                keyColumn: "Id",
                keyValue: 60);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 104,
                column: "PrivilegeId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 105,
                column: "PrivilegeId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 106,
                column: "PrivilegeId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 107,
                column: "PrivilegeId",
                value: 4);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 108,
                column: "PrivilegeId",
                value: 5);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 109,
                column: "PrivilegeId",
                value: 6);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 110,
                column: "PrivilegeId",
                value: 7);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 111,
                column: "PrivilegeId",
                value: 8);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 112,
                column: "PrivilegeId",
                value: 9);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 113,
                column: "PrivilegeId",
                value: 10);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 114,
                column: "PrivilegeId",
                value: 11);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 115,
                column: "PrivilegeId",
                value: 12);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 116,
                column: "PrivilegeId",
                value: 13);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 117,
                column: "PrivilegeId",
                value: 14);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 118,
                column: "PrivilegeId",
                value: 15);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 119,
                column: "PrivilegeId",
                value: 16);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 120,
                column: "PrivilegeId",
                value: 17);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 121,
                column: "PrivilegeId",
                value: 18);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 122,
                column: "PrivilegeId",
                value: 19);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 123,
                column: "PrivilegeId",
                value: 20);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 124,
                column: "PrivilegeId",
                value: 21);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 125,
                column: "PrivilegeId",
                value: 22);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 126,
                column: "PrivilegeId",
                value: 23);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 127,
                column: "PrivilegeId",
                value: 25);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 128,
                column: "PrivilegeId",
                value: 26);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 129,
                column: "PrivilegeId",
                value: 27);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 130,
                column: "PrivilegeId",
                value: 28);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 131,
                column: "PrivilegeId",
                value: 29);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 132,
                column: "PrivilegeId",
                value: 30);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 133,
                column: "PrivilegeId",
                value: 31);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 134,
                column: "PrivilegeId",
                value: 32);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 135,
                column: "PrivilegeId",
                value: 33);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 136,
                column: "PrivilegeId",
                value: 34);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 137,
                column: "PrivilegeId",
                value: 35);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 138,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 36, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 139,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 37, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 140,
                column: "PrivilegeId",
                value: 38);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 141,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 39, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 142,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 40, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 143,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 41, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 144,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 42, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 145,
                column: "PrivilegeId",
                value: 43);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 146,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 45, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 147,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 46, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 148,
                column: "PrivilegeId",
                value: 47);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 149,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 48, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 150,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 49, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 151,
                column: "PrivilegeId",
                value: 50);

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 152,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 51, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 153,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 52, 4 });

            migrationBuilder.UpdateData(
                table: "RolePrivilege",
                keyColumn: "Id",
                keyValue: 154,
                columns: new[] { "PrivilegeId", "RoleId" },
                values: new object[] { 53, 4 });
        }
    }
}
