﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class RemoveBodyTextField : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldTypeAttribute",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 5);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "ApplicationFormFieldType",
                columns: new[] { "Id", "DisplayName", "IsCustomFieldType", "Name" },
                values: new object[] { 5, "Body Text", true, "BodyText" });

            migrationBuilder.InsertData(
                table: "ApplicationFormFieldTypeAttribute",
                columns: new[] { "Id", "FieldAttributeId", "FieldTypeId" },
                values: new object[] { 3, 3, 5 });
        }
    }
}
