﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobPostApplicationFormIdNotNull : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_ApplicationForm_ApplicationFormId",
                table: "JobPost");

            migrationBuilder.AlterColumn<int>(
                name: "ApplicationFormId",
                table: "JobPost",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_ApplicationForm_ApplicationFormId",
                table: "JobPost",
                column: "ApplicationFormId",
                principalTable: "ApplicationForm",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_ApplicationForm_ApplicationFormId",
                table: "JobPost");

            migrationBuilder.AlterColumn<int>(
                name: "ApplicationFormId",
                table: "JobPost",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_ApplicationForm_ApplicationFormId",
                table: "JobPost",
                column: "ApplicationFormId",
                principalTable: "ApplicationForm",
                principalColumn: "Id");
        }
    }
}