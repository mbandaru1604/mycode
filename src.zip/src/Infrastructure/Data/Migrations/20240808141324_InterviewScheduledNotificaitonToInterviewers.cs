﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class InterviewScheduledNotificaitonToInterviewers : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[] { 161, null, 11, true, "Interviwe Scheduled Notification To Interviewers", 15 });

            migrationBuilder.InsertData(
                table: "NotificationTemplate",
                columns: new[] { "Id", "ApplicantInterviewStatusId", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "TypeId" },
                values: new object[] { 13, null, null, null, "ats-interviewscheduled-interviewers", 2, "d-1c3db312fcb24dbe806699294103993d", null, null, 161 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 161);
        }
    }
}
