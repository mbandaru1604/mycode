﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class NewHireInitiatedEventUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 1,
                column: "Code",
                value: "F");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 2,
                column: "Code",
                value: "P");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 3,
                column: "Code",
                value: "B");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 4,
                column: "Code",
                value: "S");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 5,
                column: "Code",
                value: "V");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 16,
                column: "Code",
                value: "Y");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 17,
                column: "Code",
                value: "B");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 18,
                column: "Code",
                value: "M");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 20,
                column: "Code",
                value: "S");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 21,
                column: "Code",
                value: "W");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 23,
                column: "Code",
                value: "H");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 24,
                column: "Code",
                value: "S");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 25,
                column: "Code",
                value: "C");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 26,
                column: "Code",
                value: "D");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 1,
                column: "Code",
                value: "FULL TIME");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 2,
                column: "Code",
                value: "PART TIME");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 3,
                column: "Code",
                value: "PART-TIME ELIGIBILE FOR BENEFITS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 4,
                column: "Code",
                value: "SEASONAL");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 5,
                column: "Code",
                value: "VARIABLE");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 16,
                column: "Code",
                value: "Annually");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 17,
                column: "Code",
                value: "Bi-Weekly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 18,
                column: "Code",
                value: "Monthly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 20,
                column: "Code",
                value: "Semi-Monthly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 21,
                column: "Code",
                value: "Weekly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 23,
                column: "Code",
                value: "Hourly");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 24,
                column: "Code",
                value: "Salary");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 25,
                column: "Code",
                value: "Commission");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 26,
                column: "Code",
                value: "Driver");
        }
    }
}
