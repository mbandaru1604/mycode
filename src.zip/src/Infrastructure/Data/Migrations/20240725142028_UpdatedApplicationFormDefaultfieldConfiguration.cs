﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedApplicationFormDefaultfieldConfiguration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "ApplicationFormFieldType",
                columns: new[] { "Id", "DisplayName", "IsCustomFieldType", "Name" },
                values: new object[] { 9, "Radio Button", false, "RadioButton" });

            migrationBuilder.InsertData(
                table: "ApplicationFormSection",
                columns: new[] { "Id", "DisplayOrder", "Name", "TypeId" },
                values: new object[] { 7, 5, "Voluntary Self-Identification", 91 });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 118,
                column: "DisplayOrder",
                value: 7);

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 17, "Voluntary Self Identification" },
                    { 18, "Gender" },
                    { 19, "EthnicityRace" },
                    { 20, "Veteran" },
                    { 21, "Veteran Status" }
                });

            migrationBuilder.InsertData(
                table: "ApplicationFormDefaultField",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "IsAlwaysActiveAndRequired", "IsRequired", "LookupTypeId", "Name", "SectionId", "TypeId" },
                values: new object[,]
                {
                    { 26, 26, true, false, false, 17, "Voluntary Self-Identification", 7, 9 },
                    { 27, 27, true, false, false, 18, "Gender", 7, 1 },
                    { 28, 28, true, false, false, 19, "EthnicityRace", 7, 1 },
                    { 29, 29, true, false, false, 20, "Veteran", 7, 9 },
                    { 30, 30, true, false, false, 21, "Veteran Status", 7, 1 },
                    { 31, 31, true, false, false, null, "Disability", 7, 4 }
                });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 122, null, 1, true, "Yes, I would like to volunteer this information", 17 },
                    { 123, null, 2, true, "No, I would not like to volunteer this information", 17 },
                    { 124, null, 1, true, "Female", 18 },
                    { 125, null, 2, true, "Male", 18 },
                    { 126, null, 3, true, "Non-disclosed", 18 },
                    { 127, null, 4, true, "Other", 18 },
                    { 128, null, 1, true, "American Indian or Alaska Native (Non-Hispanic or Latino)", 19 },
                    { 129, null, 2, true, "Asian (Non-Hispanic or Latino)", 19 },
                    { 130, null, 3, true, "Black or African American (Non-Hispanic or Latino)", 19 },
                    { 131, null, 4, true, "Hispanic or Latino", 19 },
                    { 132, null, 5, true, "Native Hawaiian or Other Pacific Islander (Non-Hispanic or Latino)", 19 },
                    { 133, null, 6, true, "White (Non-Hispanic or Latino)", 19 },
                    { 134, null, 1, true, "I am a veteran", 20 },
                    { 135, null, 2, true, "Not a veteran", 20 },
                    { 136, null, 3, true, "I prefer not to disclose", 20 },
                    { 137, null, 1, true, "Active Duty Wartime or Campaign Badge Veteran", 21 },
                    { 138, null, 2, true, "Armed Forces Service Medal Veteran", 21 },
                    { 139, null, 3, true, "Disabled Veteran", 21 },
                    { 140, null, 4, true, "Other Veteran", 21 },
                    { 141, null, 5, true, "Recently Separated Veteran", 21 }
                });

            migrationBuilder.InsertData(
                table: "DefaultFieldAttributeValue",
                columns: new[] { "Id", "AttributeId", "AttributeValue", "DefaultFieldId" },
                values: new object[] { 23, 1, "500", 31 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 27);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 28);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 29);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 30);

            migrationBuilder.DeleteData(
                table: "DefaultFieldAttributeValue",
                keyColumn: "Id",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 122);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 123);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 124);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 125);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 126);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 127);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 128);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 129);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 130);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 131);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 132);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 133);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 134);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 135);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 136);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 137);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 138);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 139);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 140);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 141);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 31);

            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 118,
                column: "DisplayOrder",
                value: 4);
        }
    }
}
