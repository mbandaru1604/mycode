﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class REQ1086EducationHistoryWorkHistory : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TypeId",
                table: "ApplicationFormSection",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "JobApplicationFieldSet",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobApplicationId = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobApplicationFieldSet", x => x.Id);
                    table.ForeignKey(
                        name: "FK_JobApplicationFieldSet_JobApplication_JobApplicationId",
                        column: x => x.JobApplicationId,
                        principalTable: "JobApplication",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "JobApplicationFieldSetFieldValue",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FormFieldValue = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    FormFieldSetId = table.Column<int>(type: "int", nullable: false),
                    FormFieldId = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobApplicationFieldSetFieldValue", x => x.Id);
                    table.ForeignKey(
                        name: "FK_JobApplicationFieldSetFieldValue_ApplicationFormField_FormFieldId",
                        column: x => x.FormFieldId,
                        principalTable: "ApplicationFormField",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_JobApplicationFieldSetFieldValue_JobApplicationFieldSet_FormFieldSetId",
                        column: x => x.FormFieldSetId,
                        principalTable: "JobApplicationFieldSet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 1,
                column: "TypeId",
                value: 91);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 2,
                column: "TypeId",
                value: 91);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 3,
                column: "TypeId",
                value: 91);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 4,
                column: "TypeId",
                value: 91);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 5,
                column: "TypeId",
                value: 92);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 6,
                column: "TypeId",
                value: 92);

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 9, "Section Type" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 91, null, 1, true, "Regular", 9 },
                    { 92, null, 2, true, "Tabular", 9 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormSection_TypeId",
                table: "ApplicationFormSection",
                column: "TypeId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationFieldSet_JobApplicationId",
                table: "JobApplicationFieldSet",
                column: "JobApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationFieldSetFieldValue_FormFieldId",
                table: "JobApplicationFieldSetFieldValue",
                column: "FormFieldId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationFieldSetFieldValue_FormFieldSetId",
                table: "JobApplicationFieldSetFieldValue",
                column: "FormFieldSetId");

            migrationBuilder.AddForeignKey(
                name: "FK_ApplicationFormSection_LookupData_TypeId",
                table: "ApplicationFormSection",
                column: "TypeId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ApplicationFormSection_LookupData_TypeId",
                table: "ApplicationFormSection");

            migrationBuilder.DropTable(
                name: "JobApplicationFieldSetFieldValue");

            migrationBuilder.DropTable(
                name: "JobApplicationFieldSet");

            migrationBuilder.DropIndex(
                name: "IX_ApplicationFormSection_TypeId",
                table: "ApplicationFormSection");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 91);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 92);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DropColumn(
                name: "TypeId",
                table: "ApplicationFormSection");
        }
    }
}
