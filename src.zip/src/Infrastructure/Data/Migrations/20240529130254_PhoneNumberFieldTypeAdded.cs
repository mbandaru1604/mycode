﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class PhoneNumberFieldTypeAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        { 
            migrationBuilder.InsertData(
                table: "ApplicationFormFieldType",
                columns: new[] { "Id", "DisplayName", "Name" },
                values: new object[] { 7, "Phone Number", "PhoneNumber" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 5,
                column: "TypeId",
                value: 7);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 6,
                column: "TypeId",
                value: 7);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 5,
                column: "TypeId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 6,
                column: "TypeId",
                value: 3);

            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 7);
        }
    }
}
