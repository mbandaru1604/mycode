﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class DefaultFieldModified : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.InsertData(
                            table: "ApplicationFormFieldType",
                            columns: new[] { "Id", "DisplayName", "Name" },
                            values: new object[] { 6, "Date Picker", "DatePicker" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 4,
                column: "Name",
                value: "Personal Email Address");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 5,
                column: "Name",
                value: "Home Telephone Number");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 6,
                column: "Name",
                value: "Mobile Phone Number");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 7,
                column: "IsAlwaysActiveAndRequired",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "DisplayOrder", "IsAlwaysActiveAndRequired" },
                values: new object[] { 11, true });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "DisplayOrder", "IsAlwaysActiveAndRequired" },
                values: new object[] { 9, true });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 12,
                column: "DisplayOrder",
                value: 10);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 16,
                column: "TypeId",
                value: 6);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Personal Information");

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "Address");

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Work History");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 4,
                column: "Name",
                value: "Email");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 5,
                column: "Name",
                value: "Home Phone");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 6,
                column: "Name",
                value: "Mobile");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 7,
                column: "IsAlwaysActiveAndRequired",
                value: false);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "DisplayOrder", "IsAlwaysActiveAndRequired" },
                values: new object[] { 9, false });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "DisplayOrder", "IsAlwaysActiveAndRequired" },
                values: new object[] { 11, false });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 12,
                column: "DisplayOrder",
                value: 12);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 16,
                column: "TypeId",
                value: 3);

            migrationBuilder.InsertData(
                table: "ApplicationFormDefaultField",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "IsAlwaysActiveAndRequired", "IsRequired", "Name", "SectionId", "TypeId" },
                values: new object[] { 10, 10, true, true, true, "County", 2, 1 });

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Personal Details");

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "Addresses");

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Professional Details");

            migrationBuilder.DeleteData(
                            table: "ApplicationFormFieldType",
                            keyColumn: "Id",
                            keyValue: 6);

        }
    }
}
