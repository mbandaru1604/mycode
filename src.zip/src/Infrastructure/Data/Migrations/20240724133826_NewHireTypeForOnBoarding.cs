﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class NewHireTypeForOnBoarding : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "NewHireTypeId",
                table: "JobApplication",
                type: "int",
                nullable: true);

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 16, "New Hire Type" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 119, null, 1, true, "Electronic", 16 },
                    { 120, null, 2, true, "Manual", 16 },
                    { 121, null, 3, true, "Paper Onboarding", 16 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobApplication_NewHireTypeId",
                table: "JobApplication",
                column: "NewHireTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplication_LookupData_NewHireTypeId",
                table: "JobApplication",
                column: "NewHireTypeId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobApplication_LookupData_NewHireTypeId",
                table: "JobApplication");

            migrationBuilder.DropIndex(
                name: "IX_JobApplication_NewHireTypeId",
                table: "JobApplication");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 119);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 120);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 121);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.DropColumn(
                name: "NewHireTypeId",
                table: "JobApplication");
        }
    }
}
