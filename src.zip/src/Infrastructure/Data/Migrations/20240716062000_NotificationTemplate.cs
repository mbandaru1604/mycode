﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class NotificationTemplate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsEmailSent",
                table: "JobApplicationStatusHistory",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "NotificationTemplate",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobApplicationStatusId = table.Column<int>(type: "int", nullable: true),
                    ReceiverTypeId = table.Column<int>(type: "int", nullable: true),
                    MatchingSendGridEmailTemplateId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    EmailTemplateName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NotificationTemplate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_NotificationTemplate_JobApplicationStatus_JobApplicationStatusId",
                        column: x => x.JobApplicationStatusId,
                        principalTable: "JobApplicationStatus",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_NotificationTemplate_LookupData_ReceiverTypeId",
                        column: x => x.ReceiverTypeId,
                        principalTable: "LookupData",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 14, "Receiver Type" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 109, null, 1, true, "Applicant", 14 },
                    { 110, null, 2, true, "Hiring Manager", 14 },
                    { 111, null, 3, true, "Interviewer", 14 }
                });

            migrationBuilder.InsertData(
                table: "NotificationTemplate",
                columns: new[] { "Id", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "ReceiverTypeId" },
                values: new object[,]
                {
                    { 1, null, null, "ats-appliednotification-applicant", 1, "d-3195d5ecf9a24cb1af68198d228d6ddb", null, null, 109 },
                    { 2, null, null, "ats-appliednotification-hiringmanager", 1, "d-02ed72a2e23d41a29daeff7d1048c808", null, null, 110 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_NotificationTemplate_JobApplicationStatusId",
                table: "NotificationTemplate",
                column: "JobApplicationStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_NotificationTemplate_ReceiverTypeId",
                table: "NotificationTemplate",
                column: "ReceiverTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "NotificationTemplate");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 109);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 110);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 111);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 14);

            migrationBuilder.DropColumn(
                name: "IsEmailSent",
                table: "JobApplicationStatusHistory");
        }
    }
}
