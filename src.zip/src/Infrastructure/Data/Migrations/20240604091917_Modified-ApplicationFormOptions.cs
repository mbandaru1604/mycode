﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class ModifiedApplicationFormOptions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DisplayEEOSurvey",
                table: "ApplicationForm");

            migrationBuilder.RenameColumn(
                name: "DisplayPreviousEmployers",
                table: "ApplicationForm",
                newName: "IncludeWorkHistory");

            migrationBuilder.RenameColumn(
                name: "DisplayEducation",
                table: "ApplicationForm",
                newName: "IncludeEducationHistory");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "IncludeWorkHistory",
                table: "ApplicationForm",
                newName: "DisplayPreviousEmployers");

            migrationBuilder.RenameColumn(
                name: "IncludeEducationHistory",
                table: "ApplicationForm",
                newName: "DisplayEducation");

            migrationBuilder.AddColumn<bool>(
                name: "DisplayEEOSurvey",
                table: "ApplicationForm",
                type: "bit",
                nullable: true);
        }
    }
}
