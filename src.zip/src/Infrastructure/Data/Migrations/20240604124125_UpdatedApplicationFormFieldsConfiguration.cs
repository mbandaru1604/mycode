﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedApplicationFormFieldsConfiguration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 7,
                column: "MaxLength",
                value: 100);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 8,
                column: "MaxLength",
                value: 100);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 9,
                column: "MaxLength",
                value: 5);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 10,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                column: "TypeId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 32,
                column: "Name",
                value: "ALABAMA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 33,
                column: "Name",
                value: "ALASKA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 34,
                column: "Name",
                value: "ARIZONA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 35,
                column: "Name",
                value: "ARKANSAS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 36,
                column: "Name",
                value: "CALIFORNIA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 37,
                column: "Name",
                value: "COLORADO");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 38,
                column: "Name",
                value: "CONNECTICUT");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 39,
                column: "Name",
                value: "DELAWARE");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 40,
                column: "Name",
                value: "FLORIDA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 41,
                column: "Name",
                value: "GEORGIA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 42,
                column: "Name",
                value: "HAWAII");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 43,
                column: "Name",
                value: "IDAHO");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 44,
                column: "Name",
                value: "ILLINOIS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 45,
                column: "Name",
                value: "INDIANA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 46,
                column: "Name",
                value: "IOWA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 47,
                column: "Name",
                value: "KANSAS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 48,
                column: "Name",
                value: "KENTUCKY");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 49,
                column: "Name",
                value: "LOUISIANA");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 50,
                column: "Name",
                value: "MAINE");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 51,
                column: "Name",
                value: "MARYLAND");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 52,
                column: "Name",
                value: "MASSACHUSETTS");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 53,
                column: "Name",
                value: "MICHIGAN");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 54,
                column: "Name",
                value: "MINNESOTA");

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "DisplayOrder", "Name", "TypeId" },
                values: new object[,]
                {
                    { 55, 55, "MISSISSIPPI", 7 },
                    { 56, 56, "MISSOURI", 7 },
                    { 57, 57, "MONTANA", 7 },
                    { 58, 58, "NEBRASKA", 7 },
                    { 59, 59, "NEVADA", 7 },
                    { 60, 60, "NEW HAMPSHIRE", 7 },
                    { 61, 61, "NEW JERSEY", 7 },
                    { 62, 62, "NEW MEXICO", 7 },
                    { 63, 63, "NEW YORK", 7 },
                    { 64, 64, "NORTH CAROLINA", 7 },
                    { 65, 65, "NORTH DAKOTA", 7 },
                    { 66, 66, "OHIO", 7 },
                    { 67, 67, "OKLAHOMA", 7 },
                    { 68, 68, "OREGON", 7 },
                    { 69, 69, "PENNSYLVANIA", 7 },
                    { 70, 70, "RHODE ISLAND", 7 },
                    { 71, 71, "SOUTH CAROLINA", 7 },
                    { 72, 72, "SOUTH DAKOTA", 7 },
                    { 73, 73, "TENNESSEE", 7 },
                    { 74, 74, "TEXAS", 7 },
                    { 75, 75, "UTAH", 7 },
                    { 76, 76, "VERMONT", 7 },
                    { 77, 77, "VIRGINIA", 7 },
                    { 78, 78, "WASHINGTON", 7 },
                    { 79, 79, "WEST VIRGINIA", 7 },
                    { 80, 80, "WISCONSIN", 7 },
                    { 81, 81, "WYOMING", 7 },
                    { 82, 82, "DISTRICT OF COLUMBIA", 7 },
                    { 83, 83, "PUERTO RICO", 7 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 55);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 56);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 57);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 58);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 59);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 60);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 61);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 62);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 63);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 64);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 65);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 66);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 67);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 68);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 69);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 70);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 71);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 72);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 73);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 74);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 75);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 76);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 77);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 78);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 79);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 80);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 81);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 82);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 83);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 7,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 8,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 9,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 10,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                column: "TypeId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 32,
                column: "Name",
                value: "Arizona");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 33,
                column: "Name",
                value: "California");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 34,
                column: "Name",
                value: "Colorado");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 35,
                column: "Name",
                value: "Delaware");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 36,
                column: "Name",
                value: "Idaho");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 37,
                column: "Name",
                value: "Illinois");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 38,
                column: "Name",
                value: "Kentucky");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 39,
                column: "Name",
                value: "Louisiana");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 40,
                column: "Name",
                value: "Maryland");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 41,
                column: "Name",
                value: "Massachusetts");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 42,
                column: "Name",
                value: "Minnesota");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 43,
                column: "Name",
                value: "Missouri");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 44,
                column: "Name",
                value: "Nevada");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 45,
                column: "Name",
                value: "New York");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 46,
                column: "Name",
                value: "North Carolina");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 47,
                column: "Name",
                value: "Ohio");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 48,
                column: "Name",
                value: "Oklahoma");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 49,
                column: "Name",
                value: "Oregon");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 50,
                column: "Name",
                value: "Pennsylvania");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 51,
                column: "Name",
                value: "Tennessee");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 52,
                column: "Name",
                value: "Texas");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 53,
                column: "Name",
                value: "Utah");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 54,
                column: "Name",
                value: "Washington");
        }
    }
}
