﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class ApplicantinterviewDesignChange : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ApplicantInterviewer_ApplicantInterview_ApplicantInterviewId1",
                table: "ApplicantInterviewer");

            migrationBuilder.DropIndex(
                name: "IX_ApplicantInterviewer_ApplicantInterviewId1",
                table: "ApplicantInterviewer");

            migrationBuilder.DropColumn(
                name: "ApplicantInterviewId1",
                table: "ApplicantInterviewer");

            migrationBuilder.DropColumn(
                name: "Location",
                table: "ApplicantInterview");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "User",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "User",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AddColumn<int>(
                name: "ApplicantInterviewId1",
                table: "ApplicantInterviewer",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Location",
                table: "ApplicantInterview",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterviewer_ApplicantInterviewId1",
                table: "ApplicantInterviewer",
                column: "ApplicantInterviewId1");

            migrationBuilder.AddForeignKey(
                name: "FK_ApplicantInterviewer_ApplicantInterview_ApplicantInterviewId1",
                table: "ApplicantInterviewer",
                column: "ApplicantInterviewId1",
                principalTable: "ApplicantInterview",
                principalColumn: "Id");
        }
    }
}
