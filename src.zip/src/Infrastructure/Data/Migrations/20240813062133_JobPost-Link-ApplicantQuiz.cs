﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobPostLinkApplicantQuiz : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ApplicantQuizId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CompanyId",
                table: "ApplicantQuiz",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_ApplicantQuizId",
                table: "JobPost",
                column: "ApplicantQuizId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantQuiz_CompanyId",
                table: "ApplicantQuiz",
                column: "CompanyId");

            migrationBuilder.AddForeignKey(
                name: "FK_ApplicantQuiz_Company_CompanyId",
                table: "ApplicantQuiz",
                column: "CompanyId",
                principalTable: "Company",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_ApplicantQuiz_ApplicantQuizId",
                table: "JobPost",
                column: "ApplicantQuizId",
                principalTable: "ApplicantQuiz",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ApplicantQuiz_Company_CompanyId",
                table: "ApplicantQuiz");

            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_ApplicantQuiz_ApplicantQuizId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_ApplicantQuizId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_ApplicantQuiz_CompanyId",
                table: "ApplicantQuiz");

            migrationBuilder.DropColumn(
                name: "ApplicantQuizId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "CompanyId",
                table: "ApplicantQuiz");
        }
    }
}
