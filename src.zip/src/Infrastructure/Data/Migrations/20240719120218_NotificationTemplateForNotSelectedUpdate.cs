﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class NotificationTemplateForNotSelectedUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 7,
                column: "JobApplicationStatusId",
                value: 3);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 7,
                column: "JobApplicationStatusId",
                value: 2);
        }
    }
}
