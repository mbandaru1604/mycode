﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class Dropdownlistnamechange : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 1,
                column: "DisplayName",
                value: "Drop-down List");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 1,
                column: "DisplayName",
                value: "Drop-down list");

        }
    }
}
