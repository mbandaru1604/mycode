﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class JobPostLinkApplicationForm : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ApplicationFormId",
                table: "JobPost",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_JobPost_ApplicationFormId",
                table: "JobPost",
                column: "ApplicationFormId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobPost_ApplicationForm_ApplicationFormId",
                table: "JobPost",
                column: "ApplicationFormId",
                principalTable: "ApplicationForm",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobPost_ApplicationForm_ApplicationFormId",
                table: "JobPost");

            migrationBuilder.DropIndex(
                name: "IX_JobPost_ApplicationFormId",
                table: "JobPost");

            migrationBuilder.DropColumn(
                name: "ApplicationFormId",
                table: "JobPost");
        }
    }
}
