﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class ApplicantInterviewDesign : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "User",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ApplicantInterview",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobApplicationId = table.Column<int>(type: "int", nullable: false),
                    InterviewTypeId = table.Column<int>(type: "int", nullable: false),
                    InterviewDate = table.Column<DateOnly>(type: "date", nullable: false),
                    StartTime = table.Column<TimeOnly>(type: "time", nullable: false),
                    EndTime = table.Column<TimeOnly>(type: "time", nullable: false),
                    StatusId = table.Column<int>(type: "int", nullable: true),
                    MeetingLink = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    WorksiteLocationId = table.Column<int>(type: "int", nullable: true),
                    LocationTypeId = table.Column<int>(type: "int", nullable: true),
                    Address1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Address2 = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    City = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    StateId = table.Column<int>(type: "int", nullable: true),
                    ZipCode = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    Location = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IsEmailSent = table.Column<bool>(type: "bit", nullable: true),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicantInterview", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicantInterview_JobApplication_JobApplicationId",
                        column: x => x.JobApplicationId,
                        principalTable: "JobApplication",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicantInterview_LookupData_InterviewTypeId",
                        column: x => x.InterviewTypeId,
                        principalTable: "LookupData",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicantInterview_LookupData_LocationTypeId",
                        column: x => x.LocationTypeId,
                        principalTable: "LookupData",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ApplicantInterview_LookupData_StateId",
                        column: x => x.StateId,
                        principalTable: "LookupData",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ApplicantInterview_LookupData_StatusId",
                        column: x => x.StatusId,
                        principalTable: "LookupData",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ApplicantInterview_WorksiteLocation_WorksiteLocationId",
                        column: x => x.WorksiteLocationId,
                        principalTable: "WorksiteLocation",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "ApplicantInterviewer",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicantInterviewId = table.Column<int>(type: "int", nullable: false),
                    InterviewerId = table.Column<int>(type: "int", nullable: false),
                    ApplicantInterviewId1 = table.Column<int>(type: "int", nullable: true),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicantInterviewer", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApplicantInterviewer_ApplicantInterview_ApplicantInterviewId",
                        column: x => x.ApplicantInterviewId,
                        principalTable: "ApplicantInterview",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicantInterviewer_ApplicantInterview_ApplicantInterviewId1",
                        column: x => x.ApplicantInterviewId1,
                        principalTable: "ApplicantInterview",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ApplicantInterviewer_User_InterviewerId",
                        column: x => x.InterviewerId,
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 10, "Interview Type" },
                    { 11, "Interview Status" }
                });

            migrationBuilder.InsertData(
                table: "Role",
                columns: new[] { "Id", "CreatedBy", "CreatedOn", "ModifiedBy", "ModifiedOn", "Name" },
                values: new object[,]
                {
                    { 3, null, null, null, null, "System Administrator" },
                    { 4, null, null, null, null, "Interviewer" }
                });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "Id",
                keyValue: 1,
                column: "Email",
                value: "jhondoe@test.com");

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "Id",
                keyValue: 2,
                column: "Email",
                value: "janesmith@test.com");

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "Id",
                keyValue: 3,
                column: "Email",
                value: "micheljhonson@test.com");

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "Id",
                keyValue: 4,
                column: "Email",
                value: "emilydavis@test.com");

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "Id",
                keyValue: 5,
                column: "Email",
                value: "chrisbrown@test.com");

            migrationBuilder.UpdateData(
                table: "UserRole",
                keyColumn: "Id",
                keyValue: 3,
                column: "RoleId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "UserRole",
                keyColumn: "Id",
                keyValue: 5,
                column: "RoleId",
                value: 4);

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 93, null, 1, true, "Phone", 10 },
                    { 94, null, 2, true, "Video", 10 },
                    { 95, null, 3, true, "In-Person", 10 },
                    { 96, null, 1, true, "Interview Scheduled", 11 },
                    { 97, null, 2, true, "Interview Completed", 11 },
                    { 98, null, 3, true, "Interview No Show", 11 },
                    { 99, null, 4, true, "Interview Canceled", 11 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterview_InterviewTypeId",
                table: "ApplicantInterview",
                column: "InterviewTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterview_JobApplicationId",
                table: "ApplicantInterview",
                column: "JobApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterview_LocationTypeId",
                table: "ApplicantInterview",
                column: "LocationTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterview_StateId",
                table: "ApplicantInterview",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterview_StatusId",
                table: "ApplicantInterview",
                column: "StatusId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterview_WorksiteLocationId",
                table: "ApplicantInterview",
                column: "WorksiteLocationId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterviewer_ApplicantInterviewId",
                table: "ApplicantInterviewer",
                column: "ApplicantInterviewId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterviewer_ApplicantInterviewId1",
                table: "ApplicantInterviewer",
                column: "ApplicantInterviewId1");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicantInterviewer_InterviewerId",
                table: "ApplicantInterviewer",
                column: "InterviewerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ApplicantInterviewer");

            migrationBuilder.DropTable(
                name: "ApplicantInterview");

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 93);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 94);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 95);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 96);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 97);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 98);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 99);

            migrationBuilder.DeleteData(
                table: "Role",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Role",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DropColumn(
                name: "Email",
                table: "User");

            migrationBuilder.UpdateData(
                table: "UserRole",
                keyColumn: "Id",
                keyValue: 3,
                column: "RoleId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "UserRole",
                keyColumn: "Id",
                keyValue: 5,
                column: "RoleId",
                value: 1);
        }
    }
}
