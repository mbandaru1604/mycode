﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class BackToPortalMenuItem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "MenuItem",
                columns: new[] { "Id", "Code", "DisplayOrder", "Icon", "IsVisible", "Label", "Url" },
                values: new object[] { 8, "Back to Portal", 8, "icon-back-to-portal-light", true, "Back to Portal", "back-to-ats" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 8);
        }
    }
}
