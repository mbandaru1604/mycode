﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class NotificaitonTemplateTypes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 15, "Notification Template Type" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 112, null, 1, true, "Interview Type In Person", 15 },
                    { 113, null, 2, true, "Interview Type Phone", 15 },
                    { 114, null, 3, true, "Interview Type Video", 15 }
                });

            migrationBuilder.InsertData(
                table: "NotificationTemplate",
                columns: new[] { "Id", "CreatedBy", "CreatedOn", "EmailTemplateName", "JobApplicationStatusId", "MatchingSendGridEmailTemplateId", "ModifiedBy", "ModifiedOn", "ReceiverTypeId" },
                values: new object[,]
                {
                    { 3, null, null, "ats-scheduledinterview-applicant-inperson", 2, "d-3f9999920ca643959f863ac264cda4f5", null, null, 112 },
                    { 4, null, null, "ats-scheduledinterview-applicant-phone", 2, "d-6fb2458353a2414dbe72cff8997a8aab", null, null, 113 },
                    { 5, null, null, "ats-scheduledinterview-applicant-video", 2, "d-adaa128f45a84ae8a460ebdb216dac24", null, null, 114 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 112);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 113);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 114);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 15);
        }
    }
}
