﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdateFormFieldTypeAndSection : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsCustomFieldType",
                table: "ApplicationFormFieldType",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "MaxLength",
                table: "ApplicationFormField",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MaxLength",
                table: "ApplicationFormDefaultField",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 1,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 2,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 3,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 4,
                column: "MaxLength",
                value: 100);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 5,
                column: "MaxLength",
                value: 10);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 6,
                column: "MaxLength",
                value: 10);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 7,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 8,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 9,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 10,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 12,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 13,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 14,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 15,
                column: "MaxLength",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsCustomFieldType",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsCustomFieldType",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsCustomFieldType",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 4,
                column: "IsCustomFieldType",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 5,
                column: "IsCustomFieldType",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 6,
                column: "IsCustomFieldType",
                value: false);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 7,
                column: "IsCustomFieldType",
                value: false);

            migrationBuilder.InsertData(
                table: "ApplicationFormFieldType",
                columns: new[] { "Id", "DisplayName", "IsCustomFieldType", "Name" },
                values: new object[] { 8, "Email Address", false, "EmailAddress" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Professional Details");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DropColumn(
                name: "IsCustomFieldType",
                table: "ApplicationFormFieldType");

            migrationBuilder.DropColumn(
                name: "MaxLength",
                table: "ApplicationFormField");

            migrationBuilder.DropColumn(
                name: "MaxLength",
                table: "ApplicationFormDefaultField");

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Work History");
        }
    }
}
