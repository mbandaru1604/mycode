﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class CustomFieldTypeChange : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "DisplayName", "Name" },
                values: new object[] { "Single Line Input", "SingleLineInput" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "DisplayName", "Name" },
                values: new object[] { "Paragraph Field", "ParagraphField" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "DisplayName", "Name" },
                values: new object[] { "Text Box", "TextBox" });

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldType",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "DisplayName", "Name" },
                values: new object[] { "Text Area", "TextArea" });
        }
    }
}
