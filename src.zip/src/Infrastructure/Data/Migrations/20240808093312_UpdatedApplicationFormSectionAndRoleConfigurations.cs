﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedApplicationFormSectionAndRoleConfigurations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsCustomFieldSection",
                table: "ApplicationFormSection",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsCustomFieldSection",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsCustomFieldSection",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsCustomFieldSection",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 4,
                column: "IsCustomFieldSection",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 5,
                column: "IsCustomFieldSection",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 6,
                column: "IsCustomFieldSection",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormSection",
                keyColumn: "Id",
                keyValue: 7,
                column: "IsCustomFieldSection",
                value: false);

            migrationBuilder.UpdateData(
                table: "Role",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Company Admin");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsCustomFieldSection",
                table: "ApplicationFormSection");

            migrationBuilder.UpdateData(
                table: "Role",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "System Administrator");
        }
    }
}
