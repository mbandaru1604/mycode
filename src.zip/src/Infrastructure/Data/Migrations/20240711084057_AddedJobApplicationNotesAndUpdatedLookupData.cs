﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddedJobApplicationNotesAndUpdatedLookupData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 104);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 105);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 106);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 107);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 108);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 109);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 110);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 111);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 112);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 113);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 114);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 13);

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "ApplicantInterview");

            migrationBuilder.CreateTable(
                name: "JobApplicationStatus",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DisplayOrder = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobApplicationStatus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "JobApplicationNote",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobApplicationId = table.Column<int>(type: "int", nullable: false),
                    ApplicantInterviewId = table.Column<int>(type: "int", nullable: true),
                    JobApplicationStatusId = table.Column<int>(type: "int", nullable: false),
                    Note = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Rating = table.Column<int>(type: "int", nullable: true),
                    CreatedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    ModifiedOn = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<int>(type: "int", nullable: true),
                    Version = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobApplicationNote", x => x.Id);
                    table.ForeignKey(
                        name: "FK_JobApplicationNote_ApplicantInterview_ApplicantInterviewId",
                        column: x => x.ApplicantInterviewId,
                        principalTable: "ApplicantInterview",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_JobApplicationNote_JobApplicationStatus_JobApplicationStatusId",
                        column: x => x.JobApplicationStatusId,
                        principalTable: "JobApplicationStatus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_JobApplicationNote_JobApplication_JobApplicationId",
                        column: x => x.JobApplicationId,
                        principalTable: "JobApplication",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "JobApplicationStatus",
                columns: new[] { "Id", "DisplayOrder", "Name" },
                values: new object[,]
                {
                    { 1, 1, "Applied" },
                    { 2, 2, "Interview Scheduled" },
                    { 3, 3, "Interview No Show" },
                    { 4, 4, "Interview Canceled" },
                    { 5, 5, "Interview Completed" },
                    { 6, 6, "Not Selected" },
                    { 7, 7, "Offer Extended" },
                    { 8, 8, "Offer Accepted" },
                    { 9, 9, "Offer Declined" },
                    { 10, 10, "Onboarding" },
                    { 11, 11, "Hired" }
                });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 100,
                column: "Name",
                value: "Resume");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 101,
                column: "Name",
                value: "Cover Letter");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 102,
                column: "Name",
                value: "Photo");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 103,
                column: "Name",
                value: "Custom");

            migrationBuilder.UpdateData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 12,
                column: "Name",
                value: "JobApplication Attachment Type");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationNote_ApplicantInterviewId",
                table: "JobApplicationNote",
                column: "ApplicantInterviewId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationNote_JobApplicationId",
                table: "JobApplicationNote",
                column: "JobApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationNote_JobApplicationStatusId",
                table: "JobApplicationNote",
                column: "JobApplicationStatusId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "JobApplicationNote");

            migrationBuilder.DropTable(
                name: "JobApplicationStatus");

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "ApplicantInterview",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 100,
                column: "Name",
                value: "Applied");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 101,
                column: "Name",
                value: "Interview Scheduled");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 102,
                column: "Name",
                value: "Interview No Show");

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 103,
                column: "Name",
                value: "Interview Canceled");

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 104, null, 5, true, "Interview Completed", 12 },
                    { 105, null, 6, true, "Not Selected", 12 },
                    { 106, null, 7, true, "Offer Extended", 12 },
                    { 107, null, 8, true, "Offer Accepted", 12 },
                    { 108, null, 9, true, "Offer Declined", 12 },
                    { 109, null, 10, true, "Onboarding", 12 },
                    { 110, null, 11, true, "Hired", 12 }
                });

            migrationBuilder.UpdateData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 12,
                column: "Name",
                value: "JobApplication Status");

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 13, "JobApplication Attachment Type" });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 111, null, 1, true, "Resume", 13 },
                    { 112, null, 2, true, "Cover Letter", 13 },
                    { 113, null, 3, true, "Photo", 13 },
                    { 114, null, 4, true, "Custom", 13 }
                });
        }
    }
}
