﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class ATSMenuNewItemAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 2,
                column: "Label",
                value: "Job Categories");

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 4,
                column: "Label",
                value: "Applicant List");

            migrationBuilder.InsertData(
                table: "MenuItem",
                columns: new[] { "Id", "Code", "DisplayOrder", "Icon", "IsVisible", "Label", "Url" },
                values: new object[] { 5, "Audit Log", 5, "icon-audit-log-light", true, "Audit Log", "/audit-log" });

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 7,
                column: "JobApplicationStatusId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 9,
                column: "JobApplicationStatusId",
                value: 2);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 2,
                column: "Label",
                value: "Categories");

            migrationBuilder.UpdateData(
                table: "MenuItem",
                keyColumn: "Id",
                keyValue: 4,
                column: "Label",
                value: "Applicant Reports");

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 7,
                column: "JobApplicationStatusId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "NotificationTemplate",
                keyColumn: "Id",
                keyValue: 9,
                column: "JobApplicationStatusId",
                value: 96);
        }
    }
}
