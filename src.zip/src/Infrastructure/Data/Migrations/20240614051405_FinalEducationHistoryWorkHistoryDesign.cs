﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class FinalEducationHistoryWorkHistoryDesign : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "MaxLength",
                table: "ApplicationFormField",
                newName: "LookupTypeId");

            migrationBuilder.RenameColumn(
                name: "MaxLength",
                table: "ApplicationFormDefaultField",
                newName: "LookupTypeId");

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                table: "LookupData",
                type: "bit",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                table: "ApplicationFormFieldAttribute",
                type: "bit",
                nullable: false,
                defaultValue: true);

            migrationBuilder.CreateTable(
                name: "DefaultFieldAttributeValue",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AttributeId = table.Column<int>(type: "int", nullable: false),
                    AttributeValue = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DefaultFieldId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DefaultFieldAttributeValue", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DefaultFieldAttributeValue_ApplicationFormDefaultField_DefaultFieldId",
                        column: x => x.DefaultFieldId,
                        principalTable: "ApplicationFormDefaultField",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DefaultFieldAttributeValue_ApplicationFormFieldAttribute_AttributeId",
                        column: x => x.AttributeId,
                        principalTable: "ApplicationFormFieldAttribute",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 1,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 2,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 3,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 4,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 5,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 6,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 7,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 8,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 9,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 10,
                column: "LookupTypeId",
                value: null);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                column: "LookupTypeId",
                value: 7);

            migrationBuilder.InsertData(
                table: "ApplicationFormDefaultField",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "IsAlwaysActiveAndRequired", "IsRequired", "LookupTypeId", "Name", "SectionId", "TypeId" },
                values: new object[,]
                {
                    { 17, 17, true, false, false, null, "School Major", 5, 3 },
                    { 18, 18, true, false, false, null, "School Name", 5, 3 },
                    { 19, 19, true, false, false, null, "Graduation Year", 5, 6 },
                    { 20, 20, true, false, false, null, "Notes", 5, 4 },
                    { 21, 21, true, false, false, null, "Company Name", 6, 3 },
                    { 22, 22, true, false, false, null, "Job Title", 6, 3 },
                    { 23, 23, true, false, false, null, "Industry Type", 6, 3 },
                    { 24, 24, true, false, false, null, "Start Date", 6, 6 },
                    { 25, 25, true, false, false, null, "End Date", 6, 6 }
                });

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldAttribute",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldAttribute",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "ApplicationFormFieldAttribute",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsActive",
                value: true);

            migrationBuilder.InsertData(
                table: "ApplicationFormFieldAttribute",
                columns: new[] { "Id", "IsActive", "Name" },
                values: new object[,]
                {
                    { 4, true, "Length" },
                    { 5, true, "Allowed file formats" }
                });

            migrationBuilder.InsertData(
                table: "DefaultFieldAttributeValue",
                columns: new[] { "Id", "AttributeId", "AttributeValue", "DefaultFieldId" },
                values: new object[,]
                {
                    { 1, 1, "50", 1 },
                    { 2, 1, "50", 2 },
                    { 3, 1, "50", 3 },
                    { 4, 1, "100", 4 },
                    { 5, 1, "100", 7 },
                    { 6, 1, "100", 8 },
                    { 7, 1, "5", 9 },
                    { 8, 1, "50", 10 },
                    { 17, 2, "1048576", 13 },
                    { 18, 2, "1048576", 14 },
                    { 19, 2, "1048576", 12 }
                });

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 4,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 5,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 6,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 7,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 8,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 9,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 10,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 11,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 12,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 13,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 14,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 15,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 16,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 17,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 18,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 19,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 20,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 21,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 22,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 23,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 24,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 25,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 26,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 27,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 28,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 29,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 30,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 31,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 32,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 33,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 34,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 35,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 36,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 37,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 38,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 39,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 40,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 41,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 42,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 43,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 44,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 45,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 46,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 47,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 48,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 49,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 50,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 51,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 52,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 53,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 54,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 55,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 56,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 57,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 58,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 59,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 60,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 61,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 62,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 63,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 64,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 65,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 66,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 67,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 68,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 69,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 70,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 71,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 72,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 73,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 74,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 75,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 76,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 77,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 78,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 79,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 80,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 81,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 82,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 83,
                column: "IsActive",
                value: true);

            migrationBuilder.InsertData(
                table: "LookupType",
                columns: new[] { "Id", "Name" },
                values: new object[] { 8, "Education Level" });

            migrationBuilder.InsertData(
                table: "ApplicationFormDefaultField",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "IsAlwaysActiveAndRequired", "IsRequired", "LookupTypeId", "Name", "SectionId", "TypeId" },
                values: new object[] { 16, 16, true, false, false, 8, "Education Level", 5, 1 });

            migrationBuilder.InsertData(
                table: "ApplicationFormFieldTypeAttribute",
                columns: new[] { "Id", "FieldAttributeId", "FieldTypeId" },
                values: new object[] { 5, 4, 7 });

            migrationBuilder.InsertData(
                table: "DefaultFieldAttributeValue",
                columns: new[] { "Id", "AttributeId", "AttributeValue", "DefaultFieldId" },
                values: new object[,]
                {
                    { 9, 1, "100", 17 },
                    { 10, 1, "100", 18 },
                    { 11, 1, "500", 20 },
                    { 12, 1, "100", 21 },
                    { 13, 1, "100", 22 },
                    { 14, 1, "100", 23 },
                    { 15, 4, "10", 5 },
                    { 16, 4, "10", 6 },
                    { 20, 5, "doc,docx,pdf", 13 },
                    { 21, 5, "doc,docx,pdf", 14 },
                    { 22, 5, "jpeg,png,jpg", 12 }
                });

            migrationBuilder.InsertData(
                table: "LookupData",
                columns: new[] { "Id", "Code", "DisplayOrder", "IsActive", "Name", "TypeId" },
                values: new object[,]
                {
                    { 84, null, 1, true, "Associates Degree", 8 },
                    { 85, null, 2, true, "Bachelor's Degree", 8 },
                    { 86, null, 3, true, "Master's Degree", 8 },
                    { 87, null, 4, true, "Ph.D.", 8 },
                    { 88, null, 5, true, "High School Diploma", 8 },
                    { 89, null, 6, true, "GED", 8 },
                    { 90, null, 7, true, "Vocational/Technical School", 8 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormField_LookupTypeId",
                table: "ApplicationFormField",
                column: "LookupTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationFormDefaultField_LookupTypeId",
                table: "ApplicationFormDefaultField",
                column: "LookupTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_DefaultFieldAttributeValue_AttributeId",
                table: "DefaultFieldAttributeValue",
                column: "AttributeId");

            migrationBuilder.CreateIndex(
                name: "IX_DefaultFieldAttributeValue_DefaultFieldId",
                table: "DefaultFieldAttributeValue",
                column: "DefaultFieldId");

            migrationBuilder.AddForeignKey(
                name: "FK_ApplicationFormDefaultField_LookupType_LookupTypeId",
                table: "ApplicationFormDefaultField",
                column: "LookupTypeId",
                principalTable: "LookupType",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ApplicationFormField_LookupType_LookupTypeId",
                table: "ApplicationFormField",
                column: "LookupTypeId",
                principalTable: "LookupType",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ApplicationFormDefaultField_LookupType_LookupTypeId",
                table: "ApplicationFormDefaultField");

            migrationBuilder.DropForeignKey(
                name: "FK_ApplicationFormField_LookupType_LookupTypeId",
                table: "ApplicationFormField");

            migrationBuilder.DropTable(
                name: "DefaultFieldAttributeValue");

            migrationBuilder.DropIndex(
                name: "IX_ApplicationFormField_LookupTypeId",
                table: "ApplicationFormField");

            migrationBuilder.DropIndex(
                name: "IX_ApplicationFormDefaultField_LookupTypeId",
                table: "ApplicationFormDefaultField");

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 25);

            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldAttribute",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldTypeAttribute",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 84);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 85);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 86);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 87);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 88);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 89);

            migrationBuilder.DeleteData(
                table: "LookupData",
                keyColumn: "Id",
                keyValue: 90);

            migrationBuilder.DeleteData(
                table: "ApplicationFormFieldAttribute",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "LookupType",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "LookupData");

            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "ApplicationFormFieldAttribute");

            migrationBuilder.RenameColumn(
                name: "LookupTypeId",
                table: "ApplicationFormField",
                newName: "MaxLength");

            migrationBuilder.RenameColumn(
                name: "LookupTypeId",
                table: "ApplicationFormDefaultField",
                newName: "MaxLength");

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 1,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 2,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 3,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 4,
                column: "MaxLength",
                value: 100);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 5,
                column: "MaxLength",
                value: 10);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 6,
                column: "MaxLength",
                value: 10);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 7,
                column: "MaxLength",
                value: 100);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 8,
                column: "MaxLength",
                value: 100);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 9,
                column: "MaxLength",
                value: 5);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 10,
                column: "MaxLength",
                value: 50);

            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 11,
                column: "MaxLength",
                value: null);
        }
    }
}
