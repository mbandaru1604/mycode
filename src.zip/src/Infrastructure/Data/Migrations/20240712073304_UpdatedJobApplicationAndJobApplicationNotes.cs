﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedJobApplicationAndJobApplicationNotes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobApplication_LookupData_StatusId",
                table: "JobApplication");

            migrationBuilder.DropForeignKey(
                name: "FK_JobApplicationNote_JobApplicationStatus_JobApplicationStatusId",
                table: "JobApplicationNote");

            migrationBuilder.DeleteData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.AlterColumn<int>(
                name: "JobApplicationStatusId",
                table: "JobApplicationNote",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "ApplicantInterviewStatusId",
                table: "JobApplicationNote",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Not Selected");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 4,
                column: "Name",
                value: "Offer Extended");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 5,
                column: "Name",
                value: "Offer Accepted");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 6,
                column: "Name",
                value: "Offer Declined");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 7,
                column: "Name",
                value: "Onboarding");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 8,
                column: "Name",
                value: "Hired");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplicationNote_ApplicantInterviewStatusId",
                table: "JobApplicationNote",
                column: "ApplicantInterviewStatusId");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplication_JobApplicationStatus_StatusId",
                table: "JobApplication",
                column: "StatusId",
                principalTable: "JobApplicationStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplicationNote_JobApplicationStatus_JobApplicationStatusId",
                table: "JobApplicationNote",
                column: "JobApplicationStatusId",
                principalTable: "JobApplicationStatus",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplicationNote_LookupData_ApplicantInterviewStatusId",
                table: "JobApplicationNote",
                column: "ApplicantInterviewStatusId",
                principalTable: "LookupData",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JobApplication_JobApplicationStatus_StatusId",
                table: "JobApplication");

            migrationBuilder.DropForeignKey(
                name: "FK_JobApplicationNote_JobApplicationStatus_JobApplicationStatusId",
                table: "JobApplicationNote");

            migrationBuilder.DropForeignKey(
                name: "FK_JobApplicationNote_LookupData_ApplicantInterviewStatusId",
                table: "JobApplicationNote");

            migrationBuilder.DropIndex(
                name: "IX_JobApplicationNote_ApplicantInterviewStatusId",
                table: "JobApplicationNote");

            migrationBuilder.DropColumn(
                name: "ApplicantInterviewStatusId",
                table: "JobApplicationNote");

            migrationBuilder.AlterColumn<int>(
                name: "JobApplicationStatusId",
                table: "JobApplicationNote",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Interview No Show");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 4,
                column: "Name",
                value: "Interview Canceled");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 5,
                column: "Name",
                value: "Interview Completed");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 6,
                column: "Name",
                value: "Not Selected");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 7,
                column: "Name",
                value: "Offer Extended");

            migrationBuilder.UpdateData(
                table: "JobApplicationStatus",
                keyColumn: "Id",
                keyValue: 8,
                column: "Name",
                value: "Offer Accepted");

            migrationBuilder.InsertData(
                table: "JobApplicationStatus",
                columns: new[] { "Id", "DisplayOrder", "Name" },
                values: new object[,]
                {
                    { 9, 9, "Offer Declined" },
                    { 10, 10, "Onboarding" },
                    { 11, 11, "Hired" }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplication_LookupData_StatusId",
                table: "JobApplication",
                column: "StatusId",
                principalTable: "LookupData",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplicationNote_JobApplicationStatus_JobApplicationStatusId",
                table: "JobApplicationNote",
                column: "JobApplicationStatusId",
                principalTable: "JobApplicationStatus",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
