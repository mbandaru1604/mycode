﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBSI.ATS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdateJobApplicationDesign : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 4,
                column: "TypeId",
                value: 8);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "ApplicationFormDefaultField",
                keyColumn: "Id",
                keyValue: 4,
                column: "TypeId",
                value: 3);
        }
    }
}
