﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicationFormSectionConfiguration : IEntityTypeConfiguration<ApplicationFormSection>
{
    public static readonly ApplicationFormSection[] Sections = [
        new() { Id = 1, Name = "Personal Information", DisplayOrder = 1, TypeId = (long)SectionType.Regular ,IsCustomFieldSection = true },
        new() { Id = 2, Name = "Address", DisplayOrder = 2, TypeId = (long)SectionType.Regular ,IsCustomFieldSection = true },
        new() { Id = 3, Name = "Professional Details", DisplayOrder = 3, TypeId = (long)SectionType.Regular ,IsCustomFieldSection = true},
        new() { Id = 4, Name = "Additional Details", DisplayOrder = 6, TypeId = (long)SectionType.Regular ,IsCustomFieldSection = true },
        new() { Id = 5, Name = "Education History", DisplayOrder = 4, TypeId = (long)SectionType.Tabular,IsCustomFieldSection = true },
        new() { Id = 6, Name = "Work History", DisplayOrder = 5, TypeId = (long)SectionType.Tabular ,IsCustomFieldSection = true},
        new() { Id = 7, Name = "Voluntary Self-Identification", DisplayOrder = 7, TypeId = (long)SectionType.Regular,IsCustomFieldSection = false }
    ];

    public void Configure(EntityTypeBuilder<ApplicationFormSection> builder)
    {
        builder.ToTable(nameof(ApplicationFormSection));

        builder.Property(s => s.Name)
               .IsRequired()
               .HasMaxLength(100);

        builder.HasOne(section => section.Type)
               .WithMany()
               .HasForeignKey(section => section.TypeId);

        builder.HasData
        (
            Sections
        );
    }
}