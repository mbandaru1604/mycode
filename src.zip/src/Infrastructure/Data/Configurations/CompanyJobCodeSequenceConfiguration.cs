﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class CompanyJobCodeSequenceConfiguration : IEntityTypeConfiguration<CompanyJobCodeSequence>
{
    public void Configure(EntityTypeBuilder<CompanyJobCodeSequence> builder)
    {
        builder.ToTable(nameof(CompanyJobCodeSequence));

        builder.HasOne(jobCodeSequence => jobCodeSequence.Company)
               .WithMany()
               .HasForeignKey(jobCodeSequence => jobCodeSequence.CompanyId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(jobCodeSequence => new { jobCodeSequence.CompanyId, jobCodeSequence.SequenceNumber })
               .IsUnique();
    }
}