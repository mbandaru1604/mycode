﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class NotificationTemplateConfiguration : IEntityTypeConfiguration<NotificationTemplate>
    {
        public void Configure(EntityTypeBuilder<NotificationTemplate> builder)
        {
            builder.ToTable(nameof(NotificationTemplate));

            builder.HasOne(notificationTemplate => notificationTemplate.JobApplicationStatus)
                .WithMany()
                .HasForeignKey(notificationTemplate => notificationTemplate.JobApplicationStatusId);

            builder.HasOne(notificationTemplate => notificationTemplate.ApplicantInterviewStatus)
                .WithMany()
                .HasForeignKey(notificationTemplate => notificationTemplate.ApplicantInterviewStatusId);

            builder.HasOne(notificationTemplate => notificationTemplate.ReceiverType)
                   .WithMany()
                   .HasForeignKey(notificationTemplate => notificationTemplate.TypeId);

            builder.Property(notificationTemplate => notificationTemplate.MatchingSendGridEmailTemplateId)
                   .HasMaxLength(100);

            builder.Property(notificationTemplate => notificationTemplate.EmailTemplateName)
                  .HasMaxLength(100);

            builder.HasData(
                new() { Id = 1, JobApplicationStatusId = (long)JobApplicationStatuses.Applied, TypeId = (long)ReceiverType.Applicant, MatchingSendGridEmailTemplateId = "d-3195d5ecf9a24cb1af68198d228d6ddb", EmailTemplateName = "ats-appliednotification-applicant" },
                new() { Id = 2, JobApplicationStatusId = (long)JobApplicationStatuses.Applied, TypeId = (long)ReceiverType.HiringManager, MatchingSendGridEmailTemplateId = "d-02ed72a2e23d41a29daeff7d1048c808", EmailTemplateName = "ats-appliednotification-hiringmanager" },
                new() { Id = 3, JobApplicationStatusId = (long)JobApplicationStatuses.InterviewScheduled, TypeId = (long)NotificationTemplateType.InterviewTypeInPerson, MatchingSendGridEmailTemplateId = "d-3f9999920ca643959f863ac264cda4f5", EmailTemplateName = "ats-scheduledinterview-applicant-inperson" },
                new() { Id = 4, JobApplicationStatusId = (long)JobApplicationStatuses.InterviewScheduled, TypeId = (long)NotificationTemplateType.InterviewTypePhone, MatchingSendGridEmailTemplateId = "d-6fb2458353a2414dbe72cff8997a8aab", EmailTemplateName = "ats-scheduledinterview-applicant-phone" },
                new() { Id = 5, JobApplicationStatusId = (long)JobApplicationStatuses.InterviewScheduled, TypeId = (long)NotificationTemplateType.InterviewTypeVideo, MatchingSendGridEmailTemplateId = "d-adaa128f45a84ae8a460ebdb216dac24", EmailTemplateName = "ats-scheduledinterview-applicant-video" },
                new() { Id = 6, JobApplicationStatusId = (long)JobApplicationStatuses.OfferExtended, TypeId = (long)NotificationTemplateType.OfferExtendedEmailNotification, MatchingSendGridEmailTemplateId = "d-9f8a365f214d4d33a958cf50667fb8af", EmailTemplateName = "ats-offerextended-applicant" },
                new() { Id = 7, JobApplicationStatusId = (long)JobApplicationStatuses.NotSelected, TypeId = (long)NotificationTemplateType.NotSelected, MatchingSendGridEmailTemplateId = "d-8d871423c4fc41cfad2770900f20bff1", EmailTemplateName = "ats-applicantnotselected" },
                new() { Id = 8, ApplicantInterviewStatusId = (long)InterviewStatus.InterviewCancelled, TypeId = (long)NotificationTemplateType.InterviewCancelled, MatchingSendGridEmailTemplateId = "d-54a647ac712041eaa2a9c262310bdd23", EmailTemplateName = "ats-interviewcancellednotification-applicant" },
                new() { Id = 9, JobApplicationStatusId = (long)JobApplicationStatuses.InterviewScheduled, TypeId = (long)NotificationTemplateType.InterviewScheduleUpdated, MatchingSendGridEmailTemplateId = "d-9a31117d846849fc8098391c8cc9516d", EmailTemplateName = "ats-interviewupdated-applicant" },
                new() { Id = 10, JobApplicationStatusId = (long)JobApplicationStatuses.OfferAccepted, TypeId = (long)NotificationTemplateType.OfferAcceptedEmailNotification, MatchingSendGridEmailTemplateId = "d-79833af620df4f9e90a53843f4dc5258", EmailTemplateName = "ats-applicants-offeracceptednotification-hiringmanager" },
                new() { Id = 11, JobApplicationStatusId = (long)JobApplicationStatuses.OfferDeclined, TypeId = (long)NotificationTemplateType.OfferDeclinedEmailNotification, MatchingSendGridEmailTemplateId = "d-73fa8d40523b4063ad011f38b14a3cd1", EmailTemplateName = "ats-applicant-offerdeclinednotification-hiringmanager" },
                new() { Id = 12, JobApplicationStatusId = (long)JobApplicationStatuses.InterviewScheduled, TypeId = (long)NotificationTemplateType.InterviewFeedbackNotificaiton, MatchingSendGridEmailTemplateId = "d-c9e13004449e414da1cd83f28626845c", EmailTemplateName = "ats-interviewfeedbacknotificaiton-hiringmanager" },
                new() { Id = 13, JobApplicationStatusId = (long)JobApplicationStatuses.InterviewScheduled, TypeId = (long)NotificationTemplateType.InterviewScheduledInterviewer, MatchingSendGridEmailTemplateId = "d-1c3db312fcb24dbe806699294103993d", EmailTemplateName = "ats-interviewscheduled-interviewers" }
            );
        }
    }
}