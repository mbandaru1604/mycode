﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class JobApplicationNoteConfiguration : IEntityTypeConfiguration<JobApplicationNote>
{
    public void Configure(EntityTypeBuilder<JobApplicationNote> builder)
    {
        builder.ToTable(nameof(JobApplicationNote));

        builder.Property(notes => notes.JobApplicationId)
                .IsRequired();

        builder.Property(notes => notes.Note)
                .HasMaxLength(500)
                .IsRequired();
        builder.Property(notes => notes.IsManualUpdate)
                .HasDefaultValue(true)
                .IsRequired();

        builder.HasOne(note => note.Company)
               .WithMany()
               .HasForeignKey(note => note.CompanyId);

        builder.HasOne(notes => notes.JobApplication)
                .WithMany()
                .HasForeignKey(notes => notes.JobApplicationId)
                .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(notes => notes.ApplicantInterview)
                .WithMany()
                .HasForeignKey(notes => notes.ApplicantInterviewId);

        builder.HasOne(notes => notes.JobApplicationStatus)
                .WithMany()
                .HasForeignKey(notes => notes.JobApplicationStatusId)
                .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(notes => notes.ApplicantInterviewStatus)
                .WithMany()
                .HasForeignKey(notes => notes.ApplicantInterviewStatusId);
    }
}