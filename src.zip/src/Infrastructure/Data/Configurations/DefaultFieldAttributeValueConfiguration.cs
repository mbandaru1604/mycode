﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class DefaultFieldAttributeValueConfiguration : IEntityTypeConfiguration<DefaultFieldAttributeValue>
    {
        public void Configure(EntityTypeBuilder<DefaultFieldAttributeValue> builder)
        {
            builder.ToTable(nameof(DefaultFieldAttributeValue));

            builder.HasOne(attributeValue => attributeValue.Attribute)
                   .WithMany()
                   .HasForeignKey(attributeValue => attributeValue.AttributeId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(attributeValue => attributeValue.DefaultField)
                   .WithMany(ff => ff.AttributeValues)
                   .HasForeignKey(attributeValue => attributeValue.DefaultFieldId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.Property(attributeValue => attributeValue.DefaultFieldId)
                   .IsRequired();

            builder.Property(attributeValue => attributeValue.AttributeId)
                   .IsRequired();

            builder.Property(attributeValue => attributeValue.AttributeValue)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.HasData
            (
                new() { Id = 1, DefaultFieldId = (long)ApplicationFormDefaultFields.FirstName, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.FirstNameMaxLength.ToString() },
                new() { Id = 2, DefaultFieldId = (long)ApplicationFormDefaultFields.MiddleName, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.MiddleNameMaxLength.ToString() },
                new() { Id = 3, DefaultFieldId = (long)ApplicationFormDefaultFields.LastName, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.LastNameMaxLength.ToString() },
                new() { Id = 4, DefaultFieldId = (long)ApplicationFormDefaultFields.PersonalEmailAddress, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.EmailAddressMaxLength.ToString() },
                new() { Id = 5, DefaultFieldId = (long)ApplicationFormDefaultFields.AddressLine1, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.AddressLine1MaxLength.ToString() },
                new() { Id = 6, DefaultFieldId = (long)ApplicationFormDefaultFields.AddressLine2, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.AddressLine2MaxLength.ToString() },
                new() { Id = 7, DefaultFieldId = (long)ApplicationFormDefaultFields.ZipCode, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.ZipCodeMaxLength.ToString() },
                new() { Id = 8, DefaultFieldId = (long)ApplicationFormDefaultFields.City, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.CityMaxLength.ToString() },
                new() { Id = 9, DefaultFieldId = (long)ApplicationFormDefaultFields.SchoolMajor, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.SchoolMajorMaxLength.ToString() },
                new() { Id = 10, DefaultFieldId = (long)ApplicationFormDefaultFields.SchoolName, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.SchoolNameMaxLength.ToString() },
                new() { Id = 11, DefaultFieldId = (long)ApplicationFormDefaultFields.Notes, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.NotesMaxLength.ToString() },
                new() { Id = 12, DefaultFieldId = (long)ApplicationFormDefaultFields.CompanyName, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.CompanyNameMaxLength.ToString() },
                new() { Id = 13, DefaultFieldId = (long)ApplicationFormDefaultFields.JobTitle, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.JobtitleMaxLength.ToString() },
                new() { Id = 14, DefaultFieldId = (long)ApplicationFormDefaultFields.IndustryType, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.IndustryTypeMaxLength.ToString() },

                new() { Id = 15, DefaultFieldId = (long)ApplicationFormDefaultFields.HomeTelephoneNumber, AttributeId = (long)ApplicationFormFieldAttributes.Length, AttributeValue = DefaultFieldsValidation.PhoneNumberLength.ToString() },
                new() { Id = 16, DefaultFieldId = (long)ApplicationFormDefaultFields.MobilePhoneNumber, AttributeId = (long)ApplicationFormFieldAttributes.Length, AttributeValue = DefaultFieldsValidation.PhoneNumberLength.ToString() },

                new() { Id = 17, DefaultFieldId = (long)ApplicationFormDefaultFields.Resume, AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = DefaultFieldsValidation.MaxFileLengthBytes.ToString() },
                new() { Id = 18, DefaultFieldId = (long)ApplicationFormDefaultFields.CoverLetter, AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = DefaultFieldsValidation.MaxFileLengthBytes.ToString() },
                new() { Id = 19, DefaultFieldId = (long)ApplicationFormDefaultFields.Photo, AttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize, AttributeValue = DefaultFieldsValidation.MaxFileLengthBytes.ToString() },

                new() { Id = 20, DefaultFieldId = (long)ApplicationFormDefaultFields.Resume, AttributeId = (long)ApplicationFormFieldAttributes.AllowedFileFormats, AttributeValue = DefaultFieldsValidation.ResumeCoverLetterAllowedFileFormats.ToString() },
                new() { Id = 21, DefaultFieldId = (long)ApplicationFormDefaultFields.CoverLetter, AttributeId = (long)ApplicationFormFieldAttributes.AllowedFileFormats, AttributeValue = DefaultFieldsValidation.ResumeCoverLetterAllowedFileFormats.ToString() },
                new() { Id = 22, DefaultFieldId = (long)ApplicationFormDefaultFields.Photo, AttributeId = (long)ApplicationFormFieldAttributes.AllowedFileFormats, AttributeValue = DefaultFieldsValidation.PhotoAllowedFileFormats.ToString() },

                new() { Id = 23, DefaultFieldId = (long)ApplicationFormDefaultFields.Disability, AttributeId = (long)ApplicationFormFieldAttributes.MaxLength, AttributeValue = DefaultFieldsValidation.DisabilityMaxLength.ToString() }

            );
        }
    }
}