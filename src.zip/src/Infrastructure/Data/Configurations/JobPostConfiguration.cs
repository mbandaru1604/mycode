﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobPostConfiguration : IEntityTypeConfiguration<JobPost>
    {
        public void Configure(EntityTypeBuilder<JobPost> builder)
        {
            builder.ToTable(nameof(JobPost));

            builder.Property(jobPost => jobPost.Description);

            builder.Property(jobPost => jobPost.Title)
                   .IsRequired()
                   .HasMaxLength(56);

            builder.Property(jobPost => jobPost.IsActive)
                   .IsRequired()
                   .HasDefaultValue(false);

            builder.Property(jobPost => jobPost.IsSubmitted)
                   .IsRequired()
                   .HasDefaultValue(false);

            builder.Property(jobPost => jobPost.CCEmailAddresses)
                   .HasMaxLength(500);

            builder.HasOne(jobPost => jobPost.ApplicationForm)
                   .WithMany(form => form.JobPosts)
                   .HasForeignKey(jobPost => jobPost.ApplicationFormId);

            builder.HasOne(jobPost => jobPost.Category)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.CategoryId);

            builder.HasOne(jobPost => jobPost.Company)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.CompanyId);

            builder.HasOne(jobPost => jobPost.EEOClass)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.EEOClassId);

            builder.HasOne(jobPost => jobPost.EmployeeType)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.EmployeeTypeId);

            builder.HasOne(jobPost => jobPost.PayGroup)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.PayGroupId);

            builder.HasOne(jobPost => jobPost.PayMethod)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.PayMethodId);

            builder.HasOne(jobPost => jobPost.WorkArrangement)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.WorkArrangementId);

            builder.Property(jobPost => jobPost.JobCode)
                   .HasMaxLength(100);

            builder.Property(jobPost => jobPost.Location)
                   .HasMaxLength(50);

            builder.HasOne(jobPost => jobPost.WorksiteLocation)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.WorksiteLocationId);

            builder.HasOne(jobPost => jobPost.LocationType)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.LocationTypeId);

            builder.Property(jobPost => jobPost.City)
                   .HasMaxLength(50);

            builder.Property(jobPost => jobPost.Country)
                   .HasMaxLength(50);

            builder.HasOne(jobPost => jobPost.State)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.StateId);

            builder.HasOne(jobPost => jobPost.HiringManager)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.HiringManagerId);

            builder.Property(jobPost => jobPost.OptOutNotification)
                  .IsRequired()
                  .HasDefaultValue(false);

            builder.HasOne(jobPost => jobPost.ApplicantQuiz)
                   .WithMany()
                   .HasForeignKey(jobPost => jobPost.ApplicantQuizId);

            builder.Property(jobPost => jobPost.DerivedLocation)
                   .HasMaxLength(200);

            builder.HasIndex(jobPost => new { jobPost.IsActive, jobPost.IsSubmitted, jobPost.CompanyId })
                   .IncludeProperties(jobPost => jobPost.DerivedLocation)
                   .HasDatabaseName("IX_JobPost_IsActive_IsSubmitted_CompanyId");

            builder.HasIndex(jobPost => new { jobPost.LinkId })
                   .HasDatabaseName("IX_JobPost_LinkId");

            builder.HasIndex(jobPost => new { jobPost.IsActive, jobPost.IsSubmitted, jobPost.CompanyId, jobPost.StartDate })
                   .HasDatabaseName("IX_JobPost_IsActive_IsSubmitted_CompanyId_StartDate");
        }
    }
}