﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class ApplicationFormFieldAttributeConfiguration : IEntityTypeConfiguration<ApplicationFormFieldAttribute>
    {
        public void Configure(EntityTypeBuilder<ApplicationFormFieldAttribute> builder)
        {
            builder.ToTable(nameof(ApplicationFormFieldAttribute));

            builder.Property(FormFieldAttribute => FormFieldAttribute.Name)
                   .IsRequired();

            builder.Property(attribute => attribute.IsActive)
                   .IsRequired()
                   .HasDefaultValue(true);

            builder.HasData(
                new() { Id = 1, Name = "Max Length" },
                new() { Id = 2, Name = "Max File Upload Size" },
                new() { Id = 3, Name = "Text Value" },
                new() { Id = 4, Name = "Length" },
                new() { Id = 5, Name = "Allowed file formats" }
            );
        }
    }
}