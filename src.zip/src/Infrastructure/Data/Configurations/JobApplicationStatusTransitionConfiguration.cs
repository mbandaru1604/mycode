﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobApplicationStatusTransitionConfiguration : IEntityTypeConfiguration<JobApplicationStatusTransition>
    {
        public void Configure(EntityTypeBuilder<JobApplicationStatusTransition> builder)
        {
            builder.ToTable(nameof(JobApplicationStatusTransition));

            builder.Property(statusTransition => statusTransition.TriggerId)
                   .IsRequired();

            builder.Property(statusTransition => statusTransition.ToStatusId)
                   .IsRequired();

            builder.Property(statusTransition => statusTransition.Note)
                   .IsRequired()
                   .HasMaxLength(1000);

            builder.HasOne(statusTransition => statusTransition.FromStatus)
                   .WithMany()
                   .HasForeignKey(statusTransition => statusTransition.FromStatusId);

            builder.HasOne(statusTransition => statusTransition.Trigger)
                   .WithMany()
                   .HasForeignKey(statusTransition => statusTransition.TriggerId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(statusTransition => statusTransition.ToStatus)
                   .WithMany()
                   .HasForeignKey(statusTransition => statusTransition.ToStatusId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasData
            (
                new()
                {
                    Id = 1,
                    TriggerId = (long)StatusTransitionTriggers.InitialApplicationStatus,
                    ToStatusId = (long)JobApplicationStatuses.Applied,
                    Note = "The status has been changed to 'Applied'"
                },
                new()
                {
                    Id = 2,
                    FromStatusId = (long)JobApplicationStatuses.Applied,
                    TriggerId = (long)StatusTransitionTriggers.InterviewScheduling,
                    ToStatusId = (long)JobApplicationStatuses.InterviewScheduled,
                    Note = "The status has been changed to 'Interview Scheduled' from 'Applied'"
                },
                new()
                {
                    Id = 3,
                    FromStatusId = (long)JobApplicationStatuses.OfferExtended,
                    TriggerId = (long)StatusTransitionTriggers.OfferAcceptance,
                    ToStatusId = (long)JobApplicationStatuses.OfferAccepted,
                    Note = "The status has been changed to 'Offer Accepted' from 'Offer Extended'"
                },
                new()
                {
                    Id = 4,
                    FromStatusId = (long)JobApplicationStatuses.OfferExtended,
                    TriggerId = (long)StatusTransitionTriggers.OfferDecline,
                    ToStatusId = (long)JobApplicationStatuses.OfferDeclined,
                    Note = "The status has been changed to Offer Declined' from 'Offer Extended'"
                },
                new()
                {
                    Id = 5,
                    FromStatusId = (long)JobApplicationStatuses.Onboarding,
                    TriggerId = (long)StatusTransitionTriggers.SuccessfulHireEvent,
                    ToStatusId = (long)JobApplicationStatuses.Hired,
                    Note = "The status has been changed to 'Hired' from 'Onboarding'"
                }
            );
        }
    }
}