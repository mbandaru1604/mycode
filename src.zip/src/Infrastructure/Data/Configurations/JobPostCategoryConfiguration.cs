﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobPostCategoryConfiguration : IEntityTypeConfiguration<JobPostCategory>
    {
        public void Configure(EntityTypeBuilder<JobPostCategory> builder)
        {
            builder.ToTable(nameof(JobPostCategory));

            builder.Property(category => category.Name)
                   .IsRequired()
                   .HasMaxLength(JobPostCategoryValidation.NameMaxLength);

            builder.Property(category => category.IsActive)
                   .IsRequired()
                   .HasDefaultValue(true);

            builder.Property(category => category.IsDeleted)
                    .IsRequired()
                    .HasDefaultValue(false);

            builder.HasOne(category => category.Company)
                   .WithMany()
                   .HasForeignKey(category => category.CompanyId)
                   .IsRequired(false);

            builder.HasIndex(jobPostCategory => new { jobPostCategory.CompanyId, jobPostCategory.Name, jobPostCategory.IsDeleted })
                   .HasDatabaseName("IX_JobPostCategory_CompanyId_Name_IsDeleted");
        }
    }
}