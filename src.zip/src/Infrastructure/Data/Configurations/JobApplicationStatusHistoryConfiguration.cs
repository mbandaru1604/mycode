﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobApplicationStatusHistoryConfiguration : IEntityTypeConfiguration<JobApplicationStatusHistory>
    {
        public void Configure(EntityTypeBuilder<JobApplicationStatusHistory> builder)
        {
            builder.ToTable(nameof(JobApplicationStatusHistory));

            builder.Property(jobApplicationStatusHistory => jobApplicationStatusHistory.JobApplicationId)
                   .IsRequired();

            builder.Property(jobApplicationStatusHistory => jobApplicationStatusHistory.IsEmailSent)
                  .IsRequired()
                  .HasDefaultValue(false);

            builder.Property(jobApplicationStatusHistory => jobApplicationStatusHistory.ToStatusId)
                   .IsRequired();

            builder.HasOne(jobApplicationStatusHistory => jobApplicationStatusHistory.JobApplication)
                   .WithMany()
                   .HasForeignKey(jobApplicationStatusHistory => jobApplicationStatusHistory.JobApplicationId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(jobApplicationStatusHistory => jobApplicationStatusHistory.FromStatus)
                   .WithMany()
                   .HasForeignKey(jobApplicationStatusHistory => jobApplicationStatusHistory.FromStatusId);

            builder.HasOne(jobApplicationStatusHistory => jobApplicationStatusHistory.ToStatus)
                   .WithMany()
                   .HasForeignKey(jobApplicationStatusHistory => jobApplicationStatusHistory.ToStatusId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasIndex(statusHistory => statusHistory.CreatedOn)
                   .IncludeProperties(statusHistory => new { statusHistory.JobApplicationId, statusHistory.ToStatusId })
                   .HasDatabaseName("IX_JobApplicationStatusHistory_CreatedOn");
        }
    }
}