﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicantQuizConfiguration : IEntityTypeConfiguration<ApplicantQuiz>
{
    public void Configure(EntityTypeBuilder<ApplicantQuiz> builder)
    {
        builder.ToTable(nameof(ApplicantQuiz));

        builder.Property(quiz => quiz.Name)
               .IsRequired()
               .HasMaxLength(50);

        builder.Property(quiz => quiz.MinimumPassingScore)
               .IsRequired();

        builder.Property(quiz => quiz.Description)
               .HasMaxLength(500);

        builder.Property(quiz => quiz.IsActive)
               .HasDefaultValue(true)
               .IsRequired();

        builder.HasMany(quiz => quiz.QuizQuestions)
               .WithOne(form => form.ApplicantQuiz)
               .HasForeignKey(form => form.ApplicantQuizId);

        builder.Property(quiz => quiz.CompanyId)
               .IsRequired();

        builder.HasOne(quiz => quiz.Company)
               .WithMany()
               .HasForeignKey(quiz => quiz.CompanyId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(quiz => new { quiz.Name, quiz.CompanyId })
               .HasDatabaseName("IX_ApplicantQuiz_Name_CompanyId");
    }
}