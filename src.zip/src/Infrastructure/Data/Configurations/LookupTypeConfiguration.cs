﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class LookupTypeConfiguration : IEntityTypeConfiguration<LookupType>
{
    public void Configure(EntityTypeBuilder<LookupType> builder)
    {
        builder.ToTable(nameof(LookupType));

        builder.Property(lookupType => lookupType.Name)
                      .IsRequired()
                      .HasMaxLength(100);

        builder.HasData
        (
            new() { Id = 1, Name = "Employee Type" },
            new() { Id = 2, Name = "EEO Class" },
            new() { Id = 3, Name = "Pay Group" },
            new() { Id = 4, Name = "Pay Method" },
            new() { Id = 5, Name = "Work Arrangement" },
            new() { Id = 6, Name = "Location Type" },
            new() { Id = 7, Name = "State" },
            new() { Id = 8, Name = "Education Level" },
            new() { Id = 9, Name = "Section Type" },
            new() { Id = 10, Name = "Interview Type" },
            new() { Id = 11, Name = "Interview Status" },
            new() { Id = 12, Name = "JobApplication Attachment Type" },
            new() { Id = 13, Name = "JobApplication Status Transition Trigger" },
            new() { Id = 14, Name = "Receiver Type" },
            new() { Id = 15, Name = "Notification Template Type" },
            new() { Id = 16, Name = "New Hire Type" },
            new() { Id = 17, Name = "Voluntary Self Identification" },
            new() { Id = 18, Name = "Gender" },
            new() { Id = 19, Name = "EthnicityRace" },
            new() { Id = 20, Name = "Veteran" },
            new() { Id = 21, Name = "Veteran Status" },  
            new() { Id = 22, Name = "Page Name" },
            new() { Id = 23, Name = "Section Name" },
            new() { Id = 24, Name = "Question Type" },
            new() { Id = 25, Name = "True/False" },
            new() { Id = 26, Name = "Job Board" }
        );
    }
}