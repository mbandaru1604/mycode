﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class ApplicationFormFieldTypeAttributeConfiguration : IEntityTypeConfiguration<ApplicationFormFieldTypeAttribute>
    {
        public void Configure(EntityTypeBuilder<ApplicationFormFieldTypeAttribute> builder)
        {
            builder.ToTable(nameof(ApplicationFormFieldTypeAttribute));

            builder.Property(fieldTypeAttribute => fieldTypeAttribute.FieldTypeId)
                .IsRequired();

            builder.Property(fieldTypeAttribute => fieldTypeAttribute.FieldAttributeId)
                .IsRequired();

            builder.HasData
            (
                new() { Id = 1, FieldTypeId = (long)ApplicationFormFieldTypes.SingleLineInput, FieldAttributeId = (long)ApplicationFormFieldAttributes.MaxLength },
                new() { Id = 2, FieldTypeId = (long)ApplicationFormFieldTypes.ParagraphField, FieldAttributeId = (long)ApplicationFormFieldAttributes.MaxLength },
                new() { Id = 4, FieldTypeId = (long)ApplicationFormFieldTypes.FileUpload, FieldAttributeId = (long)ApplicationFormFieldAttributes.MaxFileUploadSize },
                new() { Id = 5, FieldTypeId = (long)ApplicationFormFieldTypes.PhoneNumber, FieldAttributeId = (long)ApplicationFormFieldAttributes.Length }
            );
        }
    }
}