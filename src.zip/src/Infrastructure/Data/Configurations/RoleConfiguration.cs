﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        builder.ToTable(nameof(Role));

        builder.Property(role => role.Name)
               .IsRequired()
               .HasMaxLength(100);

        builder.HasData
        (
            new() { Id = 1, Name = "Hiring Manager", Code = "Hiring Manager" },
            new() { Id = 2, Name = "User", Code = "User" },
            new() { Id = 3, Name = "Company Admin", Code = "Company Admin" },
            new() { Id = 4, Name = "Interviewer", Code = "Interviewer" }
        );
    }
}