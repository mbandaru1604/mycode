﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class UserCompanyRoleConfiguration : IEntityTypeConfiguration<UserCompanyRole>
{
    public void Configure(EntityTypeBuilder<UserCompanyRole> builder)
    {
        builder.ToTable(nameof(UserCompanyRole));

        builder.Property(ucr => ucr.UserType)
               .HasMaxLength(100);

        builder.Property(ucr => ucr.UserId)
               .IsRequired();

        builder.Property(ucr => ucr.CompanyId)
               .IsRequired();

        builder.Property(ucr => ucr.RoleId)
               .IsRequired();

        builder.Property(ucr => ucr.IsActive)
              .IsRequired()
              .HasDefaultValue(true);

        builder.HasOne(ucr => ucr.Company)
               .WithMany()
               .HasForeignKey(ucr => ucr.CompanyId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(ucr => ucr.User)
               .WithMany()
               .HasForeignKey(ucr => ucr.UserId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(ucr => ucr.Role)
               .WithMany()
               .HasForeignKey(ucr => ucr.RoleId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(userCompanyRole => new { userCompanyRole.CompanyId, userCompanyRole.IsActive })
               .IncludeProperties(userCompanyRole => new { userCompanyRole.UserId, userCompanyRole.RoleId })
               .HasDatabaseName("IX_UserCompanyRole_CompanyId_IsActive");
    }
}