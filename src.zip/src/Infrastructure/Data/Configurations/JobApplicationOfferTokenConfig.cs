﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
	public class JobApplicationOfferTokenConfig : IEntityTypeConfiguration<JobApplicationOfferToken>
	{
		public void Configure(EntityTypeBuilder<JobApplicationOfferToken> builder)
		{
			builder.ToTable(nameof(JobApplicationOfferToken));

			builder.HasOne(jobApplicationOfferToken => jobApplicationOfferToken.JobApplication)
				   .WithMany()
				   .HasForeignKey(jobApplicationOfferToken => jobApplicationOfferToken.JobApplicationId);

			builder.Property(jobApplicationOfferToken => jobApplicationOfferToken.Token)
				   .IsRequired()
				   .HasMaxLength(100);

			builder.Property(jobApplicationOfferToken => jobApplicationOfferToken.IsUsed)
				   .IsRequired()
				   .HasDefaultValue(false);

			builder.Property(jobApplicationOfferToken => jobApplicationOfferToken.Status)
				   .IsRequired()
				   .HasMaxLength(50);
		}
	}
}