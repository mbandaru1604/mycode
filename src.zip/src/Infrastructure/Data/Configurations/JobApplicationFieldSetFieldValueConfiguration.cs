﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobApplicationFieldSetFieldValueConfiguration : IEntityTypeConfiguration<JobApplicationFieldSetFieldValue>
    {
        public void Configure(EntityTypeBuilder<JobApplicationFieldSetFieldValue> builder)
        {
            builder.ToTable(nameof(JobApplicationFieldSetFieldValue));

            builder.Property(fieldsetFieldValue => fieldsetFieldValue.FormFieldValue)
                   .HasMaxLength(1000);

            builder.Property(fieldsetFieldValue => fieldsetFieldValue.FormFieldSetId)
                   .IsRequired();

            builder.Property(fieldsetFieldValue => fieldsetFieldValue.FormFieldId)
                   .IsRequired();

            builder.HasOne(fieldsetFieldValue => fieldsetFieldValue.FormFieldSet)
                   .WithMany(fieldset => fieldset.FieldValues)
                   .HasForeignKey(fieldsetFieldValue => fieldsetFieldValue.FormFieldSetId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(fieldsetFieldValue => fieldsetFieldValue.FormField)
                   .WithMany()
                   .HasForeignKey(fieldsetFieldValue => fieldsetFieldValue.FormFieldId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}