﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicationFormFieldTypeConfiguration : IEntityTypeConfiguration<ApplicationFormFieldType>
{
    public void Configure(EntityTypeBuilder<ApplicationFormFieldType> builder)
    {
        builder.ToTable(nameof(ApplicationFormFieldType));

        builder.Property(fieldType => fieldType.DisplayName)
               .IsRequired()
               .HasMaxLength(50);

        builder.Property(fieldType => fieldType.Name)
               .IsRequired()
               .HasMaxLength(50);

        builder.Property(fieldtype => fieldtype.IsCustomFieldType)
               .IsRequired();

        builder.HasMany(fieldType => fieldType.Attributes)
                .WithMany(attribute => attribute.FieldTypes)
                .UsingEntity<ApplicationFormFieldTypeAttribute>(
                    fieldTypeAttribute => fieldTypeAttribute
                        .HasOne(fta => fta.FieldAttribute)
                        .WithMany(attribute => attribute.FieldTypeAttributes)
                        .HasForeignKey(fta => fta.FieldAttributeId)
                        .OnDelete(DeleteBehavior.Restrict),
                    fieldTypeAttribute => fieldTypeAttribute
                        .HasOne(fta => fta.FieldType)
                        .WithMany(ft => ft.FieldTypeAttributes)
                        .HasForeignKey(fta => fta.FieldTypeId)
                        .OnDelete(DeleteBehavior.Restrict)
                );

        builder.HasData(
            new() { Id = 1, DisplayName = "Drop-down List", Name = "DropdownList", IsCustomFieldType = true },
            new() { Id = 2, DisplayName = "File Upload", Name = "FileUpload", IsCustomFieldType = true },
            new() { Id = 3, DisplayName = "Single Line Input", Name = "SingleLineInput", IsCustomFieldType = true },
            new() { Id = 4, DisplayName = "Paragraph Field", Name = "ParagraphField", IsCustomFieldType = true },
            new() { Id = 6, DisplayName = "Date Picker", Name = "DatePicker", IsCustomFieldType = false },
            new() { Id = 7, DisplayName = "Phone Number", Name = "PhoneNumber", IsCustomFieldType = false },
            new() { Id = 8, DisplayName = "Email Address", Name = "EmailAddress", IsCustomFieldType = false },
            new() { Id = 9, DisplayName = "Radio Button", Name = "RadioButton", IsCustomFieldType = false }
        );
    }
}