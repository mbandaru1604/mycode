﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobApplicationFieldSetConfiguration : IEntityTypeConfiguration<JobApplicationFieldSet>
    {
        public void Configure(EntityTypeBuilder<JobApplicationFieldSet> builder)
        {
            builder.ToTable(nameof(JobApplicationFieldSet));

            builder.Property(fieldset => fieldset.JobApplicationId)
                   .IsRequired();

            builder.HasOne(fieldset => fieldset.JobApplication)
                   .WithMany(jobApplication => jobApplication.FieldSets)
                   .HasForeignKey(fieldset => fieldset.JobApplicationId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}