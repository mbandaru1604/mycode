﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicationFormFieldConfiguration : IEntityTypeConfiguration<ApplicationFormField>
{
    public void Configure(EntityTypeBuilder<ApplicationFormField> builder)
    {
        builder.ToTable(nameof(ApplicationFormField));

        builder.HasOne(formField => formField.Company)
               .WithMany()
               .HasForeignKey(formField => formField.CompanyId);

        builder.HasOne(formField => formField.DefaultField)
               .WithMany()
               .HasForeignKey(formField => formField.DefaultFieldId);

        builder.Property(formField => formField.ApplicationFormId)
               .IsRequired();

        builder.HasOne(formField => formField.ApplicationForm)
               .WithMany(form => form.Fields)
               .HasForeignKey(formField => formField.ApplicationFormId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(formField => formField.Section)
               .WithMany()
               .HasForeignKey(formField => formField.SectionId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(formField => formField.Type)
               .WithMany()
               .HasForeignKey(formField => formField.TypeId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.Property(formField => formField.DisplayOrder)
               .IsRequired();

        builder.Property(formField => formField.IsActive)
               .IsRequired()
               .HasDefaultValue(true);

        builder.Property(formField => formField.IsAlwaysActiveAndRequired)
               .IsRequired()
               .HasDefaultValue(false);

        builder.Property(formField => formField.IsRequired)
               .IsRequired()
               .HasDefaultValue(false);

        builder.Property(formField => formField.IsSystemDefault)
               .IsRequired()
               .HasDefaultValue(false);

        builder.Property(formField => formField.Name)
               .IsRequired()
               .HasMaxLength(100);

        builder.Property(formField => formField.SectionId)
               .IsRequired();

        builder.Property(formField => formField.TypeId)
               .IsRequired();

        builder.Property(formField => formField.IsDeleted)
               .IsRequired()
               .HasDefaultValue(false);

        builder.HasOne(field => field.LookupType)
               .WithMany()
               .HasForeignKey(df => df.LookupTypeId);
    }
}