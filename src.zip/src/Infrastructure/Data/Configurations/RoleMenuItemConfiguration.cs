﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class RoleMenuItemConfiguration : IEntityTypeConfiguration<RoleMenuItem>
{
    public void Configure(EntityTypeBuilder<RoleMenuItem> builder)
    {
        builder.ToTable(nameof(RoleMenuItem));

        builder.Property(roleMenuItem => roleMenuItem.RoleId)
               .IsRequired();

        builder.Property(roleMenuItem => roleMenuItem.MenuItemId)
               .IsRequired();

        builder.HasOne(roleMenuItem => roleMenuItem.Role)
               .WithMany()
               .HasForeignKey(roleMenuItem => roleMenuItem.RoleId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(roleMenuItem => roleMenuItem.MenuItem)
               .WithMany()
               .HasForeignKey(roleMenuItem => roleMenuItem.MenuItemId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasData(
            new() { Id = 1, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 1 },
            new() { Id = 2, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 2 },
            new() { Id = 3, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 3 },
            new() { Id = 4, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 4 },
            new() { Id = 5, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 5 },
            new() { Id = 6, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 6 },
            new() { Id = 7, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 7 },
            new() { Id = 8, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 8 },
            new() { Id = 9, RoleId = (long)Roles.CompanyAdmin, MenuItemId = 9 },

            new() { Id = 10, RoleId = (long)Roles.HiringManager, MenuItemId = 1 },
            new() { Id = 11, RoleId = (long)Roles.HiringManager, MenuItemId = 2 },
            new() { Id = 12, RoleId = (long)Roles.HiringManager, MenuItemId = 3 },
            new() { Id = 13, RoleId = (long)Roles.HiringManager, MenuItemId = 4 },
            new() { Id = 14, RoleId = (long)Roles.HiringManager, MenuItemId = 5 },
            new() { Id = 15, RoleId = (long)Roles.HiringManager, MenuItemId = 6 },
            new() { Id = 16, RoleId = (long)Roles.HiringManager, MenuItemId = 7 },
            new() { Id = 17, RoleId = (long)Roles.HiringManager, MenuItemId = 8 },
            new() { Id = 18, RoleId = (long)Roles.HiringManager, MenuItemId = 9 },

            new() { Id = 19, RoleId = (long)Roles.Interviewer, MenuItemId = 1 },
            new() { Id = 20, RoleId = (long)Roles.Interviewer, MenuItemId = 2 },
            new() { Id = 21, RoleId = (long)Roles.Interviewer, MenuItemId = 7 }
        );
    }
}
