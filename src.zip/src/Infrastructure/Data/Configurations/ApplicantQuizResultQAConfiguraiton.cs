﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class ApplicantQuizResultQAConfiguraiton : IEntityTypeConfiguration<ApplicantQuizResultQA>
    {
        public void Configure(EntityTypeBuilder<ApplicantQuizResultQA> builder)
        {
            builder.ToTable(nameof(ApplicantQuizResultQA));

            builder.HasOne(quizResultQA => quizResultQA.QuizQuestion)
                   .WithMany()
                   .HasForeignKey(quizResultQA => quizResultQA.QuestionId);

            builder.HasOne(quizResultQA => quizResultQA.QuizQuestionAnswer)
                   .WithMany()
                   .HasForeignKey(quizResultQA => quizResultQA.AnswerId);

            builder.Property(quizResultQA => quizResultQA.IsCorrect)
                   .IsRequired();

            builder.HasOne(quizResultQA => quizResultQA.ApplicantQuizResult)
                   .WithMany(quizResult => quizResult.QuizAnswers)
                   .HasForeignKey(quizResultQA => quizResultQA.ResultId);
        }
    }
}