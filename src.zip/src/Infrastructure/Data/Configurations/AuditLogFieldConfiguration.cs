﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class AuditLogFieldConfiguration : IEntityTypeConfiguration<AuditLogField>
{
    public void Configure(EntityTypeBuilder<AuditLogField> builder)
    {
        builder.ToTable(nameof(AuditLogField));

        builder.Property(auditLogField => auditLogField.Name)
                      .IsRequired()
                      .HasMaxLength(100); 
    }
}