﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicantInterviewConfiguration : IEntityTypeConfiguration<ApplicantInterview>
{
    public void Configure(EntityTypeBuilder<ApplicantInterview> builder)
    {
        builder.ToTable(nameof(ApplicantInterview));

        builder.Property(interview => interview.JobApplicationId)
               .IsRequired();

        builder.Property(interview => interview.InterviewTypeId)
                .IsRequired();

        builder.Property(interview => interview.InterviewDate)
                .IsRequired();

        builder.Property(interview => interview.StartDateTime)
               .IsRequired();

        builder.Property(interview => interview.EndDateTime)
               .IsRequired();

        builder.Property(interview => interview.StartTime)
               .HasMaxLength(50)
               .IsRequired();

        builder.Property(interview => interview.EndTime)
               .HasMaxLength(50)
               .IsRequired();

        builder.Property(interview => interview.Location)
               .HasMaxLength(50);

        builder.Property(interview => interview.Address1)
               .HasMaxLength(100);

        builder.Property(interview => interview.Address2)
               .HasMaxLength(200);

        builder.Property(interview => interview.City)
               .HasMaxLength(200);

        builder.Property(interview => interview.ZipCode)
               .HasMaxLength(5);

        builder.Property(interview => interview.TimeZone)
               .IsRequired()
               .HasMaxLength(50);

        builder.HasOne(interview => interview.Company)
               .WithMany()
               .HasForeignKey(interview => interview.CompanyId);

        builder.HasOne(interview => interview.JobApplication)
               .WithMany()
               .HasForeignKey(interview => interview.JobApplicationId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(interview => interview.InterviewType)
                .WithMany()
                .HasForeignKey(interview => interview.InterviewTypeId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(interview => interview.Status)
               .WithMany()
               .HasForeignKey(interview => interview.StatusId);

        builder.HasOne(interview => interview.WorksiteLocation)
               .WithMany()
               .HasForeignKey(interview => interview.WorksiteLocationId);

        builder.HasOne(interview => interview.LocationType)
               .WithMany()
               .HasForeignKey(interview => interview.LocationTypeId);

        builder.HasOne(interview => interview.State)
               .WithMany()
               .HasForeignKey(interview => interview.StateId);

        builder.HasMany(form => form.Interviewers)
                .WithOne(form => form.ApplicantInterview)
                .HasForeignKey(form => form.ApplicantInterviewId);
    }
}