﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class PrivilegeConfiguration : IEntityTypeConfiguration<Privilege>

{
    public void Configure(EntityTypeBuilder<Privilege> builder)
    {
        builder.ToTable(nameof(Privilege));
        builder.Property(privilege => privilege.IsActive)
                .HasDefaultValue(true)
                .IsRequired();

        builder.HasData(
            new Privilege { Id = 1, Name = "ApplicationFormsListPage", DisplayName = "Application Forms List Page", Feature = "ApplicationForms", SubFeature = "ApplicationForms" },
            new Privilege { Id = 2, Name = "AddForm", DisplayName = "Add Form", Feature = "ApplicationForms", SubFeature = "ApplicationForms" },
            new Privilege { Id = 3, Name = "EditForm", DisplayName = "Edit Form", Feature = "ApplicationForms", SubFeature = "ApplicationForms" },
            new Privilege { Id = 4, Name = "ApplicationFormFilters", DisplayName = "Filters", Feature = "ApplicationForms", SubFeature = "ApplicationForms" },

            new Privilege { Id = 5, Name = "JobCategoryListPage", DisplayName = "Job Category List Page", Feature = "JobCategories", SubFeature = "JobCategories" },
            new Privilege { Id = 6, Name = "AddCategory", DisplayName = "Add Category", Feature = "JobCategories", SubFeature = "JobCategories" },
            new Privilege { Id = 7, Name = "EditCategory", DisplayName = "Edit Category", Feature = "JobCategories", SubFeature = "JobCategories" },
            new Privilege { Id = 8, Name = "DeleteCategory", DisplayName = "Delete Category", Feature = "JobCategories", SubFeature = "JobCategories" },
            new Privilege { Id = 9, Name = "JobCategoryFilters", DisplayName = "Filters", Feature = "JobCategories", SubFeature = "JobCategories" },

            new Privilege { Id = 10, Name = "JobPostsListPage", DisplayName = "Job Posts List Page", Feature = "Job Posts", SubFeature = "JobPosts" },
            new Privilege { Id = 11, Name = "AddJobPost", DisplayName = "Add Job Post", Feature = "JobPosts", SubFeature = "JobPosts" },
            new Privilege { Id = 12, Name = "EditJobPost", DisplayName = "Edit Job Post", Feature = "JobPosts", SubFeature = "JobPosts" },
            new Privilege { Id = 13, Name = "CopyToClipboard", DisplayName = "Copy to Clipboard", Feature = "JobPosts", SubFeature = "JobPosts" },
            new Privilege { Id = 14, Name = "JobPostPreview", DisplayName = "Job Post Preview", Feature = "JobPosts", SubFeature = "JobPosts" },
            new Privilege { Id = 15, Name = "JobPostFilters", DisplayName = "Filters", Feature = "JobPosts", SubFeature = "JobPosts" },
            new Privilege { Id = 16, Name = "PublishJobsToIndeed", DisplayName = "Publish Jobs to Indeed", Feature = "JobPosts", SubFeature = "JobPosts" },

            new Privilege { Id = 17, Name = "ViewAllJobPosts", DisplayName = "View All Job Posts", Feature = "ApplyForJobPosts", SubFeature = "ApplyForJobPosts" },
            new Privilege { Id = 18, Name = "ApplyForJobPosts", DisplayName = "Apply for Job Posts", Feature = "ApplyForJobPosts", SubFeature = "ApplyForJobPosts" },
            new Privilege { Id = 19, Name = "ApplyForJobPostsFilters", DisplayName = "Filters", Feature = "ApplyForJobPosts", SubFeature = "ApplyForJobPosts" },

            new Privilege { Id = 20, Name = "ApplicantDetailsListPage", DisplayName = "Applicant Details List Page", Feature = "ApplicantDetails", SubFeature = "ApplicantDetailsListPage" },
            new Privilege { Id = 21, Name = "ApplicantDetailsFilters", DisplayName = "Filters", Feature = "ApplicantDetails", SubFeature = "ApplicantDetailsListPage" },
            new Privilege { Id = 22, Name = "CompletedApplication", DisplayName = "Completed Application", Feature = "ApplicantDetails", SubFeature = "ApplicationTab" },
            new Privilege { Id = 23, Name = "AbilityToDownloadApplication", DisplayName = "Ability to Download Application", Feature = "ApplicantDetails", SubFeature = "ApplicationTab" },
            new Privilege { Id = 24, Name = "AbilityToPurgeApplicantData", DisplayName = "Ability to Purge Applicant Data", Feature = "ApplicantDetails", SubFeature = "ApplicationTab" },
            new Privilege { Id = 25, Name = "InterviewsListPage", DisplayName = "Interviews List Page", Feature = "ApplicantDetails", SubFeature = "InterviewTab" },
            new Privilege { Id = 26, Name = "ScheduleInterview", DisplayName = "Schedule Interview", Feature = "ApplicantDetails", SubFeature = "InterviewTab" },
            new Privilege { Id = 27, Name = "EditScheduledInterview", DisplayName = "Edit Scheduled Interview", Feature = "ApplicantDetails", SubFeature = "InterviewTab" },
            new Privilege { Id = 28, Name = "CancelScheduledInterview", DisplayName = "Cancel Scheduled Interview", Feature = "ApplicantDetails", SubFeature = "InterviewTab" },
            new Privilege { Id = 29, Name = "MarkInterviewAsNoShow", DisplayName = "Mark Interview as No-Show", Feature = "ApplicantDetails", SubFeature = "InterviewTab" },
            new Privilege { Id = 30, Name = "InterviewNotesFeedback", DisplayName = "Interview Notes Feedback", Feature = "ApplicantDetails", SubFeature = "InterviewTab" },
            new Privilege { Id = 31, Name = "InterviewEditNotes", DisplayName = "Edit Interview Notes", Feature = "ApplicantDetails", SubFeature = "InterviewTab" },
            new Privilege { Id = 32, Name = "NotesListPage", DisplayName = "Notes List Page", Feature = "ApplicantDetails", SubFeature = "NotesTab" },
            new Privilege { Id = 33, Name = "ViewNotes", DisplayName = "View Notes", Feature = "ApplicantDetails", SubFeature = "NotesTab" },
            new Privilege { Id = 34, Name = "AddNotes", DisplayName = "Add Notes", Feature = "ApplicantDetails", SubFeature = "NotesTab" },
            new Privilege { Id = 35, Name = "EditNotes", DisplayName = "Edit Notes", Feature = "ApplicantDetails", SubFeature = "NotesTab" },
            new Privilege { Id = 36, Name = "AttachmentsListPage", DisplayName = "Attachments List Page", Feature = "ApplicantDetails", SubFeature = "AttachmentsTab" },
            new Privilege { Id = 37, Name = "AddAttachments", DisplayName = "Add Attachments", Feature = "ApplicantDetails", SubFeature = "AttachmentsTab" },
            new Privilege { Id = 38, Name = "DeleteAttachments", DisplayName = "Delete Attachments", Feature = "ApplicantDetails", SubFeature = "AttachmentsTab" },
            new Privilege { Id = 39, Name = "ViewAttachments", DisplayName = "View Attachments", Feature = "ApplicantDetails", SubFeature = "AttachmentsTab" },
            new Privilege { Id = 40, Name = "EditAttachments", DisplayName = "Edit Attachments", Feature = "ApplicantDetails", SubFeature = "AttachmentsTab" },

            new Privilege { Id = 41, Name = "ManualChangeStatus", DisplayName = "Manual Change Status", Feature = "StatusChangesNotifications", SubFeature = "StatusChangesNotifications" },

            new Privilege { Id = 42, Name = "ViewAuditLog", DisplayName = "View Audit Log", Feature = "AuditLog", SubFeature = "AuditLog" },
            new Privilege { Id = 43, Name = "ExportToCSV", DisplayName = "Export to CSV", Feature = "AuditLog", SubFeature = "AuditLog" },

            new Privilege { Id = 44, Name = "AutoLogOffATS", DisplayName = "Auto Log Off ATS", Feature = "Global", SubFeature = "AuditLog" },
            new Privilege { Id = 45, Name = "UniqueURLOnJobBoardForEachCompany", DisplayName = "Unique URL on Job Board for Each Company", Feature = "Global", SubFeature = "Global" },
            new Privilege { Id = 46, Name = "ClientNameAndIDAddedToTopOfATSScreens", DisplayName = "Client Name and ID Added to Top of ATS Screens", Feature = "Global", SubFeature = "Global" },
            new Privilege { Id = 47, Name = "ATSMenu", DisplayName = "ATS Menu", Feature = "Global", SubFeature = "Global" },
            new Privilege { Id = 48, Name = "AbilityToSwitchCompanies", DisplayName = "Ability to Switch Companies", Feature = "Global", SubFeature = "Global" },
            new Privilege { Id = 49, Name = "AbilityToMoveBackToPortalFromATS", DisplayName = "Ability to Move Back to Portal from ATS", Feature = "Global", SubFeature = "Global" },

            new Privilege { Id = 50, Name = "ScheduledInterviewCalendar", DisplayName = "Scheduled Interview Calendar", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 51, Name = "PipelineOverview", DisplayName = "Pipeline Overview", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 52, Name = "MetricsSummary", DisplayName = "Metrics Summary", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 53, Name = "MonthlyJobTrend", DisplayName = "Monthly Job Trend", Feature = "Dashboard", SubFeature = "Dashboard" },

            new Privilege { Id = 54, Name = "EmailNotificationPreview", DisplayName = "Email Notification Preview", Feature = "StatusChangesNotifications", SubFeature = "Notification" },
            new Privilege { Id = 55, Name = "ApplicationSubmittedEmailtoHiringManagerOptiontoSend", DisplayName = "Application Submitted Email to Hiring Manager Option to Send", Feature = "StatusChangesNotifications", SubFeature = "Notification" },
            new Privilege { Id = 56, Name = "InterviewScheduledApplicantEmailNotificationOptiontoSend", DisplayName = "Interview Scheduled Applicant Email Notification Option to Send", Feature = "StatusChangesNotifications", SubFeature = "Notification" },
            new Privilege { Id = 57, Name = "InterviewUpdatedEmailNotificationOptiontoSend", DisplayName = "Interview Updated Email Notification Option to Send", Feature = "StatusChangesNotifications", SubFeature = "Notification" },
            new Privilege { Id = 58, Name = "InterviewCancelledEmailNotificationOptiontoSend", DisplayName = "Interview Cancelled Email Notification Option to Send", Feature = "StatusChangesNotifications", SubFeature = "Notification" },
            new Privilege { Id = 59, Name = "NotSelectedEmailNotificationOptiontoSend", DisplayName = "Not Selected Email Notification Option to Send", Feature = "StatusChangesNotifications", SubFeature = "Notification" },
            new Privilege { Id = 60, Name = "OfferExtendedEmailNotificationOptiontoSend", DisplayName = "Offer Extended Email Notification Option to Send", Feature = "StatusChangesNotifications", SubFeature = "Notification" },

            new Privilege { Id = 61, Name = "ApplicantQuizList", DisplayName = "Applicant Quiz List", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },
            new Privilege { Id = 62, Name = "AddEditQuiz", DisplayName = "Add and Edit Quiz", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },
            new Privilege { Id = 63, Name = "AddQuestionsAnswers", DisplayName = "Add Questions and Answers", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },
            new Privilege { Id = 64, Name = "DeleteQuestionsAnswers", DisplayName = "Delete Questions and Answers", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },
            new Privilege { Id = 65, Name = "EditQuestionsAnswers", DisplayName = "Edit Questions and Answers", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },
            new Privilege { Id = 66, Name = "CompleteQuiz", DisplayName = "Complete Quiz", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },
            new Privilege { Id = 67, Name = "ScoreQuiz", DisplayName = "Score Quiz", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },
            new Privilege { Id = 68, Name = "ViewQuizResults", DisplayName = "View Quiz Results", Feature = "ApplicantQuiz", SubFeature = "ApplicantQuiz" },

            new Privilege { Id = 69, Name = "JobFeedListPage", DisplayName = "Job Feed List Page", Feature = "JobFeed", SubFeature = "JobFeed" },
            new Privilege { Id = 70, Name = "AddNewJobFeed", DisplayName = "Add New Job Feed", Feature = "JobFeed", SubFeature = "JobFeed" },

            new Privilege { Id = 71, Name = "EmailNotificationToInterviewersOfScheduledInterviewOptionToSend", DisplayName = "Email Notification to Interviewer(s) of Scheduled Interview - Option to Send", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 72, Name = "EmailNotificationToInterviewersOfScheduledInterviewSendEmail", DisplayName = "Email Notification to Interviewer(s) of Scheduled Interview - Send Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 73, Name = "EmailNotificationToInterviewersOfScheduledInterviewReceiveEmail", DisplayName = "Email Notification to Interviewer(s) of Scheduled Interview - Receive Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 74, Name = "InterviewFeedbackEmailNotificationToHiringManagerOptionToSend", DisplayName = "Interview Feedback Email Notification to Hiring Manager  - Option to Send", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 75, Name = "InterviewFeedbackEmailNotificationToHiringManagerSendEmail", DisplayName = "Interview Feedback Email Notification to Hiring Manager  -  Send Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 76, Name = "InterviewFeedbackEmailNotificationToHiringManagerReceiveEmail", DisplayName = "Interview Feedback Email Notification to Hiring Manager  - Receive Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 77, Name = "OfferDeclinedEmailNotificationOptionToSend", DisplayName = "Offer Declined Email Notification - Option to Send", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 78, Name = "OfferDeclinedEmailNotificationSendEmail", DisplayName = "Offer Declined Email Notification - Send Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 79, Name = "OfferDeclinedEmailNotificationReceiveEmail", DisplayName = "Offer Declined Email Notification - Receive Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 80, Name = "OfferAcceptedEmailNotificationOptionToSend", DisplayName = "Offer Accepted Email Notification - Option to Send", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 81, Name = "OfferAcceptedEmailNotificationSendEmail", DisplayName = "Offer Accepted Email Notification - Send Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 82, Name = "OfferAcceptedEmailNotificationReceiveEmail", DisplayName = "Offer Accepted Email Notification - Receive Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 83, Name = "JobPostExpirationOptionToSend", DisplayName = "Job Post Expiration - Option to Send", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 84, Name = "JobPostExpirationSendEmail", DisplayName = "Job Post Expiration - Send Email", Feature = "Notifications", SubFeature = "Notifications" },
            new Privilege { Id = 85, Name = "JobPostExpirationReceiveEmail", DisplayName = "Job Post Expiration - Receive Email", Feature = "Notifications", SubFeature = "Notifications" },

            new Privilege { Id = 86, Name = "SSOToATSFromMyBBSIWidget", DisplayName = "SSO to ATS from myBBSI widget", Feature = "Global", SubFeature = "Global" },
            new Privilege { Id = 87, Name = "GenerateUniqueURLforEachCompanysJobBoard", DisplayName = "Generate Unique URL for each company's job board", Feature = "Global", SubFeature = "Global" },
            new Privilege { Id = 88, Name = "UserBellPushNotifications", DisplayName = "User Bell Push Notifications", Feature = "Global", SubFeature = "Global" },
            new Privilege { Id = 89, Name = "HelpDocumentation", DisplayName = "Help Documentation", Feature = "Global", SubFeature = "Global" },

            new Privilege { Id = 90, Name = "UserProfile", DisplayName = "User Profile", Feature = "Global", SubFeature = "Global" },

            new Privilege { Id = 91, Name = "InterviewCalendar", DisplayName = "Interview Calendar", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 92, Name = "ApplicantStatusOverview", DisplayName = "Applicant status overview", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 93, Name = "ActiveJobsByCategory", DisplayName = "Active jobs by category", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 94, Name = "Activejobsbylocation", DisplayName = "Active jobs by location", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 95, Name = "OfferStatusOverview", DisplayName = "Offer status overview", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 96, Name = "JobsByAge", DisplayName = "Jobs by age", Feature = "Dashboard", SubFeature = "Dashboard" },
            new Privilege { Id = 97, Name = "InterviewerInterviews", DisplayName = "Interviewer Interviews", Feature = "Dashboard", SubFeature = "Dashboard" }

        );
    }
}