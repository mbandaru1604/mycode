﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static BBSI.ATS.Common.Constants;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class WorksiteLocationConfiguration : IEntityTypeConfiguration<WorksiteLocation>
    {
        public void Configure(EntityTypeBuilder<WorksiteLocation> builder)
        {
            builder.ToTable(nameof(WorksiteLocation));

            builder.Property(location => location.Code)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(location => location.Name)
                   .IsRequired()
                   .HasMaxLength(200);

            builder.Property(location => location.IsActive)
                   .IsRequired();

            builder.Property(location => location.Address1)
                   .HasMaxLength(100);

            builder.Property(location => location.Address2)
                   .HasMaxLength(200);

            builder.Property(location => location.City)
                   .HasMaxLength(200);

            builder.Property(location => location.State)
                   .HasMaxLength(100);

            builder.Property(location => location.Country)
                   .HasMaxLength(50)
                   .HasDefaultValue(PropertyDefaultValues.WorksiteLocationCountry);

            builder.Property(location => location.ZipCode)
                   .HasMaxLength(20);

            builder.HasOne(location => location.Company)
                   .WithMany(company => company.WorksiteLocations)
                   .HasForeignKey(location => location.CompanyId);
        }
    }
}