﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobApplicationConfiguration : IEntityTypeConfiguration<JobApplication>
    {
        public void Configure(EntityTypeBuilder<JobApplication> builder)
        {
            builder.ToTable(nameof(JobApplication));

            builder.Property(jobApplication => jobApplication.ApplicantName)
                   .IsRequired()
                   .HasDefaultValue(string.Empty)
                   .HasMaxLength(200);

            builder.Property(jobApplication => jobApplication.EmployeeId)
                   .HasMaxLength(50);

            builder.HasOne(jobApplication => jobApplication.Company)
                   .WithMany()
                   .HasForeignKey(jobApplication => jobApplication.CompanyId);

            builder.Property(jobApplication => jobApplication.JobPostId)
                   .IsRequired();

            builder.HasOne(jobApplication => jobApplication.JobPost)
                   .WithMany()
                   .HasForeignKey(jobApplication => jobApplication.JobPostId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(jobApplication => jobApplication.FieldValues)
                   .WithOne(fieldValue => fieldValue.JobApplication)
                   .HasForeignKey(fieldValue => fieldValue.JobApplicationId);

            builder.HasMany(jobApplication => jobApplication.FieldSets)
                   .WithOne(fieldset => fieldset.JobApplication)
                   .HasForeignKey(fieldset => fieldset.JobApplicationId);

            builder.HasOne(jobApplication => jobApplication.Status)
                   .WithMany()
                   .HasForeignKey(jobApplication => jobApplication.StatusId);

            builder.HasMany(jobApplication => jobApplication.Attachments)
                   .WithOne(attachment => attachment.JobApplication)
                   .HasForeignKey(attachment => attachment.JobApplicationId);

            builder.HasOne(jobApplication => jobApplication.NewHireType)
                   .WithMany()
                   .HasForeignKey(jobApplication => jobApplication.NewHireTypeId);

            builder.HasIndex(jobApplication => jobApplication.StatusId)
                   .IncludeProperties(jobApplication => jobApplication.JobPostId)
                   .HasDatabaseName("IX_JobApplication_StatusId");
        }
    }
}