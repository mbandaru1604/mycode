﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class ApplicationFormFieldOptionConfiguration : IEntityTypeConfiguration<ApplicationFormFieldOption>
    {
        public void Configure(EntityTypeBuilder<ApplicationFormFieldOption> builder)
        {
            builder.ToTable(nameof(ApplicationFormFieldOption));

            builder.HasOne(fieldOption => fieldOption.FormField)
                   .WithMany(formField => formField.Options)
                   .HasForeignKey(fieldOption => fieldOption.FormFieldId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.Property(fieldOption => fieldOption.Name)
                   .IsRequired()
                   .HasMaxLength(DropdownValidation.OptionMaxLength);

            builder.Property(fieldOption => fieldOption.FormFieldId)
                   .IsRequired();

            builder.Property(fieldOption => fieldOption.IsDeleted)
                   .IsRequired()
                   .HasDefaultValue(false);
        }
    }
}