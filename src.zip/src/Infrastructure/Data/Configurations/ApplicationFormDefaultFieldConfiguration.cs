﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicationFormDefaultFieldConfiguration : IEntityTypeConfiguration<ApplicationFormDefaultField>
{
    public void Configure(EntityTypeBuilder<ApplicationFormDefaultField> builder)
    {
        builder.ToTable(nameof(ApplicationFormDefaultField));

        builder.HasOne(field => field.Section)
               .WithMany()
               .HasForeignKey(df => df.SectionId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(field => field.Type)
               .WithMany()
               .HasForeignKey(field => field.TypeId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.Property(field => field.DisplayOrder)
               .IsRequired();

        builder.Property(field => field.IsActive)
               .IsRequired()
               .HasDefaultValue(true);

        builder.Property(field => field.IsAlwaysActiveAndRequired)
               .IsRequired();

        builder.Property(field => field.IsRequired)
                .IsRequired();

        builder.Property(field => field.Name)
              .IsRequired()
              .HasMaxLength(100);

        builder.Property(field => field.SectionId)
             .IsRequired();

        builder.Property(field => field.TypeId)
              .IsRequired();

        builder.HasOne(field => field.LookupType)
               .WithMany()
               .HasForeignKey(df => df.LookupTypeId);

        builder.HasData(
            new() { Id = 1, Name = "First Name", DisplayOrder = 1, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 2, Name = "Middle Name", DisplayOrder = 2, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 3, Name = "Last Name", DisplayOrder = 3, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 4, Name = "Personal Email Address", DisplayOrder = 4, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.EmailAddress },
            new() { Id = 5, Name = "Home Telephone Number", DisplayOrder = 5, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.PhoneNumber },
            new() { Id = 6, Name = "Mobile Phone Number", DisplayOrder = 6, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.PersonalInformation, TypeId = (long)ApplicationFormFieldTypes.PhoneNumber },
            new() { Id = 7, Name = "Address Line 1", DisplayOrder = 7, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 8, Name = "Address Line 2", DisplayOrder = 8, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 9, Name = "Zip Code", DisplayOrder = 11, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 10, Name = "City", DisplayOrder = 9, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 11, Name = "State", DisplayOrder = 10, IsActive = true, IsAlwaysActiveAndRequired = true, IsRequired = true, SectionId = (long)ApplicationFormSections.Address, TypeId = (long)ApplicationFormFieldTypes.Dropdown, LookupTypeId = (long)LookupTypes.State },
            new() { Id = 12, Name = "Photo", DisplayOrder = 14, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.FileUpload },
            new() { Id = 13, Name = "Resume", DisplayOrder = 12, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = true, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.FileUpload },
            new() { Id = 14, Name = "Cover Letter", DisplayOrder = 13, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.FileUpload },
            new() { Id = 15, Name = "When are you available to start work?", DisplayOrder = 15, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.ProfessionalDetails, TypeId = (long)ApplicationFormFieldTypes.DatePicker },
            new() { Id = 16, Name = "Education Level", DisplayOrder = 16, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.Dropdown, LookupTypeId = (long)LookupTypes.EducationLevel },
            new() { Id = 17, Name = "School Major", DisplayOrder = 17, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 18, Name = "School Name", DisplayOrder = 18, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 19, Name = "Graduation Year", DisplayOrder = 19, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.DatePicker },
            new() { Id = 20, Name = "Notes", DisplayOrder = 20, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.EducationHistory, TypeId = (long)ApplicationFormFieldTypes.ParagraphField },
            new() { Id = 21, Name = "Company Name", DisplayOrder = 21, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 22, Name = "Job Title", DisplayOrder = 22, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 23, Name = "Industry Type", DisplayOrder = 23, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.SingleLineInput },
            new() { Id = 24, Name = "Start Date", DisplayOrder = 24, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.DatePicker },
            new() { Id = 25, Name = "End Date", DisplayOrder = 25, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.WorkHistory, TypeId = (long)ApplicationFormFieldTypes.DatePicker },
            new() { Id = 26, Name = "Voluntary Self-Identification", DisplayOrder = 26, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.VoluntarySelfIdentification, TypeId = (long)ApplicationFormFieldTypes.RadioButton, LookupTypeId = (long)LookupTypes.VoluntarySelfIdentification },
            new() { Id = 27, Name = "Gender", DisplayOrder = 27, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.VoluntarySelfIdentification, TypeId = (long)ApplicationFormFieldTypes.Dropdown, LookupTypeId = (long)LookupTypes.Gender },
            new() { Id = 28, Name = "EthnicityRace", DisplayOrder = 28, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.VoluntarySelfIdentification, TypeId = (long)ApplicationFormFieldTypes.Dropdown, LookupTypeId = (long)LookupTypes.EthnicityRace },
            new() { Id = 29, Name = "Veteran", DisplayOrder = 29, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.VoluntarySelfIdentification, TypeId = (long)ApplicationFormFieldTypes.RadioButton, LookupTypeId = (long)LookupTypes.Veteran },
            new() { Id = 30, Name = "Veteran Status", DisplayOrder = 30, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.VoluntarySelfIdentification, TypeId = (long)ApplicationFormFieldTypes.Dropdown, LookupTypeId = (long)LookupTypes.VeteranStatus },
            new() { Id = 31, Name = "Disability", DisplayOrder = 31, IsActive = true, IsAlwaysActiveAndRequired = false, IsRequired = false, SectionId = (long)ApplicationFormSections.VoluntarySelfIdentification, TypeId = (long)ApplicationFormFieldTypes.ParagraphField }
        );
    }
}