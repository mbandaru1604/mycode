﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class ApplicantQuizResultConfiguration : IEntityTypeConfiguration<ApplicantQuizResult>
    {
        public void Configure(EntityTypeBuilder<ApplicantQuizResult> builder)
        {
            builder.ToTable(nameof(ApplicantQuizResult));

            builder.HasOne(quizResult => quizResult.Quiz)
                   .WithMany()
                   .HasForeignKey(quizResult => quizResult.QuizId);
        }
    }
}