﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobApplicationAttachmentConfiguration : IEntityTypeConfiguration<JobApplicationAttachment>
    {
        public void Configure(EntityTypeBuilder<JobApplicationAttachment> builder)
        {
            builder.ToTable(nameof(JobApplicationAttachment));

            builder.Property(attachment => attachment.Name)
                   .IsRequired()
                   .HasMaxLength(JobApplicationAttachmentValidation.FileNameMaxLength);

            builder.Property(attachment => attachment.Path)
                   .IsRequired();

            builder.Property(attachment => attachment.TypeId)
                  .IsRequired();

            builder.Property(attachment => attachment.JobApplicationId)
                  .IsRequired();

            builder.HasOne(attachment => attachment.Type)
                   .WithMany()
                   .HasForeignKey(attachment => attachment.TypeId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(attachment => attachment.JobApplication)
                   .WithMany()
                   .HasForeignKey(attachment => attachment.JobApplicationId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}