﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class QuizQuestionAnswerConfiguration : IEntityTypeConfiguration<QuizQuestionAnswer>
{
    public void Configure(EntityTypeBuilder<QuizQuestionAnswer> builder)
    {
        builder.ToTable(nameof(QuizQuestionAnswer));

        builder.Property(quizAnswer => quizAnswer.Answer)
               .IsRequired()
               .HasMaxLength(100);

        builder.Property(quizAnswer => quizAnswer.QuizQuestionId)
               .IsRequired();

        builder.Property(quizAnswer => quizAnswer.IsDeleted)
               .IsRequired()
               .HasDefaultValue(false);

        builder.HasOne(quizAnswer => quizAnswer.QuizQuestion)
               .WithMany(quizQuestion => quizQuestion.Answers)
               .HasForeignKey(quizQuestion => quizQuestion.QuizQuestionId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(quizQuestionAnswer => quizQuestionAnswer.IsDeleted)
               .IncludeProperties(quizQuestionAnswer => quizQuestionAnswer.QuizQuestionId)
               .HasDatabaseName("IX_QuizQuestionAnswer_IsDeleted");
    }
}