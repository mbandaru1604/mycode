﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicationFormConfiguration : IEntityTypeConfiguration<ApplicationForm>
{
    public void Configure(EntityTypeBuilder<ApplicationForm> builder)
    {
        builder.ToTable(nameof(ApplicationForm));

        builder.Property(form => form.Name)
               .IsRequired()
               .HasMaxLength(FormValidation.FormNameMaxLength);

        builder.Property(form => form.IsActive)
               .IsRequired()
               .HasDefaultValue(true);

        builder.HasMany(form => form.Fields)
                .WithOne(form => form.ApplicationForm)
                .HasForeignKey(form => form.ApplicationFormId);

        builder.HasOne(form => form.Company)
               .WithMany()
               .HasForeignKey(form => form.CompanyId);

        builder.HasIndex(applicationForm => new { applicationForm.Name, applicationForm.CompanyId })
               .HasDatabaseName("IX_ApplicationForm_Name_CompanyId");
    }
}