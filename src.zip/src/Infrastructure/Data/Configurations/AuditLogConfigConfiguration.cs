﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class AuditLogConfigConfiguration : IEntityTypeConfiguration<AuditLogConfig>
{
    public void Configure(EntityTypeBuilder<AuditLogConfig> builder)
    {
        builder.ToTable(nameof(AuditLogConfig));

        builder.Property(auditLogConfig => auditLogConfig.PageId)
                      .IsRequired();

        builder.Property(auditLogConfig => auditLogConfig.SectionId)
                     .IsRequired();

        builder.HasOne(field => field.Page)
               .WithMany()
               .HasForeignKey(df => df.PageId);

        builder.HasOne(field => field.Section)
               .WithMany()
               .HasForeignKey(df => df.SectionId);

        builder.HasOne(field => field.Field)
             .WithMany()
             .HasForeignKey(df => df.FieldId);
    }
}