﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class JobApplicationStatusConfiguration : IEntityTypeConfiguration<JobApplicationStatus>
{
    public void Configure(EntityTypeBuilder<JobApplicationStatus> builder)
    {
        builder.ToTable(nameof(JobApplicationStatus));

        builder.Property(jobApplicationStatus => jobApplicationStatus.Name)
                       .IsRequired()
                       .HasMaxLength(100);

        builder.Property(jobApplicationStatus => jobApplicationStatus.DisplayOrder)
                       .IsRequired();

        builder.HasData
        (
            new() { Id = 1, Name = "Applied", DisplayOrder = 1 },
            new() { Id = 2, Name = "Interview Scheduled", DisplayOrder = 2 },
            new() { Id = 3, Name = "Not Selected", DisplayOrder = 3 },
            new() { Id = 4, Name = "Offer Extended", DisplayOrder = 4 },
            new() { Id = 5, Name = "Offer Accepted", DisplayOrder = 5 },
            new() { Id = 6, Name = "Offer Declined", DisplayOrder = 6 },
            new() { Id = 7, Name = "Onboarding", DisplayOrder = 7 },
            new() { Id = 8, Name = "Hired", DisplayOrder = 8 }
        );
    }
}