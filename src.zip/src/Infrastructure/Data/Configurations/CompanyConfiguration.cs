﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class CompanyConfiguration : IEntityTypeConfiguration<Company>
    {
        public void Configure(EntityTypeBuilder<Company> builder)
        {
            builder.ToTable(nameof(Company));

            builder.Property(company => company.Code)
                   .IsRequired()
                   .HasMaxLength(6);

            builder.Property(company => company.DbaName)
                   .IsRequired()
                   .HasMaxLength(157);

            builder.Property(company => company.LegalName)
                   .IsRequired()
                   .HasMaxLength(114);

            builder.Property(company => company.StatusCode)
                   .IsRequired()
                   .HasMaxLength(114);

            builder.Property(company => company.Identifier)
                   .IsRequired(false);

            builder.HasMany(company => company.WorksiteLocations)
                   .WithOne(worksiteLocation => worksiteLocation.Company)
                   .HasForeignKey(worksiteLocation => worksiteLocation.CompanyId);
        }
    }
}