﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class QuizQuestionConfiguration : IEntityTypeConfiguration<QuizQuestion>
{
    public void Configure(EntityTypeBuilder<QuizQuestion> builder)
    {
        builder.ToTable(nameof(QuizQuestion));

        builder.Property(quizQuestion => quizQuestion.Question)
               .IsRequired()
               .HasMaxLength(100);

        builder.Property(quizQuestion => quizQuestion.TypeId)
               .IsRequired();

        builder.Property(quizQuestion => quizQuestion.Score)
               .IsRequired()
               .HasDefaultValue(1);

        builder.Property(quizQuestion => quizQuestion.IsActive)
               .HasDefaultValue(true);

        builder.Property(quizQuestion => quizQuestion.IsRequired)
               .HasDefaultValue(true);

        builder.Property(quizQuestion => quizQuestion.ApplicantQuizId)
               .IsRequired();

        builder.Property(quizQuestion => quizQuestion.IsDeleted)
               .IsRequired()
               .HasDefaultValue(false);

        builder.HasOne(quizQuestion => quizQuestion.ApplicantQuiz)
               .WithMany(quiz => quiz.QuizQuestions)
               .HasForeignKey(quizQuestion => quizQuestion.ApplicantQuizId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(quizQuestion => quizQuestion.Type)
               .WithMany()
               .HasForeignKey(quizQuestion => quizQuestion.TypeId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(quizQuestion => quizQuestion.IsDeleted)
               .IncludeProperties(quizQuestion => quizQuestion.ApplicantQuizId)
               .HasDatabaseName("IX_QuizQuestion_IsDeleted");
    }
}
