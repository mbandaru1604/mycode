﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class MenuItemConfiguration : IEntityTypeConfiguration<MenuItem>
    {
        public void Configure(EntityTypeBuilder<MenuItem> builder)
        {
            builder.ToTable(nameof(MenuItem));

            builder.Property(menuItem => menuItem.Label)
                          .IsRequired()
                          .HasMaxLength(100);

            builder.Property(menuItem => menuItem.Code)
                          .IsRequired()
                          .HasMaxLength(100);

            builder.Property(menuItem => menuItem.Url)
                          .IsRequired()
                          .HasMaxLength(250);

            builder.Property(menuItem => menuItem.Icon)
                          .IsRequired()
                          .HasMaxLength(100);

            builder.Property(menuItem => menuItem.DisplayOrder)
                          .IsRequired();

            builder.Property(menuItem => menuItem.IsVisible)
                          .IsRequired()
                          .HasDefaultValue(true);

            builder.HasData
            (
                new() { Id = 1, Label = "Home", Url = "/dashboard", Icon = "icon-home-light", Code = "Dashboard", DisplayOrder = 1, IsVisible = true },
                new() { Id = 2, Label = "Applicant List", Url = "/applicantlist", Icon = "icon-applicant-list", Code = "Applicant List", DisplayOrder = 2, IsVisible = true },
                new() { Id = 3, Label = "Application Forms", Url = "/application-form", Icon = "icon-application-from-settings-light", Code = "Application Forms", DisplayOrder = 3, IsVisible = true },
                new() { Id = 4, Label = "Job Categories", Url = "/job-category", Icon = "icon-job-category-light", Code = "Categories", DisplayOrder = 4, IsVisible = true },
                new() { Id = 5, Label = "Applicant Quizzes", Url = "/quiz", Icon = "icon-quiz-light", Code = "Applicant Quiz", DisplayOrder = 5, IsVisible = true },
                new() { Id = 6, Label = "Job Posts", Url = "/manage-job", Icon = "icon-manage-jobs-light", Code = "Job Posts", DisplayOrder = 6, IsVisible = true },
                new() { Id = 7, Label = "Audit Log", Url = "/audit-log", Icon = "icon-audit-log-light", Code = "Audit Log", DisplayOrder = 8, IsVisible = true },
                new() { Id = 8, Label = "Back to Portal", Url = "back-to-ats", Icon = "icon-back-to-portal-light", Code = "Back to Portal", DisplayOrder = 9, IsVisible = true },
                new() { Id = 9, Label = "Job Board Integrations", Url = "/job-board-integration", Icon = "icon-job-board-integrations", Code = "Job Board Integration", DisplayOrder = 7, IsVisible = true }
            );
        }
    }
}