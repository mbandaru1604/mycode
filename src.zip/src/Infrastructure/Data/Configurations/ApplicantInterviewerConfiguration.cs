﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class ApplicantInterviewerConfiguration : IEntityTypeConfiguration<ApplicantInterviewer>
{
    public void Configure(EntityTypeBuilder<ApplicantInterviewer> builder)
    {
        builder.ToTable(nameof(ApplicantInterviewer));

        builder.Property(interviewer => interviewer.InterviewerId)
                .IsRequired();

        builder.Property(interviewer => interviewer.ApplicantInterviewId)
                .IsRequired();

        builder.HasOne(interviewer => interviewer.Interviewer)
                .WithMany()
                .HasForeignKey(interviewer => interviewer.InterviewerId)
                .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(interviewer => interviewer.ApplicantInterview)
               .WithMany(interview => interview.Interviewers)
               .HasForeignKey(interviewer => interviewer.ApplicantInterviewId)
                .OnDelete(DeleteBehavior.Restrict);
    }
}