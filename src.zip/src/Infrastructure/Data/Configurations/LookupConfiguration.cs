﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations;

public class LookupConfiguration : IEntityTypeConfiguration<LookupData>
{
    public void Configure(EntityTypeBuilder<LookupData> builder)
    {
        builder.ToTable(nameof(LookupData));

        builder.Property(lookup => lookup.Name)
                       .IsRequired()
                       .HasMaxLength(100);

        builder.HasOne(lookup => lookup.Type)
                .WithMany()
                .HasForeignKey(lookup => lookup.TypeId);

        builder.Property(lookup => lookup.DisplayOrder)
                       .IsRequired();

        builder.Property(lookup => lookup.IsActive)
               .IsRequired()
               .HasDefaultValue(true);

        builder.HasData
        (
            new() { Id = 1, TypeId = (long)LookupTypes.EmployeeType, Name = "Full Time", DisplayOrder = 1, Code = "F" },
            new() { Id = 2, TypeId = (long)LookupTypes.EmployeeType, Name = "Part Time", DisplayOrder = 2, Code = "P" },
            new() { Id = 3, TypeId = (long)LookupTypes.EmployeeType, Name = "Part Time Eligible for Benefits", DisplayOrder = 3, Code = "B" },
            new() { Id = 4, TypeId = (long)LookupTypes.EmployeeType, Name = "Seasonal", DisplayOrder = 4, Code = "S" },
            new() { Id = 5, TypeId = (long)LookupTypes.EmployeeType, Name = "Variable", DisplayOrder = 5, Code = "V" },

            new() { Id = 6, TypeId = (long)LookupTypes.EEOClass, Name = "Executive/ Senior Level Officials/ Managers", DisplayOrder = 6 },
            new() { Id = 7, TypeId = (long)LookupTypes.EEOClass, Name = "First/ Mid Level Officials/ Managers", DisplayOrder = 7 },
            new() { Id = 8, TypeId = (long)LookupTypes.EEOClass, Name = "Professionals", DisplayOrder = 8 },
            new() { Id = 9, TypeId = (long)LookupTypes.EEOClass, Name = "Technicians", DisplayOrder = 9 },
            new() { Id = 10, TypeId = (long)LookupTypes.EEOClass, Name = "Sales Workers", DisplayOrder = 10 },
            new() { Id = 11, TypeId = (long)LookupTypes.EEOClass, Name = "Administrative Support Workers", DisplayOrder = 11 },
            new() { Id = 12, TypeId = (long)LookupTypes.EEOClass, Name = "Craft or Skilled Workers", DisplayOrder = 12 },
            new() { Id = 13, TypeId = (long)LookupTypes.EEOClass, Name = "Operatives or Semi-Skilled Workers", DisplayOrder = 13 },
            new() { Id = 14, TypeId = (long)LookupTypes.EEOClass, Name = "Laborers or Helpers", DisplayOrder = 14 },
            new() { Id = 15, TypeId = (long)LookupTypes.EEOClass, Name = "Service Workers", DisplayOrder = 15 },

            new() { Id = 16, TypeId = (long)LookupTypes.PayGroup, Name = "Annually", DisplayOrder = 16, Code = "Y" },
            new() { Id = 17, TypeId = (long)LookupTypes.PayGroup, Name = "Bi-Weekly", DisplayOrder = 17, Code = "B" },
            new() { Id = 18, TypeId = (long)LookupTypes.PayGroup, Name = "Monthly", DisplayOrder = 18, Code = "M" },
            new() { Id = 20, TypeId = (long)LookupTypes.PayGroup, Name = "Semi-Monthly", DisplayOrder = 20, Code = "S" },
            new() { Id = 21, TypeId = (long)LookupTypes.PayGroup, Name = "Weekly", DisplayOrder = 21, Code = "W" },
            new() { Id = 22, TypeId = (long)LookupTypes.PayGroup, Name = "Daily", DisplayOrder = 22, Code = "Daily" },

            new() { Id = 23, TypeId = (long)LookupTypes.PayMethod, Name = "Hourly", DisplayOrder = 23, Code = "H" },
            new() { Id = 24, TypeId = (long)LookupTypes.PayMethod, Name = "Salary", DisplayOrder = 24, Code = "S" },
            new() { Id = 25, TypeId = (long)LookupTypes.PayMethod, Name = "Commission", DisplayOrder = 25, Code = "C" },
            new() { Id = 26, TypeId = (long)LookupTypes.PayMethod, Name = "Driver", DisplayOrder = 26, Code = "D" },

            new() { Id = 27, TypeId = (long)LookupTypes.WorkArrangement, Name = "Remote", DisplayOrder = 27, Code = "Remote" },
            new() { Id = 28, TypeId = (long)LookupTypes.WorkArrangement, Name = "Hybrid", DisplayOrder = 28 },
            new() { Id = 29, TypeId = (long)LookupTypes.WorkArrangement, Name = "Onsite", DisplayOrder = 29 },

            new() { Id = 30, TypeId = (long)LookupTypes.LocationType, Name = "Worksite Location", DisplayOrder = 30 },
            new() { Id = 31, TypeId = (long)LookupTypes.LocationType, Name = "Custom Location", DisplayOrder = 31 },

            new() { Id = 32, Code = "AL", TypeId = (long)LookupTypes.State, Name = "ALABAMA", DisplayOrder = 32 },
            new() { Id = 33, Code = "AK", TypeId = (long)LookupTypes.State, Name = "ALASKA", DisplayOrder = 33 },
            new() { Id = 34, Code = "AZ", TypeId = (long)LookupTypes.State, Name = "ARIZONA", DisplayOrder = 34 },
            new() { Id = 35, Code = "AR", TypeId = (long)LookupTypes.State, Name = "ARKANSAS", DisplayOrder = 35 },
            new() { Id = 36, Code = "CA", TypeId = (long)LookupTypes.State, Name = "CALIFORNIA", DisplayOrder = 36 },
            new() { Id = 37, Code = "CO", TypeId = (long)LookupTypes.State, Name = "COLORADO", DisplayOrder = 37 },
            new() { Id = 38, Code = "CT", TypeId = (long)LookupTypes.State, Name = "CONNECTICUT", DisplayOrder = 38 },
            new() { Id = 39, Code = "DE", TypeId = (long)LookupTypes.State, Name = "DELAWARE", DisplayOrder = 39 },
            new() { Id = 40, Code = "DC", TypeId = (long)LookupTypes.State, Name = "DISTRICT OF COLUMBIA", DisplayOrder = 40 },
            new() { Id = 41, Code = "FL", TypeId = (long)LookupTypes.State, Name = "FLORIDA", DisplayOrder = 41 },
            new() { Id = 42, Code = "GA", TypeId = (long)LookupTypes.State, Name = "GEORGIA", DisplayOrder = 42 },
            new() { Id = 43, Code = "HI", TypeId = (long)LookupTypes.State, Name = "HAWAII", DisplayOrder = 43 },
            new() { Id = 44, Code = "ID", TypeId = (long)LookupTypes.State, Name = "IDAHO", DisplayOrder = 44 },
            new() { Id = 45, Code = "IL", TypeId = (long)LookupTypes.State, Name = "ILLINOIS", DisplayOrder = 45 },
            new() { Id = 46, Code = "IN", TypeId = (long)LookupTypes.State, Name = "INDIANA", DisplayOrder = 46 },
            new() { Id = 47, Code = "IA", TypeId = (long)LookupTypes.State, Name = "IOWA", DisplayOrder = 47 },
            new() { Id = 48, Code = "KS", TypeId = (long)LookupTypes.State, Name = "KANSAS", DisplayOrder = 48 },
            new() { Id = 49, Code = "KY", TypeId = (long)LookupTypes.State, Name = "KENTUCKY", DisplayOrder = 49 },
            new() { Id = 50, Code = "LA", TypeId = (long)LookupTypes.State, Name = "LOUISIANA", DisplayOrder = 50 },
            new() { Id = 51, Code = "ME", TypeId = (long)LookupTypes.State, Name = "MAINE", DisplayOrder = 51 },
            new() { Id = 52, Code = "MD", TypeId = (long)LookupTypes.State, Name = "MARYLAND", DisplayOrder = 52 },
            new() { Id = 53, Code = "MA", TypeId = (long)LookupTypes.State, Name = "MASSACHUSETTS", DisplayOrder = 53 },
            new() { Id = 54, Code = "MI", TypeId = (long)LookupTypes.State, Name = "MICHIGAN", DisplayOrder = 54 },
            new() { Id = 55, Code = "MN", TypeId = (long)LookupTypes.State, Name = "MINNESOTA", DisplayOrder = 55 },
            new() { Id = 56, Code = "MS", TypeId = (long)LookupTypes.State, Name = "MISSISSIPPI", DisplayOrder = 56 },
            new() { Id = 57, Code = "MO", TypeId = (long)LookupTypes.State, Name = "MISSOURI", DisplayOrder = 57 },
            new() { Id = 58, Code = "MT", TypeId = (long)LookupTypes.State, Name = "MONTANA", DisplayOrder = 58 },
            new() { Id = 59, Code = "NE", TypeId = (long)LookupTypes.State, Name = "NEBRASKA", DisplayOrder = 59 },
            new() { Id = 60, Code = "NV", TypeId = (long)LookupTypes.State, Name = "NEVADA", DisplayOrder = 60 },
            new() { Id = 61, Code = "NH", TypeId = (long)LookupTypes.State, Name = "NEW HAMPSHIRE", DisplayOrder = 61 },
            new() { Id = 62, Code = "NJ", TypeId = (long)LookupTypes.State, Name = "NEW JERSEY", DisplayOrder = 62 },
            new() { Id = 63, Code = "NM", TypeId = (long)LookupTypes.State, Name = "NEW MEXICO", DisplayOrder = 63 },
            new() { Id = 64, Code = "NY", TypeId = (long)LookupTypes.State, Name = "NEW YORK", DisplayOrder = 64 },
            new() { Id = 65, Code = "NC", TypeId = (long)LookupTypes.State, Name = "NORTH CAROLINA", DisplayOrder = 65 },
            new() { Id = 66, Code = "ND", TypeId = (long)LookupTypes.State, Name = "NORTH DAKOTA", DisplayOrder = 66 },
            new() { Id = 67, Code = "OH", TypeId = (long)LookupTypes.State, Name = "OHIO", DisplayOrder = 67 },
            new() { Id = 68, Code = "OK", TypeId = (long)LookupTypes.State, Name = "OKLAHOMA", DisplayOrder = 68 },
            new() { Id = 69, Code = "OR", TypeId = (long)LookupTypes.State, Name = "OREGON", DisplayOrder = 69 },
            new() { Id = 70, Code = "PA", TypeId = (long)LookupTypes.State, Name = "PENNSYLVANIA", DisplayOrder = 70 },
            new() { Id = 71, Code = "PR", TypeId = (long)LookupTypes.State, Name = "PUERTO RICO", DisplayOrder = 71 },
            new() { Id = 72, Code = "RI", TypeId = (long)LookupTypes.State, Name = "RHODE ISLAND", DisplayOrder = 72 },
            new() { Id = 73, Code = "SC", TypeId = (long)LookupTypes.State, Name = "SOUTH CAROLINA", DisplayOrder = 73 },
            new() { Id = 74, Code = "SD", TypeId = (long)LookupTypes.State, Name = "SOUTH DAKOTA", DisplayOrder = 74 },
            new() { Id = 75, Code = "TN", TypeId = (long)LookupTypes.State, Name = "TENNESSEE", DisplayOrder = 75 },
            new() { Id = 76, Code = "TX", TypeId = (long)LookupTypes.State, Name = "TEXAS", DisplayOrder = 76 },
            new() { Id = 77, Code = "UT", TypeId = (long)LookupTypes.State, Name = "UTAH", DisplayOrder = 77 },
            new() { Id = 78, Code = "VT", TypeId = (long)LookupTypes.State, Name = "VERMONT", DisplayOrder = 78 },
            new() { Id = 79, Code = "VA", TypeId = (long)LookupTypes.State, Name = "VIRGINIA", DisplayOrder = 79 },
            new() { Id = 80, Code = "WA", TypeId = (long)LookupTypes.State, Name = "WASHINGTON", DisplayOrder = 80 },
            new() { Id = 81, Code = "WV", TypeId = (long)LookupTypes.State, Name = "WEST VIRGINIA", DisplayOrder = 81 },
            new() { Id = 82, Code = "WI", TypeId = (long)LookupTypes.State, Name = "WISCONSIN", DisplayOrder = 82 },
            new() { Id = 83, Code = "WY", TypeId = (long)LookupTypes.State, Name = "WYOMING", DisplayOrder = 83 },

            new() { Id = 84, TypeId = (long)LookupTypes.EducationLevel, Name = "Associates Degree", DisplayOrder = 1 },
            new() { Id = 85, TypeId = (long)LookupTypes.EducationLevel, Name = "Bachelor's Degree", DisplayOrder = 2 },
            new() { Id = 86, TypeId = (long)LookupTypes.EducationLevel, Name = "Master's Degree", DisplayOrder = 3 },
            new() { Id = 87, TypeId = (long)LookupTypes.EducationLevel, Name = "Ph.D.", DisplayOrder = 4 },
            new() { Id = 88, TypeId = (long)LookupTypes.EducationLevel, Name = "High School Diploma", DisplayOrder = 5 },
            new() { Id = 89, TypeId = (long)LookupTypes.EducationLevel, Name = "GED", DisplayOrder = 6 },
            new() { Id = 90, TypeId = (long)LookupTypes.EducationLevel, Name = "Vocational/Technical School", DisplayOrder = 7 },

            new() { Id = 91, TypeId = (long)LookupTypes.SectionType, Name = "Regular", DisplayOrder = 1 },
            new() { Id = 92, TypeId = (long)LookupTypes.SectionType, Name = "Tabular", DisplayOrder = 2 },

            new() { Id = 93, TypeId = (long)LookupTypes.InterviewType, Name = "Phone", DisplayOrder = 1 },
            new() { Id = 94, TypeId = (long)LookupTypes.InterviewType, Name = "Video", DisplayOrder = 2 },
            new() { Id = 95, TypeId = (long)LookupTypes.InterviewType, Name = "In-Person", DisplayOrder = 3 },

            new() { Id = 96, TypeId = (long)LookupTypes.InterviewStatus, Name = "Interview Scheduled", DisplayOrder = 1 },
            new() { Id = 97, TypeId = (long)LookupTypes.InterviewStatus, Name = "Interview Completed", DisplayOrder = 2 },
            new() { Id = 98, TypeId = (long)LookupTypes.InterviewStatus, Name = "Interview No Show", DisplayOrder = 3 },
            new() { Id = 99, TypeId = (long)LookupTypes.InterviewStatus, Name = "Interview Cancelled", DisplayOrder = 4 },

            new() { Id = 100, TypeId = (long)LookupTypes.JobApplicationAttachmentType, Name = "Resume", DisplayOrder = 1 },
            new() { Id = 101, TypeId = (long)LookupTypes.JobApplicationAttachmentType, Name = "Cover Letter", DisplayOrder = 2 },
            new() { Id = 102, TypeId = (long)LookupTypes.JobApplicationAttachmentType, Name = "Photo", DisplayOrder = 3 },
            new() { Id = 103, TypeId = (long)LookupTypes.JobApplicationAttachmentType, Name = "Custom", DisplayOrder = 4 },
            new() { Id = 104, TypeId = (long)LookupTypes.JobApplicationStatusTransitionTrigger, Name = "Initial Application Status", DisplayOrder = 1 },
            new() { Id = 105, TypeId = (long)LookupTypes.JobApplicationStatusTransitionTrigger, Name = "Interview Scheduling", DisplayOrder = 2 },
            new() { Id = 106, TypeId = (long)LookupTypes.JobApplicationStatusTransitionTrigger, Name = "Offer Acceptance", DisplayOrder = 3 },
            new() { Id = 107, TypeId = (long)LookupTypes.JobApplicationStatusTransitionTrigger, Name = "Offer Decline", DisplayOrder = 4 },
            new() { Id = 108, TypeId = (long)LookupTypes.JobApplicationStatusTransitionTrigger, Name = "Successful Hire Event", DisplayOrder = 5 },

            new() { Id = 109, TypeId = (long)LookupTypes.ReceiverType, Name = "Applicant", DisplayOrder = 1 },
            new() { Id = 110, TypeId = (long)LookupTypes.ReceiverType, Name = "Hiring Manager", DisplayOrder = 2 },
            new() { Id = 111, TypeId = (long)LookupTypes.ReceiverType, Name = "Interviewer", DisplayOrder = 3 },

            new() { Id = 112, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Interview Type In Person", DisplayOrder = 1 },
            new() { Id = 113, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Interview Type Phone", DisplayOrder = 2 },
            new() { Id = 114, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Interview Type Video", DisplayOrder = 3 },
            new() { Id = 115, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Offer Extended Email Notification", DisplayOrder = 4 },
            new() { Id = 116, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Not Selected", DisplayOrder = 5 },
            new() { Id = 117, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Interview Cancelled", DisplayOrder = 6 },
            new() { Id = 118, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Interview Schedule Update", DisplayOrder = 4 },
            new() { Id = 119, TypeId = (long)LookupTypes.NewHireType, Name = "Electronic", DisplayOrder = 1, Code = "Electronic" },
            new() { Id = 120, TypeId = (long)LookupTypes.NewHireType, Name = "Manual", DisplayOrder = 2, Code = "Manual" },
            new() { Id = 121, TypeId = (long)LookupTypes.NewHireType, Name = "Paper Onboarding", DisplayOrder = 3, Code = "Paper Onboarding" },

            new() { Id = 122, TypeId = (long)LookupTypes.VoluntarySelfIdentification, Name = "Yes, I would like to volunteer this information", DisplayOrder = 1 },
            new() { Id = 123, TypeId = (long)LookupTypes.VoluntarySelfIdentification, Name = "No, I would not like to volunteer this information", DisplayOrder = 2 },

            new() { Id = 124, TypeId = (long)LookupTypes.Gender, Name = "Female", DisplayOrder = 1 },
            new() { Id = 125, TypeId = (long)LookupTypes.Gender, Name = "Male", DisplayOrder = 2 },
            new() { Id = 126, TypeId = (long)LookupTypes.Gender, Name = "Non-disclosed", DisplayOrder = 3 },
            new() { Id = 127, TypeId = (long)LookupTypes.Gender, Name = "Other", DisplayOrder = 4 },

            new() { Id = 128, TypeId = (long)LookupTypes.EthnicityRace, Name = "American Indian or Alaska Native (Non-Hispanic or Latino)", DisplayOrder = 1 },
            new() { Id = 129, TypeId = (long)LookupTypes.EthnicityRace, Name = "Asian (Non-Hispanic or Latino)", DisplayOrder = 2 },
            new() { Id = 130, TypeId = (long)LookupTypes.EthnicityRace, Name = "Black or African American (Non-Hispanic or Latino)", DisplayOrder = 3 },
            new() { Id = 131, TypeId = (long)LookupTypes.EthnicityRace, Name = "Hispanic or Latino", DisplayOrder = 4 },
            new() { Id = 132, TypeId = (long)LookupTypes.EthnicityRace, Name = "Native Hawaiian or Other Pacific Islander (Non-Hispanic or Latino)", DisplayOrder = 5 },
            new() { Id = 133, TypeId = (long)LookupTypes.EthnicityRace, Name = "White (Non-Hispanic or Latino)", DisplayOrder = 6 },

            new() { Id = 134, TypeId = (long)LookupTypes.Veteran, Name = "I am a veteran", DisplayOrder = 1 },
            new() { Id = 135, TypeId = (long)LookupTypes.Veteran, Name = "Not a veteran", DisplayOrder = 2 },
            new() { Id = 136, TypeId = (long)LookupTypes.Veteran, Name = "I prefer not to disclose", DisplayOrder = 3 },

            new() { Id = 137, TypeId = (long)LookupTypes.VeteranStatus, Name = "Active Duty Wartime or Campaign Badge Veteran", DisplayOrder = 1 },
            new() { Id = 138, TypeId = (long)LookupTypes.VeteranStatus, Name = "Armed Forces Service Medal Veteran", DisplayOrder = 2 },
            new() { Id = 139, TypeId = (long)LookupTypes.VeteranStatus, Name = "Disabled Veteran", DisplayOrder = 3 },
            new() { Id = 140, TypeId = (long)LookupTypes.VeteranStatus, Name = "Other Veteran", DisplayOrder = 4 },
            new() { Id = 141, TypeId = (long)LookupTypes.VeteranStatus, Name = "Recently Separated Veteran", DisplayOrder = 5 },

            new() { Id = 142, TypeId = (long)LookupTypes.PageName, Name = "Application Forms", DisplayOrder = 1 },
            new() { Id = 143, TypeId = (long)LookupTypes.PageName, Name = "Add Form", DisplayOrder = 2 },
            new() { Id = 144, TypeId = (long)LookupTypes.PageName, Name = "Edit Form", DisplayOrder = 3 },
            new() { Id = 145, TypeId = (long)LookupTypes.PageName, Name = "Job Categories", DisplayOrder = 4 },
            new() { Id = 146, TypeId = (long)LookupTypes.PageName, Name = "Job Posts", DisplayOrder = 5 },

            new() { Id = 147, TypeId = (long)LookupTypes.SectionName, Name = "Add New Field", DisplayOrder = 1 },
            new() { Id = 148, TypeId = (long)LookupTypes.SectionName, Name = "Add Category", DisplayOrder = 2 },
            new() { Id = 149, TypeId = (long)LookupTypes.SectionName, Name = "Edit Category", DisplayOrder = 3 },
            new() { Id = 150, TypeId = (long)LookupTypes.SectionName, Name = "Submitted Jobs", DisplayOrder = 4 },
            new() { Id = 151, TypeId = (long)LookupTypes.SectionName, Name = "Add Job Post", DisplayOrder = 5 },
            new() { Id = 152, TypeId = (long)LookupTypes.SectionName, Name = "Edit Job Post", DisplayOrder = 6 },
            new() { Id = 153, TypeId = (long)LookupTypes.SectionName, Name = "In-Progress", DisplayOrder = 7 },

            new() { Id = 154, TypeId = (long)LookupTypes.QuestionType, Name = "Multiple Choice", DisplayOrder = 1 },
            new() { Id = 155, TypeId = (long)LookupTypes.QuestionType, Name = "True/False", DisplayOrder = 2 },

            new() { Id = 156, TypeId = (long)LookupTypes.TrueFalse, Name = "True", DisplayOrder = 1 },
            new() { Id = 157, TypeId = (long)LookupTypes.TrueFalse, Name = "False", DisplayOrder = 2 },
            new() { Id = 158, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Applicant Offer Accepted Notification To Hiring Manager", DisplayOrder = 8 },
            new() { Id = 159, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Applicant Offer Declined Notification To Hiring Manager", DisplayOrder = 9 },
            new() { Id = 160, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Interviewer feedback Notification To Hiring Manager", DisplayOrder = 10 },
            new() { Id = 161, TypeId = (long)LookupTypes.NotificationTemplateType, Name = "Interview Scheduled Notification To Interviewers", DisplayOrder = 11 },

            new() { Id = 162, TypeId = (long)LookupTypes.PageName, Name = "Add Quiz", DisplayOrder = 6 },
            new() { Id = 163, TypeId = (long)LookupTypes.PageName, Name = "Edit Quiz", DisplayOrder = 7 },

            new() { Id = 164, TypeId = (long)LookupTypes.SectionName, Name = "Add Question", DisplayOrder = 8 },
            new() { Id = 165, TypeId = (long)LookupTypes.SectionName, Name = "Edit Question", DisplayOrder = 9 },

            new() { Id = 166, TypeId = (long)LookupTypes.JobBoard, Name = "Indeed", DisplayOrder = 1 }
         );
    }
}