﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class ApplicationFormFieldAttributeValueConfiguration : IEntityTypeConfiguration<ApplicationFormFieldAttributeValue>
    {
        public void Configure(EntityTypeBuilder<ApplicationFormFieldAttributeValue> builder)
        {
            builder.ToTable(nameof(ApplicationFormFieldAttributeValue));

            builder.HasOne(attributeValue => attributeValue.Attribute)
                    .WithMany()
                    .HasForeignKey(attributeValue => attributeValue.AttributeId)
                    .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(attributeValue => attributeValue.FormField)
                  .WithMany(ff => ff.AttributeValues)
                  .HasForeignKey(attributeValue => attributeValue.FormFieldId)
               .OnDelete(DeleteBehavior.Restrict);

            builder.Property(attributeValue => attributeValue.FormFieldId)
                .IsRequired();

            builder.Property(attributeValue => attributeValue.AttributeId)
                .IsRequired();

            builder.Property(attributeValue => attributeValue.AttributeValue)
                .IsRequired();

            builder.Property(attributeValue => attributeValue.IsDeleted)
                   .IsRequired()
                   .HasDefaultValue(false);
        }
    }
}