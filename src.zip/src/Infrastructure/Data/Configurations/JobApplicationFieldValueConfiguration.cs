﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class JobApplicationFieldValueConfiguration : IEntityTypeConfiguration<JobApplicationFieldValue>
    {
        public void Configure(EntityTypeBuilder<JobApplicationFieldValue> builder)
        {
            builder.ToTable(nameof(JobApplicationFieldValue));

            builder.Property(jobApplicationFieldValue => jobApplicationFieldValue.FormFieldValue)
                   .HasMaxLength(1000);

            builder.Property(jobApplicationFieldValue => jobApplicationFieldValue.JobApplicationId)
                   .IsRequired();

            builder.Property(jobApplicationFieldValue => jobApplicationFieldValue.FormFieldId)
                   .IsRequired();

            builder.HasOne(jobApplicationFieldValue => jobApplicationFieldValue.ApplicationFormField)
                   .WithMany()
                   .HasForeignKey(jobApplicationFieldValue => jobApplicationFieldValue.FormFieldId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(jobApplicationFieldValue => jobApplicationFieldValue.JobApplication)
                   .WithMany(jobApplication => jobApplication.FieldValues)
                   .HasForeignKey(jobApplicationFieldValue => jobApplicationFieldValue.JobApplicationId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}