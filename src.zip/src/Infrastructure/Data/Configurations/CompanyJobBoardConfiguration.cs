﻿using BBSI.ATS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BBSI.ATS.Infrastructure.Data.Configurations
{
    public class CompanyJobBoardConfiguration : IEntityTypeConfiguration<CompanyJobBoard>
    {
        public void Configure(EntityTypeBuilder<CompanyJobBoard> builder)
        {
            builder.ToTable(nameof(CompanyJobBoard));

            builder.Property(jobBoard => jobBoard.CompanyJobBoardId)
                   .IsRequired();

            builder.Property(jobBoard => jobBoard.EmailAddress)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(jobBoard => jobBoard.IsActive)
                   .IsRequired();

            builder.HasOne(jobBoard => jobBoard.Company)
                   .WithMany()
                   .HasForeignKey(jobBoard => jobBoard.CompanyId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(jobBoard => jobBoard.JobBoard)
                   .WithMany()
                   .HasForeignKey(jobBoard => jobBoard.CompanyJobBoardId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
