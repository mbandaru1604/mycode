﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class MetaDataController(IMetaDataService metaDataService) : ControllerBase
{
    private readonly IMetaDataService _metaDataService = metaDataService;

    /// <summary>
    /// Get list of default fields to be displayed when a new application form page is loaded
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("FormDefaultFields")]
    public async Task<ActionResult<IEnumerable<ApplicationFormDefaultFieldDto>>> GetApplicationFormDefaultFields()
    {
        var defaultFields = await _metaDataService.GetApplicationFormDefaultFieldsAsync();
        return OkOrNoContent(defaultFields);
    }

    /// <summary>
    /// Get list of field types for the default fields
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("FormFieldTypes")]
    public async Task<ActionResult<IEnumerable<ApplicationFormFieldTypeDto>>> GetApplicationFormFieldTypes()
    {
        var fieldTypes = await _metaDataService.GetApplicationFormFieldTypesAsync();
        return OkOrNoContent(fieldTypes);
    }

    /// <summary>
    /// Get list of custom field types for the application form
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("FormCustomFieldTypes")]
    public async Task<ActionResult<IEnumerable<ApplicationFormFieldTypeDto>>> GetApplicationFormCustomFieldTypes()
    {
        var fieldTypes = await _metaDataService.GetApplicationFormCustomFieldTypesAsync();
        return OkOrNoContent(fieldTypes);
    }

    /// <summary>
    /// Get list of pay groups
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("PayGroups")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetPayGroups()
    {
        var payGroups = await _metaDataService.GetLookupData(LookupTypes.PayGroup);
        return OkOrNoContent(payGroups);
    }

    /// <summary>
    /// Get list of pay methods
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("PayMethods")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetPayMethods()
    {
        var payMethods = await _metaDataService.GetLookupData(LookupTypes.PayMethod);
        return OkOrNoContent(payMethods);
    }

    /// <summary>
    /// Get list of menu items
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ATSMenu)]
    [HttpGet("MenuItems")]
    public async Task<ActionResult<IEnumerable<MenuItemDto>>> GetMenuItems()
    {
        var menuItems = await _metaDataService.GetMenuItemsAsync();
        return OkOrNoContent(menuItems);
    }

    /// <summary>
    /// Get list of EEO classes
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("EEOClasses")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetEEOClasses()
    {
        var eeoClasses = await _metaDataService.GetLookupData(LookupTypes.EEOClass);
        return OkOrNoContent(eeoClasses);
    }

    /// <summary>
    /// Get list of Employee Types
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("EmployeeTypes")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetEmployeeTypes()
    {
        var employeeTypes = await _metaDataService.GetLookupData(LookupTypes.EmployeeType);
        return OkOrNoContent(employeeTypes);
    }

    /// <summary>
    /// Get list of Work Arrangements
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("WorkArrangements")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetWorkArrangements()
    {
        var workArrangements = await _metaDataService.GetLookupData(LookupTypes.WorkArrangement);
        return OkOrNoContent(workArrangements);
    }

    /// <summary>
    /// Get list of location types
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("LocationTypes")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetLocationTypes()
    {
        var locationTypes = await _metaDataService.GetLookupData(LookupTypes.LocationType);
        return OkOrNoContent(locationTypes);
    }

    /// <summary>
    /// Get list of states
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("States")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetStates()
    {
        var states = await _metaDataService.GetLookupData(LookupTypes.State);
        return OkOrNoContent(states);
    }

    /// <summary>
    /// Get all section names of application form
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("ApplicationFormSections")]
    public async Task<ActionResult<List<ApplicationFormSectionDto>>> GetApplicationFormSections()
    {
        var applicationFormSections = await _metaDataService.GetApplicationFormSections();
        return OkOrNoContent(applicationFormSections);
    }

    /// <summary>
    /// Get list of form field attributes
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("ApplicationFormAttributes")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetApplicationFormAttributes()
    {
        var applicationFormAttributes = await _metaDataService.GetApplicationFormAttributes();
        return OkOrNoContent(applicationFormAttributes);
    }

    /// <summary>
    /// Get look up data of for a lookup type
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("LookupData/{id:long}")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetLookupData(long id)
    {
        var lookupData = await _metaDataService.GetLookupData((LookupTypes)id);
        return OkOrNoContent(lookupData);
    }

    /// <summary>
    /// Get all job application statuses
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("JobApplicationStatus")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetJobApplicationStatuses()
    {
        var lookupData = await _metaDataService.GetJobApplicationStatusesAsync();
        return OkOrNoContent(lookupData);
    }

    /// <summary>
    /// Get list of page names for Audit log level filter
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("PageNames")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetPageNames()
    {
        var lookupData = await _metaDataService.GetLookupData(LookupTypes.PageName);
        return OkOrNoContent(lookupData);
    }

    /// <summary>
    /// Get all section names
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("SectionNames")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetSectionNames()
    {
        var lookupData = await _metaDataService.GetLookupData(LookupTypes.SectionName);
        return OkOrNoContent(lookupData);
    }

    /// <summary>
    /// Get all active users and their role details
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("Roles")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetRoles()
    {
        var roles = await _metaDataService.GetRolesAsync();
        return OkOrNoContent(roles);
    }
}