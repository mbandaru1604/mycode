﻿using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantQuizzesController(IApplicantQuizService applicantQuizService) : ControllerBase
    {
        private readonly IApplicantQuizService _applicantQuizService = applicantQuizService;

        /// <summary>
        /// Get all quizzes
        /// </summary>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ApplicantQuizList)]
        [HttpGet]
        public async Task<ActionResult<List<ApplicantQuizListDto>>> GetAllQuizzes()
        {
            var applicantQuizzes = await _applicantQuizService.GetAllQuizzes();
            return OkOrNoContent(applicantQuizzes);
        }

        /// <summary>
        /// Checks whether a quiz is already exists with the given name for the current company.
        /// </summary>
        /// <param name="name"></param>
        /// <returns>{exists: true/false}</returns>
        [Authorize(Policy = UserPrivileges.AddEditQuiz)]
        [HttpGet("Exists")]
        public async Task<ActionResult<AtsRecordExistsResponse>> ExistsAsync(string name)
        {
            var quizExists = await _applicantQuizService.ExistsAsync(name);
            return OkOrNoContent(new AtsRecordExistsResponse { Exists = quizExists });
        }

        /// <summary>
        /// Add quiz details along with questions and their corresponding answers.
        /// </summary>
        /// <param name="applicantQuizDto"></param>
        /// <remarks>Returns Quiz Id</remarks>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.AddEditQuiz)]
        [HttpPost]
        public async Task<ActionResult<long?>> Create([FromBody] ApplicantQuizDto applicantQuizDto)
        {
            var applicantQuizId = await _applicantQuizService.AddAsync(applicantQuizDto);
            return CreatedOrNoContent(applicantQuizId);
        }

        /// <summary>
        /// Get quiz details for a given Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.AddEditQuiz)]
        [HttpGet("{id:long}")]
        public async Task<ActionResult<ApplicantQuizDto>> GetByIdAsync(long id)
        {
            var applicantQuizzes = await _applicantQuizService.GetDetailsByIdAsync(id);
            return OkOrRecordNotFound(applicantQuizzes);
        }

        /// <summary>
        /// Updates the quiz details including questions and their corresponding answers.
        /// </summary>
        /// <param name="applicantQuizDto"></param>
        /// <returns></returns>
        [HttpPut]
        [Authorize(Policy = UserPrivileges.AddEditQuiz)]
        public async Task<IActionResult> UpdateAsync([FromBody] ApplicantQuizDto applicantQuizDto)
        {
            await _applicantQuizService.UpdateApplicantQuizAsync(applicantQuizDto);
            return Ok();
        }

        /// <summary>
        /// Get list of active quizzes
        /// </summary>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ApplicantQuizList)]
        [HttpGet("QuizzesForJobPost")]
        public async Task<ActionResult<List<NameIdPairDto>>> GetQuizzesForJobPost()
        {
            var applicantQuizzes = await _applicantQuizService.GetQuizzesForJobPost();
            return OkOrNoContent(applicantQuizzes);
        }

        /// <summary>
        /// Get quiz details for a job post
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet("jobpost-quiz/{id}")]
        public async Task<ActionResult<ApplicantQuizDto>> GetByJobPostLinkIdAsync(Guid id)
        {
            var applicantQuizzes = await _applicantQuizService.GetDetailsByJobPostLinkIdAsync(id);
            return OkOrNoContent(applicantQuizzes);
        }

        /// <summary>
        /// Get applicant's quiz result
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ViewQuizResults)]
        [HttpGet("quiz-result/{id}")]
        public async Task<ActionResult<ApplicantQuizResultResponseDto>> GetQuizResultByJobApplicationIdAsync(long id)
        {
            var quizResult = await _applicantQuizService.GetQuizResultByJobApplicationIdAsync(id);
            return OkOrNoContent(quizResult);
        }
    }
}