﻿using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuthController(IAuthenticationService authenticationService) : ControllerBase
{
    /// <summary>
    /// Authenticate user by validating the BBSI Portal token
    /// </summary>
    /// <param name="loginRequestDto"></param>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpPost("sso-login")]
    public async Task<ActionResult<TokenDto>> Login([FromBody] LoginRequestDto loginRequestDto)
    {
        var tokenDto = await authenticationService.Login(loginRequestDto);
        return OkOrNoContent(tokenDto);
    }

    /// <summary>
    /// Switch current user's company
    /// </summary>
    /// <param name="companyCode"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AbilityToSwitchCompanies)]
    [HttpPost("switch-company")]
    public async Task<ActionResult<TokenDto>> SwitchCompany(int companyCode)
    {
        var tokenDto = await authenticationService.SwitchCompany(companyCode);
        return OkOrNoContent(tokenDto);
    }

    /// <summary>
    /// Logout user
    /// </summary>
    /// <returns></returns>
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await authenticationService.Logout();
        return Ok();
    }
}