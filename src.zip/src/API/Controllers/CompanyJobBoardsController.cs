﻿using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CompanyJobBoardsController(ICompanyJobBoardService jobBoardService) : ControllerBase
{
    private readonly ICompanyJobBoardService _jobBoardService = jobBoardService;

    /// <summary>
    /// Add a job board feed
    /// </summary>
    /// <param name="jobBoardDto"></param>
    /// <remarks>Returns Job Board Feed Id</remarks>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AddNewJobFeed)]
    [HttpPost]
    public async Task<ActionResult<long?>> Create([FromBody] CompanyJobBoardDto jobBoardDto)
    {
        var jobBoardId = await _jobBoardService.AddAsync(jobBoardDto);
        return CreatedOrNoContent(jobBoardId);
    }

    /// <summary>
    /// Get all job boards
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.JobFeedListPage)]
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CompanyJobBoardListDto>>> GetAllJobBoards()
    {
        var jobBoards = await _jobBoardService.GetAllJobBoardsAsync();
        return OkOrNoContent(jobBoards);
    }

    /// <summary>
    /// Get job board details by job board record
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpGet("{id:long}")]
    public async Task<ActionResult<CompanyJobBoardDto?>> GetCompanyJobBoardById(long id)
    {
        var jobBoard = await _jobBoardService.GetByJobBoardIdAsync(id);
        return OkOrNoContent(jobBoard);
    }

    /// <summary>
    /// Update a job board
    /// </summary>
    /// <param name="jobBoardDto"></param>
    /// <returns></returns>
    [HttpPut]
    public async Task<IActionResult> Update([FromBody] CompanyJobBoardDto jobBoardDto)
    {
        await _jobBoardService.UpdateJobBoardAsync(jobBoardDto);
        return Ok();
    }
}
