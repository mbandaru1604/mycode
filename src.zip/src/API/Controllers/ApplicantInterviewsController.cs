﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ApplicantInterviewsController(IApplicantInterviewService applicantInterviewService) : ControllerBase
{
    private readonly IApplicantInterviewService _applicantInterviewService = applicantInterviewService;

    /// <summary>
    /// Schedule interview for an applicant
    /// </summary>
    /// <param name="applicantInterviewDTO"></param>
    /// <remarks>Returns Interview Id</remarks>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ScheduleInterview)]
    [HttpPost]
    public async Task<ActionResult<int?>> Create([FromBody] ApplicantInterviewDto applicantInterviewDTO)
    {
        var applicantInterviewId = await _applicantInterviewService.AddAsync(applicantInterviewDTO);
        return CreatedOrNoContent(applicantInterviewId);
    }

    /// <summary>
    /// Get all interviews for an applicant
    /// </summary>
    /// <param name="jobApplicationId"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.InterviewsListPage)]
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ApplicantInterviewListDto>>> GetAllAsync(long jobApplicationId)
    {
        var applicationForm = await _applicantInterviewService.GetListAsync(jobApplicationId);
        return OkOrRecordNotFound(applicationForm);
    }

    /// <summary>
    /// Cancel a scheduled interview for an applicant
    /// </summary>
    /// <param name="applicantInterviewStatusUpdateDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.CancelScheduledInterview)]
    [HttpPut("Cancel")]
    public async Task<IActionResult> CancelAsync([FromBody] ApplicantInterviewNotesDto applicantInterviewStatusUpdateDto)
    {
        var applicantInterviewStatusId = (long)InterviewStatus.InterviewCancelled;
        var jobApplicantInterviewNotes = await _applicantInterviewService.UpdateStatusAsync(applicantInterviewStatusUpdateDto, applicantInterviewStatusId);
        return CreatedOrNoContent(jobApplicantInterviewNotes);
    }

    /// <summary>
    /// Re-schedule applicant interview
    /// </summary>
    /// <param name="applicantInterviewDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditScheduledInterview)]
    [HttpPut()]
    public async Task<IActionResult> UpdateAsync([FromBody] ApplicantInterviewDto applicantInterviewDto)
    {
        await _applicantInterviewService.UpdateApplicantInterviewAsync(applicantInterviewDto);
        return Ok();
    }

    /// <summary>
    /// Get interview details
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditScheduledInterview)]
    [HttpGet("{id:long}")]
    public async Task<ActionResult<ApplicantInterviewDto>> GetById(long id)
    {
        var applicantInterviewDetails = await _applicantInterviewService.GetApplicantInterviewDetailsByIdAsync(id);
        return OkOrRecordNotFound(applicantInterviewDetails);
    }

    /// <summary>
    /// Complete the applicant interview process.
    /// </summary>
    /// <param name="applicantInterviewStatusUpdateDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.InterviewNotesFeedback)]
    [HttpPost("Notes")]
    public async Task<IActionResult> CompleteAsync([FromBody] ApplicantInterviewNotesDto applicantInterviewStatusUpdateDto)
    {
        var applicantInterviewStatusId = (long)InterviewStatus.InterviewCompleted;
        var jobApplicantInterviewNotes = await _applicantInterviewService.UpdateStatusAsync(applicantInterviewStatusUpdateDto, applicantInterviewStatusId);
        return CreatedOrNoContent(jobApplicantInterviewNotes);
    }

    /// <summary>
    /// Update the interview feedback and rating for an interview.
    /// </summary>
    /// <param name="applicantInterviewNoteDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.InterviewEditNotes)]
    [HttpPut("Notes")]
    public async Task<IActionResult> UpdateNoteAsync([FromBody] ApplicantInterviewNotesDto applicantInterviewNoteDto)
    {
        await _applicantInterviewService.UpdateNoteAsync(applicantInterviewNoteDto);
        return Ok();
    }

    /// <summary>
    /// Marks the interview as "No Show" for an interview.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.MarkInterviewAsNoShow)]
    [HttpPost("{id:long}/NoShow")]
    public async Task<IActionResult> NoShowAsync(long id)
    {
        await _applicantInterviewService.UpdateStatusAsync(id, InterviewStatus.InterviewNoShow);
        return Ok();
    }

    /// <summary>
    /// Get email preview content for an email notification type
    /// </summary>
    /// <param name="typeId"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EmailNotificationPreview)]
    [HttpGet("templates/{typeId:long}")]
    public ActionResult<EmailPreviewDto> GetEmailPreviewByType(long typeId)
    {
        var template = _applicantInterviewService.GetEmailPreview(typeId);
        return OkOrRecordNotFound(template);
    }

    /// <summary>
    /// Get the interview schedules for a given date range &amp; status
    /// </summary>
    /// <param name="calendarFilter"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.InterviewCalendar)]
    [HttpPost("scheduled-interviews")]
    public async Task<ActionResult<IEnumerable<InterviewCalendarOverviewDto>>> GetScheduledInterviewsAsync([FromBody] InterviewCalendarFilterDto calendarFilter)
    {
        var scheduledInterviews = await _applicantInterviewService.GetInterviewCalendarOverviewAsync(calendarFilter);
        return OkOrRecordNotFound(scheduledInterviews);
    }

    /// <summary>
    /// Get current user interviews
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.InterviewerInterviews)]
    [HttpGet("current-user-interviews")]
    public async Task<ActionResult<InterviewerInterviewsDto>> GetCurrentUserInterviewsAsync()
    {
        var currentUserInterviews = await _applicantInterviewService.GetCurrentUserInterviewsAsync();
        return OkOrRecordNotFound(currentUserInterviews);
    }
}