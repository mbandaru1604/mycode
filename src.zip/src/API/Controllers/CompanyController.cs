﻿using BBSI.ATS.Common;
using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CompanyController(ICompanyService companyService, CurrentUserContext currentUserContext) : ControllerBase
{
    private readonly ICompanyService _companyService = companyService;

    /// <summary>
    /// Get worksite location details of a specified company
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditScheduledInterview)]
    [Authorize(Policy = UserPrivileges.ScheduleInterview)]
    [HttpGet("WorksiteLocations/{id:long}")]
    public async Task<ActionResult<IEnumerable<WorksiteLocationDto>>> GetWorksiteLocationsByCompanyId(long id)
    {
        var locations = await _companyService.GetWorksiteLocationsByCompanyId(id);
        return OkOrRecordNotFound(locations);
    }

    /// <summary>
    /// Get worksite location details of current company
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditScheduledInterview)]
    [Authorize(Policy = UserPrivileges.ScheduleInterview)]
    [HttpGet("WorksiteLocations")]
    public async Task<ActionResult<IEnumerable<WorksiteLocationDto>>> GetWorksiteLocationsAsync()
    {
        var locations = await _companyService.GetWorksiteLocationsByCompanyId(currentUserContext.CompanyId);
        return OkOrRecordNotFound(locations);
    }
}