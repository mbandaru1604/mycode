﻿using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class JobApplicationNotesController(IJobApplicationNoteService jobApplicationNoteService) : ControllerBase
{
    private readonly IJobApplicationNoteService _jobApplicationNoteService = jobApplicationNoteService;

    /// <summary>
    /// Add applicant interview feedback and rating
    /// </summary>
    /// <param name="jobApplicationNoteDto"></param>
    /// <remarks>Returns Job Application Note Id</remarks>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AddNotes)]
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] JobApplicationNoteDto jobApplicationNoteDto)
    {
        var applicantInterviewId = await _jobApplicationNoteService.AddAsync(jobApplicationNoteDto);
        return CreatedOrNoContent(applicantInterviewId);
    }

    /// <summary>
    /// Get applicant interview feedback details
    /// </summary>
    /// <param name="applicantInterviewId"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.InterviewEditNotes)]
    [HttpGet("InterviewNotes")]
    public async Task<ActionResult<IEnumerable<JobApplicationInterviewNotesListDto>>> GetInterviewNotesAsync(long applicantInterviewId)
    {
        var jobApplicationNotesList = await _jobApplicationNoteService.GetInterviewNotesAsync(applicantInterviewId);
        return OkOrRecordNotFound(jobApplicationNotesList);
    }

    /// <summary>
    /// Get applicant interview feedback details for the note ID provided
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditNotes)]
    [HttpGet("{id:long}")]
    public async Task<IActionResult> GetByIdAsync(long id)
    {
        var jobApplicationNotesList = await _jobApplicationNoteService.GetByIdAsync(id);
        return OkOrRecordNotFound(jobApplicationNotesList);
    }

    /// <summary>
    /// Update applicant feedback/rating details
    /// </summary>
    /// <param name="jobApplicationNoteDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditNotes)]
    [HttpPut]
    public async Task<IActionResult> UpdateAsync([FromBody] JobApplicationNoteDto jobApplicationNoteDto)
    {
        await _jobApplicationNoteService.UpdateAsync(jobApplicationNoteDto);
        return Ok();
    }

    /// <summary>
    /// Get list of feedback details of an applicant
    /// </summary>
    /// <param name="jobApplicationId"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.NotesListPage)]
    [HttpGet]
    public async Task<ActionResult<IEnumerable<JobApplicationNotesListDto>>> GetAllNotesAsync(long jobApplicationId)
    {
        var jobApplicationNotesList = await _jobApplicationNoteService.GetAllNotesAsync(jobApplicationId);
        return OkOrRecordNotFound(jobApplicationNotesList);
    }
}