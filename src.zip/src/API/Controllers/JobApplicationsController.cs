﻿using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobApplicationsController(IJobApplicationService jobApplicationService) : ControllerBase
    {
        private readonly IJobApplicationService _jobApplicationService = jobApplicationService;

        /// <summary>
        /// Apply for a Job
        /// </summary>
        /// <param name="jobApplicationDTO"></param>
        /// <remarks>Return Job Application Id</remarks>
        /// <returns>Returns Job Application Id</returns>
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<long?>> Create([FromBody] JobApplicationDto jobApplicationDTO)
        {
            var jobApplicationId = await _jobApplicationService.AddAsync(jobApplicationDTO);
            return CreatedOrNoContent(jobApplicationId);
        }

        /// <summary>
        /// Get all the Applicants
        /// </summary>
        /// <param name="isActive"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ViewAllJobPosts)]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<JobApplicationListDto>>> GetAllAsync(bool isActive)
        {
            var jobApplications = await _jobApplicationService.GetListAsync(isActive);
            return OkOrRecordNotFound(jobApplications);
        }

        /// <summary>
        /// Add attachment to an Application
        /// </summary>
        /// <param name="attachmentDto"></param>
        /// <remarks>Returns Attachment Id</remarks>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.AddAttachments)]
        [HttpPost("Attachments")]
        public async Task<ActionResult<long?>> AddAttachment(JobApplicationAttachmentDto attachmentDto)
        {
            var attachmentId = await _jobApplicationService.AddAttachment(attachmentDto);
            return CreatedOrNoContent(attachmentId);
        }

        /// <summary>
        /// Get Applicant attachment
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.AttachmentsListPage)]
        [HttpGet("Attachment/{id:long}")]
        public async Task<ActionResult<string?>> GetJobApplicationAttachmentById(long id)
        {
            var attachment = await _jobApplicationService.GetJobApplicationAttachmentByIdAsync(id);
            return OkOrRecordNotFound(attachment);
        }

        /// <summary>
        /// Get preview of applicant attachment
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ViewAttachments)]
        [HttpGet("ApplicationFieldValue/{id:long}")]
        [HttpGet("Attachments/Preview/{id:long}")]
        public async Task<ActionResult<string?>> GetJobApplicationFieldValueByIdAsync(long id)
        {
            var attachment = await _jobApplicationService.GetJobApplicationFieldValueByIdAsync(id);
            return OkOrRecordNotFound(attachment);
        }

        /// <summary>
        /// Get Applicant Details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.CompletedApplication)]
        [HttpGet("{id:long}")]
        public async Task<ActionResult<IEnumerable<JobApplicationDetailsDto>>> GetById(long id)
        {
            var jobApplication = await _jobApplicationService.GetDetailsByIdAsync(id);
            return OkOrRecordNotFound(jobApplication);
        }

        /// <summary>
        /// Get applicant attachment
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ViewAttachments)]
        [HttpGet("{id:long}/Attachments")]
        public async Task<ActionResult<IEnumerable<JobApplicationAttachmentListDto>?>> GetAttachmentByIdAsync(long id)
        {
            var attachments = await _jobApplicationService.GetAttachmentsByIdAsync(id);
            return OkOrRecordNotFound(attachments);
        }

        /// <summary>
        /// Delete applicant attachment
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.DeleteAttachments)]
        [HttpDelete("Attachments/{id:long}")]
        public async Task<ActionResult> DeleteAttachmentByIdAsync(long id)
        {
            await _jobApplicationService.DeleteAttachmentByIdAsync(id);
            return Ok();
        }

        /// <summary>
        /// Download applicant job application as PDF file
        /// </summary>
        /// <param name="id"></param>
        /// <param name="isPreview"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.AbilityToDownloadApplication)]
        [HttpGet("{id:long}/Download")]
        public async Task<IActionResult> DownloadApplication(long id, bool isPreview = false)
        {
            var jobApplicationDto = await _jobApplicationService.GetDetailsForDownloadByIdAsync(id);
            var pdfContent = await _jobApplicationService.DownloadJobApplication(jobApplicationDto);
            if (isPreview)
                return OkOrRecordNotFound(Convert.ToBase64String(pdfContent));
            return File(pdfContent, "application/pdf", $"{jobApplicationDto.DownloadFileName}.pdf");
        }

        /// <summary>
        /// Update applicant job application status
        /// </summary>
        /// <param name="jobApplicationManualStatusUpdateDto"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ManualChangeStatus)]
        [HttpPut("UpdateStatus")]
        public async Task<IActionResult> UpdateStatusAsync(JobApplicationManualStatusUpdateDto jobApplicationManualStatusUpdateDto)
        {
            await _jobApplicationService.UpdateStatusAsync(jobApplicationManualStatusUpdateDto);
            return Ok();
        }

        /// <summary>
        /// Update applicant job application status to "Accepted" when offer is Accepted (link from Email)
        /// </summary>
        /// <param name="offerToken"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPut("Offer/{offerToken}/Accept")]
        public async Task<ActionResult<object>> AcceptOffer(string offerToken)
        {
            var response = await _jobApplicationService.OfferStatusUpdateAsync(offerToken, true);
            return new { Response = response };
        }

        /// <summary>
        /// Update applicant job application status to "Declined" when offer is Declined (link from Email)
        /// </summary>
        /// <param name="offerToken"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPut("Offer/{offerToken}/Decline")]
        public async Task<ActionResult<object>> DeclineOffer(string offerToken)
        {
            var response = await _jobApplicationService.OfferStatusUpdateAsync(offerToken, false);
            return new { Response = response };
        }

        /// <summary>
        /// Get email preview content for offer extended email notification
        /// </summary>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.OfferExtendedEmailNotificationOptiontoSend)]
        [HttpGet("Preview/OfferExtendedEmail")]
        public EmailPreviewDto PreviewOfOfferExtended()
        {
            return _jobApplicationService.PreviewMessageForOfferExtendedEmail();
        }

        /// <summary>
        /// Get applicant application status bar for UI
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ManualChangeStatus)]
        [HttpGet("{id:long}/ProgressBarStatusList")]
        public async Task<ActionResult<IEnumerable<ApplicantStatusProgressBarDto>>> GetProgressBarStatusListAsync(long id)
        {
            var jobApplication = await _jobApplicationService.GetProgressBarStatusListAsync(id);
            return OkOrRecordNotFound(jobApplication);
        }

        /// <summary>
        /// Dashboard - Offers with respective status (Accepted/Offer Declined/Offer Extended etc.)
        /// location(s) &amp; category
        /// </summary>
        /// <param name="widgetFilterCriteriaDto"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.OfferStatusOverview)]
        [HttpPost("offer-status-count")]
        public async Task<ActionResult<OfferStatusCountDto>> GetOfferStatusCount([FromBody] WidgetFilterCriteriaDto widgetFilterCriteriaDto)
        {
            var offerStatus = await _jobApplicationService.GetOfferStatusCountAsync(widgetFilterCriteriaDto);
            return OkOrNoContent(offerStatus);
        }

        /// <summary>
        /// Dashboard - Get all applications count by application status
        /// Applied, Interview Scheduled, Offer Extended, Offer Accepted, On Boarding &amp; Hired
        /// </summary>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.ApplicantStatusOverview)]
        [HttpGet("count-by-status")]
        public async Task<ActionResult<List<NameCountPairDto>>> GetCountByStatus()
        {
            var statusesCount = await _jobApplicationService.GetCountByStatus();
            return OkOrRecordNotFound(statusesCount);
        }

        /// <summary>
        /// Dashboard - Get all active jobs &amp; status Applied, Offer Extended &amp; Hired applications for the past 12 months
        /// </summary>
        /// <param name="widgetFilterCriteriaDto"></param>
        /// <returns></returns>
        [Authorize(Policy = UserPrivileges.MonthlyJobTrend)]
        [HttpPost("monthly-job-trend-analysis")]
        public async Task<ActionResult<List<MonthlyJobTrendAnalysisDto>>> GetMonthlyJobTrendAnalysis(JobTrendFilterCriteriaDto widgetFilterCriteriaDto)
        {
            var monthlyTrendAnalysis = await _jobApplicationService.GetMonthlyJobTrendAnalysis(widgetFilterCriteriaDto);
            return OkOrNoContent(monthlyTrendAnalysis);
        }
    }
}