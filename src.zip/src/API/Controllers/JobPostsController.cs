﻿using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class JobPostsController(IJobPostService jobPostService) : ControllerBase
{
    private readonly IJobPostService _service = jobPostService;

    /// <summary>
    /// Add a new Job Post
    /// </summary>
    /// <param name="jobPostDto"></param>
    /// <remarks>Returns Job Post Id</remarks>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AddJobPost)]
    [HttpPost]
    public async Task<ActionResult<long?>> Create([FromBody] JobPostDto jobPostDto)
    {
        var jobPostId = await _service.AddAsync(jobPostDto);
        return CreatedOrNoContent(jobPostId);
    }

    /// <summary>
    /// Get job post details
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditJobPost)]
    [HttpGet("{id:long}")]
    public async Task<ActionResult<JobPostDto>> GetById(long id)
    {
        var jobPost = await _service.GetByIdAsync(id);
        return OkOrRecordNotFound(jobPost);
    }

    /// <summary>
    /// Get list of job posts based on the submission status
    /// </summary>
    /// <param name="isSubmitted"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.JobPostsListPage)]
    [HttpGet]
    public async Task<ActionResult<IEnumerable<JobPostListDto>>> GetList(bool isSubmitted)
    {
        var applicationForm = await _service.GetList(isSubmitted);
        return OkOrRecordNotFound(applicationForm);
    }

    /// <summary>
    /// Updates an existing job post based on the provided data.
    /// </summary>
    /// <param name="jobPostDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditJobPost)]
    [HttpPut()]
    public async Task<IActionResult> Update([FromBody] JobPostDto jobPostDto)
    {
        await _service.JobPostUpdateAsync(jobPostDto);
        return Ok();
    }

    /// <summary>
    ///  Get list of active job posts
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.JobPostsListPage)]
    [HttpGet("get-active-jobposts")]
    public async Task<ActionResult<IEnumerable<NameIdPairDto>>> GetActiveJobPosts()
    {
        var activeJobPosts = await _service.GetActiveJobPosts();
        return OkOrNoContent(activeJobPosts);
    }

    /// <summary>
    /// Get preview of a job post
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.JobPostPreview)]
    [HttpGet("Preview/{id:long}")]
    public async Task<ActionResult<JobPostPreviewDto>> GetJobPostPreviewById(long id)
    {
        var jobPost = await _service.GetJobPostPreviewById(id);

        return OkOrRecordNotFound(jobPost);
    }

    /// <summary>
    ///  Get Job Post by Link
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("Link/{id:Guid}")]
    public async Task<ActionResult<JobPostPreviewDto>> GetByLinkIdAsync(Guid id)
    {
        var jobPost = await _service.GetByLinkIdAsync(id);

        return OkOrRecordNotFound(jobPost);
    }

    /// <summary>
    /// Get all job posts of a company
    /// </summary>
    /// <param name="identifier"></param>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("company/{identifier:Guid}")]
    public async Task<ActionResult<CompanyJobPostsDto>> GetByCompanyIdentifierAsync(Guid identifier)
    {
        var jobPosts = await _service.GetByCompanyIdentifierAsync(identifier);

        return OkOrRecordNotFound(jobPosts);
    }

    /// <summary>
    /// Get all job posts of a company in XML format to publish in Indeed
    /// </summary>
    /// <param name="identifier"></param>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("company/{identifier:Guid}/indeed")]
    public async Task<IActionResult> GetByCompanyIdentifierForIndeedAsync(Guid identifier)
    {
        var jobPostsXml = await _service.GetActiveJobPostsByCompanyForIndeedAsync(identifier);
        return Content(jobPostsXml, "application/xml", Encoding.UTF8);
    }

    /// <summary>
    /// Get application form details of a job post by Link Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("{id:Guid}/ApplicationForm")]
    public async Task<ActionResult<ApplicationFormDto>> GetActiveFieldsById(Guid id)
    {
        var applicationForm = await _service.GetApplicationFormByJobPostLinkIdAsync(id);
        return OkOrRecordNotFound(applicationForm);
    }

    /// <summary>
    /// Get location specific list of active job posts
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ActiveJobsByLocation)]
    [HttpGet("active-job-posts-by-location")]
    public async Task<ActionResult<List<NameCountPairDto>>> GetActiveJobPostsByLocationAsync()
    {
        var applicationForm = await _service.GetActiveJobPostsByLocationAsync();
        return OkOrRecordNotFound(applicationForm);
    }

    /// <summary>
    /// Get count of active job posts of current company
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ApplicantStatusOverview)]
    [HttpGet("active-job-posts-count")]
    public async Task<ActionResult> GetActiveJobPostsCountAsync()
    {
        var JobPostCount = await _service.GetActiveJobPostsCountAsync();
        return Ok(new { Count = JobPostCount });
    }

    /// <summary>
    /// Get list of locations for all submitted job posts
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.MonthlyJobTrend)]
    [HttpGet("locations-for-all-jobs")]
    public async Task<ActionResult<IEnumerable<string>>> GetLocationsForAllSubmittedJobsAsync()
    {
        var locations = await _service.GetLocationsForAllSubmittedJobsAsync();
        return OkOrNoContent(locations);
    }

    /// <summary>
    /// Deletion of a particular job post
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpDelete("{id:long}")]
    public async Task<IActionResult> Delete(long id)
    {
        await _service.DeleteJobPostAsync(id);
        return Ok();
    }
}