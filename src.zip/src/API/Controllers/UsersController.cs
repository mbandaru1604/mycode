﻿using BBSI.ATS.DTO;
using BBSI.ATS.DTO.RolePrivilege;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class UsersController(IUserService userService) : ControllerBase
{
    private readonly IUserService _userService = userService;

    /// <summary>
    /// Get list of active Hiring Managers
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AddJobPost)]
    [HttpGet("HiringManagers")]
    public async Task<ActionResult<List<UserDto>>> GetHiringManagers()
    {
        var hiringManagers = await _userService.GetHiringManagers();
        return OkOrNoContent(hiringManagers);
    }

    /// <summary>
    /// Get active interviewers
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ScheduleInterview)]
    [Authorize(Policy = UserPrivileges.EditScheduledInterview)]
    [HttpGet("Interviewers")]
    public async Task<ActionResult<List<UserDto>>> GetInterviewers()
    {
        var hiringManagers = await _userService.GetInterviewers();
        return OkOrNoContent(hiringManagers);
    }

    /// <summary>
    /// Get list of users with their email id
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ViewAuditLog)]
    [HttpGet("UserEmails")]
    public async Task<ActionResult<List<NameIdPairDto>>> GetUserEmails()
    {
        var users = await _userService.GetUserEmails();
        return OkOrNoContent(users);
    }

    /// <summary>
    /// Get current user details along with privileges and list of companies he belongs to
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.UserProfile)]
    [HttpGet("profile")]
    public async Task<ActionResult<UserProfileDto>> GetUserProfileAsync()
    {
        var userProfileDto = await _userService.GetUserProfileAsync();
        return OkOrRecordNotFound(userProfileDto);
    }
}