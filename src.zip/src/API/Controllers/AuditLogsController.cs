﻿using BBSI.ATS.Common;
using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuditLogsController(IAuditLogService auditLogService, CurrentUserContext currentUserContext) : ControllerBase
{
    private readonly IAuditLogService _auditLogService = auditLogService;

    /// <summary>
    /// Get list of audit logs for the given date range, search term, pages/sections &amp; modified by users
    /// </summary>
    /// <param name="auditLogRequestDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ViewAuditLog)]
    [HttpGet]
    public async Task<ActionResult<PaginatedAuditLogDto>> GetListAsync([FromQuery] AuditLogRequestDto auditLogRequestDto)
    {
        var auditLogs = await _auditLogService.GetListAsync(auditLogRequestDto);
        return OkOrNoContent(auditLogs);
    }

    /// <summary>
    /// Export audit log list to CSV file
    /// </summary>
    /// <param name="auditLogRequestDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ExportToCSV)]
    [HttpGet("ExportToCsv")]
    public async Task<ActionResult> GetListExportToCsv([FromQuery] AuditLogRequestDto auditLogRequestDto)
    {
        var auditLogsCsvBytes = await _auditLogService.GetListExportToCsvAsync(auditLogRequestDto);
        if (auditLogsCsvBytes != null && auditLogsCsvBytes.Length > 0)
        {
            var companyCode = currentUserContext.CompanyCode;
            return File(auditLogsCsvBytes, "text/csv", companyCode + "_Audit Log.csv");
        }
        return NoContent();
    }
}