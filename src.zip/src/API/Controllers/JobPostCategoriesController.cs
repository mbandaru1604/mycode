﻿using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class JobPostCategoriesController(IJobPostCategoryService jobPostCategoryService) : ControllerBase
{
    private readonly IJobPostCategoryService _service = jobPostCategoryService;

    /// <summary>
    /// Add a job post category
    /// </summary>
    /// <param name="jobpostCategoryDTO"></param>
    /// <remarks>Returns Job Post Category Id</remarks>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AddCategory)]
    [HttpPost]
    public async Task<ActionResult<long?>> Create([FromBody] JobPostCategoryDto jobpostCategoryDTO)
    {
        var id = await _service.AddAsync(jobpostCategoryDTO);
        return CreatedOrNoContent(id);
    }

    /// <summary>
    /// Delete a job post category
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.DeleteCategory)]
    [HttpDelete("{id:long}")]
    public async Task<ActionResult<long?>> Delete(long id)
    {
        await _service.DeleteJobPostCategoryAsync(id);
        return Ok();
    }

    /// <summary>
    /// Get job post category details of a category
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditCategory)]
    [HttpGet("{id:long}")]
    public async Task<ActionResult<JobPostCategoryDto?>> GetJobPostCategoryById(long id)
    {
        var result = await _service.GetByJobPostCategoryIdAsync(id);
        return OkOrNoContent(result);
    }

    /// <summary>
    /// Get all job post categories of current company
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.JobCategoryListPage)]
    [HttpGet()]
    public async Task<ActionResult<List<JobPostCategoryListDto>>> GetJobPostCategories()
    {
        var jobPostCategories = await _service.GetJobCategoriesAsync();
        return OkOrNoContent(jobPostCategories);
    }

    /// <summary>
    /// Get all active job post categories of current company
    /// </summary>
    /// <returns></returns>
    [HttpGet("get-active-categories")]
    public async Task<ActionResult<IEnumerable<NameIdPairDto>>> GetActiveJobCategories()
    {
        var jobPostCategories = await _service.GetActiveCategories();
        return OkOrNoContent(jobPostCategories);
    }

    /// <summary>
    /// Update a job post category
    /// </summary>
    /// <param name="categoryDTO"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditCategory)]
    [HttpPut()]
    public async Task<IActionResult> Update([FromBody] JobPostCategoryDto categoryDTO)
    {
        await _service.UpdateJobPostCategoryAsync(categoryDTO);
        return Ok();
    }
}