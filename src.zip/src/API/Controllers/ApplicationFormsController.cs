﻿using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.DTO;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static BBSI.ATS.API.Utilities.ResponseUtil;

namespace BBSI.ATS.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ApplicationFormsController(IApplicationFormService formService) : ControllerBase
{
    private readonly IApplicationFormService _service = formService;

    /// <summary>
    /// Create an application form by setting the default fields, custom fields. Use MetaData related API endpoints to form the input request data.
    /// </summary>
    /// <param name="formDTO"></param>
    /// <remarks>Returns Application Form Id</remarks>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AddForm)]
    [HttpPost]
    public async Task<ActionResult<long?>> Create([FromBody] ApplicationFormDto formDTO)
    {
        var id = await _service.AddAsync(formDTO);
        return CreatedOrNoContent(id);
    }

    /// <summary>
    /// Check whether the given application form name already exist with the current company
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.AddForm)]
    [HttpGet("Exists")]
    public async Task<ActionResult<AtsRecordExistsResponse>> Exists(string name)
    {
        var formExists = await _service.ExistsAsync(name);
        return OkOrNoContent(new AtsRecordExistsResponse { Exists = formExists });
    }

    /// <summary>
    /// Get application form details by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditForm)]
    [HttpGet("{id:long}")]
    public async Task<ActionResult<ApplicationFormDto>> GetById(long id)
    {
        var applicationForm = await _service.GetByIdAsync(id);
        return OkOrRecordNotFound(applicationForm);
    }

    /// <summary>
    /// Get list of application forms for the current company
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ApplicationFormsListPage)]
    [HttpGet]
    public async Task<ActionResult<List<ApplicationFormListDto>>> GetAllForms()
    {
        var applicationForms = await _service.GetAllForms();
        return OkOrNoContent(applicationForms);
    }

    /// <summary>
    /// Get list of active job posts of given application form
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.ApplicationFormsListPage)]
    [HttpGet("{id:long}/JobPost")]
    public async Task<ActionResult<List<JobPostListDto>>> GetJobPostsById(long id)
    {
        var jobPostList = await _service.GetJobPostsByIdAsync(id);
        return OkOrNoContent(jobPostList);
    }

    /// <summary>
    /// Update application form details
    /// </summary>
    /// <param name="formDto"></param>
    /// <returns></returns>
    [Authorize(Policy = UserPrivileges.EditForm)]
    [HttpPut()]
    public async Task<IActionResult> Update([FromBody] ApplicationFormDto formDto)
    {
        await _service.UpdateFormAsync(formDto);
        return Ok();
    }
}