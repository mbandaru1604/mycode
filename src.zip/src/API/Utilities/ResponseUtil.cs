﻿using BBSI.ATS.API.ResponseModels;
using BBSI.ATS.Common;
using Microsoft.AspNetCore.Mvc;

namespace BBSI.ATS.API.Utilities;

public static class ResponseUtil
{
    public static ActionResult OkOrNoContent(object? result)
    {
        return result == null ? new NoContentResult() : new OkObjectResult(result);
    }

    public static ActionResult OkOrRecordNotFound(object? result)
    {
        return result == null ? new BadRequestObjectResult(ErrorMessages.InvalidRecordId) : new OkObjectResult(result);
    }

    public static ActionResult CreatedOrNoContent(object? value)
    {
        return value == null ? new NoContentResult() : new OkObjectResult(new CreatedResponse { Id = (long)value });
    }
}