﻿global using static BBSI.ATS.Common.ErrorMessages;
global using static BBSI.ATS.Common.Helpers.UtilityHelper;
global using static BBSI.ATS.Common.Constants;