﻿using BBSI.ATS.Infrastructure.Data.Persistence;
using Microsoft.AspNetCore.Authorization;
using System.Diagnostics.CodeAnalysis;

namespace BBSI.ATS.API.Middleware.Authorization;

[ExcludeFromCodeCoverage(Justification = "Not required unit tests for Policy Provider")]
public class AuthorizationPolicyProvider(AtsDbContext dbContext)
{
    private readonly AtsDbContext _dbContext = dbContext;
    public void AddPolicies(AuthorizationOptions options)
    {
        var privileges = _dbContext.Privileges.ToList();

        foreach (var privilege in privileges)
        {
            options.AddPolicy(privilege.Name!, policy =>
                    policy.Requirements.Add(new PrivilegeRequirement(privilege.Id)));
        }
    }
}
