﻿using BBSI.ATS.Common;
using BBSI.ATS.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using System.Diagnostics.CodeAnalysis;

namespace BBSI.ATS.API.Middleware.Authorization;

[ExcludeFromCodeCoverage(Justification = "Not required unit tests for Handlers")]
public class PrivilegeHandler(IRolePrivilegeService rolePrivilegeService, CurrentUserContext currentUserContext) : AuthorizationHandler<PrivilegeRequirement>
{
    protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, PrivilegeRequirement requirement)
    {
        if (await rolePrivilegeService.HasRolePrivilegeAsync(currentUserContext.RoleIds!, requirement.PrivilegeId))
        {
            context.Succeed(requirement);
        }
        else
        {
            context.Fail();
        }
    }
}