﻿using Microsoft.AspNetCore.Authorization;
using System.Diagnostics.CodeAnalysis;

namespace BBSI.ATS.API.Middleware.Authorization;

[ExcludeFromCodeCoverage(Justification ="Not required as this is the definition for the policy requirement")]
public class PrivilegeRequirement : IAuthorizationRequirement
{
    public long PrivilegeId { get; }

    public PrivilegeRequirement(long privilegeId)
    {
        PrivilegeId = privilegeId;
    }
}