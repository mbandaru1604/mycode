﻿using BBSI.ATS.Common;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.Common.Extensions;
using BBSI.ATS.Common.Helpers;
using BBSI.ESB.Models.Exceptions;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;
using System.Net;

namespace BBSI.ATS.API.Middleware.ExceptionHandler;

[ExcludeFromCodeCoverage]
public class AtsGlobalExceptionHandler(ILogger<AtsGlobalExceptionHandler> logger) : IExceptionHandler
{
    private readonly ILogger<AtsGlobalExceptionHandler> _logger = logger;

    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        _logger.LogException(exception, $"An error occurred while processing your request: {exception.Message}");

        AtsProblemDetails atsProblemDetails = exception switch
        {
            AtsException => CreateProblemDetails(httpContext, (AtsException)exception),
            BadHttpRequestException or ValidationException => new()
            {
                Detail = exception.Message,
                ErrorCode = ErrorCodes.BadRequest,
                Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1",
                Status = (int)HttpStatusCode.BadRequest,
                Title = exception.GetType().Name,
                //ErrorStackTrace = Newtonsoft.Json.JsonConvert.SerializeObject(exception)
            },
            UnauthorizedException => new()
            {
                Detail = exception.Message,
                ErrorCode = ErrorCodes.Unauthorized,
                Type = "https://datatracker.ietf.org/doc/html/rfc7235#section-3.1",
                Status = (int)HttpStatusCode.Unauthorized,
                Title = exception.GetType().Name,
                //ErrorStackTrace = Newtonsoft.Json.JsonConvert.SerializeObject(exception)
            },
            DbUpdateConcurrencyException => new()
            {
                Detail = ConflictMessage,
                ErrorCode = ErrorCodes.ConflictError,
                Type = "https://datatracker.ietf.org/doc/html/rfc7235#section-3.1",
                Status = (int)HttpStatusCode.Conflict,
                Title = "Conflict",
                //ErrorStackTrace = Newtonsoft.Json.JsonConvert.SerializeObject(exception)
            },
            EnterpriseBusException => new()
            {
                Detail = UnhandledException,
                ErrorCode = ErrorCodes.InternalServerError,
                Type = "https://datatracker.ietf.org/doc/html/rfc7235#section-3.1",
                Status = (int)HttpStatusCode.InternalServerError,
                Title = InternalServerError,
                //ErrorStackTrace = Newtonsoft.Json.JsonConvert.SerializeObject(exception)
            },
            _ => new()
            {
                Detail = exception.Message,
                ErrorCode = ErrorCodes.InternalServerError,
                Type = "https://datatracker.ietf.org/doc/html/rfc7231#section-6.6.1",
                Status = (int)HttpStatusCode.InternalServerError,
                Title = InternalServerError,
                //ErrorStackTrace = Newtonsoft.Json.JsonConvert.SerializeObject(exception)
            },
        };

        httpContext.Response.StatusCode = atsProblemDetails.Status ?? (int)HttpStatusCode.InternalServerError;

        await httpContext
             .Response
             .WriteAsJsonAsync(atsProblemDetails, cancellationToken);

        return true;
    }

    private static AtsProblemDetails CreateProblemDetails(HttpContext context, AtsException exception)
    {
        var errorCode = exception.ErrorCode;
        var statusCode = context.Response.StatusCode;
        var reasonPhrase = ReasonPhrases.GetReasonPhrase(statusCode);
        if (string.IsNullOrWhiteSpace(reasonPhrase))
        {
            reasonPhrase = ErrorMessages.UnhandledException;
        }

        var atsProbelmDetails = new AtsProblemDetails
        {
            Status = statusCode,
            Title = reasonPhrase,
            Extensions =
            {
                [nameof(errorCode)] = errorCode
            },
            ErrorCode = exception.ErrorCode,
            Detail = exception.Message
        };
        atsProbelmDetails.Extensions["traceId"] = context.TraceIdentifier;
        atsProbelmDetails.Extensions["data"] = exception.Data;

        return atsProbelmDetails;
    }
}