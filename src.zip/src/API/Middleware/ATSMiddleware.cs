﻿using BBSI.ATS.API.Extensions;
using BBSI.ATS.Common;
using BBSI.ATS.Infrastructure.Integrations.Interfaces;
using System.Diagnostics.CodeAnalysis;

namespace BBSI.ATS.API.Middleware;

[ExcludeFromCodeCoverage]
public class AtsMiddleware(RequestDelegate next, IRedisCacheProvider redisCacheProvider)
{
    private readonly RequestDelegate _next = next;
    private readonly IRedisCacheProvider _redisCacheProvider = redisCacheProvider;

    public async Task Invoke(HttpContext httpContext, CurrentUserContext currentUserContext)
    {
        var endpoint = httpContext.GetEndpoint();

        if (endpoint == null)
        {
            httpContext.Response.StatusCode = StatusCodes.Status404NotFound;
            return;
        }

        if (endpoint.Metadata.GetMetadata<Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute>() != null)
        {
            await _next(httpContext);
            return;
        }

        if (!httpContext.User.Identity?.IsAuthenticated ?? true)
        {
            httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return;
        }

        currentUserContext.PopulateFromHttpContext(httpContext);

        if (currentUserContext.UserId > 0)
        {
            var isTokenIdValid = true;

            if (string.IsNullOrEmpty(currentUserContext.TokenId))
            {
                isTokenIdValid = false;
            }
            else
            {
                var cachedUserId = await _redisCacheProvider.GetStringAsync(currentUserContext.TokenId);
                if (string.IsNullOrEmpty(cachedUserId) || !cachedUserId.Equals(currentUserContext.UserId.ToString(),
                                                                 StringComparison.OrdinalIgnoreCase))
                    isTokenIdValid = false;
            }

            if (!isTokenIdValid)
            {
                httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return;
            }
        }

        AddResponseSecurityHeaders(httpContext);

        await _next(httpContext);
    }

    private static void AddResponseSecurityHeaders(HttpContext httpContext)
    {
        var headers = httpContext.Response.Headers;

        //This header helps prevent a variety of attacks, such as Cross-Site Scripting (XSS) and other cross-site injections.
        headers.Append("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'self'; object-src 'none';");

        //Setting this to nosniff prevents browsers from interpreting files as a different MIME type,
        //which can help mitigate attacks based on MIME type confusion.
        headers.Append("X-Content-Type-Options", "nosniff");

        //This header prevents clickjacking attacks by disallowing the site to be framed. Options include DENY or SAMEORIGIN
        //to ensure that the site can only be displayed in a frame if it's from the same origin.
        headers.Append("X-Frame-Options", "DENY");

        // This header ensures that the browser only communicates with the server over HTTPS,
        // preventing man-in-the-middle attacks.
        headers.Append("Strict-Transport-Security", "max-age=31536000; includeSubDomains");

        //This controls how much referrer information is shared when navigating from your site to another.
        headers.Append("Referrer-Policy", "strict-origin-when-cross-origin");

        //This controls what web platform features can be used in the browser, such as geolocation, camera, microphone, etc.
        headers.Append("Permissions-Policy", "geolocation=(self), camera=(), microphone=()");

        //These headers will ensure that the responses are not cached by the browser or any intermediate caches,
        //thereby protecting any sensitive data from being stored
        headers.Append("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
        headers.Append("Pragma", "no-cache");
        headers.Append("Expires", "0");
    }
}