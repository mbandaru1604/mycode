﻿using BBSI.ATS.DTO;
using FluentValidation;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.API.Validators
{
    public class ApplicantInterviewNotesDtoValidator : AbstractValidator<ApplicantInterviewNotesDto>
    {
        public ApplicantInterviewNotesDtoValidator()
        {
            RuleFor(applicantInterview => applicantInterview.Note)
               .NotEmpty().WithMessage(ApplicantInterviewValidation.NoteRequried)
               .NotNull().WithMessage(ApplicantInterviewValidation.NoteRequried)
               .MaximumLength(ApplicantInterviewValidation.NotesMaxLength).WithMessage(ApplicantInterviewValidation.NotesMaxLengthExceededMessage);
        }
    }
}