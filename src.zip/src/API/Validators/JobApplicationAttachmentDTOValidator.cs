﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class JobApplicationAttachmentDtoValidator : AbstractValidator<JobApplicationAttachmentDto>
{
    public JobApplicationAttachmentDtoValidator()
    {
        RuleFor(attachment => attachment.Name)
             .NotEmpty().WithMessage(JobApplicationAttachmentValidation.FileNameRequired)
             .MaximumLength(JobApplicationAttachmentValidation.FileNameMaxLength)
             .WithMessage(JobApplicationAttachmentValidation.FileNameMaxLengthExceeded);

        RuleFor(attachment => attachment.File)
             .NotNull().WithMessage(JobApplicationAttachmentValidation.AttachmentRequired);

        When(attachment => attachment.File != null, () =>
        {
            RuleFor(attachment => attachment.File!.Length)
                 .LessThanOrEqualTo(JobApplicationAttachmentValidation.MaxFileSizeInBytes)
                 .WithMessage(JobApplicationAttachmentValidation.FileMaxLengthExceeded);

            RuleFor(attachment => attachment.File!.FileName)
                 .Must(HasValidExtension)
                 .WithMessage(JobApplicationAttachmentValidation.UploadValidFile);
        });

        RuleFor(attachment => attachment.TypeId)
             .NotEmpty().WithMessage(JobApplicationAttachmentValidation.FileTypeRequired);

        RuleFor(attachment => attachment.JobApplicationId)
             .NotEmpty().WithMessage(JobApplicationAttachmentValidation.JobApplicationRequired);
    }

    private static bool HasValidExtension(string fileName)
    {
        var extension = Path.GetExtension(fileName).TrimStart('.').ToLowerInvariant();
        return JobApplicationAttachmentValidation.PermittedExtensions.Any(fileExtension => fileExtension == extension);
    }
}