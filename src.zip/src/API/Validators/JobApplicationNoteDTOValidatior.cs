﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class JobApplicationNoteDtoValidatior : AbstractValidator<JobApplicationNoteDto>
{
    public JobApplicationNoteDtoValidatior()
    {
        RuleFor(jobApplicationNote => jobApplicationNote.JobApplicationId)
                .NotNull().WithMessage(ApplicantInterviewValidation.JobApplicationIdRequired);

        RuleFor(jobApplicationNote => jobApplicationNote.Note)
                .NotEmpty().WithMessage(JobApplicationNoteValidation.NoteRequried)
                .NotNull().WithMessage(JobApplicationNoteValidation.NoteRequried)
                .MaximumLength(JobApplicationNoteValidation.NotesMaxLength).WithMessage(JobApplicationNoteValidation.NotesMaxLengthExceededMessage);

        When(jobApplicationNote => jobApplicationNote.ApplicantInterviewId.HasValue, () =>
        {
            RuleFor(jobApplicationNote => jobApplicationNote.Rating)
                .NotNull().WithMessage(JobApplicationNoteValidation.RatingRequried);
        });
    }
}