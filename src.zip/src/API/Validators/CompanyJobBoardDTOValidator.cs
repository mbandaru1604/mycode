﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators
{
    public class CompanyJobBoardDtoValidator : AbstractValidator<CompanyJobBoardDto>
    {
        public CompanyJobBoardDtoValidator()
        {
            RuleFor(jobBoard => jobBoard.CompanyJobBoardId)
               .NotEmpty().WithMessage(CompanyJobBoardValidation.CompanyJobBoardRequired);

            RuleFor(jobBoard => jobBoard.EmailAddress)
                .NotEmpty().WithMessage(CompanyJobBoardValidation.EmailAddressRequired)
                .Must(email => email != null && IsValidEmail(email!.Trim()))
                .WithMessage(CompanyJobBoardValidation.EmailInvalid);
        }
    }
}
