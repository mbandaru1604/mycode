﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class JobPostCategoryDtoValidator : AbstractValidator<JobPostCategoryDto>
{
    public JobPostCategoryDtoValidator()
    {
        RuleFor(category => category.Name)
           .NotEmpty().WithMessage(JobPostCategoryValidation.NameIsRequired)
           .MaximumLength(JobPostCategoryValidation.NameMaxLength).WithMessage(JobPostCategoryValidation.NameMaxLengthExceededMessage);
    }
}
