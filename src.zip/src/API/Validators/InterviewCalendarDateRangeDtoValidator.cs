﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators
{
    public class InterviewCalendarDateRangeDtoValidator : AbstractValidator<InterviewCalendarFilterDto>
    {
        public InterviewCalendarDateRangeDtoValidator()
        {
            RuleFor(CalendarOverviewDateRange => CalendarOverviewDateRange.ToDate)
                .GreaterThanOrEqualTo(CalendarOverviewDateRange => CalendarOverviewDateRange.FromDate)
                .WithMessage(InterviewCalendarDateRangeValidation.ToDateEarlierThanFromDate);
        }
    }
}

