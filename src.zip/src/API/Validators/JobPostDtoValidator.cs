﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.API.Validators;

public class JobPostDtoValidator : AbstractValidator<JobPostDto>
{
    public JobPostDtoValidator()
    {
        RuleFor(jobPost => jobPost.Title)
                .NotEmpty().WithMessage(JobPostValidation.TitleRequired)
                .MaximumLength(JobPostValidation.TitleMaxLength)
                .WithMessage(JobPostValidation.TitleMaxLengthExceededMessage);

        When(jobPost => jobPost.IsSubmitted, () =>
        {
            RuleFor(jobPost => jobPost.PayGroupId)
                .NotEmpty().WithMessage(JobPostValidation.PayGroupRequired);

            RuleFor(jobPost => jobPost.PayMethodId)
                .NotEmpty().WithMessage(JobPostValidation.PayMethodRequired);

            RuleFor(jobPost => jobPost.WorkArrangementId)
                .NotEmpty().WithMessage(JobPostValidation.WorkArrangementRequired);

            RuleFor(jobPost => jobPost.Description)
                .NotEmpty().WithMessage(JobPostValidation.DescriptionRequired);

            RuleFor(jobPost => jobPost.ApplicationFormId)
                .NotEmpty().WithMessage(JobPostValidation.ApplicationFormRequired);

            RuleFor(jobPost => jobPost.StartDateTime)
               .NotEmpty().WithMessage(JobPostValidation.StartDateRequired);

            When(jobPost => jobPost.StartDateTime.HasValue, () =>
            {
                RuleFor(jobPost => jobPost.EndDateTime)
                    .GreaterThanOrEqualTo(jobPost => jobPost.StartDateTime)
                    .WithMessage(JobPostValidation.InvalidEndDate);
            });

            RuleFor(jobPost => jobPost.EmployeeTypeId)
                .NotEmpty().WithMessage(JobPostValidation.EmployeeTypeRequired);

            When(jobPost => jobPost.LocationTypeId == (long)LocationType.WorksiteLocation, () =>
            {
                RuleFor(jobPost => jobPost.WorksiteLocationId)
                    .NotEmpty()
                    .WithMessage(JobPostValidation.WorksiteLocationRequired);
            });

            When(jobPost => jobPost.WorkArrangementId == (long)WorkArrangement.Remote, () =>
            {
                RuleFor(jobPost => jobPost.City)
                .MaximumLength(JobPostValidation.CityMaxLength)
                .WithMessage(JobPostValidation.CityMaxLengthExceededMessage);

                RuleFor(jobPost => jobPost.Country)
                .MaximumLength(JobPostValidation.CountryMaxLength)
                .WithMessage(JobPostValidation.CountryMaxLengthExceededMessage);
            });

            When(jobPost => jobPost.LocationTypeId == (long)LocationType.CustomLocation, () =>
            {
                RuleFor(jobPost => jobPost.Location)
                    .MaximumLength(JobPostValidation.LocationMaxLength)
                    .WithMessage(JobPostValidation.LocationMaxLengthExceededMessage);

                RuleFor(jobPost => jobPost.City)
                    .NotEmpty()
                    .WithMessage(JobPostValidation.CityRequired)
                    .NotNull()
                    .WithMessage(JobPostValidation.CityRequired);

                RuleFor(jobPost => jobPost.City)
                    .MaximumLength(JobPostValidation.CityMaxLength)
                    .WithMessage(JobPostValidation.CityMaxLengthExceededMessage);

                RuleFor(jobPost => jobPost.StateId)
                    .NotEmpty()
                    .WithMessage(JobPostValidation.StateRequired)
                    .NotNull()
                    .WithMessage(JobPostValidation.StateRequired);
            });

            RuleFor(jobPost => jobPost.MinSalary)
                    .GreaterThanOrEqualTo(0)
                    .WithMessage(JobPostValidation.JobPostInvalidMinSalaryFormat);

            When(jobPost => jobPost.MinSalary.HasValue && jobPost.MinSalary > 0, () =>
            {
                RuleFor(jobPost => jobPost.MaxSalary)
                    .NotEmpty()
                    .WithMessage(JobPostValidation.JobPostMaxSalaryRequired)
                    .GreaterThanOrEqualTo(0)
                    .WithMessage(JobPostValidation.JobPostMaxSalaryRequired);

                RuleFor(jobPost => jobPost.MaxSalary)
                    .GreaterThanOrEqualTo(jobPost => jobPost.MinSalary)
                    .WithMessage(JobPostValidation.JobPostInvalidMaxSalary);
            });

            When(jobPost => jobPost.MaxSalary.HasValue && jobPost.MaxSalary > 0, () =>
            {
                RuleFor(jobPost => jobPost.MinSalary)
                    .NotEmpty().WithMessage(JobPostValidation.JobPostMinSalaryRequired);
            });

            RuleFor(jobPostDto => jobPostDto.HiringManagerId)
                 .NotEmpty()
                 .WithMessage(JobPostValidation.HiringManagerRequired)
                 .NotNull()
                 .WithMessage(JobPostValidation.HiringManagerRequired);

            When(jobPost => jobPost.Salary.HasValue, () =>
            {
                RuleFor(jobPost => jobPost.Salary)
                    .GreaterThanOrEqualTo(0)
                    .WithMessage(JobPostValidation.JobPostSalaryGreaterThanZero);
            });

            When(jobPost => (jobPost.WorkArrangementId == (long)WorkArrangement.Onsite || jobPost.WorkArrangementId == (long)WorkArrangement.Hybrid), () =>
            {
                RuleFor(jobPost => jobPost.LocationTypeId)
                .NotEmpty()
                .WithMessage(JobPostValidation.WorksiteLocationTypeRequired)
                .NotNull()
                .WithMessage(JobPostValidation.WorksiteLocationTypeRequired);
            });
        });
    }
}