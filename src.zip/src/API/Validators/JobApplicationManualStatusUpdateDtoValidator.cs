﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators
{
    public class JobApplicationManualStatusUpdateDtoValidator : AbstractValidator<JobApplicationManualStatusUpdateDto>
    {
        public JobApplicationManualStatusUpdateDtoValidator()
        {
            RuleFor(dto => dto.JobApplicationId)
                .NotNull().WithMessage(JobApplicationValidation.JobApplicationIdMandatory);

            RuleFor(dto => dto.StatusId)
                .NotNull().WithMessage(JobApplicationValidation.StatusIdMandatory);

            When(dto => dto.StatusId == (long)JobApplicationStatuses.NotSelected, () =>
            {
                RuleFor(dto => dto.Note)
                    .NotNull().WithMessage(JobApplicationValidation.NoteMandatory)
                    .NotEmpty().WithMessage(JobApplicationValidation.NoteMandatory);
            });
        }
    }
}