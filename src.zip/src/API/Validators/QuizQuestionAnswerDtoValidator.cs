﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class QuizQuestionAnswerDtoValidator : AbstractValidator<QuizQuestionAnswerDto>
{
    public QuizQuestionAnswerDtoValidator()
    {
        RuleFor(quizQuestionAnswer => quizQuestionAnswer.Answer)
                    .NotEmpty().WithMessage(ApplicantQuizValidation.AnswerRequried)
                    .NotNull().WithMessage(ApplicantQuizValidation.AnswerRequried);
    }
}