﻿using BBSI.ATS.DTO;
using FluentValidation;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.API.Validators;

public class ApplicationFormFieldOptionDtoValidator : AbstractValidator<ApplicationFormFieldOptionDto>
{
    public ApplicationFormFieldOptionDtoValidator()
    {
        RuleFor(formFieldOption => formFieldOption.Name)
            .NotEmpty().WithMessage(DropdownValidation.OptionEmptyErrorMessage)
            .MaximumLength(DropdownValidation.OptionMaxLength).WithMessage(DropdownValidation.OptionMaxLengthErrorMessage);
    }
}