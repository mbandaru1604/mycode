﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators
{
    public class WidgetFilterCriteriaDtoValidator : AbstractValidator<WidgetFilterCriteriaDto>
    {
        public WidgetFilterCriteriaDtoValidator()
        {
            RuleFor(filterDto => filterDto.FromDate)
                .NotNull().WithMessage(OfferStatusCountValidation.FromDateOfferExtendedIsRequired)
                .NotEmpty().WithMessage(OfferStatusCountValidation.FromDateOfferExtendedIsRequired);

            RuleFor(filterDto => filterDto.ToDate)
                .NotNull().WithMessage(OfferStatusCountValidation.ToDateOfferExtendedIsRequired)
                .NotEmpty().WithMessage(OfferStatusCountValidation.ToDateOfferExtendedIsRequired);

            RuleFor(filterDto => filterDto)
                .Must(offerStatus =>
                {
                        return offerStatus.FromDate.HasValue && offerStatus.ToDate.HasValue && offerStatus.FromDate.Value <= offerStatus.ToDate.Value;
                })
                .WithMessage(filterDto => string.Format(OfferStatusCountValidation.InvalidExtendedDates,
                  filterDto.FromDate.ToString(),
                  filterDto.ToDate.ToString()));
        }
    }
}