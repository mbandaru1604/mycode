﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.API.Validators;

public class ApplicationFormFieldDtoValidator : AbstractValidator<ApplicationFormFieldDto>
{
    public ApplicationFormFieldDtoValidator()
    {
        RuleFor(formField => formField.Name)
            .NotEmpty().WithMessage(FormFieldValidation.FieldNameEmptyErrorMessage)
            .MaximumLength(FormFieldValidation.FormFieldNameMaxLength).WithMessage(FormFieldValidation.FieldNameMaxLengthExceededErrorMessage);

        RuleFor(formField => formField.Options)
                    .NotEmpty()
                    .WithMessage(FormFieldValidation.DropdownOptionsEmptyErrorMessage)
                    .When(formField => formField.TypeId == (long)ApplicationFormFieldTypes.Dropdown && !formField.IsSystemDefault.GetValueOrDefault());

        RuleFor(dropdownField => dropdownField.Options)
         .Custom((Options, context) =>
         {
             Options?.GroupBy(option => option.Name)
                    .Where(optionGroup => optionGroup.Count() > 1)
                    .ToList()
                    .ForEach(duplicateOption =>
                        {
                            context.AddFailure(String.Format(DropdownValidation.OptionNameExists, duplicateOption.Key));
                        });
         }).When(field => field.TypeId == (long)ApplicationFormFieldTypes.Dropdown);

        RuleForEach(form => form.Options).SetValidator(new ApplicationFormFieldOptionDtoValidator());
    }
}