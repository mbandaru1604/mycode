﻿using BBSI.ATS.DTO;
using FluentValidation;
using static BBSI.ATS.Common.ErrorMessages;

namespace BBSI.ATS.API.Validators;

public class ApplicantInterviewerDtoValidator : AbstractValidator<ApplicantInterviewerDto>
{
    public ApplicantInterviewerDtoValidator()
    {

        RuleFor(applicantInterviewer => applicantInterviewer.InterviewerId)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.InterviewerIdRequried)
                .NotNull().WithMessage(ApplicantInterviewValidation.InterviewerIdRequried);
    }
}
