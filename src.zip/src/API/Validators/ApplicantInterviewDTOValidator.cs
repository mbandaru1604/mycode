﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class ApplicantInterviewDtoValidator : AbstractValidator<ApplicantInterviewDto>
{
    public ApplicantInterviewDtoValidator()
    {
        RuleFor(applicantInterview => applicantInterview.JobApplicationId)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.JobApplicationIdRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.JobApplicationIdRequired);

        RuleFor(applicantInterview => applicantInterview.InterviewTypeId)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.InterviewTypeIdRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.InterviewTypeIdRequired);

        RuleFor(applicantInterview => applicantInterview.InterviewDate)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.InterviewDateRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.InterviewDateRequired);

        When(applicantInterview => applicantInterview.InterviewDate.HasValue, () =>
        {
            RuleFor(applicantInterview => applicantInterview.StartDateTime)
                .Must(startDateTime =>
                {
                    DateTime parsedStartDateTime;
                    if (DateTime.TryParse(startDateTime, out parsedStartDateTime))
                    {
                        return parsedStartDateTime.Date >= DateTime.UtcNow.Date;
                    }
                    return false; 
                })
                .WithMessage(ApplicantInterviewValidation.InvalidInterviewDate);
        });

        RuleFor(applicantInterview => applicantInterview.StartDateTime)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.StartTimeRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.StartTimeRequired);

        RuleFor(applicantInterview => applicantInterview.EndDateTime)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.EndTimeRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.EndTimeRequired);

        RuleFor(applicantInterview => applicantInterview.StartTime)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.StartTimeRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.StartTimeRequired);

        RuleFor(applicantInterview => applicantInterview.EndTime)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.EndTimeRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.EndTimeRequired);

        RuleFor(applicantInterview => applicantInterview.TimeZone)
          .NotEmpty().WithMessage(ApplicantInterviewValidation.TimeZoneRequired)
          .NotNull().WithMessage(ApplicantInterviewValidation.TimeZoneRequired);

        When(applicantInterview => applicantInterview.InterviewTypeId == (long)InterviewType.Video, () =>
        {
            RuleFor(applicantInterview => applicantInterview.MeetingLink)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.MeetingLinkRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.MeetingLinkRequired);
        });

        When(applicantInterview => applicantInterview.InterviewTypeId == (long)InterviewType.InPerson, () =>
        {
            RuleFor(applicantInterview => applicantInterview.LocationTypeId)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.LocationTypeisRequried)
                .NotNull().WithMessage(ApplicantInterviewValidation.LocationTypeisRequried);
        });

        When(applicantInterview => applicantInterview.LocationTypeId == (long)LocationType.CustomLocation, () =>
        {
            RuleFor(applicantInterview => applicantInterview.Location)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.LocationRequried)
                .NotNull().WithMessage(ApplicantInterviewValidation.LocationRequried);

            RuleFor(applicantInterview => applicantInterview.Location)
                .MaximumLength(ApplicantInterviewValidation.LocationMaxLength)
                .WithMessage(ApplicantInterviewValidation.LocationMaxLengthExceededMessage);

            RuleFor(applicantInterview => applicantInterview.Address1)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.Address1)
                .NotNull().WithMessage(ApplicantInterviewValidation.Address1);

            RuleFor(applicantInterview => applicantInterview.Address1)
                .MaximumLength(ApplicantInterviewValidation.Address1MaxLength)
                .WithMessage(ApplicantInterviewValidation.Address1MaxLengthExceededMessage);

            RuleFor(applicantInterview => applicantInterview.Address2)
                .MaximumLength(ApplicantInterviewValidation.Address2MaxLength)
                .WithMessage(ApplicantInterviewValidation.Address2MaxLengthExceededMessage);

            RuleFor(applicantInterview => applicantInterview.City)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.CityRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.CityRequired);

            RuleFor(applicantInterview => applicantInterview.City)
                .MaximumLength(ApplicantInterviewValidation.CityMaxLength)
                .WithMessage(ApplicantInterviewValidation.CityMaxLengthExceededMessage);

            RuleFor(applicantInterview => applicantInterview.StateId)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.StateRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.StateRequired);

            RuleFor(applicantInterview => applicantInterview.ZipCode)
                .NotEmpty().WithMessage(ApplicantInterviewValidation.ZipCodeRequired)
                .NotNull().WithMessage(ApplicantInterviewValidation.ZipCodeRequired);

            RuleFor(applicantInterview => applicantInterview.ZipCode)
                .MaximumLength(ApplicantInterviewValidation.ZipCodeMaxLength)
                .WithMessage(ApplicantInterviewValidation.ZipCodeMaxLengthExceededMessage);
        });

        When(applicantInterview => applicantInterview.LocationTypeId == (long)LocationType.WorksiteLocation, () =>
        {
            RuleFor(applicantInterview => applicantInterview.WorksiteLocationId)
                   .NotEmpty().WithMessage(ApplicantInterviewValidation.WorkSiteLocationRequried)
                   .NotNull().WithMessage(ApplicantInterviewValidation.WorkSiteLocationRequried);
        });

        RuleFor(applicantInterview => applicantInterview.Interviewers)
         .NotEmpty().WithMessage(ApplicantInterviewValidation.InterviewerRequried);

        RuleForEach(applicantInterview => applicantInterview.Interviewers).SetValidator(new ApplicantInterviewerDtoValidator());
    }
}