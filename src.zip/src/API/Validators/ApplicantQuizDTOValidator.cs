﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class ApplicantQuizDtoValidator : AbstractValidator<ApplicantQuizDto>
{
    public ApplicantQuizDtoValidator()
    {
        RuleFor(applicantQuiz => applicantQuiz.Name)
                .NotEmpty().WithMessage(ApplicantQuizValidation.QuizNameRequried)
                .NotNull().WithMessage(ApplicantQuizValidation.QuizNameRequried)
                .MaximumLength(50).WithMessage(ApplicantQuizValidation.QuizNameMaxLengthErroMessage);

        RuleFor(applicantQuiz => applicantQuiz.MinimumPassingScore)
            .NotNull().WithMessage(ApplicantQuizValidation.MinimumPassingScoreRequriedErrorMessage)
            .InclusiveBetween(1, 100).WithMessage(ApplicantQuizValidation.MinimumPassingScoreErrorMessage);

        RuleFor(applicantQuiz => applicantQuiz.Description)
            .MaximumLength(500).WithMessage(ApplicantQuizValidation.DescriptionMaxLengthErrorMessage);

        RuleFor(applicantQuiz => applicantQuiz.QuizQuestions)
           .Must(questions => questions == null || questions.Count >= 1).WithMessage(ApplicantQuizValidation.MinQuestionsRequiredErrorMessage)
           .Must(questions => questions == null || questions.Count <= 15).WithMessage(ApplicantQuizValidation.MaxQuestionsLimitExceeded);

        When(applicantQuiz => applicantQuiz.QuizQuestions != null && applicantQuiz.QuizQuestions.Count > 0, () =>
        {
            RuleFor(applicantQuiz => applicantQuiz.QuizQuestions)
                .Must((quiz, questions) => questions
                                           .Where(questions => questions.IsActive && questions.IsDeleted == false)
                                           .Sum(questions => questions.Score) >= quiz.MinimumPassingScore)
                .WithMessage(ApplicantQuizValidation.TotalScoreMustMeetOrExceedToMinimumScore);
        });

        RuleForEach(applicantQuiz => applicantQuiz.QuizQuestions).SetValidator(new QuizQuestionDtoValidator());
    }
}
