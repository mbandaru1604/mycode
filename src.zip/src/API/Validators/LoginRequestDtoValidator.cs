﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class LoginRequestDtoValidator : AbstractValidator<LoginRequestDto>
{
    public LoginRequestDtoValidator()
    {
        RuleFor(loginRequestDto => loginRequestDto.Token)
           .NotNull().WithMessage(UserAuthenticationValidation.TokenIsRequired)
           .NotEmpty().WithMessage(UserAuthenticationValidation.TokenIsRequired);
    }
}
