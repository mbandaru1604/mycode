﻿using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class ApplicationFormDtoValidator : AbstractValidator<ApplicationFormDto>
{
    public ApplicationFormDtoValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage(FormValidation.FormNameRequired)
            .MaximumLength(FormValidation.FormNameMaxLength).WithMessage(FormValidation.FormNameMaxLengthExceededMessage);

        RuleFor(applicationForm => applicationForm.Fields)
          .Custom((fields, context) =>
          {
              if (fields != null)
              {
                  fields.GroupBy(fieldName => fieldName.Name)
                        .Where(fieldNameGroup => fieldNameGroup.Count() > 1)
                        .ToList()
                        .ForEach(duplicateName =>
                         {
                             context.AddFailure(string.Format(FormFieldValidation.FormFieldNameExists, duplicateName.Key));
                         });
              }
          });

        RuleForEach(applicationForm => applicationForm.Fields).SetValidator(new ApplicationFormFieldDtoValidator());
    }
}