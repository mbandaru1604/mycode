﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using FluentValidation;

namespace BBSI.ATS.API.Validators;

public class QuizQuestionDtoValidator : AbstractValidator<QuizQuestionDto>
{
    public QuizQuestionDtoValidator()
    {
        RuleFor(quizQuestion => quizQuestion.Question)
            .NotEmpty().WithMessage(ApplicantQuizValidation.QuestionIsRequried)
            .NotNull().WithMessage(ApplicantQuizValidation.QuestionIsRequried)
            .MaximumLength(100).WithMessage(ApplicantQuizValidation.QuestionMaxLengthErrorMEssage);

        RuleFor(quizQuestion => quizQuestion.TypeId)
            .Must(typeId => typeId == (long)QuestionType.MultipleChoice || typeId == (long)QuestionType.TrueFalse)
            .NotNull().WithMessage(ApplicantQuizValidation.TypeIdRequried);

        RuleFor(quizQuestion => quizQuestion.Score)
            .NotNull().WithMessage(ApplicantQuizValidation.ScoreRequried)
            .InclusiveBetween(1, 100).WithMessage(ApplicantQuizValidation.ScoreMustBe1To100);

        When(quizQuestion => quizQuestion.TypeId == (long)QuestionType.MultipleChoice, () =>
        {
            RuleFor(quizQuestion => quizQuestion.Answers)
                .Must(answers => answers?.Count >= 2).WithMessage(ApplicantQuizValidation.AtleastTwoAnswersAreRequired)
                .Must(answers => answers?.Count <= 5).WithMessage(ApplicantQuizValidation.FiveAnswersOnlyAllowed);
        });

        RuleFor(quizQuestion => quizQuestion.Answers)
            .Must(answers => answers?.Count > 0 && answers.Any(answers => answers.IsCorrect)).WithMessage(ApplicantQuizValidation.CorrectAnswerMustBeSelected);

        RuleForEach(quizQuestion => quizQuestion.Answers).SetValidator(new QuizQuestionAnswerDtoValidator());
    }
}