﻿using Serilog.Events;
using Serilog.Formatting;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json;

namespace BBSI.ATS.API.Extensions;

[ExcludeFromCodeCoverage]
public class SerilogJsonFormatter : ITextFormatter
{
    private readonly JsonSerializerOptions _options;

    public SerilogJsonFormatter()
    {
        _options = new JsonSerializerOptions
        {
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };
    }

    public void Format(LogEvent logEvent, TextWriter output)
    {
        var logObject = new
        {
            Timestamp = logEvent.Timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff zzz"),
            TimeMilli = logEvent.Timestamp.ToUnixTimeMilliseconds(),
            Level = logEvent.Level.ToString(),
            SourceContext = GetPropertyValue(logEvent, "SourceContext"),
            Message = logEvent.RenderMessage(),
            ClassName = GetPropertyValue(logEvent, "ClassName"),
            MethodName = GetPropertyValue(logEvent, "MethodName"),
            Module = GetPropertyValue(logEvent, "ApplicationName"),
            Username = GetPropertyValue(logEvent, "Username")
        };
        output.WriteLine(JsonSerializer.Serialize(logObject, _options));
    }

    private static string GetPropertyValue(LogEvent logEvent, string propertyName)
    {
        return (logEvent.Properties.ContainsKey(propertyName) ?
            ((ScalarValue)logEvent.Properties[propertyName]).Value?.ToString() : null)!;
    }
}