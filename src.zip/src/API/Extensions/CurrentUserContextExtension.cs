﻿using BBSI.ATS.Common;
using System.Diagnostics.CodeAnalysis;
using System.Security.Claims;

namespace BBSI.ATS.API.Extensions;

[ExcludeFromCodeCoverage]
public static class CurrentUserContextExtension
{
    public static void PopulateFromHttpContext(this CurrentUserContext currentUserContext, HttpContext context)
    {
        if (context == null
            || context.User == null
            || context.User.Identity == null
            || !context.User.Identity.IsAuthenticated)
            return;

        var user = context.User;

        currentUserContext.UserId = Convert.ToInt32(user.Claims.First(claim => claim.Type.Equals(AuthenticationTokenClaimTypes.UserId, StringComparison.OrdinalIgnoreCase)).Value);
        currentUserContext.TokenId = user.Claims.First(claim => claim.Type.Equals(AuthenticationTokenClaimTypes.TokenId, StringComparison.OrdinalIgnoreCase)).Value;
        currentUserContext.UserEmail = user.Claims.First(claim => claim.Type == ClaimTypes.Email).Value;
        currentUserContext.CompanyId = Convert.ToInt32(user.Claims.First(claim => claim.Type.Equals(AuthenticationTokenClaimTypes.CompanyId, StringComparison.OrdinalIgnoreCase)).Value);
        currentUserContext.CompanyCode = Convert.ToInt32(user.Claims.First(claim => claim.Type.Equals(AuthenticationTokenClaimTypes.CompanyCode, StringComparison.OrdinalIgnoreCase)).Value);
        currentUserContext.RoleIds = user.Claims
                                         .Where(c => c.Type == ClaimTypes.Role)
                                         .Select(c => long.Parse(c.Value))
                                         .ToList();
    }
}