using BBSI.ATS.API.Filters;
using BBSI.ATS.API.Middleware;
using BBSI.ATS.API.Middleware.Authorization;
using BBSI.ATS.API.Middleware.ExceptionHandler;
using BBSI.ATS.API.Validators;
using BBSI.ATS.BackgroundServices;
using BBSI.ATS.Common;
using BBSI.ATS.Common.Exceptions;
using BBSI.ATS.Common.Helpers;
using BBSI.ATS.DTO;
using BBSI.ATS.Infrastructure.Data.Persistence;
using BBSI.ATS.Infrastructure.Data.Repositories.Concrete;
using BBSI.ATS.Infrastructure.Data.Repositories.Interfaces;
using BBSI.ATS.Infrastructure.Integrations.Concrete;
using BBSI.ATS.Infrastructure.Integrations.Interfaces;
using BBSI.ATS.Services.Comparers;
using BBSI.ATS.Services.Concrete;
using BBSI.ATS.Services.Concrete.Events;
using BBSI.ATS.Services.Interfaces;
using BBSI.ATS.Services.Mappings;
using BBSI.ESB;
using BBSI.ESB.Handlers.Interfaces;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Azure.Cosmos;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Morcatko.AspNetCore.JsonMergePatch;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Text;
using WkHtmlToPdfDotNet;
using WkHtmlToPdfDotNet.Contracts;

namespace BBSI.ATS.API;

[ExcludeFromCodeCoverage]
internal static class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        var appConfig = new AppConfig();
        builder.Configuration.Bind(appConfig);
        builder.Services.AddSingleton(appConfig);

        var allowedOrigins = appConfig.AllowedOriginsForCORS.Split(',');
        builder.Services.AddCors(options =>
        {
            options.AddPolicy(name: "ATS", builder =>
            {
                builder.WithOrigins(allowedOrigins)
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            });
        });

        // Add services to the container.
        builder.Services.AddControllers()
                        .AddNewtonsoftJson()
                        .AddNewtonsoftJsonMergePatch();
        builder.Services.AddValidatorsFromAssemblyContaining<ApplicationFormDtoValidator>();
        builder.Services.AddFluentValidationAutoValidation()
                        .AddFluentValidationClientsideAdapters();

        ////Add support to logging with SERILOG
        builder.Host.UseSerilog((context, configuration) =>
        {
            configuration.ReadFrom.Configuration(context.Configuration);
            //configuration.WriteTo.Console(new SerilogJsonFormatter());
            //configuration.Enrich.With<ThreadIdEnricher>();
            //configuration.Enrich.FromLogContext();
        });

        builder.Services.AddExceptionHandler<AtsGlobalExceptionHandler>();
        builder.Services.AddProblemDetails();

        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo { Title = "ATS API", Version = "v1" });

            // Set the XML comments file path
            var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            c.IncludeXmlComments(xmlPath);

            c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, "BBSI.ATS.Common.xml"));

            c.OperationFilter<JsonMergePatchDocumentOperationFilter>();
            // Uncommented this code further
            c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
            {
                Name = "Authorization",
                Type = SecuritySchemeType.ApiKey,
                Scheme = "Bearer",
                BearerFormat = "JWT",
                In = ParameterLocation.Header,
                Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
            });
            c.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                new OpenApiSecurityScheme {
                    Reference = new OpenApiReference {
                        Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                    }
                },
                Array.Empty<string>()
                }
            });
        }).AddSwaggerGenNewtonsoftSupport();

        var dbConnectionString = builder.Configuration.GetConnectionString("AtsDbContext");
        builder.Services.AddDbContext<AtsDbContext>(options =>
        {
            options.UseSqlServer(dbConnectionString);
            if (builder.Environment.IsDevelopment())
            {
                options.EnableDetailedErrors();
                options.EnableSensitiveDataLogging();
            }
        });

        builder.Services.AddAutoMapper(typeof(MappingProfile));
        builder.Services.AddScoped<IApplicationFormRepository, ApplicationFormRepository>();
        builder.Services.AddScoped<IApplicationFormService, ApplicationFormService>();
        builder.Services.AddScoped<IAtsBaseRepository, AtsBaseRepository>();
        builder.Services.AddScoped<IMetaDataService, MetaDataService>();
        builder.Services.AddScoped<IJobPostRepository, JobPostRepository>();
        builder.Services.AddScoped<IJobPostService, JobPostService>();
        builder.Services.AddScoped<IJobPostCategoryRepository, JobPostCategoryRepository>();
        builder.Services.AddScoped<IJobPostCategoryService, JobPostCategoryService>();
        builder.Services.AddScoped<ICompanyService, CompanyService>();
        builder.Services.AddScoped<ICompanyRepository, CompanyRepository>();
        builder.Services.AddScoped<IJobApplicationService, JobApplicationService>();
        builder.Services.AddScoped<IJobApplicationRepository, JobApplicationRepository>();
        builder.Services.AddScoped<IUserService, UserService>();
        builder.Services.AddScoped<IApplicantInterviewService, ApplicantInterviewService>();
        builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
        builder.Services.AddScoped<IAuditLogService, AuditLogService>();
        builder.Services.AddScoped<IUserRepository, UserRepository>();
        builder.Services.AddScoped<ICustomComparer<ApplicationFormFieldDto>, ApplicationFormFieldComparer>();
        builder.Services.AddScoped<ICustomComparer<ApplicationFormDto>, ApplicationFormComparer>();
        builder.Services.AddScoped<ICustomComparer<ApplicantQuizDto>, ApplicantQuizComparer>();
        builder.Services.AddScoped<IJobApplicationNoteRepository, JobApplicationNoteRepository>();
        builder.Services.AddScoped<IApplicantQuizRepository, ApplicantQuizRepository>();
        builder.Services.AddScoped<IApplicantInterviewRepository, ApplicantInterviewRepository>();
        builder.Services.AddScoped<ICustomComparer<ApplicantInterviewAuditDto>, ApplicantInterviewComparer>();
        builder.Services.AddScoped<ICompanyJobBoardService, CompanyJobBoardService>();

        builder.Services.AddScoped<CompanyEventHandler>();
        builder.Services.AddScoped<WorksiteLocationEventHandler>();
        builder.Services.AddScoped<DomainProductEnabledEventHandler>();
        builder.Services.AddScoped<NewHireCreatedEventHandler>();
        builder.Services.AddScoped<NewHireInitiatedEventPublisher>();
        builder.Services.AddScoped<DomainUserUpdatedEventHandler>();

        builder.Services.AddScoped<IJobApplicationNoteService, JobApplicationNoteService>();
        builder.Services.AddScoped<IMetaDataRepository, MetaDataRepository>();
        builder.Services.AddScoped<IApplicantQuizService, ApplicantQuizService>();

        builder.Services.AddSingleton(typeof(IConverter), new SynchronizedConverter(new PdfTools()));
        builder.Services.AddSingleton<IRazorLightEngineWrapper, RazorLightEngineWrapper>();
        builder.Services.AddScoped<IHtmlToPdfConverterService, HtmlToPdfConverterService>();

        builder.Services.AddHttpContextAccessor();
        builder.Services.AddScoped<CurrentUserContext>();

        builder.Services.AddSingleton<IEventHandlerFactory, EventHandlerFactory>();

        var eventBusConnectionString = builder.Configuration.GetConnectionString("ServiceBusConnection");
        var eventBusConfig = builder.Configuration.GetSection("EventBusConfig").Get<EventBusConfig>();
        builder.Services.Configure<EventBusConfig>(builder.Configuration.GetSection("EventBusConfig"));

        if (eventBusConfig == null) throw new AtsException(EventBusValidation.EventBusTopicConfigIsEmpty);
        if (string.IsNullOrEmpty(eventBusConnectionString)) throw new AtsException(EventBusValidation.EventBusConnectionIsEmpty);

        var schemas = ResourceReader.ReadEmbeddedResource(Assembly.LoadFrom(Assembly.GetExecutingAssembly().Location.Replace(Assembly.GetExecutingAssembly().Location.Split("\\").Last(), string.Empty) + "BBSI.ATS.Common.dll"), $"BBSI.ATS.Common.EventSchemas");
        var eventSchemas = schemas.ToDictionary(schema => schema.Key.Replace($"BBSI.ATS.Common.EventSchemas.", string.Empty), schema => schema.Value);

        var notificationTemplates = ResourceReader.ReadEmbeddedResource(Assembly.LoadFrom(Assembly.GetExecutingAssembly().Location.Replace(Assembly.GetExecutingAssembly().Location.Split("\\").Last(), string.Empty) + "BBSI.ATS.Common.dll"), $"BBSI.ATS.Common.NotificationTemplates");
        var notificationTemplatesList = notificationTemplates.ToDictionary(template => Path.GetFileNameWithoutExtension(template.Key.Replace($"BBSI.ATS.Common.NotificationTemplates.", string.Empty)), template => template.Value);

        builder.Services.AddSingleton(notificationTemplatesList);

        builder.Services.AddSingleton<EnterpriseBus>(serviceProvider =>
        {
            var logger = serviceProvider.GetRequiredService<ILoggerFactory>();
            return new EnterpriseBus(new EnterpriseBusConfig
            {
                Connection = eventBusConnectionString,
                EventSchemaDefinitions = eventSchemas,
                EventAndSchemaResourceMapping = EventBusSchemaMappings.AtsEventSchemaNames,
                ErrorTopicName = eventBusConfig.ErrorTopicName
            },
            serviceProvider.GetRequiredService<IEventHandlerFactory>(), logger, serviceProvider);
        });

        builder.Services.AddHostedService(serviceProvider => new AtsEventWorker(eventBusConfig.Subscriptions!.Select(subscription => new EnterpriseBusSubscriptionConfig
        {
            ErrorTopicName = subscription.ErrorTopicName,
            InboundTopicName = subscription.TopicName,
            Subscription = subscription.Subscription
        }).ToList(), serviceProvider, serviceProvider.GetRequiredService<EnterpriseBus>()));

        var jobPostWorkerExecutionFrequencyInHours = builder.Configuration.GetValue<int>("JobPostWorkerExecutionFrequencyInHours");
        builder.Services.AddHostedService(serviceProvider => new JobPostWorker(
                                                serviceProvider.GetRequiredService<ILogger<JobPostWorker>>(),
                                                serviceProvider,
                                                jobPostWorkerExecutionFrequencyInHours));

        var emailConfig = builder.Configuration.GetSection("EmailConfig").Get<SendGridEmailConfig>();
        if (emailConfig == null) throw new AtsException("Email config not found");
        builder.Services.AddTransient<IEmailClient>(serviceProvider =>
        {
            var logger = serviceProvider.GetRequiredService<ILogger<EmailClient>>();
            return new EmailClient(emailConfig, logger);
        });

        builder.Services.Configure<EmailTemplateConfig>(builder.Configuration.GetSection("EmailTemplateConfig"));

        var blobConnectionString = builder.Configuration.GetConnectionString("AzureBlobStorage");
        var blobContainer = builder.Configuration["AzureBlobContainer"];
        builder.Services.AddScoped<IBlobService, BlobService>(_ => new BlobService(blobConnectionString!, blobContainer!));

        builder.Services.AddScoped<IAuthorizationHandler, PrivilegeHandler>();

        var redisConfigSection = builder.Configuration.GetSection("RedisConfig");
        builder.Services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = redisConfigSection.GetValue<string>("ConnectionString");
            options.InstanceName = redisConfigSection.GetValue<string>("InstanceName");
        });

        builder.Services.AddSingleton<IRedisCacheProvider, RedisCacheProvider>();

        builder.Services.Configure<JwtConfig>(builder.Configuration.GetSection("JwtConfig"));
        var jwtSettings = builder.Configuration.GetSection("JwtConfig").Get<JwtConfig>();
        var key = Encoding.UTF8.GetBytes(jwtSettings!.Key!);

        builder.Services.AddHttpClient(CustomHttpClient.Name)
            .ConfigurePrimaryHttpMessageHandler(() =>
            {
                var handler = new HttpClientHandler();
                //if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development")
                //{
                handler.ServerCertificateCustomValidationCallback = (message, certificate, chain, errors) => true;
                //}
                return handler;
            });

        builder.Services.AddTransient<IHttpClientWrapper>(provider =>
        {
            var httpClient = provider.GetRequiredService<IHttpClientFactory>().CreateClient(CustomHttpClient.Name);
            return new HttpClientWrapper(httpClient);
        });

        builder.Services.AddTransient<ITokenService>(provider =>
        {
            var httpClientWrapper = provider.GetRequiredService<IHttpClientWrapper>();
            var tokenValidationEndpoint = builder.Configuration["TokenValidationEndpoint"];
            return new TokenService(jwtSettings, httpClientWrapper, tokenValidationEndpoint!);
        });

        builder.Services.AddScoped<IAuthenticationService, AuthenticationService>();

        builder.Services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer = jwtSettings.Issuer,
                ValidAudience = jwtSettings.Audience,
                IssuerSigningKey = new SymmetricSecurityKey(key)
            };
        });

        builder.Services.AddAuthorization(options =>
        {
            options.FallbackPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();

            using (var scope = builder.Services.BuildServiceProvider().CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<AtsDbContext>();
                var policyProvider = new AuthorizationPolicyProvider(dbContext);
                policyProvider.AddPolicies(options);
            }
        });

        builder.Services.AddSingleton<IRolePrivilegeService, RolePrivilegeService>();

        if (string.IsNullOrEmpty(blobConnectionString)) throw new AtsException(BlobServiceValidation.blobConnectionStringIsEmpty);

        var cosmosDbConfig = builder.Configuration.GetSection("CosmosDbConfig").Get<CosmosDbConfig>();

        if (cosmosDbConfig == null) throw new AtsException(CosmosDbValidation.CosmosDbConnectionIsEmpty);

        builder.Services.Configure<CosmosDbConfig>(builder.Configuration.GetSection("CosmosDbConfig"));

        builder.Services.AddSingleton<CosmosClient>(serviceProvier =>
        {
            var cosmosDbConfig = serviceProvier.GetRequiredService<IOptions<CosmosDbConfig>>().Value;
            return new CosmosClient(cosmosDbConfig.ConnectionString, new CosmosClientOptions
            {
                ConnectionMode = ConnectionMode.Direct,
                RequestTimeout = TimeSpan.FromSeconds(cosmosDbConfig.TimeoutInSeconds)
            });
        });

        builder.Services.AddScoped<ICosmosDbService, CosmosDbService>();
        builder.Services.Configure<JobBoardConfig>(builder.Configuration.GetSection("JobBoardConfig"));
        builder.Services.AddHealthChecks();

        var app = builder.Build();
        app.MapHealthChecks("/health").AllowAnonymous();

        app.UseExceptionHandler();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseCors("ATS");
        app.UseHttpsRedirection();

        app.UseAuthentication();
        app.UseMiddleware<AtsMiddleware>();
        app.UseAuthorization();

        app.MapControllers();

        Log.Logger.Information("Application Started");
        Log.Logger.Information("AllowedOriginsForCORS: {AllowedOrigins}", string.Join(", ", allowedOrigins));

        app.Run();
    }
}