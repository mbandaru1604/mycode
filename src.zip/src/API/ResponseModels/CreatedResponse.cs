﻿namespace BBSI.ATS.API.ResponseModels;

public class CreatedResponse
{
    public long Id { get; set; }
}