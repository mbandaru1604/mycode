﻿namespace BBSI.ATS.API.ResponseModels;

public class AtsRecordExistsResponse
{
    public bool Exists { get; set; }
}