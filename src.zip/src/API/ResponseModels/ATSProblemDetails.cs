﻿using Microsoft.AspNetCore.Mvc;

namespace BBSI.ATS.Common.Helpers;

public class AtsProblemDetails : ProblemDetails
{
    public string? ErrorCode { get; set; }
    public string? ErrorStackTrace { get; set; }
}