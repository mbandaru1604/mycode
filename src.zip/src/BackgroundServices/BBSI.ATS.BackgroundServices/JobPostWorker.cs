﻿using BBSI.ATS.Common.Extensions;
using BBSI.ATS.Services.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;

namespace BBSI.ATS.BackgroundServices;

[ExcludeFromCodeCoverage(Justification = "This is a background worker which updates status of JobPosts based on current date")]
public class JobPostWorker(ILogger<JobPostWorker> logger,
                           IServiceProvider serviceProvider,
                           int jobPostWorkerExecutionFrequencyInHours) : BackgroundService
{
    private readonly ILogger<JobPostWorker> _logger = logger;
    private readonly IServiceProvider _serviceProvider = serviceProvider;
    private readonly int _jobPostWorkerExecutionFrequencyInHours = jobPostWorkerExecutionFrequencyInHours;
    private Timer _timer;

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _timer = new Timer(async state => await UpdateStatusAsync(stoppingToken), null, TimeSpan.Zero,
                           TimeSpan.FromHours(_jobPostWorkerExecutionFrequencyInHours));
        return Task.CompletedTask;
    }

    private async Task UpdateStatusAsync(CancellationToken stoppingToken)
    {
        if (stoppingToken.IsCancellationRequested)
        {
            _logger.LogInformation("JobPostWorker cancellation is requested and stopping.");
            return;
        }

        using (var scope = _serviceProvider.CreateScope())
        {
            var jobPostService = scope.ServiceProvider.GetRequiredService<IJobPostService>();

            try
            {
                _logger.LogInformation("JobPostWorker running at: {time}", DateTimeOffset.Now);
                await jobPostService.UpdateStatusAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while executing the job.");
            }
        }
    }

    public override void Dispose()
    {
        _timer?.Dispose();
        base.Dispose();
    }
}