﻿using BBSI.ESB;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;

namespace BBSI.ATS.BackgroundServices;

[ExcludeFromCodeCoverage(Justification = "This is background worker that initiates the subscriptions")]
public class AtsEventWorker(IList<EnterpriseBusSubscriptionConfig> servicebusConfigs,
                            IServiceProvider serviceProvider, EnterpriseBus enterpriseBus) : BackgroundService
{
    private readonly IList<EnterpriseBusSubscriptionConfig> _servicebusConfigs = servicebusConfigs;
    private readonly ILogger<AtsEventWorker> _logger = serviceProvider.GetRequiredService<ILogger<AtsEventWorker>>();

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("ATS Event Worker Started");
        await enterpriseBus.SubscribeAsync(_servicebusConfigs);

        await Task.Delay(Timeout.Infinite, stoppingToken);

        await enterpriseBus.StopAllSubscriptions();
        _logger.LogInformation("ATS Event Worker Stopped");
    }
}