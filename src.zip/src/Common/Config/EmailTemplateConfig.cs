﻿namespace BBSI.ATS.Common;

public class EmailTemplateConfig
{
    public string? BaseUri { get; set; }
}