﻿namespace BBSI.ATS.Common;

public class AppConfig
{
    public string AllowedOriginsForCORS { get; set; } = string.Empty;
    public string AppUrl { get; set; } = string.Empty;
    public CompanyJobBoardConfig CompanyJobBoardConfig { get; set; } = new();
}
public class CompanyJobBoardConfig
{
    public string JobPostUrl { get; set; } = string.Empty;
}