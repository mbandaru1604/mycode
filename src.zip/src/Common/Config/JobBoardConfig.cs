﻿namespace BBSI.ATS.Common;

public class JobBoardConfig
{
    public string? AppUrl { get; set; }
    public string? JobPostUrl { get; set; }
}
