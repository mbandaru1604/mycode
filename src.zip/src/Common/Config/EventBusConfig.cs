﻿namespace BBSI.ATS.Common;

public class EventBusConfig
{
    public IList<EventBusSubscriptionConfig>? Subscriptions { get; set; }
    public string? PublishToTopic { get; set; }
    public string? ErrorTopicName { get; set; }
}

public class EventBusSubscriptionConfig
{
    public string? TopicName { get; set; }
    public string? Subscription { get; set; }
    public string? ErrorTopicName { get; set; }
}