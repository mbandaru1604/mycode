﻿namespace BBSI.ATS.Common;

public class SendGridEmailConfig
{
    public string? ApiKey { get; set; }
    public string? SenderEmail { get; set; }
    public string? SenderName { get; set; }
}