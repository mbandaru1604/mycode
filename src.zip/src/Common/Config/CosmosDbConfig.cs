﻿namespace BBSI.ATS.Common;

public class CosmosDbConfig
{
    public required string ConnectionString { get; set; }
    public required string DatabaseName { get; set; }
    public required string ContainerName { get; set; }
    public required double TimeoutInSeconds { get; set; }
}