﻿namespace BBSI.ATS.Common;

public class JwtConfig
{
    public string? Key { get; set; }
    public string? Issuer { get; set; }
    public string? Audience { get; set; }
    public int ExpiryTimeInMinutes { get; set; }
}