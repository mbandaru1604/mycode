﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace BBSI.ATS.Common.Extensions;

public static class EnumExtensions
{
    public static string GetEnumDisplayName(this Enum value)
    {
        var field = value.GetType().GetField(value.ToString());
        var attribute = field?.GetCustomAttribute<DisplayAttribute>();
        var output = attribute == null ? value.ToString() : attribute.Name;
        return output ?? string.Empty;
    }
}