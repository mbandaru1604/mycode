﻿namespace BBSI.ATS.Common.Extensions;

public static class StringExtensions
{
}