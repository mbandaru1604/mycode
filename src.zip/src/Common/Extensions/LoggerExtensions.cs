﻿using Microsoft.Extensions.Logging;
using System.Runtime.CompilerServices;

namespace BBSI.ATS.Common.Extensions;

public static class LoggerExtensions
{
    public static void LogInfo(this ILogger logger, string? message, [CallerMemberName] string memberName = "")
    {
        var loggerItems = new Dictionary<string, object>()
        {
            { "MethodName", memberName }
        };

        using (logger.BeginScope(loggerItems))
        {
            logger.LogInformation(message);
        }
    }

    public static void LogException(this ILogger logger, Exception ex, string? message, [CallerMemberName] string memberName = "")
    {
        var loggerItems = new Dictionary<string, object>()
        {
            { "MethodName", memberName }
        };

        using (logger.BeginScope(loggerItems))
        {
            logger.LogError(ex, message);
        }
    }
}