﻿using System.Collections.ObjectModel;

namespace BBSI.ATS.Common;

public static class ErrorMessages
{
    public const string InternalServerError = "Internal Server Error";
    public const string UnhandledException = "An unhandled exception has occurred while executing the request.";
    public const string InvalidRecordId = "Invalid Id";
    public const string ApplicationFormNameExists = "An application form with this name already exists";
    public const string JobPostTitleExists = "Title with this name already exists";

    public const string FormFieldAttributeValueExists = "Form Field Attribute Value with this name already exists";

    public const string FormFieldInactive = "'{0}' Should be Active";
    public const string FormFieldOptionalMandatory = "'{0}' Should be Required";
    public const string InvalidForm = "Application Form is not available";
    public const string InActiveApplicationForm = "Application Form is Inactive";
    public const string InvalidJobPost = "JobPost is not available";
    public const string InActiveJobPost = "JobPost is Inactive";
    public const string ConflictMessage = "The record has been modified by another user. Please reload the page and try again.";

    public static class FormValidation
    {
        public const int FormNameMaxLength = 56;
        public const string FormNameRequired = "Application Form Name is required.";
        public static readonly string FormNameMaxLengthExceededMessage = "Application Form Name Max Length cannot exceed " + FormNameMaxLength + " characters";
    }

    public static class DropdownValidation
    {
        public const int OptionMaxLength = 100;
        public const string OptionEmptyErrorMessage = "Option Name is required.";
        public static readonly string OptionMaxLengthErrorMessage = "Option Name Max Length cannot exceed " + OptionMaxLength + " characters";
        public const string OptionNameExists = "An option with this name '{0}' already exists";
    }

    public static class FormFieldValidation
    {
        public const int FormFieldNameMaxLength = 56;
        public const string DropdownOptionsEmptyErrorMessage = "The Dropdown field options must not be empty.";
        public const string FieldNameEmptyErrorMessage = "Field Name is required.";

        public static readonly string FieldNameMaxLengthExceededErrorMessage = "Field Name Max Length cannot exceed "
                                                                                + FormFieldNameMaxLength + " characters";

        public const string FormFieldNameExists = "A field with this name '{0}' already exists";
        public const int MaxAllowedCustomFields = 20;
        public const string ExceededMaxAllowedCustomFields = "You cannot add more than 20 records";
        public const int SingleLineMaxLength = 100;
        public const int ParagraphFieldMaxLength = 500;
        public const string TextFieldMaxLengthExceeded = "{0} max Length cannot exceed {1} characters";
    }

    public static class JobPostCategoryValidation
    {
        public const string NameExists = "Category with this name already exists";
        public const int NameMaxLength = 56;
        public const string NameIsRequired = "Job Post Category Name is required.";
        public static readonly string NameMaxLengthExceededMessage = "Job Post Category Name Max Length cannot exceed " + NameMaxLength + " characters";
    }

    public static class JobPostValidation
    {
        public const string DescriptionRequired = "Description is required.";

        public const string TitleExists = "Title with this name already exists";
        public const int TitleMaxLength = 56;
        public static readonly string TitleMaxLengthExceededMessage = $"Title Max Length cannot exceed {TitleMaxLength} characters";
        public const string TitleRequired = "Title is required.";
        public const string PayGroupRequired = "Pay Group is required.";
        public const string PayMethodRequired = "Pay Method is required.";
        public const string EmailInvalid = "{0} is not a valid email address.";
        public const string StartDateRequired = "Start Date is required.";
        public const string StartDateFutureDate = "Start date should be greater than or equal to current date";
        public const string InvalidEndDate = "End date cannot be set before the start date";
        public const string EmployeeTypeRequired = "Employee Type is required.";
        public const string ApplicationFormRequired = "Application form is required.";
        public const string WorkArrangementRequired = "Work Arrangement is required";
        public const string WorksiteLocationRequired = "WorkSite Location is required";
        public const string CityRequired = "City is required for Custom location";
        public const string StateRequired = "State is required for Custom location";
        public const int CityMaxLength = 50;
        public static readonly string CityMaxLengthExceededMessage = $"City Max Length cannot exceed {CityMaxLength} characters";
        public const int CountryMaxLength = 50;
        public static readonly string CountryMaxLengthExceededMessage = $"Country Max Length cannot exceed {CountryMaxLength} characters";
        public const int LocationMaxLength = 50;
        public static readonly string LocationMaxLengthExceededMessage = $"Location Max Length cannot exceed {LocationMaxLength} characters";
        public const string JobPostWorksiteLocationInactive = "The selected worksite location is currently inactive. Please choose another worksite.";
        public const string JobPostInvalidMaxSalary = "Max salary should be greater than Min salary.";
        public const string JobPostMinSalaryRequired = "Min salary is required.";
        public const string JobPostMaxSalaryRequired = "Max salary is required.";
        public const string JobPostInvalidMinSalaryFormat = "Min salary is not in correct format.";
        public const string JobPostInvalidMaxSalaryFormat = "Max salary is not in correct format.";
        public const string JobPostInvalidSalaryFormat = "Amount is not in correct format.";
        public const string HiringManagerRequired = "Hiring Manager is required";
        public const string JobPostSalaryGreaterThanZero = "Salary should be greater than zero.";
        public const string WorksiteLocationTypeRequired = "WorkSite Location Type is required";
    }

    public static class CompanyValidation
    {
        public const string CompanyAlreadyExists = "Company Already Exists";
        public const string CompanyCodeRequired = "Company Code is required";
        public const string CompanyCodeInvalid = "Company Code is invalid";
        public const string CompanyNotFound = "Company with code {0} not found";
        public const string DbaNameRequired = "DBA Name is required";
        public const string LegalNameRequired = "Legal Name is required";
        public const string StatusCodeRequired = "Status code is required";
        public const string StatusCodeInvalid = "Company Status Code {0} invalid";
    }

    public static class EventBusValidation
    {
        public const string EventBusConnectionIsEmpty = "Service Bus Connection string is empty";
        public const string EventBusTopicConfigIsEmpty = "Service Bus Topics Configuration is empty";
        public const string EventBusSchemaValidationFailed = "Service Bus Event Schema Validation Failed";
    }

    public static class ApplicationFormFieldValidation
    {
        public const string DropdownOptionsEmptyErrorMessage = "The Dropdown field options must not be empty.";
        public const string FieldEmptyErrorMessage = "{0} Field is required.";
        public const string FormFieldNameExists = "A field with this name '{0}' already exists";
        public const string InvalidApplicationField = "Invalid Application Field, Please Refresh";
        public const string FieldSetLimitExceeded = "more than 10 records cannot be added for {0}";
        public const string InvalidApplicationForm = "You cannot apply to this job since the form is not available ";
    }

    public static class JobApplicationValidation
    {
        public static readonly string MaxLengthExceeded = "{0} Max Length Exceeded";
        public static readonly string InvalidField = "{0} is invalid";
        public static readonly string LengthNotEqual = "{0} Length should be {1} characters";
        public static readonly string WhenAreYouAvailableToStartWork = "{0} should be greater than or equal to current date";
        public static readonly string InvalidFileFormat = "{0} invalid File Extension";
        public static readonly string FileSizeExceeds = "{0} File size exceeds 1MB";
        public const string FormFieldFileNameMissing = "{0} File Name is Missing";
        public static readonly string WorkHistoryInvalidStartDate = "{0} should be less than current date";
        public static readonly string WorkHistoryInvalidEndDate = "The {0} cannot be set before the start date. Please ensure that the end date is after the start date";
        public static readonly string WorkHistoryDateRequired = "{0} is required";
        public static readonly string GraduationYear = "{0} should be less than than current year";
        public const string InvalidJobApplicationId = "Invalid Job Application Id.";
        public const string InvalidJobApplicationStatusId = "Job Application Status Id is Invalid";
        public static readonly string StatusTransitionNotFound = $"Next status not found for the current status {0} and trigger {1}";
        public const string JobApplicationIdMandatory = "Job Application Id is mandatory";
        public const string StatusIdMandatory = "Status Id is mandatory";
        public const string NoteMandatory = "Note is mandatory";
        public const string InvalidNewHireTypeId = "Invalid New Hire TypeId";
    }

    public static class BlobServiceValidation
    {
        public const string blobConnectionStringIsEmpty = "Blob Connection string is empty";
    }

    public static class CosmosDbValidation
    {
        public const string CosmosDbConnectionIsEmpty = "CosmosDb Connection string is empty";
    }

    public static class DefaultFieldsValidation
    {
        public const string PersonalEmailAddress = "Personal Email Address";
        public const int FirstNameMaxLength = 50;
        public const int MiddleNameMaxLength = 50;
        public const int LastNameMaxLength = 50;
        public const int EmailAddressMaxLength = 100;
        public const int PhoneNumberLength = 10;
        public const int AddressLine1MaxLength = 100;
        public const int AddressLine2MaxLength = 100;
        public const int ZipCodeMaxLength = 5;
        public const int CityMaxLength = 50;
        public const int SchoolMajorMaxLength = 100;
        public const int SchoolNameMaxLength = 100;
        public const int NotesMaxLength = 500;
        public const int CompanyNameMaxLength = 100;
        public const int JobtitleMaxLength = 100;
        public const int IndustryTypeMaxLength = 100;
        public const int MaxFileLengthBytes = 1048576;
        public const string PhotoAllowedFileFormats = "jpeg,png,jpg";
        public const string ResumeCoverLetterAllowedFileFormats = "doc,docx,pdf";
        public const int DisabilityMaxLength = 500;
    }

    public static class ApplicantInterviewValidation
    {
        public const string JobApplicationIdRequired = "Job Application Id is requried";
        public const string InterviewTypeIdRequired = "Interview TypeId is required.";
        public const string InterviewDateRequired = "Interview Date is required.";
        public const string InvalidInterviewDate = "Date should be greater than or equal to current date";
        public const string StartTimeRequired = "Start Time is requried.";
        public const string EndTimeRequired = "End Time is required.";
        public const string TimeZoneRequired = "Time Zone is required.";
        public const string InterviewerIdRequired = "InterviewerIdRequired is required.";
        public const string MeetingLinkRequired = "Meeting Link is required.";
        public const string LocationTypeisRequried = "Location Type is required";
        public const string Address1 = "Address1 is required.";
        public const int Address1MaxLength = 100;
        public static readonly string Address1MaxLengthExceededMessage = $"Address1 Max Length cannot exceed {Address1MaxLength} characters";
        public const int Address2MaxLength = 200;
        public static readonly string Address2MaxLengthExceededMessage = $"Address2 Max Length cannot exceed {Address2MaxLength} characters";
        public const string CityRequired = "City is required.";
        public const int CityMaxLength = 200;
        public static readonly string CityMaxLengthExceededMessage = $"City Max Length cannot exceed {CityMaxLength} characters";
        public const string StateRequired = "State is required.";
        public const string ZipCodeRequired = "ZipCode is required.";
        public const int ZipCodeMaxLength = 5;
        public static readonly string ZipCodeMaxLengthExceededMessage = $"ZipCode Max Length cannot exceed {ZipCodeMaxLength} characters";
        public const string WorkSiteLocationRequried = "WorkSite Location is required.";
        public const string InvalidJobApplicationId = "Job Application does not Exists";
        public const string InvalidApplicantInterviewId = "Applicant does not Exist";
        public const string NoteRequried = "Please enter valid Notes.";
        public const int NotesMaxLength = 500;
        public static readonly string NotesMaxLengthExceededMessage = "Notes max length cannot exceed " + NotesMaxLength + " characters";
        public const string InterviewTimeValidationErrorMessage = "Please enter valid time";
        public const string InvalidInterviewTimeFormatErrorMessage = "{0} invalid format";
        public const string LocationRequried = "Location is required.";
        public const int LocationMaxLength = 50;
        public static readonly string LocationMaxLengthExceededMessage = $"City Max Length cannot exceed {LocationMaxLength} characters";
        public const string InterviewerIdRequried = "Interviewer Id is required.";
        public const string InterviewerRequried = "Interviewer is required.";
        public const string InterviewDatAndTimeConflict = "{0}, {1} has a scheduled interview for the selected date and time slot.";
    }

    public static class JobApplicationAttachmentValidation
    {
        public const int FileNameMaxLength = 200;
        public const int MaxFileSizeInBytes = 1024 * 1024;
        public const string FileNameRequired = "File name is required.";
        public const string FileNameMaxLengthExceeded = "File name max length exceeded.";
        public const string AttachmentRequired = "File upload is required";
        public const string AttachmentUpdateNoAcess = "Attachment Update is restricted";

        public static readonly ReadOnlyCollection<string> PermittedExtensions = new(
                                                                                    new List<string> { "jpeg", "jpg", "png", "doc", "docx", "pdf", "xls", "xlsx", "ppt", "pptx", "csv", "txt" }
                                                                                    );

        public const string UploadValidFile = "File type is not permitted.";
        public const string FileMaxLengthExceeded = "The uploaded file must be less than or equal to 1 MB.";
        public const string FileTypeRequired = "File type is required.";
        public const string FileAlreadyExist = "File with this name already exist.";
        public const string InvalidAttachmentId = "Invalid attachment Id.";
        public const string JobApplicationRequired = "Job application is required.";
    }

    public static class NewHireCreatedEventValidation
    {
        public const string CompanyNotFound = "Company not found for the code {0}";
        public const string CorrelationIdNotFound = "CorrelationId not found for any Applicant in ATS {0}";
        public const string ApplicantAlreadyHired = "Applicant already hired for Correlation Id {0}";
        public const string EmployeeIdAlreadyExists = "Employee Id {0} already exists for Correlation Id {1}";
        public const string CompanyCodeDifferentForCorrelationId = "Company Code {0} for Correlation Id {1} is different from New Hire event Company Code {2}";
    }

    public static class JobApplicationNoteValidation
    {
        public const string InvalidApplicantInterviewId = "Applicant interview Id not found";
        public const string NoteRequried = "Note is required.";
        public const int NotesMaxLength = 500;
        public static readonly string NotesMaxLengthExceededMessage = $"Notes max length cannot exceed {NotesMaxLength} characters";
        public const string RatingRequried = "Rating is required.";
        public const string JobApplicationNoteNotFound = "Job Application Not found";
        public const string JobApplicationNoteUpdateNoAcess = "Note update is restricted";
        public const string JobApplicationNoteUpdateInvalid = "You cannot add Interview Notes/Feedback until the scheduled interview has taken place";
    }

    public static class OfferExtendedEmailValidation
    {
        public const string OfferLinkExpired = "This link has expired. Please contact your hiring manager for assistance";
        public const string ResponseToApplicant = "Thanks! Your response has been received. We will get in touch with you regarding further updates";
        public const string OfferStatusAlreadyChanged = "You can submit your response only once. Please contact your Hiring Manager for further discussion";
    }

    public static class DomainUserUpdatedEventValidation
    {
        public const string CompanyNotFound = "Company with code {0} not found";
        public const string RoleNotFound = "Role with code {0} not found";
    }

    public static class ApplicantQuizValidation
    {
        public const string DuplicateQuizName = "A quiz with this name already exists.";
        public const string DuplicateAnswers = "Duplicate answer is not allowed";
        public const string DuplicateQuestions = "Duplicate questions are not allowed";
        public const string MinQuestionsRequiredErrorMessage = "You must provide at least one question.";
        public const string MaxQuestionsLimitExceeded = "You cannot add more than 15 questions.";
        public const string QuizNameRequried = "Quiz Name is required.";
        public const string QuizNameMaxLengthErroMessage = "Quiz Name must not exceed 50 characters.";
        public const string MinimumPassingScoreRequriedErrorMessage = "Minimum Passing Score is Required";
        public const string MinimumPassingScoreErrorMessage = "Minimum Passing Score must be between 1 and 100.";
        public const string DescriptionMaxLengthErrorMessage = "Description must not exceed 500 characters.";
        public const string TotalScoreMustMeetOrExceedToMinimumScore = "The total score of all added questions must meet or exceed the minimum passing score for the quiz. Please adjust the question scores or the minimum passing score and try again.";
        public const string QuestionIsRequried = "Question is required.";
        public const string QuestionMaxLengthErrorMEssage = "Question must not exceed 100 characters.";
        public const string TypeIdRequried = "TypeId is Requried";
        public const string ScoreRequried = "Score is Requried";
        public const string ScoreMustBe1To100 = "Score must be between 1 and 100.";
        public const string AtleastTwoAnswersAreRequired = "Please add at least two answer options to save the question.";
        public const string FiveAnswersOnlyAllowed = "You can only add up to five answer options.";
        public const string CorrectAnswerMustBeSelected = "Please select a correct answer before saving the question.";
        public const string AnswerRequried = "Answer is Requried";
        public const string InvalidApplicantQuizId = "Applicant Quiz does not Exist";
        public const string InActiveApplicantQuiz = "The Quiz chosen earlier has become inactive. Please choose another active quiz";
    }

    public static class OfferStatusCountValidation
    {
        public const string FromDateOfferExtendedIsRequired = "From Date is required";
        public const string ToDateOfferExtendedIsRequired = "To Date is required";
        public const string InvalidExtendedDates = "From Offer Extended date {0} is greater than To Offer Extended date {1}";
    }

    public static class InterviewCalendarDateRangeValidation
    {
        public const string ToDateEarlierThanFromDate = "To Date Should not be earlier than from date.";
    }

    public static class CosmosDbErrorMessages
    {
        public const string General = "An error occurred while processing your request: {0}";
        public const string TimeoutException = "Request timeout occurred during {0}";
    }

    public static class UserAuthenticationValidation
    {
        public const string TokenIsRequired = "Token is required";
        public const string AuthorizationHeaderMissing = "Authorization Header missing";
        public const string UserNotFound = "User Id not found for the email {0}";
        public const string InvalidToken = "Invalid Token";
        public const string UserEmailOrCompanyCodeNotFound = "User Email or Company Code not found";
        public const string CompanyCodeInvalidType = "Company Code must be an integer";
        public const string UserCompanyRolesNotFound = "No roles found for the current user {0} and the company {1}";
    }

    public static class CompanyJobBoardValidation
    {
        public const string CompanyJobBoardRequired = "Company Job Board is required.";
        public const string EmailAddressRequired = "Email Address is required.";
        public const string EmailInvalid = "Invalid email address provided";
        public const string CompanyNotIntegratedWithJobBoard = "Company not integrated with {0} Job board";
        public const string CompanyAlreadyIntegratedWithJobBoard = "This job board already exists";
    }
}