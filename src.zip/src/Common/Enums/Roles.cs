﻿namespace BBSI.ATS.Common.Enums;

public enum Roles
{
    HiringManager = 1,
    User = 2,
    CompanyAdmin = 3,
    Interviewer = 4
}