﻿namespace BBSI.ATS.Common.Enums
{
    public enum ApplicationFormSections
    {
        PersonalInformation = 1,
        Address,
        ProfessionalDetails,
        AdditionalDetails,
        EducationHistory,
        WorkHistory,
        VoluntarySelfIdentification
    }
}