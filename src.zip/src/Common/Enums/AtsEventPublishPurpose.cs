﻿namespace BBSI.ATS.Common.Enums
{
    public enum AtsEventPublishTopicPurposes
    {
        SchemaValidation,
        Success
    }
}