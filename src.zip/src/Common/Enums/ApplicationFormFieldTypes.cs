﻿using System.ComponentModel.DataAnnotations;

namespace BBSI.ATS.Common.Enums
{
    public enum ApplicationFormFieldTypes
    {
        Dropdown = 1,

        FileUpload = 2,

        [Display(Name = "Single Line Input")]
        SingleLineInput = 3,

        [Display(Name = "Paragraph Field")]
        ParagraphField = 4,

        DatePicker = 6,

        PhoneNumber = 7,

        EmailAddress = 8,

        RadioButton = 9
    }
}