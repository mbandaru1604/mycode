﻿using System.ComponentModel.DataAnnotations;

namespace BBSI.ATS.Common.Enums
{
    public enum PayGroup
    {
        Annually = 16,

        [Display(Name = "Bi-weekly")]
        Biweekly,

        Monthly,

        [Display(Name = "Semi-Monthly")]
        SemiMonthly,

        Weekly,

        Daily
    }

    public enum PayMethod
    {
        Hourly = 23,
        Salary,
        Commission,
        Driver
    }

    public enum WorkArrangement
    {
        [Display(Name = "Remote")]
        Remote = 27,

        Hybrid,
        Onsite
    }

    public enum LocationType
    {
        WorksiteLocation = 30,
        CustomLocation
    }

    public enum SectionType
    {
        Regular = 91,
        Tabular
    }

    public enum InterviewType
    {
        Phone = 93,

        Video = 94,

        [Display(Name = "In-Person")]
        InPerson = 95
    }

    public enum InterviewStatus
    {
        InterviewScheduled = 96,
        InterviewCompleted = 97,
        InterviewNoShow = 98,
        InterviewCancelled = 99,
    }

    public enum JobApplicationAttachmentType
    {
        Resume = 100,

        [Display(Name = "Cover Letter")]
        CoverLetter,

        Photo,

        Custom,
    }

    public enum States
    {
        ALABAMA = 32,
        ALASKA = 33
    }

    public enum ReceiverType
    {
        Applicant = 109,
        HiringManager,
        Interviewer
    }

    public enum StatusTransitionTriggers
    {
        InitialApplicationStatus = 104,
        InterviewScheduling,
        OfferAcceptance,
        OfferDecline,
        SuccessfulHireEvent
    }

    public enum NotificationTemplateType
    {
        InterviewTypeInPerson = 112,
        InterviewTypePhone,
        InterviewTypeVideo,
        OfferExtendedEmailNotification,
        NotSelected,
        InterviewCancelled,
        InterviewScheduleUpdated,
        OfferAcceptedEmailNotification = 158,
        OfferDeclinedEmailNotification = 159,
        InterviewFeedbackNotificaiton = 160,
        InterviewScheduledInterviewer = 161
    }

    public enum NewHireType
    {
        Electronic = 119,
        Manual,
        PaperOnBoarding
    }

    public enum VoluntarySelfIdentification
    {
        Yes = 122,
        No = 123
    }

    public enum Veteran
    {
        IamaVeteran = 134,
        NotAVeteran = 135,
        IPreferNotToDisclose = 136
    }

    public enum PageName
    {
        [Display(Name = "Application Forms")]
        ApplicationForms = 142,

        [Display(Name = "Add Form/Edit Form")]
        AddFormOrEditForm,

        [Display(Name = "Job Categories")]
        JobCategories,

        [Display(Name = "Job Posts")]
        JobPosts,

        [Display(Name = "Applicant Details")]
        ApplicantDetails
    }

    public enum SectionName
    {
        General = 147,

        AddNewField,

        [Display(Name = "Add")]
        AddCategory,

        SubmittedJobs,

        [Display(Name = "Add")]
        AddJobPost,

        InProgress,

        Application,

        Interviews,

        Attachments,

        Notes,

        ApplicantDetails,

        [Display(Name = "Edit")]
        EditJobPost,

        [Display(Name = "Edit")]
        EditCategory,

        [Display(Name = "Delete")]
        DeleteJobPost
    }

    public enum QuestionType
    {
        MultipleChoice = 154,
        TrueFalse = 155,
    }

    public enum JobBoard
    {
        Indeed = 166
    }
}