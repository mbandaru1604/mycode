﻿namespace BBSI.ATS.Common.Enums
{
    public enum OrderByDirection
    {
        Ascending,
        Descending
    }
}