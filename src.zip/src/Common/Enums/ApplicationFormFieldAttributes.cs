﻿namespace BBSI.ATS.Common.Enums;

public enum ApplicationFormFieldAttributes
{
    MaxLength = 1,
    MaxFileUploadSize,
    TextValue,
    Length,
    AllowedFileFormats
}