﻿namespace BBSI.ATS.Common.Enums;

public enum LookupTypes
{
    /// <summary>
    /// Employee Type
    /// </summary>
    EmployeeType = 1,
    /// <summary>
    /// EEO Class
    /// </summary>
    EEOClass,
    /// <summary>
    /// Pay Group
    /// </summary>
    PayGroup,
    /// <summary>
    /// Pay Method
    /// </summary>
    PayMethod,
    /// <summary>
    /// Work Arrangement
    /// </summary>
    WorkArrangement,
    /// <summary>
    /// Location Type
    /// </summary>
    LocationType,
    /// <summary>
    /// State
    /// </summary>
    State,
    /// <summary>
    /// Education Level
    /// </summary>
    EducationLevel,
    /// <summary>
    /// Section Type
    /// </summary>
    SectionType,
    /// <summary>
    /// Interview Type
    /// </summary>
    InterviewType,
    /// <summary>
    /// Interview Status
    /// </summary>
    InterviewStatus,
    /// <summary>
    /// Job Application Attachment Type
    /// </summary>
    JobApplicationAttachmentType,
    /// <summary>
    /// Job Application Status Transition Trigger
    /// </summary>
    JobApplicationStatusTransitionTrigger,
    /// <summary>
    /// Receiver Type
    /// </summary>
    ReceiverType,
    /// <summary>
    /// Notification Template Type
    /// </summary>
    NotificationTemplateType,
    /// <summary>
    /// Notification Template Type
    /// </summary>
    NewHireType,
    /// <summary>
    /// Voluntary Self Identification
    /// </summary>
    VoluntarySelfIdentification,
    /// <summary>
    /// Gender
    /// </summary>
    Gender,
    /// <summary>
    /// Ethnicity Race
    /// </summary>
    EthnicityRace,
    /// <summary>
    /// Veteran
    /// </summary>
    Veteran,
    /// <summary>
    /// Veteran Status
    /// </summary>
    VeteranStatus,
    /// <summary>
    /// Page Name
    /// </summary>
    PageName,
    /// <summary>
    /// Section Name
    /// </summary>
    SectionName,
    /// <summary>
    /// Question Type
    /// </summary>
    QuestionType,
    /// <summary>
    /// True/False Type
    /// </summary>
    TrueFalse,
    JobBoard
}