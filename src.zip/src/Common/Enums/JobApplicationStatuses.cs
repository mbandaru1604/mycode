﻿namespace BBSI.ATS.Common.Enums;

public enum JobApplicationStatuses
{
    Applied = 1,
    InterviewScheduled = 2,
    NotSelected = 3,
    OfferExtended = 4,
    OfferAccepted = 5,
    OfferDeclined = 6,
    Onboarding = 7,
    Hired = 8
}