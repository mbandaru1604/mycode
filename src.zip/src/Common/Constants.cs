﻿using BBSI.ATS.Common.Enums;
using BBSI.ATS.DTO;
using System.Collections.Immutable;

namespace BBSI.ATS.Common;

public static class Constants
{
    public static class ErrorCodes
    {
        public const string BadRequest = "ATS0400";
        public const string Unauthorized = "ATS0401";
        public const string InternalServerError = "ATS0500";
        public const string ConflictError = "ATS0409";
    }

    public static class TimeZoneConstants
    {
        public const string PST_ZONE = "Pacific Standard Time";
        public const string UTC_ZONE = "UTC";
        public const string DateFormat = "MM/dd/yyyy";
        public const string TimeFormat = "HH:mm tt";
    }

    public static class AtsEventTypes
    {
        public const string CompanyCreated = "DOMAIN_COMPANY_CREATED";
        public const string CompanyUpdated = "DOMAIN_COMPANY_UPDATED";
        public const string WorksiteLocationCreated = "DOMAIN_COMPANY_WORKSITE_LOCATION_CREATED";
        public const string WorksiteLocationUpdated = "DOMAIN_COMPANY_WORKSITE_LOCATION_UPDATED";
        public const string DomainProductEnabledEvent = "DOMAIN_PRODUCT_ENABLED";
        public const string DomainProductEnabledAckEvent = "PIE_PRODUCT_ENABLED_ACK";
        public const string NewHireCreatedEvent = "DOMAIN_NEW_HIRE_CREATED";
        public const string NewHireInitiatedEvent = "PIE_NEW_HIRE_INITIATED";
        public const string DomainUserUpdated = "DOMAIN_USER_UPDATED";
    }

    public static class AtsPublishEventProperties
    {
        public const string EventSource = "ATS";
        public const string EventDestination = "PIE";
        public const int Priority = 1;
        public const double Version = 1.0;
        public const string UserType = "Client";
        public const string TimeZoneFormat = "yyyy-MM-ddTHH:mm:ss.fff";
    }

    public static class PropertyDefaultValues
    {
        public const string WorksiteLocationCountry = "United States";
    }

    public static class LookupConstants
    {
        public static readonly List<NameIdPairDto> WorkArrangements =
        [
            new() { Id = 27, Name = "Remote", Code = "Remote" },
            new() { Id = 28, Name = "Hybrid" },
            new() { Id = 29, Name = "Onsite" }
        ];

        public static readonly List<NameIdPairDto> LocationTypes =
        [
            new() { Id = 30, Name = "Worksite Location" },
            new() { Id = 31, Name = "Custom Location" }
        ];
    }

    public static class ApplicationFormFields
    {
        public const string FirstName = "First Name";
        public const string LastName = "Last Name";
        public const string MiddleName = "Middle Name";
        public const string PresonalEmailAddress = "Personal Email Address";
        public const string HomeTelephoneNumber = "Home Telephone Number";
        public const string MobilePhoneNumber = "Mobile Phone Number";
        public const string AddressLine1 = "Address Line 1";
        public const string AddressLine2 = "Address Line 2";
        public const string ZipCode = "Zip Code";
        public const string City = "City";
        public const string State = "State";
        public const string WhenAreYouAvailableToStartWork = "When are you available to start work?";
        public const string Photo = "Photo";
        public const string Resume = "Resume";
        public const string CoverLetter = "Cover Letter";
        public const string CompanyName = "Company Name";
        public const string JobTitle = "Job Title";
        public const string IndustryType = "Industry Type";
        public const string GraduationYear = "Graduation Year";
        public const string VoluntarySelfIdentification = "Voluntary Self Identification";
        public const string Gender = "Gender";
        public const string EthnicityRace = "Ethnicity Race";
        public const string Veteran = "Veteran";
        public const string VeteranStatus = "Veteran Status";
        public const string Disability = "Disability";
    }

    public static class ApplicationFormSectionWithNames
    {
        public static readonly ImmutableDictionary<ApplicationFormSections, string> Items = ImmutableDictionary.Create<ApplicationFormSections, string>()
            .Add(ApplicationFormSections.EducationHistory, "Education History")
            .Add(ApplicationFormSections.WorkHistory, "Work History");
    }

    public static class CompanyStatusCodes
    {
        public static readonly List<string> StatusCodes = ["C", "T", "A", "I", "p"];
    }

    public static class EventBusSchemaMappings
    {
        private static Dictionary<string, string> _atsEventSchemaNames
          = new()
                  {
                    { AtsEventTypes.CompanyCreated, "CompanySchema.json"},
                    { AtsEventTypes.CompanyUpdated, "CompanySchema.json"},
                    { AtsEventTypes.DomainProductEnabledEvent, "DomainProductEnabledEventSchema.json"},
                    { AtsEventTypes.WorksiteLocationCreated, "LocationSchema.json"},
                    { AtsEventTypes.WorksiteLocationUpdated, "LocationSchema.json"},
                    { AtsEventTypes.NewHireCreatedEvent, "NewHireCreatedSchema.json"},
                    { AtsEventTypes.DomainProductEnabledAckEvent, "ProductEnabledAcknowledgementSchema.json" },
                    { AtsEventTypes.NewHireInitiatedEvent, "NewHireInitiatedEventSchema.json" },
                    {AtsEventTypes.DomainUserUpdated, "DomainUserUpdatedEventSchema.json" }
                  };

        public static Dictionary<string, string> AtsEventSchemaNames
        { get { return _atsEventSchemaNames; } }
    }

    public static class ApplicantInterviewFields
    {
        public const string StartTime = "Start Time";
        public const string EndTime = "End Time";
        public const string DateFormat = "yyyy-MM-dd";
        public const string TimeFormat = "hh:mm tt";
        public const string Location = "Location:";
        public const string MeetingLink = "Meeting Link:";
        public const string PhoneCall = "Phone Call:";
        public const string VirtualMeetingLink = "Virtual Meeting Link:";
        public const string InterviewDateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ";
    }

    public static class JobApplicationDownloadConfig
    {
        public const string JobApplicationTemplate = "JobApplicationTemplate";
        public const string JobApplicationTemplateNamespace = "BBSI.ATS.Common.Templates";
    }

    public static class CustomFields
    {
        public const string CustomUploadFieldName = "Custom";
    }

    public static class JobApplicationNotesStatus
    {
        public const string NotApplicable = "Not Applicable";
    }

    public static class NotificationTemplateConfig
    {
        public const string ApplicantDetailsUri = "completed-applicant/{0}";
        public const string InterviewScheduledInPersonTemplate = "InPersonTemplate";
        public const string InterviewScheduledPhoneTemplate = "PhoneTemplate";
        public const string InterviewScheduledVideoTemplate = "VideoTemplate";

        public const string OfferStatusDetailUri = "jobapplication/applicant/offer/{0}/{1}";
        public const string OfferExtendedEmailTemplate = "OfferExtendedEmailTemplate";
        public const string InterviewCancelledTemplate = "InterviewCancelledTemplate";
        public const string InterviewScheduleUpdated = "InterviewScheduleUpdated";
        public const string NotSelectedTemplate = "NotSelectedTemplate";
    }

    public static class InterviewScheduledNotificationTemplateTypes
    {
        public static Dictionary<long, long> NotificationTypes => new()
        {
            { (long)InterviewType.InPerson, (long)NotificationTemplateType.InterviewTypeInPerson},
            { (long)InterviewType.Phone, (long)NotificationTemplateType.InterviewTypePhone},
            { (long)InterviewType.Video, (long)NotificationTemplateType.InterviewTypeVideo},
            { (long)NotificationTemplateType.OfferExtendedEmailNotification, (long)NotificationTemplateType.OfferExtendedEmailNotification},
            { (long)InterviewStatus.InterviewCancelled, (long)NotificationTemplateType.InterviewCancelled},
            { (long)JobApplicationStatuses.NotSelected, (long)NotificationTemplateType.NotSelected}
        };

        public static Dictionary<long, string> NotificationTemplates => new()
        {
            { (long)InterviewType.InPerson, NotificationTemplateConfig.InterviewScheduledInPersonTemplate },
            { (long)InterviewType.Phone, NotificationTemplateConfig.InterviewScheduledPhoneTemplate },
            { (long)InterviewType.Video, NotificationTemplateConfig.InterviewScheduledVideoTemplate },
            { (long)NotificationTemplateType.OfferExtendedEmailNotification, NotificationTemplateConfig.OfferExtendedEmailTemplate },
            { (long)InterviewStatus.InterviewCancelled, NotificationTemplateConfig.InterviewCancelledTemplate },
            { (long)JobApplicationStatuses.NotSelected, NotificationTemplateConfig.NotSelectedTemplate },
            { (long)NotificationTemplateType.InterviewScheduleUpdated, NotificationTemplateConfig.InterviewScheduleUpdated }
        };
    }

    public static class NewHireInitiatedEventProperties
    {
        public const string PreferredLanguageDefault = "ENG";
    }

    public static class JobApplicationNoteUser
    {
        public const string System = "System";
    }

    public static class JobApplicationConstants
    {
        public const string DateTimeFormat = "MM/dd/yyyy hh:mm:ss tt";
        public const int JobApplicationOfferExtendedHourExpired = 72;
        public const string OfferAccepted = "Accepted";
        public const string OfferRejected = "Rejected";
        public const string QuizResultPassed = "Passed";
        public const string QuizResultFailed = "Failed";
    }

    public static class DomainUserUpdatedEvent
    {
        public const string AtsDomain = "ATS";
    }

    public static class AuditLogConstants
    {
        public const string JobPostCategoryPage = "JobPostCategory";
        public const string JobPostInProgressStatus = "In-Progress";
        public const string JobPostDeleteFieldName = "Delete in In-progress jobs";
        public const string LocationName = "Location name";
        public const string WorkSiteLocation = "Worksite Location";
        public const string SalaryComments = "Salary comments";
        public const string Commission = "Commission";
        public const string AnnualSalaryComments = "Annual Salary Comments";
        public const string Driver = "Driver";
        public const string PayDetails = "Pay Details";
        public const string MaxSalRange = "Annual max salary range";
        public const string Hourly = "Hourly";
        public const string MaxHourlyRate = "Max Hourly Rate";
        public const string AnnualMinSalaryRange = "Annual min salary range";
        public const string MinHourlyRate = "Min Hourly Rate";
        public const string AnnualSalary = "Annual Salary";
        public const string HourlyRate = "Hourly Rate";
        public const string OptOutNotification = "Opt Out of Receiving Emails";
        public const string JobStatus = "Job Status";
        public const string No = "No";
        public const string Active = "Active";
        public const string Description = "Job Description";
        public const string SubmitJobPost = "Submit Job Post";
        public const string SaveJobPost = "Save Job Post";
        public const string Submit = "Submit";
        public const string Save = "Save";
        public const string LocationType = "Location Type";
        public const string Remote = "Remote";

        //DateTime format
        public const string DateTimeFormat = "MM/dd/yyyy hh:mm tt";

        //sort parameters
        public const string SortEventDateTime = "eventDateTime";

        public const string SortIdentifier = "identifier";
        public const string SortUserName = "userName";
        public const string SortPage = "page";
        public const string SortSection = "section";
        public const string SortFieldName = "fieldName";
        public const string SortBeforeValue = "beforeValue";
        public const string SortAfterValue = "afterValue";
    }

    public static class ApplicationFormAudit
    {
        public const string AddPageName = "Add Form";
        public const string EditPageName = "Edit Form";
        public const string FormName = "Form Name";
        public const string FieldDeleted = "Field Deleted";
        public const string AddNewField = "Add New Field";
        public const string AttributeValueAdded = "Attribute Value Added";
        public const string AttributeValueDeleted = "Attribute Value Deleted";
        public const string OptionAdded = "Option Added";
        public const string OptionDeleted = "Option Deleted";
        public const string DropDownOption = "Dropdown Option";
        public const string IsActive = "Active";
        public const string IncludeEducationHistory = "Include Education History";
        public const string IncludeWorkHistory = "Include Work History";
        public const string Section = "Section";
        public const string DisplayOrder = "Display Order";
        public const string IsRequired = "Mandatory";
        public const string FieldType = "Type";
    }

    public static class ApplicantQuizAudit
    {
        public const string AddPageName = "Add Quiz";
        public const string EditPageName = "Edit Quiz";
        public const string QuizName = "Quiz Name";
        public const string Active = "Active";
        public const string Inactive = "Inactive";
        public const string Description = "Description";
        public const string MinimumPassingScore = "Minimum Passing Score";
        public const string AddQuestion = "Add Question";
        public const string EditQuestion = "Edit Question";
        public const string DeleteQuestion = "Delete Question";
        public const string Question = "Question";
        public const string QuestionType = "Question Type";
        public const string Score = "Score";
        public const string Required = "Required";
        public const string Optional = "Optional";
        public const string AddAnswer = "Add Answer";
        public const string EditAnswer = "Edit Answer";
        public const string DeleteAnswer = "Delete Answer";
        public const string Correct = "Correct";
        public const string Incorrect = "Incorrect";
        public const string MultipleChoice = "Multiple Choice";
        public const string TrueOrFalse = "True/False";
    }

    public static class UserPrivileges
    {
        public const string ApplicationFormsListPage = "ApplicationFormsListPage";
        public const string AddForm = "AddForm";
        public const string EditForm = "EditForm";
        public const string ApplicationFormFilters = "ApplicationFormFilters";
        public const string JobCategoryListPage = "JobCategoryListPage";
        public const string AddCategory = "AddCategory";
        public const string EditCategory = "EditCategory";
        public const string DeleteCategory = "DeleteCategory";
        public const string JobCategoryFilters = "JobCategoryFilters";
        public const string JobPostsListPage = "JobPostsListPage";
        public const string AddJobPost = "AddJobPost";
        public const string EditJobPost = "EditJobPost";
        public const string CopyToClipboard = "CopyToClipboard";
        public const string JobPostPreview = "JobPostPreview";
        public const string JobPostFilters = "JobPostFilters";
        public const string PublishJobsToIndeed = "PublishJobsToIndeed";
        public const string ViewAllJobPosts = "ViewAllJobPosts";
        public const string ApplyForJobPosts = "ApplyForJobPosts";
        public const string ApplyForJobPostsFilters = "ApplyForJobPostsFilters";
        public const string ApplicantDetailsListPage = "ApplicantDetailsListPage";
        public const string ApplicantDetailsFilters = "ApplicantDetailsFilters";
        public const string CompletedApplication = "CompletedApplication";
        public const string AbilityToDownloadApplication = "AbilityToDownloadApplication";
        public const string AbilityToPurgeApplicantData = "AbilityToPurgeApplicantData";
        public const string InterviewsListPage = "InterviewsListPage";
        public const string ScheduleInterview = "ScheduleInterview";
        public const string EditScheduledInterview = "EditScheduledInterview";
        public const string CancelScheduledInterview = "CancelScheduledInterview";
        public const string MarkInterviewAsNoShow = "MarkInterviewAsNoShow";
        public const string InterviewNotesFeedback = "InterviewNotesFeedback";
        public const string InterviewEditNotes = "InterviewEditNotes";
        public const string NotesListPage = "NotesListPage";
        public const string ViewNotes = "ViewNotes";
        public const string AddNotes = "AddNotes";
        public const string EditNotes = "EditNotes";
        public const string AttachmentsListPage = "AttachmentsListPage";
        public const string AddAttachments = "AddAttachments";
        public const string DeleteAttachments = "DeleteAttachments";
        public const string ViewAttachments = "ViewAttachments";
        public const string EditAttachments = "EditAttachments";
        public const string ManualChangeStatus = "ManualChangeStatus";
        public const string ViewAuditLog = "ViewAuditLog";
        public const string ExportToCSV = "ExportToCSV";
        public const string AutoLogOffATS = "AutoLogOffATS";
        public const string UniqueURLOnJobBoardForEachCompany = "UniqueURLOnJobBoardForEachCompany";
        public const string ClientNameAndIDAddedToTopOfATSScreens = "ClientNameAndIDAddedToTopOfATSScreens";
        public const string ATSMenu = "ATSMenu";
        public const string AbilityToSwitchCompanies = "AbilityToSwitchCompanies";
        public const string AbilityToMoveBackToPortalFromATS = "AbilityToMoveBackToPortalFromATS";
        public const string ScheduledInterviewCalendar = "ScheduledInterviewCalendar";
        public const string PipelineOverview = "PipelineOverview";
        public const string MetricsSummary = "MetricsSummary";
        public const string MonthlyJobTrend = "MonthlyJobTrend";
        public const string EmailNotificationPreview = "EmailNotificationPreview";
        public const string ApplicationSubmittedEmailtoHiringManagerOptiontoSend = "ApplicationSubmittedEmailtoHiringManagerOptiontoSend";
        public const string InterviewScheduledApplicantEmailNotificationOptiontoSend = "InterviewScheduledApplicantEmailNotificationOptiontoSend";
        public const string InterviewUpdatedEmailNotificationOptiontoSend = "InterviewUpdatedEmailNotificationOptiontoSend";
        public const string InterviewCancelledEmailNotificationOptiontoSend = "InterviewCancelledEmailNotificationOptiontoSend";
        public const string NotSelectedEmailNotificationOptiontoSend = "NotSelectedEmailNotificationOptiontoSend";
        public const string OfferExtendedEmailNotificationOptiontoSend = "OfferExtendedEmailNotificationOptiontoSend";
        public const string ApplicantQuizList = "ApplicantQuizList";
        public const string AddEditQuiz = "AddEditQuiz";
        public const string AddQuestionsAnswers = "AddQuestionsAnswers";
        public const string DeleteQuestionsAnswers = "DeleteQuestionsAnswers";
        public const string EditQuestionsAnswers = "EditQuestionsAnswers";
        public const string CompleteQuiz = "CompleteQuiz";
        public const string ScoreQuiz = "ScoreQuiz";
        public const string ViewQuizResults = "ViewQuizResults";
        public const string JobFeedListPage = "JobFeedListPage";
        public const string AddNewJobFeed = "AddNewJobFeed";
        public const string EmailNotificationToInterviewersOfScheduledInterviewOptionToSend = "EmailNotificationToInterviewersOfScheduledInterviewOptionToSend";
        public const string EmailNotificationToInterviewersOfScheduledInterviewSendEmail = "EmailNotificationToInterviewersOfScheduledInterviewSendEmail";
        public const string EmailNotificationToInterviewersOfScheduledInterviewReceiveEmail = "EmailNotificationToInterviewersOfScheduledInterviewReceiveEmail";
        public const string InterviewFeedbackEmailNotificationToHiringManagerOptionToSend = "InterviewFeedbackEmailNotificationToHiringManagerOptionToSend";
        public const string InterviewFeedbackEmailNotificationToHiringManagerSendEmail = "InterviewFeedbackEmailNotificationToHiringManagerSendEmail";
        public const string InterviewFeedbackEmailNotificationToHiringManagerReceiveEmail = "InterviewFeedbackEmailNotificationToHiringManagerReceiveEmail";
        public const string OfferDeclinedEmailNotificationOptionToSend = "OfferDeclinedEmailNotificationOptionToSend";
        public const string OfferDeclinedEmailNotificationSendEmail = "OfferDeclinedEmailNotificationSendEmail";
        public const string OfferDeclinedEmailNotificationReceiveEmail = "OfferDeclinedEmailNotificationReceiveEmail";
        public const string OfferAcceptedEmailNotificationOptionToSend = "OfferAcceptedEmailNotificationOptionToSend";
        public const string OfferAcceptedEmailNotificationSendEmail = "OfferAcceptedEmailNotificationSendEmail";
        public const string OfferAcceptedEmailNotificationReceiveEmail = "OfferAcceptedEmailNotificationReceiveEmail";
        public const string JobPostExpirationOptionToSend = "JobPostExpirationOptionToSend";
        public const string JobPostExpirationSendEmail = "JobPostExpirationSendEmail";
        public const string JobPostExpirationReceiveEmail = "JobPostExpirationReceiveEmail";
        public const string SSOToATSFromMyBBSIWidget = "SSOToATSFromMyBBSIWidget";
        public const string GenerateUniqueURLforEachCompanysJobBoard = "GenerateUniqueURLforEachCompanysJobBoard";
        public const string UserBellPushNotifications = "UserBellPushNotifications";
        public const string HelpDocumentation = "HelpDocumentation";
        public const string UserProfile = "UserProfile";

        public const string InterviewCalendar = "InterviewCalendar";
        public const string ApplicantStatusOverview = "ApplicantStatusOverview";
        public const string ActiveJobsByCategory = "ActiveJobsByCategory";
        public const string ActiveJobsByLocation = "ActiveJobsByLocation";
        public const string OfferStatusOverview = "OfferStatusOverview";
        public const string JobsByAge = "JobsByAge";
        public const string InterviewerInterviews = "InterviewerInterviews";
    }

    public static class AuditLogs
    {
        public static readonly List<string> MembersToIgnore = [
                                                                "CreatedOn"
                                                                ,"ModifiedOn"
                                                                ,"Version"
                                                                ,"CompanyId"
                                                              ];
    }

    public static class AuditLogList
    {
        public const string PSTTimeZone = "Pacific Standard Time";
        public const string TargetDateFormat = "yyyy-MM-dd";
        public const string PSTZone = "PST";
    }

    public static class ApplicantAuditLog
    {
        public const string ApplicantDetailsPageName = "Applicant Details";
        public const string ApplicantListPageName = "Applicant List";
        public const string ApplicationSection = "Application";
        public const string ApplicantDetailsSection = "Applicant Details";
        public const string InterviewsSection = "Interviews";
        public const string NotesSection = "Notes";
        public const string AttachmentSection = "Attachments";
        public const string AttachmentAddSubSection = "Add Attachment";
        public const string AttachmentDeleteSubSection = "Delete Attachment";
        public const string DownloadAttachmentSubSection = "Download Attachment";

        public const string DownloadApplication = "Download Application";
        public const string ManualStatusChangesDropdown = "Manual status changes dropdown";
        public const string SendEmailManualStatusChange = "Send email while manual transition";
        public const string DynamicStatusChange = "Dynamic status changes";

        public const string AttachmentFileName = "File Name";
        public const string AttachmentFileType = "File Type";
        public const string AttachmentUploadFileName = "Upload File";

        public const string Note = "Note";
        public const string Rating = "Rating";
    }

    public static class ApplicantInterviewAuditLog
    {
        public const string InterviewType = "Type of Interview";
        public const string MeetingLink = "Meeting Link";
        public const string LocationType = "Location Type";
        public const string LocationName = "Location Name";
        public const string Address1 = "Address Line 1";
        public const string Address2 = "Address Line 2";
        public const string City = "City";
        public const string State = "State";
        public const string ZipCode = "ZipCode";
        public const string InterviewDate = "Interview Date";
        public const string StartTime = "Start Time";
        public const string EndTime = "End Time";
        public const string Status = "Status";
        public const string TimeZone = "Time Zone";
    }

    public static class AuthenticationTokenClaimTypes
    {
        public const string UserId = "id";
        public const string TokenId = "tokenId";
        public const string UserEmail = "email";
        public const string CompanyId = "companyId";
        public const string CompanyName = "companyName";
        public const string CompanyCode = "companyCode";
    }

    public static class CustomHttpClient
    {
        public const string Name = "HttpClientWithByPassCertificateCheck";
    }

    public static class ApplicantQuizAnswers
    {
        public const string RequiredAnswersMissing = "Mandatory questions are not attempted";
    }

    public static class CompanyJobBoards
    {
        private static Dictionary<long, string> _indeedPayMethod = new()
        {
            {(int)PayMethod.Hourly, "per hour"},
            {(int)PayMethod.Salary, "per year" },
            {(int)PayMethod.Commission, "per year" }
        };

        private static Dictionary<long, string> _indeedPayGroup = new()
        {
            {(int)PayGroup.Annually, "per year"},
            {(int)PayGroup.Weekly, "per week" },
            {(int)PayGroup.Monthly, "per month" },
            {(int)PayGroup.Biweekly, "per two weeks" },
            {(int)PayGroup.Daily, "per day" },
            {(int)PayGroup.SemiMonthly, "Semi-monthly" }
        };

        public const string Indeed = "Indeed";
        public const string SourceName = "BBSI";
        public const string JobPostDefaultCountry = "USA";

        public static Dictionary<long, string> IndeedPayMethod
        { get { return _indeedPayMethod; } }

        public static Dictionary<long, string> IndeedPayGroup
        { get { return _indeedPayGroup; } }

    }
}