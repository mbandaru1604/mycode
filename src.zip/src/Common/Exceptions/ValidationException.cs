﻿namespace BBSI.ATS.Common.Exceptions
{
    public class ValidationException(string message) : AtsBaseException(message)
    {
    }
}