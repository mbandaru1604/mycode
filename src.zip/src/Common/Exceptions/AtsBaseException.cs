﻿namespace BBSI.ATS.Common.Exceptions;

public abstract class AtsBaseException(string errorMessage) : Exception(errorMessage)
{
    public string? ErrorCode { get; set; }
}