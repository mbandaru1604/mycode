﻿namespace BBSI.ATS.Common.Exceptions;

public class UnauthorizedException(string message) : AtsBaseException(message)
{
}