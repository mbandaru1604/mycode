﻿namespace BBSI.ATS.Common.Exceptions;

public class AtsException(string message) : AtsBaseException(message)
{
}