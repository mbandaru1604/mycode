﻿using System.Text;

namespace BBSI.ATS.Common.Helpers;

public class StringWriterWithEncoding : StringWriter
{
    private readonly Encoding _encoding;

    public StringWriterWithEncoding(Encoding encoding)
    {
        _encoding = encoding;
    }

    public override Encoding Encoding => _encoding;
}