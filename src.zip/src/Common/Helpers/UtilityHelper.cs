﻿using Force.DeepCloner;
using System.Collections;
using System.Globalization;
using System.Text.RegularExpressions;
using static BBSI.ATS.Common.Constants;

namespace BBSI.ATS.Common.Helpers;

public static class UtilityHelper
{
    public static bool IsEmpty(object? value)
    {
        return value switch
        {
            null or DBNull => true,
            Guid guid => guid == Guid.Empty,
            string strValue => string.IsNullOrWhiteSpace(strValue),
            IEnumerable list => !list.Cast<object>().Any(),
            DateTime dateTime => dateTime == default,
            _ => false
        };
    }

    public static bool IsValid(object? value)
    {
        return !IsEmpty(value);
    }

    //https://learn.microsoft.com/en-us/dotnet/standard/base-types/how-to-verify-that-strings-are-in-valid-email-format
    public static bool IsValidEmail(string? email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;

        try
        {
            // Normalize the domain
            email = Regex.Replace(email, "(@)(.+)$", DomainMapper,
                                  RegexOptions.None, TimeSpan.FromMilliseconds(200));

            // Examines the domain part of the email and normalizes it.
            static string DomainMapper(Match match)
            {
                // Use IdnMapping class to convert Unicode domain names.
                var idn = new IdnMapping();

                // Pull out and process domain name (throws ArgumentException on invalid)
                string domainName = idn.GetAscii(match.Groups[2].Value);

                return match.Groups[1].Value + domainName;
            }
        }
        catch (RegexMatchTimeoutException)
        {
            return false;
        }
        catch (ArgumentException)
        {
            return false;
        }

        bool regexValid = false;
        try
        {
            regexValid = Regex.IsMatch(email,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
        }
        catch (RegexMatchTimeoutException)
        {
            regexValid = false;
        }

        if (!regexValid) return false;

        var dotCount = email.Split('@')[1].Count(c => c == '.');
        return dotCount < 3 && !email.EndsWith('.');
    }

    public static bool IsValidCurrencyValue(decimal? currency)
    {
        if (currency != null)
        {
            decimal currencyValue = currency is decimal value ? value : 0m;
            return Math.Round(currencyValue, 2) == currency;
        }
        return true;
    }

    public static string CleanHtmlContent(string content)
    {
        return Regex.Replace(content, @"\r|\n|\t", "", RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(1200));
    }

    public static string StripHTMLContent(string? description)
    {
        if (!string.IsNullOrEmpty(description))
        {
            var cleanedDescription = Regex.Replace(description, "<[a-zA-Z/].*?>", String.Empty, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(1200));
            return string.IsNullOrEmpty(cleanedDescription) ? string.Empty : cleanedDescription.Replace("&nbsp;", string.Empty);
        }
        return string.Empty;
    }

    public static DateTime ConvertPstDateToUtc(DateOnly date)
    {
        TimeZoneInfo pacificZone = TimeZoneInfo.FindSystemTimeZoneById(AuditLogList.PSTTimeZone);
        return TimeZoneInfo.ConvertTimeToUtc(date.ToDateTime(TimeOnly.MinValue), pacificZone);
    }

    public static string ConvertUtcDateToPst(DateTimeOffset? eventDateTime)
    {
        TimeZoneInfo pstZone = TimeZoneInfo.FindSystemTimeZoneById(AuditLogList.PSTTimeZone);
        if (eventDateTime.HasValue)
        {
            DateTimeOffset eventPstDateTime = TimeZoneInfo.ConvertTimeFromUtc(eventDateTime.Value.DateTime, pstZone);
            return eventPstDateTime.ToString(AuditLogConstants.DateTimeFormat);
        }

        return string.Empty;
    }
    public static string ConvertUtcDate(DateTimeOffset? eventDateTime, string timeZone)
    {
        TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
        if (eventDateTime.HasValue)
        {
            DateTimeOffset convertedDateTime = TimeZoneInfo.ConvertTimeFromUtc(eventDateTime.Value.DateTime, timeZoneInfo);
            return convertedDateTime.ToString(AuditLogConstants.DateTimeFormat);
        }

        return string.Empty;
    }

    public static string GetMonthNameByNumber(int monthNumber)
    {
        if (monthNumber < 1 || monthNumber > 12) return string.Empty;
        var date = new DateTime(DateTime.Now.Year, monthNumber, 1, 0, 0, 0, DateTimeKind.Utc);
        return date.ToString("MMM");
    }

    public static string ConvertDateToISO8601Format(DateOnly? date)
    {
        return date.HasValue ? date.Value.ToString("yyyy-MM-dd") : string.Empty;
    }
    public static string ConvertDateToISO8601Format(DateTimeOffset? date)
    {
        return date.HasValue ? date.Value.ToString("yyyy-MM-ddTHH:mm:ssZ") : string.Empty;
    }
    public static string FormatPhoneNumber(string phoneNumber)
    {
        // Remove non-numeric characters
        string cleanedNumber = Regex.Replace(phoneNumber, @"\D", "", RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(1200));

        // Check if the number has 10 digits
        if (cleanedNumber.Length == 10)
        {
            return string.Format("{0:(###)###-####}", long.Parse(cleanedNumber));
        }
        else
        {
            // If the number doesn't have 10 digits, return the cleaned number as is
            return cleanedNumber;
        }
    }

    public static T Clone<T>(this T obj) where T : class, new()
    {
        return obj.DeepClone();
    }
}