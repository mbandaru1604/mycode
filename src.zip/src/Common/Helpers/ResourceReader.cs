﻿using System.Diagnostics.CodeAnalysis;
using System.Reflection;

namespace BBSI.ATS.Common.Helpers;

[ExcludeFromCodeCoverage]
public static class ResourceReader
{
    public static IDictionary<string, string> ReadEmbeddedResource(Assembly assembly, string resourcesFolder)
    {
        var resourceNames = assembly.GetManifestResourceNames();
        var jsonResourcesWithContent = new Dictionary<string, string>();

        foreach (var resourceName in resourceNames)
        {
            if (resourceName.StartsWith(resourcesFolder))
            {
                using var stream = assembly.GetManifestResourceStream(resourceName);
                if (stream != null)
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        string content = reader.ReadToEnd();
                        jsonResourcesWithContent.Add(resourceName, content);
                    }
                }
            }
        }
        return jsonResourcesWithContent;
    }
}