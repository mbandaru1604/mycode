﻿using static BBSI.ATS.Common.Constants;

namespace BBSI.ATS.Common.Helpers;

public static class DateUtils
{
    /// <summary>
    /// Formats a DateTime object to a string representation using the specified pattern.
    /// </summary>
    /// <param name="date">The DateTime object to format.</param>
    /// <param name="pattern">The format pattern to use.</param>
    /// <returns>A string representation of the formatted DateTime.</returns>
    public static string FormatTo(DateTime date, string pattern)
    {
        return date.ToString(pattern);
    }

    /// <summary>
    /// Checks if a date falls on the same day or in the future compared to a target day.
    /// </summary>
    /// <param name="targetDay">The target date to compare against.</param>
    /// <param name="dateToTest">The date to test.</param>
    /// <returns>True if the date is the same day or in the future, otherwise false.</returns>
    public static bool IsSameOrFutureDay(DateTime targetDay, DateTime dateToTest)
    {
        return dateToTest.Date >= targetDay.Date;
    }

    /// <summary>
    /// Checks if a date falls on the same day or in the past compared to a target day.
    /// </summary>
    /// <param name="targetDay">The target date to compare against.</param>
    /// <param name="dateToTest">The date to test.</param>
    /// <returns>True if the date is the same day or in the past, otherwise false.</returns>
    public static bool IsSameOrPastDay(DateTime targetDay, DateTime dateToTest)
    {
        return dateToTest.Date <= targetDay.Date;
    }

    /// <summary>
    /// Checks if a DateTime object represents a future point in time compared to a target DateTime.
    /// </summary>
    /// <param name="targetDateTime">The target DateTime to compare against.</param>
    /// <param name="dateTimeToTest">The DateTime to test.</param>
    /// <returns>True if the DateTime is in the future, otherwise false.</returns>
    public static bool IsFutureDateTime(DateTime targetDateTime, DateTime dateTimeToTest)
    {
        return dateTimeToTest > targetDateTime;
    }

    /// <summary>
    /// Checks if a DateTime object represents a past point in time compared to a target DateTime.
    /// </summary>
    /// <param name="targetDateTime">The target DateTime to compare against.</param>
    /// <param name="dateTimeToTest">The DateTime to test.</param>
    /// <returns>True if the DateTime is in the past, otherwise false.</returns>
    public static bool IsPastDateTime(DateTime targetDateTime, DateTime dateTimeToTest)
    {
        return dateTimeToTest < targetDateTime;
    }

    /// <summary>
    /// Gets the current DateTime in Pacific Standard Time (PST).
    /// </summary>
    /// <returns>The current DateTime in PST.</returns>
    public static DateTime GetCurrentPSTDateTime()
    {
        var timeZone = TimeZoneInfo.FindSystemTimeZoneById(TimeZoneConstants.PST_ZONE);
        return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZone);
    }

    /// <summary>
    /// Converts a DateTime from the server's local time zone to Pacific Standard Time (PST).
    /// </summary>
    /// <param name="dateTime">The DateTime to convert.</param>
    /// <returns>The DateTime converted to PST.</returns>
    public static DateTime GetPSTDateTime(DateTime dateTime)
    {
        var systemTimeZone = TimeZoneInfo.Local;
        TimeZoneInfo pstTimeZone = TimeZoneInfo.FindSystemTimeZoneById(TimeZoneConstants.PST_ZONE);
        return TimeZoneInfo.ConvertTime(dateTime, systemTimeZone, pstTimeZone);
    }

    /// <summary>
    /// Converts a DateTime to the number of milliseconds since the Unix epoch (January 1, 1970 UTC).
    /// </summary>
    /// <param name="dateTime">The DateTime to convert.</param>
    /// <returns>The number of milliseconds since the Unix epoch.</returns>
    public static long DateTimeToEpochMillis(DateTime dateTime)
    {
        DateTimeOffset dateTimeOffset = dateTime.ToUniversalTime();
        return dateTimeOffset.ToUnixTimeMilliseconds();
    }

    /// <summary>
    /// Converts a DateTime to Pacific Standard Time (PST) based on the server's local time zone.
    /// </summary>
    /// <param name="dateTime">The DateTime to convert.</param>
    /// <returns>The DateTime converted to PST.</returns>
    public static DateTime ToPSTDateTime(this DateTime dateTime)
    {
        return GetPSTDateTime(dateTime);
    }

    /// <summary>
    /// Converts a DateTime to the number of milliseconds since the Unix epoch (January 1, 1970 UTC).
    /// </summary>
    /// <param name="dateTime">The DateTime to convert.</param>
    /// <returns>The number of milliseconds since the Unix epoch.</returns>
    public static long ToEpochMillis(this DateTime dateTime)
    {
        return DateTimeToEpochMillis(dateTime);
    } 
}