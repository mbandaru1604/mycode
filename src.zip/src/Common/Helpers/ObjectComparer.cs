﻿using BBSI.ATS.DTO;
using KellermanSoftware.CompareNetObjects;
using static BBSI.ATS.Common.Constants;

namespace BBSI.ATS.Common.Helpers
{
    public static class ObjectComparer
    {
        public static List<AuditLogItemField> Compare<T>(T obj1, T obj2)
        {
            var comparer = new CompareLogic();
            comparer.Config.MaxDifferences = Int32.MaxValue;
            comparer.Config.MembersToIgnore = AuditLogs.MembersToIgnore;

            var comparisonResult = comparer.Compare(obj1, obj2);
            var fieldDifferences = new List<AuditLogItemField>();

            if (!comparisonResult.AreEqual)
            {
                foreach (var difference in comparisonResult.Differences)
                {
                    fieldDifferences.Add(new AuditLogItemField
                    {
                        FieldName = difference.PropertyName,
                        BeforeValue = GetFieldValue(difference.Object1Value.Trim()),
                        AfterValue = GetFieldValue(difference.Object2Value.Trim())
                    });
                }
            }

            return fieldDifferences;
        }

        private static string GetFieldValue(string value)
        {
            return (value == "(null)") ? string.Empty : value;
        }
    }
}