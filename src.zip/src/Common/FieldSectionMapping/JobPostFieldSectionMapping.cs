﻿using BBSI.ATS.DTO;

namespace BBSI.ATS.Common;

public static class JobPostFieldSectionMapping
{
    public static Dictionary<string, (string PageName, string SectionName, string FieldName)> Mappings => new()
    {
        { nameof(JobPostAuditDto.Title),( "Job Post","{0} Job Post",  "Job Title") },
        { nameof(JobPostAuditDto.Description),( "Job Post","{0} Job Post",  "Job Description") },
        { nameof(JobPostAuditDto.Category),( "Job Post","{0} Job Post",  "Job Category") },
        { nameof(JobPostAuditDto.EmployeeType),( "Job Post","{0} Job Post",  "Employee Type") },
        { nameof(JobPostAuditDto.WorkArrangement),( "Job Post","{0} Job Post",  "Work Arrangement") },
        { nameof(JobPostAuditDto.LocationType),( "Job Post","{0} Job Post",  "Location Type") },
        { nameof(JobPostAuditDto.WorksiteLocationId),( "Job Post","{0} Job Post",  "Worksite Location") },
        { nameof(JobPostAuditDto.Location),( "Job Post","{0} Job Post",  "Location name") },
        { nameof(JobPostAuditDto.City),( "Job Post","{0} Job Post",  "City") },
        { nameof(JobPostAuditDto.State),( "Job Post","{0} Job Post",  "State") },
        { nameof(JobPostAuditDto.Country),( "Job Post","{0} Job Post",  "Country") },
        { nameof(JobPostAuditDto.HiringManager),( "Job Post","{0} Job Post",  "Hiring Manager") },
        { nameof(JobPostAuditDto.CCEmailAddresses),( "Job Post","{0} Job Post",  "CC On Job Application Notifications") },
        { nameof(JobPostAuditDto.StartDate),( "Job Post","{0} Job Post",  "Job Post Start Date") },
        { nameof(JobPostAuditDto.EndDate),( "Job Post","{0} Job Post",  "Job Post End Date") },
        { nameof(JobPostAuditDto.EEOClass),( "Job Post","{0} Job Post",  "EEO Class") },
        { nameof(JobPostAuditDto.PayGroup),( "Job Post","{0} Job Post",  "Pay Group") },
        { nameof(JobPostAuditDto.PayMethod),( "Job Post","{0} Job Post",  "Pay Method") },
        { nameof(JobPostAuditDto.MaxSalary),( "Job Post","{0} Job Post",  "Annual max salary range") },
        { nameof(JobPostAuditDto.MinSalary),( "Job Post","{0} Job Post",  "Annual min salary range") },
        { nameof(JobPostAuditDto.Salary),( "Job Post","{0} Job Post",  "Annual Salary") },
        { nameof(JobPostAuditDto.SalaryComments),( "Job Post","{0} Job Post",  "Salary comments") },
        { nameof(JobPostAuditDto.ApplicationForm),( "Job Post","{0} Job Post",  "Job Application Form") },
        { nameof(JobPostAuditDto.Status),( "Job Post","{0} Job Post",  "Job Status") },
        { nameof(JobPostAuditDto.OptOutNotification),( "Job Post","{0} Job Post",  "Opt Out of Receiving Emails") },
        { nameof(JobPostAuditDto.IsSubmitted),( "Job Post","{0} Job Post",  "Save") },
        { nameof(JobPostAuditDto.Quiz),( "Job Post","{0} Job Post",  "Quiz") },
    };
}