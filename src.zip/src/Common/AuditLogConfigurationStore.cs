﻿using BBSI.ATS.Common.Enums;

namespace BBSI.ATS.Common;

public static class AuditLogConfigurationStore
{
    public static Dictionary<string, (string PageName, string SectionName, string FieldName)> Configurations =>
        new()
        {
            { "JobCategories.Name", (PageName.JobCategories.ToString(),   "{0} Category", "Name") },
            { "JobCategories.IsActive", (PageName.JobCategories.ToString(),   "{0} Category", "IsActive") },
            { "JobCategories.IsDeleted", (PageName.JobCategories.ToString(),   "{0} Category", "IsDeleted") },
        };


    public static (string PageName, string SectionName, string FieldName)? GetConfiguration(string entityName, string propertyName)
    {
        string key = $"{entityName}.{propertyName}";
        if (Configurations.TryGetValue(key, out var config))
        {
            return config;
        }
        return null;
    }

}