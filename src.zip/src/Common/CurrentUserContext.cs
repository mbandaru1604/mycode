﻿namespace BBSI.ATS.Common;

public class CurrentUserContext
{
    public long UserId { get; set; }
    public long CompanyId { get; set; }
    public int CompanyCode { get; set; }
    public string? UserEmail { get; set; }
    public string? TokenId { get; set; }

    public IDictionary<string, string>? Claims { get; set; }
    public List<long>? RoleIds { get; set; }
    public Pagination? Pagination { get; set; }
}