﻿namespace BBSI.ATS.Common;

public class Pagination
{
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int PageCount { get; set; }
}